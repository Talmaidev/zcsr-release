#ifndef ZCSR_GL_RENDER_LIGHT2D_EXT_H
#define ZCSR_GL_RENDER_LIGHT2D_EXT_H

/*
 * Additive renderer contract required by modules/light2d/light2d.c.
 * These declarations are new APIs, not claims about the current repository.
 * Implement them inside modules/glrender and expose this header through the
 * normal include/zcsr contract boundary. No platform GL header is exposed.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "zcsr/gl_render.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef uint32_t zcsr_gl_l2d_target;
#define ZCSR_GL_L2D_TARGET_INVALID ((zcsr_gl_l2d_target)0)

typedef enum zcsr_gl_l2d_format {
    ZCSR_GL_L2D_FORMAT_RGBA8 = 1,
    ZCSR_GL_L2D_FORMAT_RGBA16F = 2,
    ZCSR_GL_L2D_FORMAT_SRGB8_ALPHA8 = 3
} zcsr_gl_l2d_format;

typedef enum zcsr_gl_l2d_program {
    ZCSR_GL_L2D_PROGRAM_RADIAL = 0,
    ZCSR_GL_L2D_PROGRAM_DEFERRED = 1,
    /* Composite variant: 9-tap brightness-gated bloom of the light and
     * emissive buffers before the same tonemap (u_LightRes = light-buffer
     * size must be set while this program is bound). */
    ZCSR_GL_L2D_PROGRAM_DEFERRED_BLOOM = 2
} zcsr_gl_l2d_program;

typedef enum zcsr_gl_l2d_blend_mode {
    ZCSR_GL_L2D_BLEND_OPAQUE = 0,
    ZCSR_GL_L2D_BLEND_ADDITIVE = 1
} zcsr_gl_l2d_blend_mode;

/* Unified frame display-transfer control. This regenerates the LUT applied
 * once by zcsr_gl_present/read_rgba after both Path A and Path B have written
 * linear values into the RGBA16F frame. Input decode is a closed contract:
 * DISPLAY textures are stored as sRGB8 and hardware-decoded; SRGB uses the
 * sRGB sampler; LINEAR is verbatim; DISPLAY tints/flat colors use the built-in
 * sRGB decoder. A custom descriptor's to_linear half MUST match the built-in
 * sRGB decoder. The setter validates this and rejects a mismatched pipeline.
 * Only the output curve (to_display) is replaceable. Use the legacy
 * zcsr_gl_set_color_pipeline only for compatibility with old code; its name
 * overstates its scope. The descriptor is borrowed, not copied: it must remain
 * valid until the renderer is destroyed. */
bool zcsr_gl_l2d_set_color_pipeline(zcsr_gl_renderer* renderer,
                                    const zcsr_color_pipeline_desc* pipeline);
const zcsr_color_pipeline_desc* zcsr_gl_l2d_get_color_pipeline(
    const zcsr_gl_renderer* renderer);

/* Post-process hook: called after the composite shader has written the
 * tonemapped LINEAR result to the engine-owned composite FBO. The callback
 * receives the composite texture (already bound to texture unit 9), the
 * frame dimensions, and the game userdata. The callback must bind its own
 * shader and draw a fullscreen quad into the linear frame target; it must not
 * display-encode. The engine blits the result into the linear frame after the
 * callback returns; zcsr_gl_present/read_rgba performs the single encode.
 * GL state (program, VAO, blend, active texture) is restored by the engine
 * after the callback. The composite texture must not be deleted or re-bound
 * by the callback. Returns true on success; false aborts the frame and blits
 * the raw composite texture instead. Not called from any thread other than the
 * render thread. */
typedef struct zcsr_gl_renderer zcsr_gl_renderer;
typedef bool (*zcsr_l2d_post_process_fn)(zcsr_gl_renderer* renderer,
                                         unsigned int composite_tex,
                                         int width,
                                         int height,
                                         void* userdata);

/* Register (or clear with NULL) the post-process hook. The hook is invoked
 * every frame after composite. Setting a new hook replaces the previous
 * one; the engine does not retain the userdata after a NULL set. */
bool zcsr_gl_l2d_set_post_process_hook(zcsr_gl_renderer* renderer,
                                       zcsr_l2d_post_process_fn callback,
                                       void* userdata);

/* Save/restore all renderer state touched by this extension: target, viewport,
 * scissor, active program, texture bindings and blend state. The stack is
 * renderer-owned; implementations must fail cleanly if it has no capacity. */
bool zcsr_gl_l2d_state_push(zcsr_gl_renderer* renderer);
bool zcsr_gl_l2d_state_pop(zcsr_gl_renderer* renderer);

/* Create/destroy/resize an MRT target. Resize must be transactional. The
 * attachments are a closed contract, not a caller-defined menu:
 *   formats[0..3] must be exactly
 *   RGBA16F, RGBA16F, RGBA8, RGBA16F
 *   (Albedo, Position, Normal, Emissive) and attachment_count must be 4.
 * Any other count/format is rejected before GL allocation so the composite
 * can never sample a mismatched G0. */
bool zcsr_gl_l2d_target_create(zcsr_gl_renderer* renderer,
                               int width,
                               int height,
                               const zcsr_gl_l2d_format* formats,
                               size_t attachment_count,
                               zcsr_gl_l2d_target* out_target);
bool zcsr_gl_l2d_target_resize(zcsr_gl_renderer* renderer,
                               zcsr_gl_l2d_target target,
                               int width,
                               int height);
void zcsr_gl_l2d_target_destroy(zcsr_gl_renderer* renderer,
                                zcsr_gl_l2d_target target);

/* Bind and clear the G-buffer. Clear values must encode an empty albedo and
 * emissive as zero, position as a FAR sentinel (air receives no light — the
 * reference engine clears its view-space position channel to zfar), and the
 * 2D neutral normal as (0.5,0.5).
 * Geometry output layout: location 0 Albedo RGBA16F (linear-light values
 * written verbatim; the composite samples them without an implicit decode);
 * location 1 Position RGBA16F
 * with xyz in WORLD 3D coordinates (x,y ground plane, z elevation; painter
 * converts its pixel-space geometry through the camera); location 2 Normal
 * RGBA8 with xy encoded from [-1,+1] to [0,1] ((0,0) decodes to the UP
 * normal, other values to in-plane wall normals); location 3 Emissive RGBA16F. */
bool zcsr_gl_l2d_gbuffer_begin(zcsr_gl_renderer* renderer,
                               zcsr_gl_l2d_target target,
                               int width,
                               int height);
/* True only when the current GL framebuffer is one of this renderer's
 * Light2D targets and that target has the exact four-attachment contract:
 * Albedo RGBA16F, Position RGBA16F, Normal RGBA8, Emissive RGBA16F. Used by
 * zcsr_gl_l2d_geo_begin to reject LIT submission into the default framebuffer
 * instead of silently drawing geometry into the wrong target. */
bool zcsr_gl_l2d_gbuffer_is_bound(zcsr_gl_renderer* renderer);
/* Bind the unified linear frame target as the composite output. The name is
 * historical: there is no direct-to-default Light2D output anymore. The
 * composite writes linear values; zcsr_gl_present/read_rgba encodes once. */
bool zcsr_gl_l2d_bind_default_target(zcsr_gl_renderer* renderer,
                                    int width,
                                    int height);

/* Bind the engine-owned composite FBO as the render target. The composite
 * shader writes LINEAR tonemapped values here; the FBO is RGBA16F. Used
 * internally by modules/light2d before the deferred/bloom draw. */
bool zcsr_gl_l2d_bind_composite_target(zcsr_gl_renderer* renderer,
                                       int width,
                                       int height);

/* After the composite shader has drawn to the composite FBO, run the
 * registered post-process hook (if any) and write the result into the
 * unified linear frame target. Without a hook the composite FBO is blitted
 * directly. Display encoding happens later, once, in present/read_rgba.
 * Called by modules/light2d at the end of a HIGH frame. */
bool zcsr_gl_l2d_finalize_composite(zcsr_gl_renderer* renderer,
                                    int width,
                                    int height);
bool zcsr_gl_l2d_bind_target_textures(zcsr_gl_renderer* renderer,
                                      zcsr_gl_l2d_target target,
                                      int first_texture_unit);

/* These program IDs select renderer-managed programs compiled from
 * shaders/light2d_low.frag and shaders/light2d.frag plus the renderer's
 * compatible fullscreen/quad vertex shader. */
bool zcsr_gl_l2d_set_program(zcsr_gl_renderer* renderer,
                             zcsr_gl_l2d_program program);
bool zcsr_gl_l2d_uniform_1f(zcsr_gl_renderer* renderer,
                            const char* name, float x);
bool zcsr_gl_l2d_uniform_2f(zcsr_gl_renderer* renderer,
                            const char* name, float x, float y);
bool zcsr_gl_l2d_uniform_3f(zcsr_gl_renderer* renderer,
                            const char* name, float x, float y, float z);
bool zcsr_gl_l2d_uniform_4f(zcsr_gl_renderer* renderer,
                            const char* name, float x, float y,
                            float z, float w);
bool zcsr_gl_l2d_uniform_1i(zcsr_gl_renderer* renderer,
                            const char* name, int value);
bool zcsr_gl_l2d_uniform_vec4_array(zcsr_gl_renderer* renderer,
                                    const char* name,
                                    const float* values,
                                    size_t vec4_count);
bool zcsr_gl_l2d_set_blend_mode(zcsr_gl_renderer* renderer,
                                zcsr_gl_l2d_blend_mode mode);
bool zcsr_gl_l2d_draw_fullscreen_quad(zcsr_gl_renderer* renderer);
/* Draw screen-space rect with UV [0,1] in the renderer's normal 2D convention. */
bool zcsr_gl_l2d_draw_quad(zcsr_gl_renderer* renderer,
                           float x, float y, float width, float height);

/* ---- Light2d v2 passes (JoyECS-style shadow mask + light accumulation) ---------------
 * Sequence per frame inside end_lighting:
 *   for each shadow-casting light:
 *     shadow_begin(...) -> shadow_edge(...)/shadow_fill(...) per occluder
 *     -> shadow_end()
 *   lightbuf_begin(...) -> light_emit(...) per light -> lightbuf_end()
 *   then bind_default_target + bind_target_textures + deferred composite.
 * shadow_begin clears the R mask to 0 and MAX-blends the occluder geometry:
 * point lights extrude selected edges radially away from (src_x, src_y);
 * parallel lights extrude along the fixed unit direction (dir_x, dir_y);
 * distance_px bounds the extrusion (finite wall-style bands), reverse edges
 * extrude toward the light instead. shadow_fill covers a convex polygon
 * itself (self-shadow), no extrusion. lightbuf_begin clears the RGBA16F
 * accumulation target; light_emit adds per light: POINT = one radial falloff
 * quad pow(1-r/R,decay) * 1/(dist3/DIST_SCALE+1); PARALLEL = fullscreen, no
 * falloff, direction-driven. Both are multiplied by the PURE max(0, N.L3)
 * term (optional), (1 - shadow) and gain. N.L3 uses the world light position
 * elevated by `height` (point) or the fixed direction (parallel); the neutral
 * G-buffer normal (0,0) decodes to the up normal (0,0,1), any other value to
 * an in-plane wall normal. Samples the G-buffer normal (unit 6) and that
 * light's shadow mask (unit 8, 5-tap MAX dilate). */
bool zcsr_gl_l2d_shadow_begin(zcsr_gl_renderer* renderer,
                              int mask_w, int mask_h,
                              int view_w, int view_h,
                              float src_x, float src_y,
                              float dir_x, float dir_y,
                              float distance_px,
                              int parallel);
bool zcsr_gl_l2d_shadow_edge(zcsr_gl_renderer* renderer,
                             float ax, float ay, float bx, float by,
                             float factor, int reverse, float distance_px);
bool zcsr_gl_l2d_shadow_fill(zcsr_gl_renderer* renderer,
                             const float* xy_px, size_t count, float factor);
bool zcsr_gl_l2d_shadow_end(zcsr_gl_renderer* renderer);

/* px_per_unit is the camera zoom (pixels per world unit): the accumulation
 * quads are sized in pixels from world-unit light radii through it. */
bool zcsr_gl_l2d_lightbuf_begin(zcsr_gl_renderer* renderer,
                                int buf_w, int buf_h,
                                int view_w, int view_h,
                                float gain, float dist_scale,
                                float px_per_unit,
                                int normals_on);
/* One accumulated light. quad_x/quad_y = the light center in SCREEN pixels
 * (caller projects through its camera, point lights only); wx/wy/height and
 * radius/decay are WORLD units. parallel != 0 switches to the reference
 * engine's parallel light: no falloff, fullscreen coverage, the normalized
 * 3D travel direction (dir_x, dir_y, dir_z) drives both N.L and the shadow
 * extrusion; radius/decay/position are ignored there. cr/cg/cb should
 * already carry the per-light intensity (color * a). The N.L term is the
 * reference engine's PURE max(0, dot) in 3D: up-facing surfaces (neutral
 * G-buffer normal) are lit only through the light's elevation/direction's z,
 * in-plane wall normals are struck full-strength by horizontal rays. The
 * shadow mask is sampled with a 5-tap MAX dilate. */
typedef struct zcsr_gl_l2d_light_draw {
    float quad_x, quad_y;
    float wx, wy, height;
    float radius, decay;
    float dir_x, dir_y, dir_z;
    float inner_angle, outer_angle;
    int   parallel;
    int   spot;
    float cr, cg, cb;
    int   use_shadow;
} zcsr_gl_l2d_light_draw;

bool zcsr_gl_l2d_light_emit(zcsr_gl_renderer* renderer,
                            const zcsr_gl_l2d_light_draw* light);
bool zcsr_gl_l2d_lightbuf_end(zcsr_gl_renderer* renderer);

/* Binds the light accumulation texture on the unit right after the G-buffer block
 * (composite sampler u_Light). */
bool zcsr_gl_l2d_bind_light_texture(zcsr_gl_renderer* renderer,
                                    int texture_unit);

/* 设置 composite 目标的多采样数（0=关，2/4/8）。上下文不支持时返回 false，
 * 调用方必须保留“未生效”，不能假装打开。下次 bind 时按新尺寸/采样数重建。 */
bool zcsr_gl_l2d_set_msaa(zcsr_gl_renderer* renderer, int samples);

#ifdef __cplusplus
}
#endif
#endif
