#ifndef ZCSR_GL_RENDER_H
#define ZCSR_GL_RENDER_H
/* GPU rendering — the only runtime 2D renderer.
 * Desktop: OpenGL 3.3 Core. Android: OpenGL ES 3.x.
 *
 * There is no CPU/software runtime fallback and modules/render no longer
 * exists. If zcsr_gl_create fails, the caller has no renderer; use the offline
 * image module for baking, not as a fallback. Implementer: modules/glrender
 * (vendors glad; glad used ONLY inside that module). Includes only shared
 * contracts. No runtime heap: renderer state lives in a caller buffer; GPU
 * memory is the driver's.
 *
 * Two paths share this one backend and one linear working space:
 *   A. screen-space sprites/instances/UI — decoded to linear, painter order.
 *   B. Light2D G-buffer (RGBA16F linear albedo) + deferred composite — linear
 *      light, linear composite.
 * Both write into one RGBA16F linear frame target; zcsr_gl_present/read_rgba
 * applies the color-pipeline LUT exactly once and writes display-encoded RGBA8.
 * There is no per-path display encode. See docs/RENDER2D_CONTRACT.md. */
#include "platform.h"       /* zcsr_surface */
#include "sprite.h"         /* zcsr_rectf */
#include "color.h"          /* zcsr_color_mode */
#include "color_pipeline.h" /* replaceable display-transfer descriptor */
#include "texture_atlas.h"  /* zcsr_atlas_region */
#include "render_tier.h"    /* zcsr_instance_compact, layout tier macros */
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

typedef struct zcsr_gl_renderer zcsr_gl_renderer; /* opaque; instance-owned */
typedef uint32_t zcsr_gl_texture;                 /* GPU texture handle; 0 = invalid */

/* Create a GL 3.3 Core context on the surface (Win32 wgl / X11 GLX / Cocoa NSOpenGL) and the
 * renderer state inside the caller buffer. NULL on failure / buffer too small.
 *
 * The renderer is large: the fixed vertex batch and the per-tier instance staging
 * array dominate it. The bundled tests/tools/Android host reserve a 16 MiB
 * static/arena pool; the layout is opaque and is never heap-allocated, so an
 * oversized static/arena buffer is the intended usage. */
zcsr_gl_renderer* zcsr_gl_create(zcsr_surface* surface, void* buffer, size_t bytes);
void              zcsr_gl_destroy(zcsr_gl_renderer*);

/* Renderer backend selection. Only GPU is a usable runtime in 1.0; CPU is a
 * reserved backend interface, not a second software rasterizer. A caller may
 * ask for CPU and get NULL with a diagnostic, but it must not silently replace
 * GPU output with a different-looking LDR path. Both backends, when they
 * exist, own the same RGBA16F linear frame and the same final LUT encode. */
typedef enum {
    ZCSR_RENDER_BACKEND_GPU = 1,
    ZCSR_RENDER_BACKEND_CPU = 2
} zcsr_render_backend;

bool zcsr_render_backend_available(zcsr_render_backend backend);
zcsr_gl_renderer* zcsr_gl_create_with_backend(zcsr_surface* surface, void* buffer,
                                               size_t bytes, zcsr_render_backend backend);

/* Runtime GPU identity. This is diagnostics only: Intel and AMD integrated GPUs
 * both take the same GL 3.3 Core path, and no renderer algorithm branches on
 * these values. Applications never need to call this to make an iGPU work; it
 * exists so a field report can name the vendor/driver/backend instead of
 * guessing from a screenshot. */
typedef enum {
    ZCSR_GPU_VENDOR_UNKNOWN = 0,
    ZCSR_GPU_VENDOR_INTEL,
    ZCSR_GPU_VENDOR_AMD,
    ZCSR_GPU_VENDOR_NVIDIA,
    ZCSR_GPU_VENDOR_APPLE,
    ZCSR_GPU_VENDOR_SOFTWARE
} zcsr_gpu_vendor_class;

typedef enum {
    ZCSR_GPU_DRIVER_GENERIC = 0,
    ZCSR_GPU_DRIVER_IRIS,
    ZCSR_GPU_DRIVER_I965,
    ZCSR_GPU_DRIVER_RADEONSI,
    ZCSR_GPU_DRIVER_ZINK,
    ZCSR_GPU_DRIVER_LLVMPIPE,
    ZCSR_GPU_DRIVER_NOUVEAU,
    ZCSR_GPU_DRIVER_NVIDIA,
    ZCSR_GPU_DRIVER_APPLE,
    ZCSR_GPU_DRIVER_MESA
} zcsr_gpu_driver_class;

typedef struct {
    zcsr_gpu_vendor_class vendor;
    zcsr_gpu_driver_class driver;
    bool     integrated;       /* true only when classified as an iGPU */
    bool     integrated_known; /* false when the renderer string cannot be classified */
    bool     software;         /* llvmpipe/softpipe/swrast */
    char     vendor_string[64];   /* GL_VENDOR */
    char     renderer_string[64]; /* GL_RENDERER */
    char     version_string[64];  /* GL_VERSION */
    char     backend[16];         /* glx / egl-wayland / wgl / cgl / egl-android */
} zcsr_gl_gpu_info;

/* Fills *out from the context that already exists. Returns false for a NULL
 * renderer/out or before context creation; never triggers detection itself. */
bool zcsr_gl_query_gpu_info(const zcsr_gl_renderer* r, zcsr_gl_gpu_info* out);

/* Runtime capability gate. Probed once on the live context at create time;
 * querying is free and never touches GL. `core_33` is desktop GL >= 3.3,
 * `gles3` is OpenGL ES >= 3.0. `float_color_buffer` is true only when a real
 * RGBA16F FBO is reportable complete; `srgb8_color_buffer` probes
 * SRGB8_ALPHA8 the same way. The unified linear frame requires
 * `(core_33||gles3) && float_color_buffer` for BOTH Path A and Path B;
 * Light2D additionally needs `mrt4`. DISPLAY offscreen targets need
 * `srgb8_color_buffer`. */
typedef struct zcsr_gl_capabilities {
    bool core_33;
    bool gles3;
    bool float_color_buffer;
    bool srgb8_color_buffer;
    bool mrt4;
    int  max_color_attachments;
    int  max_draw_buffers;
    /* ---- F4: tail-only appended reporting fields. -------------------------
     * Compatibility: the seven fields above keep their original order and
     * types; every new field lives after them. zcsr_gl_query_capabilities()
     * memset()s the whole struct before filling, so an older caller that only
     * knows the original prefix is unaffected. These report hardware facts; no
     * entry point gates an algorithm on them. The instanced entries use the
     * pointer rebase unconditionally: on the Windows GL 3.3 driver measured here,
     * glDrawArraysInstancedBaseInstance is slower per call than rebasing the
     * attribute pointers, so a capability probe must not be read as "faster". */
    bool  gpu_timer_available;       /* GL_TIME_ELAPSED core / EXT_disjoint_timer_query */
    bool  instanced_base_instance;  /* base-instance instanced draw (core 4.2 / ARB_base_instance);
                                      * reported only; not used to select the draw path. */
    bool  indirect_draw;             /* indirect draw (core 4.0 / ARB_draw_indirect) */
    int   max_texture_size;          /* GL_MAX_TEXTURE_SIZE */
    int   max_msaa_samples;           /* GL_MAX_SAMPLES */
    float max_anisotropy;            /* GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT; 0 when absent */
    bool  linear_workflow;           /* behavior report, not a hardware probe: true only when
                                      * this build's color tier is LINEAR_HDR (RGBA16F frame +
                                      * LUT encode). DIRECT_SRGB writes the default FB directly. */
} zcsr_gl_capabilities;
bool zcsr_gl_query_capabilities(const zcsr_gl_renderer* r,
                                zcsr_gl_capabilities* out);
/* Compatibility aliases for the unified frame display-transfer LUT. The name
 * is historical: the pipeline now encodes the whole linear frame (Path A and
 * Path B), not just Light2D. New code should use
 * zcsr_gl_l2d_set_color_pipeline from gl_render_light2d_ext.h.
 * NULL restores zcsr_color_pipeline_default(); the descriptor must outlive
 * the renderer (use static storage or the default). */
bool              zcsr_gl_set_color_pipeline(zcsr_gl_renderer*,
                                              const zcsr_color_pipeline_desc* pipeline);
const zcsr_color_pipeline_desc* zcsr_gl_get_color_pipeline(const zcsr_gl_renderer*);
void              zcsr_gl_set_vsync(zcsr_gl_renderer*, bool on);
/* Encode the unified linear frame through the color-pipeline LUT and swap.
 * Call after drawing; no path writes display-encoded pixels before this. */
void              zcsr_gl_present(zcsr_gl_renderer*);
/* Read the encoded frame as tightly packed RGBA8, top-to-bottom rows.
 * Intended for deterministic editor/tool screenshots taken before present().
 * Caller supplies at least width*height*4 bytes; out_w/out_h may be NULL. */
bool              zcsr_gl_read_rgba(zcsr_gl_renderer*, void* rgba, size_t bytes,
                                    int* out_w, int* out_h);
/* Clear the linear frame with a display-domain RGBA color (decoded once).
 * Selects the frame target; call present() afterwards to display it. */
void              zcsr_gl_clear(zcsr_gl_renderer*, float r, float g, float b, float a);
/* Clear the currently selected render target (linear frame or offscreen
 * texture) without changing the target. DISPLAY/SRGB targets decode the
 * display color; LINEAR targets take the values as linear. */
void              zcsr_gl_clear_target(zcsr_gl_renderer*, float r, float g, float b, float a);

/* Create/upload an 8-bit RGBA GPU texture.
 *
 * zcsr_gl_texture_create is the compatibility entry: DISPLAY color space,
 * alpha-capable (has_alpha=true), so existing callers keep their old sampling
 * behavior. DISPLAY is stored as GL_SRGB8_ALPHA8 and decoded by the sampler;
 * the shader never decodes it a second time. New asset code should use
 * zcsr_gl_texture_create_ex and declare the actual encoding and whether any
 * texel has alpha < 1.
 *
 * Path A accepts DISPLAY textures only (see texture.h). SRGB and LINEAR are
 * for the Light2D path B; submitting them through zcsr_gl_submit / instance
 * draw is rejected rather than silently double-decoded. */
zcsr_gl_texture   zcsr_gl_texture_create(zcsr_gl_renderer*, const uint8_t* rgba, int w, int h);
zcsr_gl_texture   zcsr_gl_texture_create_ex(zcsr_gl_renderer*, const uint8_t* rgba,
                                            int w, int h,
                                            zcsr_texture_color_space color_space,
                                            bool has_alpha);
bool              zcsr_gl_texture_upload(zcsr_gl_renderer*, zcsr_gl_texture, const uint8_t* rgba, int w, int h);
void              zcsr_gl_texture_filter(zcsr_gl_renderer*, zcsr_gl_texture, bool linear);
void              zcsr_gl_texture_destroy(zcsr_gl_renderer*, zcsr_gl_texture);
/* Query renderer-owned metadata. Returns false for a null/destroyed handle. */
bool              zcsr_gl_texture_query_meta(const zcsr_gl_renderer*, zcsr_gl_texture,
                                             zcsr_texture_color_space* out_color_space,
                                             bool* out_has_alpha);

/* One drawable sprite for the batch: GPU texture + dest rect (top-left origin) + rotation about
 * the rect center (radians) + RGBA color modulation (0..1).
 *
 * `r,g,b,a` is the single RGBA modulation color (full RGBA only, no per-channel control). `mode`
 * selects how it is applied (MULTIPLY/MIX/ADD); `amount` (0..1) is the blend strength for MIX/ADD.
 * A zero-initialized sprite has mode = ZCSR_MOD_MULTIPLY and amount = 0, reproducing the legacy
 * `texel * (r,g,b,a)` behavior exactly — existing callers are unaffected. MIX/ADD drive runtime
 * effects like combat flash-red and freeze-blue (a multiply alone can only darken). */
typedef struct {
    zcsr_gl_texture tex;
    zcsr_rectf      dst;
    float           rotation;
    float           r, g, b, a;
    zcsr_color_mode mode;   /* default 0 = MULTIPLY (legacy) */
    float           amount; /* blend strength 0..1 for MIX/ADD; ignored by MULTIPLY */
    /* Explicit mirroring. Negative dst.w/dst.h are normalized by the renderer
     * into these flags instead of passing negative geometry to GL. */
    bool            flip_x;
    bool            flip_y;
} zcsr_gl_sprite;

/* One arbitrary four-corner screen quad for the batch. Corners are in boundary
 * order and may form a concave polygon; the renderer chooses the valid
 * diagonal before emitting two triangles. `tex == 0` uses the internal white
 * texture, so a scene quad can be flat-tinted without an uploaded texture.
 * This is the scene quad path. zcsr_gl_instance is still rectangle-only. */
typedef struct {
    zcsr_gl_texture tex;
    float x[4], y[4];          /* screen pixels, top-left origin */
    float u[4], v[4];          /* matching texture coordinates */
    float r, g, b, a;
    zcsr_color_mode mode;
    float amount;
} zcsr_gl_quad;

/* Append one arbitrary quad to the current batch. Enqueue-only; draw happens
 * at flush. Returns false for a NULL renderer, non-finite corners, a
 * degenerate/self-intersecting polygon, or a non-zero texture handle that is
 * not owned by the renderer. */
bool zcsr_gl_submit_quad(zcsr_gl_renderer*, const zcsr_gl_quad*);

/* Batched draw. Target throughput: 200..10000 sprites within frame budget.
 * begin() clears the batch; submit() appends one; flush() draws all in one pass.
 * flush() does NOT swap buffers — call present() afterwards to display.
 * submit_batch() is the signal-friendly entry (render_submit_batch maps here). */
void zcsr_gl_begin(zcsr_gl_renderer*);
void zcsr_gl_submit(zcsr_gl_renderer*, const zcsr_gl_sprite*);
void zcsr_gl_flush(zcsr_gl_renderer*);
void zcsr_gl_submit_batch(zcsr_gl_renderer*, const zcsr_gl_sprite* sprites, size_t count);

/* Scissor (clip rectangle), UI convention: top-left origin, exclusive.
 * w<=0 or h<=0 disables the test. Coordinates are clamped to the current
 * render target; y is flipped internally because GL's origin is bottom-left.
 * Pair every "on" with zcsr_gl_scissor_off — leaving it enabled clips later draws. */
void zcsr_gl_scissor(zcsr_gl_renderer*, int x, int y, int w, int h);
void zcsr_gl_scissor_off(zcsr_gl_renderer*);

/* Offscreen render-to-texture: set the draw target (0 = back buffer / window). */
void zcsr_gl_set_target(zcsr_gl_renderer*, zcsr_gl_texture target_or_zero);

/* Built-in bitmap-font text (scores / UI). Top-left origin, color 0..1.
 * When a TTF atlas is bound (see below), this routes through it instead of the
 * built-in 8x8 bitmap font and per-glyph bearing/advance come from the TTF. */
void zcsr_gl_draw_text(zcsr_gl_renderer*, const char* utf8, float x, float y, float scale,
                       float r, float g, float b, float a);

/* ---- Game-supplied TTF text -------------------------------------------------------------
 * SDL_ttf-shaped contract: the game owns the TTF and the buffers, the engine only
 * rasterizes. Nothing in modules/ui, modules/app_shell or the settings page needs to
 * change for a game to swap fonts — bind the atlas, every zcsr_gl_draw_text call uses it.
 *
 *   zcsr_font*          f   = zcsr_font_load(ttf_bytes, len, pixel_height, buf1, n1);
 *   zcsr_font_atlas*    a   = zcsr_font_atlas_create(r, f, buf2, n2);
 *   zcsr_gl_set_font_atlas(r, a);
 *
 * Pass NULL to unbind and fall back to the built-in bitmap font. Scale in draw_text
 * multiplies the loaded pixel_height (1.0 = native raster size).
 * zcsr_font and zcsr_font_atlas must outlive the renderer binding. */
struct zcsr_font_atlas;
void zcsr_gl_set_font_atlas(zcsr_gl_renderer*, struct zcsr_font_atlas* atlas);
struct zcsr_font_atlas* zcsr_gl_get_font_atlas(zcsr_gl_renderer*);

/* Convenience: read a TTF/OTF file and bind it in one call. `buffer` holds the TTF
 * bytes, the zcsr_font instance and the atlas; size it with
 * zcsr_gl_font_buffer_bytes_required(file_bytes). Returns false on any failure and
 * leaves the previous binding untouched. */
size_t zcsr_gl_font_buffer_bytes_required(size_t ttf_len);
bool zcsr_gl_font_from_file(zcsr_gl_renderer*, const char* path, int pixel_height,
                            void* buffer, size_t bytes);

/* Same binding, but from bytes the caller already owns (APK asset, embedded
 * font). buffer must hold the TTF copy plus the font/atlas arenas; size it with
 * zcsr_gl_font_buffer_bytes_required(ttf_len). */
bool zcsr_gl_font_from_bytes(zcsr_gl_renderer*, const void* ttf, size_t ttf_len,
                             int pixel_height, void* buffer, size_t bytes);

/* Bind the default UI font with zero configuration: ZCSR_FONT_TTF if set, else the
 * first existing system UI font (Win: segoeui/arial, Linux: DejaVuSans/Liberation).
 * Returns false when nothing is found — callers keep the built-in 8x8 bitmap, which
 * stays a fallback and never the default. */
bool zcsr_gl_font_default(zcsr_gl_renderer*, int pixel_height, void* buffer, size_t bytes);

/* Default GL sampling for textures created from now on. A "Texture Quality" option can
 * map to this and actually change filtering instead of only storing a number. */
void zcsr_gl_set_texture_filter_default(zcsr_gl_renderer*, bool linear);
bool zcsr_gl_get_texture_filter_default(const zcsr_gl_renderer*);
/* 纹理质量预设：0=最近邻（最省，无 mip）；1=双线性；2=双线性+mipmap（三线性）。
 * 只影响此后创建的纹理；已有纹理保留创建时的采样方式。 */
bool zcsr_gl_set_texture_quality(zcsr_gl_renderer*, int level);
int  zcsr_gl_get_texture_quality(const zcsr_gl_renderer*);

/* ---- Atlas sprites ---------------------------------------------------------------------------
 * A sprite that samples a sub-rectangle of a shared atlas texture. Many atlas sprites with the
 * same `atlas` texture differ only in `region` UV, so they merge into one draw call even though
 * they are logically distinct images. This is the post-atlas counterpart of zcsr_gl_sprite. */
typedef struct {
    zcsr_gl_texture   atlas;  /* the packed atlas texture (shared by many sprites) */
    zcsr_atlas_region region; /* UV sub-rectangle of this sprite's image */
    zcsr_rectf        dst;
    float             rotation;
    float r, g, b, a;
    zcsr_color_mode   mode;
    float             amount;
    bool              flip_x;
    bool              flip_y;
} zcsr_gl_atlas_sprite;

/* Batched draw for atlas sprites. Same begin/flush semantics as submit_batch; all sprites that
 * share one atlas texture are coalesced into a single glDrawArrays. */
void zcsr_gl_submit_atlas_batch(zcsr_gl_renderer*, const zcsr_gl_atlas_sprite* sprites, size_t count);

/* ---- Instanced rendering ----------------------------------------------------------------------
 * One draw call (glDrawElementsInstanced) expands a single unit quad into N instances. Only the
 * per-instance data is uploaded (168 bytes each), instead of 6 full vertices per sprite (216 bytes),
 * so both CPU vertex setup and GPU transfer shrink. The rotation/quad expansion moves into the
 * vertex shader. Best for large counts of same-texture sprites.
 *
 * Contract: each instance is an axis-aligned rectangle plus one rotation about its center. It is
 * NOT an arbitrary quad and does not carry pivot, layer or ground-sort keys. The separate
 * zcsr_gl_quad path handles arbitrary and concave four-corner scene quads; do not overload this
 * struct. */
typedef struct {
    float cx, cy;          /* center position (pixels) */
    float w, h;            /* size (pixels) */
    float u0, v0, u1, v1;  /* atlas UV sub-rectangle (use 0,0,1,1 for a full texture) */
    float r, g, b, a;      /* modulation color 0..1 */
    float rotation;        /* radians, about the center */
    float amount;          /* blend strength for MIX/ADD */
    float mode;            /* zcsr_color_mode as float */
    zcsr_color_transform recolor; /* material-masked hue/chroma/emissive transform; zero = unchanged */
    uint32_t tex;          /* CPU-only: texture handle, used for sorting into runs */
    float z;               /* CPU-only painter order; larger = farther, drawn first.
                            * This is not a layer id, not a ground-sort key and not
                            * a depth buffer. A 2.5D scene needs its own layer and
                            * ground-sort contract. */
    bool has_alpha;        /* CPU-only: texture has non-opaque pixels; sort as translucent.
                            * Do not set this for fully opaque textures: it changes batching. */
    /* 约束：z 值必须为非 NaN 的有限浮点数。若传入 NaN，排序行为未定义。 */
} zcsr_gl_instance;        /* 39 float attrs + uint32 + float + bool = 168 bytes; tex/z/has_alpha are CPU-only */

/* Canonical concept name for the same data. Use this when the point is the
 * rectangle shape, not a sprite; zcsr_gl_instance remains the legacy name. */
typedef zcsr_gl_instance zcsr_gl_rectangle_instance;

/* Draw `count` instances sharing one bound texture. Instances are drawn in
 * submission order (no sorting); the implementation splits requests larger than
 * its internal instance cap into consecutive batches, so no instance is dropped.
 * Returns the number of instances actually submitted (count on success, 0 on
 * invalid renderer/texture/array). Compare with count to detect failure.
 * For a batch spanning multiple textures, sort it first (see
 * zcsr_sort_instances) then call this once per texture run, or use
 * zcsr_gl_submit_sorted_runs. */
size_t zcsr_gl_draw_instances(zcsr_gl_renderer*, zcsr_gl_texture texture,
                              const zcsr_gl_instance* instances, size_t count);

/* Sibling entry to zcsr_gl_draw_instances: the caller guarantees every one of
 * the `count` instances is visible. This entry does NO select/cull, no
 * per-instance bitmap test and no gather/reorder: the 168 B records are
 * uploaded consecutively and drawn in submission order. zcsr_gl_draw_instances
 * keeps its own cull + select + gather rearrangement; which entry the game
 * calls is the game's choice — the engine never routes between the two.
 *
 * Tier ownership (compile-time, no runtime fallback): like
 * zcsr_gl_draw_instances, this symbol is produced only by the FULL / POS_UV
 * layout tiers; the COMPACT tier produces neither. Calling an entry the
 * active tier did not compile fails at link time (no runtime return-0 stub).
 *
 * Returns the number of instances actually submitted (count on success, 0 on
 * invalid renderer/texture/array). Compare with count to detect failure. */
size_t zcsr_gl_draw_instances_visible(zcsr_gl_renderer*, zcsr_gl_texture texture,
                                      const zcsr_gl_instance* instances, size_t count);

/* ---- Plain instanced entry: no tint / mode / amount / recolor / ramp / glow ------
 * A minimal same-texture multiply record. Per-instance data is center / size /
 * UV rect / rotation / alpha only; the record carries no tint color, blend mode,
 * blend amount, recolor, ramp, glow, chroma, emissive or rim slot. The fragment
 * result is texel * vec4(1,1,1,a), the same equation the general entry produces
 * at tint=1, MULTIPLY, no optional stage active.
 *
 * The entry has its own program, VAO and VBO. Its unit quad is a 4-vertex
 * GL_TRIANGLE_STRIP (the general entry expands a 6-vertex two-triangle quad).
 * No cull, no select, no per-instance bitmap test, no gather/reorder, no sort,
 * no depth test, no MSAA: records are uploaded consecutively and drawn in
 * submission order. "Use this entry" is the caller's choice; the engine never
 * routes between it and the general entries.
 *
 * Tier ownership (compile-time, no runtime fallback): like
 * zcsr_gl_draw_instances, this symbol is produced only by the FULL / POS_UV
 * layout tiers; the COMPACT tier produces neither. Calling an entry the
 * active tier did not compile fails at link time (no runtime return-0 stub).
 *
 * Returns the number of instances actually submitted (count on success, 0 on
 * invalid renderer/texture/array). Requests larger than
 * ZCSR_GL_MAX_INSTANCES are split into consecutive draw chunks internally; no
 * instance is dropped. Compare the return with count to detect failure. */
typedef struct zcsr_gl_instance_plain {
    float cx, cy;          /* center position (pixels) */
    float w, h;            /* size (pixels) */
    float u0, v0, u1, v1;  /* atlas UV sub-rectangle (use 0,0,1,1 for a full texture) */
    float rotation;        /* radians, about the center */
    float a;               /* alpha 0..1 */
} zcsr_gl_instance_plain;  /* 10 floats = 40 bytes; no tint/mode/amount/ramp/glow/layer */

size_t zcsr_gl_draw_instances_plain(zcsr_gl_renderer*, zcsr_gl_texture texture,
                                    const zcsr_gl_instance_plain* records, size_t count);

/* Compact-tier entry: draws `count` 36 B zcsr_instance_compact records
 * (center / size / UV + one packed rotation/alpha word). The record carries
 * no tint / mode / amount / recolor / ramp / glow / chroma / emiss / rim; those
 * stages are not compiled in this tier. The entry performs its own cull/select,
 * upload and draw over the 36 B records directly — there is no 168 B record
 * staging or conversion on this path.
 *
 * Tier ownership (compile-time, no runtime fallback): the COMPACT layout tier
 * produces this symbol only; the FULL / POS_UV tiers produce
 * zcsr_gl_draw_instances / zcsr_gl_draw_instances_visible instead. Calling an
 * entry that the active tier did not compile fails at link time (no runtime
 * return-0 stub).
 *
 * Returns the number of records actually submitted (count on success, 0 on
 * invalid renderer/texture/array). Compare with count to detect failure. */
size_t zcsr_gl_draw_instances_compact(zcsr_gl_renderer*, zcsr_gl_texture texture,
                                       const zcsr_instance_compact* records, size_t count);

/* Bind the shared 1D ramp atlas used by zcsr_color_transform.ramp_row. The
 * atlas is a normal Path A DISPLAY texture whose rows are independent
 * display-domain gradients (row 0 is the first gradient). The sRGB sampler
 * decodes each row once, so the shader receives linear ramp colors without a
 * second decode. `rows` must be >= 1 and <= the texture height. Passing
 * texture=0 clears the binding; instances with ramp_amount > 0 then fail
 * validation instead of silently sampling an unbound unit. This is renderer
 * state, not per-instance state: a frame that needs more than one atlas must
 * split its draws by atlas (or use one shared atlas). */
void zcsr_gl_set_color_ramp(zcsr_gl_renderer*, zcsr_gl_texture texture, int rows);

/* Diagnostic switch: when disabled, draw_instances skips the per-frame
 * glBufferSubData and reuses the VBO contents already uploaded. Used to
 * separate upload/synchronization cost from rasterization cost. */
void zcsr_gl_set_instance_upload(zcsr_gl_renderer*, bool enabled);
void zcsr_gl_set_instance_orphan(zcsr_gl_renderer*, bool enabled);

/* Instanced-path diagnostics: instances scanned in the write-side pass,
 * 4 B index-array bytes walked by the second pass, 168 B struct bytes gathered
 * for upload, and rejected/skipped instances. Counters accumulate since renderer
 * creation; reset clears them. Getters return 0 for a NULL renderer. Added for
 * probe/test readback of the validation-selection path; no caps field changes. */
size_t zcsr_gl_instance_scanned(const zcsr_gl_renderer*);
size_t zcsr_gl_instance_touch_bytes(const zcsr_gl_renderer*);
size_t zcsr_gl_instance_upload_bytes(const zcsr_gl_renderer*);
size_t zcsr_gl_instance_skipped(const zcsr_gl_renderer*);
/* Ruling 2: gate classification counters and the cull-path marker selected
 * per batch (0 = bitmap path, 1 = full_cull sweep). Read-only diagnostics. */
size_t zcsr_gl_instance_dead(const zcsr_gl_renderer*);
size_t zcsr_gl_instance_offscreen(const zcsr_gl_renderer*);
size_t zcsr_gl_instance_alpha0(const zcsr_gl_renderer*);
int    zcsr_gl_instance_cull_path(const zcsr_gl_renderer*);
/* Ruling 9: upload calls recorded for the active ring path. */
size_t zcsr_gl_instance_upload_calls(const zcsr_gl_renderer*);
/* Ruling 9: batches written into the persistent coherent mapping (0 on the
 * default DynamicDraw ring). */
size_t zcsr_gl_instance_map_writes(const zcsr_gl_renderer*);
/* Ruling 9: true only when the opt-in persistent ring probed usable at init. */
bool   zcsr_gl_instance_persistent_ready(const zcsr_gl_renderer*);
void   zcsr_gl_instance_stats_reset(zcsr_gl_renderer*);

/* One caller-ordered texture run for zcsr_gl_submit_sorted_runs. `instances` must
 * remain valid for the duration of the call; runs are not copied or reordered. */
typedef struct zcsr_gl_sorted_run {
    zcsr_gl_texture texture;
    const zcsr_gl_instance* instances;
    size_t count;
} zcsr_gl_sorted_run;

/* Sort a writable instance array into texture runs (and blend mode within a texture) so that
 * drawing needs one state setup per run. Pure CPU, no heap: `temp` is caller scratch of at least
 * `count * sizeof(zcsr_gl_instance)` bytes. Returns the number of distinct texture runs. After
 * sorting, iterate runs with zcsr_instance_run to get each run's texture/start/count.
 *
 * CONTRACT (N2): this function REORDERS the input array in place. Instances are grouped by
 * texture; the relative order of instances with the same texture is preserved (stable), but the
 * relative order of instances with DIFFERENT textures is not. Callers that rely on the original
 * input order for overlapping instances (painter's order) must use zcsr_sort_state instead of
 * this function, or be aware that overlapping instances across texture boundaries may be drawn
 * in a different order than submitted. */
size_t zcsr_sort_instances(zcsr_gl_instance* instances, size_t count, void* temp, size_t temp_bytes);

/* Describe one texture run produced by zcsr_sort_instances. `run_index` in 0..return-1.
 * Writes the texture and the [start,start+len) slice of the sorted array. */
void zcsr_instance_run(const zcsr_gl_instance* sorted, size_t count, size_t run_index,
                       zcsr_gl_texture* out_texture, size_t* out_start, size_t* out_len);

/* Convenience: sort and draw all instances (one instanced call per texture run). `temp` is
 * caller scratch (>= count * sizeof instance).
 * CONTRACT (N2): sorts the input array in place via zcsr_sort_instances, then draws runs in
 * texture order. The relative order of instances across texture boundaries is not preserved;
 * callers with overlap dependencies must sort first with zcsr_sort_state and draw manually.
 * Returns the number of instances actually submitted; 0 on invalid arguments.
 * The instance cap (`ZCSR_GL_MAX_INSTANCES`) is applied per uploaded chunk, not as a whole-batch rejection. */
size_t zcsr_gl_submit_instance_batch(zcsr_gl_renderer*, zcsr_gl_instance* instances, size_t count,
                                     void* temp, size_t temp_bytes);

/* Draw caller-ordered, already-sorted runs with one shared GL state setup:
 * make_current / framebuffer / viewport / program / uniforms / VAO are set once,
 * then each run only binds its texture, uploads its slice and draws. Runs are
 * submitted in the array order given by the caller; no internal sorting or
 * reordering is performed, so opaque/translucent and z order are preserved.
 * A single run larger than ZCSR_GL_MAX_INSTANCES is split into consecutive
 * upload/draw chunks. `instances` pointers remain caller-owned.
 * Returns the number of instances actually submitted (sum of valid runs' counts),
 * or 0 on invalid arguments. Does NOT present; call zcsr_gl_present afterwards. */
size_t zcsr_gl_submit_sorted_runs(zcsr_gl_renderer*, const zcsr_gl_sorted_run* runs,
                                  size_t run_count);

/* ---- full state sort (opaque vs translucent) ----
 * An instance is treated as translucent when its alpha < 1.0, its color mode is MIX/ADD,
 * or its CPU-only `has_alpha` flag is true.
 * NOTE (N1): the renderer does not read texture pixels. If a texture contains transparent
 * pixels, set `has_alpha = true` on every instance that samples it. Leaving the flag false
 * keeps the old caller contract (mark translucent via alpha/mode); correctly setting it
 * allows alpha-cutout sprites to sort behind/above each other without changing their color.
 * Partitions the array into opaque instances first (sorted by texture, for batching) then
 * translucent instances sorted back-to-front by z (larger z = farther, painter's algorithm).
 * Returns the number of opaque instances. After sorting:
 *   - draw [0, opaque) via texture runs (zcsr_instance_run / zcsr_gl_draw_instances),
 *   - draw [opaque, count) in array order, grouping only adjacent same-texture instances.
 * `temp` is caller scratch (>= count * sizeof instance).
 *
 * IMPORTANT: this is a state/batching sort, not a 2.5D scene ground sort.
 * Opaque instances are reordered by texture, so their original order is not
 * preserved. A scene that needs stable y-sort across opaque quads must build
 * its own stable order and submit it through zcsr_gl_submit_sorted_runs; do not
 * use zcsr_sort_state / zcsr_gl_submit_state as the scene sorter. */
size_t zcsr_sort_state(zcsr_gl_instance* instances, size_t count, void* temp, size_t temp_bytes,
                       size_t* out_opaque);

/* Convenience: full state sort + draw. Opaque instances are drawn in texture runs;
 * translucent instances are drawn back-to-front, flushing on texture changes.
 * Does NOT swap/present buffers: call zcsr_gl_present afterwards when targeting the
 * window. `temp` is caller scratch (>= count * sizeof instance).
 * Returns the number of instances actually submitted; 0 on invalid arguments.
 * The instance cap (`ZCSR_GL_MAX_INSTANCES`) is applied per uploaded chunk, not as a whole-batch rejection. */
size_t zcsr_gl_submit_state(zcsr_gl_renderer*, zcsr_gl_instance* instances, size_t count,
                            void* temp, size_t temp_bytes);

/* ---- GPU elapsed-time query (desktop GL 3.3) ----
 * Measures GPU time between begin/end using GL_TIME_ELAPSED query objects. The
 * renderer owns two query objects lazily created inside its caller-provided
 * buffer (no heap). Pair every begin with end; at most one measurement is
 * pending. last_ms polls the completed query and returns false while the result
 * is not ready or when the backend has no timer support (currently Android/
 * GLES). This does not call glFinish. `out_ms` is written only on true. */
bool zcsr_gl_gpu_timer_begin(zcsr_gl_renderer*);
bool zcsr_gl_gpu_timer_end(zcsr_gl_renderer*);
bool zcsr_gl_gpu_timer_last_ms(zcsr_gl_renderer*, float* out_ms);

/* ---- Basic geometry (additive, white-texture quads) ----
 * Enqueue into the current sprite batch; caller still owns flush/present semantics. */

/* Draw a filled axis-aligned rectangle in screen pixels. Uses the internal white texture. */
void zcsr_gl_fill_rect(zcsr_gl_renderer*,
                       float x, float y, float w, float h,
                       float r, float g, float b, float a);

/* Draw a line segment of given pixel width. Internally a rotated quad. */
void zcsr_gl_draw_line(zcsr_gl_renderer*,
                       float x1, float y1, float x2, float y2,
                       float width,
                       float r, float g, float b, float a);

/* Draw a rectangle outline of given thickness. Internally four filled rects. */
void zcsr_gl_draw_rect(zcsr_gl_renderer*,
                       float x, float y, float w, float h,
                       float thickness,
                       float r, float g, float b, float a);

/* ---- Texture upload / atlas sprites / circle (additive) ---- */

/* Upload a sub-region of a texture from RGBA data.
 * src_stride_bytes is the byte stride of each source row (>= w*4).
 * If src_stride_bytes % 4 != 0, implementation falls back to per-row upload.
 * Restores GL_UNPACK_ROW_LENGTH to 0 after upload. */
bool zcsr_gl_texture_upload_region(zcsr_gl_renderer*,
                                    zcsr_gl_texture,
                                    int x, int y, int w, int h,
                                    int src_stride_bytes,
                                    const uint8_t* rgba);

/* Enqueue a sprite from an atlas texture with explicit UV coordinates.
 * Enqueue-only; actual draw at flush. MULTIPLY color mode, no rotation/flip.
 * Kept for existing callers; new atlas code should use the rotation/flip entry
 * below so an atlas sprite and a whole-texture sprite no longer silently differ. */
void zcsr_gl_queue_atlas_sprite(zcsr_gl_renderer*,
                                 zcsr_gl_texture atlas,
                                 float dx, float dy, float dw, float dh,
                                 float u0, float v0, float u1, float v1,
                                 float r, float g, float b, float a);

/* Atlas sub-rect with the same rotation-about-center and explicit mirroring as
 * zcsr_gl_submit. Negative dw/dh are normalized into flip_x/flip_y. */
void zcsr_gl_queue_atlas_sprite_rot(zcsr_gl_renderer*,
                                     zcsr_gl_texture atlas,
                                     float dx, float dy, float dw, float dh,
                                     float rotation,
                                     float u0, float v0, float u1, float v1,
                                     float r, float g, float b, float a,
                                     bool flip_x, bool flip_y);

/* Enqueue a filled circle. segments clamped to [32, 256].
 * Enqueue-only; uses white texture, MULTIPLY mode.
 * Rejects non-finite cx/cy/radius/color. */
void zcsr_gl_fill_circle(zcsr_gl_renderer*,
                          float cx, float cy, float radius, int segments,
                          float r, float g, float b, float a);

#endif /* ZCSR_GL_RENDER_H */
