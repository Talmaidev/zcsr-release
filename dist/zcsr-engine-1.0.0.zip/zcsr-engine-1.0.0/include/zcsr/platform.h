#ifndef ZCSR_PLATFORM_H
#define ZCSR_PLATFORM_H
#include <stdbool.h>
#include <stddef.h>
/* Platform abstraction. Win32 / X11 / Cocoa / Android, auto-selected at compile time.
 * NO OpenGL/DirectX/Vulkan. Exactly one backend is selected by the gates below.
 * Implementer: modules/platform. */

typedef enum {
    ZCSR_PLATFORM_UNKNOWN = 0,
    ZCSR_PLATFORM_WINDOWS,
    ZCSR_PLATFORM_LINUX,
    ZCSR_PLATFORM_MACOS,
    ZCSR_PLATFORM_ANDROID
} zcsr_platform;

#if defined(_WIN32)
#  define ZCSR_PLATFORM ZCSR_PLATFORM_WINDOWS
#elif defined(__APPLE__)
#  define ZCSR_PLATFORM ZCSR_PLATFORM_MACOS
#elif defined(__ANDROID__)
#  define ZCSR_PLATFORM ZCSR_PLATFORM_ANDROID
#elif defined(__linux__)
#  define ZCSR_PLATFORM ZCSR_PLATFORM_LINUX
#else
#  define ZCSR_PLATFORM ZCSR_PLATFORM_UNKNOWN
#endif

typedef struct { int x, y, w, h; } zcsr_rect;
typedef struct { float x, y, w, h; } zcsr_rectf; /* float rectangle, for viewport/rendering */

/* Layout is part of the public contract (viewport math and UI hit-tests pass
 * these by value across module boundaries). Freeze width AND field order.
 * Skipped when parsed as C++ (C11 keyword); a C++ caller includes this header
 * inside its own extern "C" block. */
#ifndef __cplusplus
_Static_assert(sizeof(zcsr_rect) == 16, "zcsr_rect ABI: must stay 16 bytes");
_Static_assert(offsetof(zcsr_rect, x) == 0, "zcsr_rect ABI: x offset");
_Static_assert(offsetof(zcsr_rect, y) == 4, "zcsr_rect ABI: y offset");
_Static_assert(offsetof(zcsr_rect, w) == 8, "zcsr_rect ABI: w offset");
_Static_assert(offsetof(zcsr_rect, h) == 12, "zcsr_rect ABI: h offset");
_Static_assert(sizeof(zcsr_rectf) == 16, "zcsr_rectf ABI: must stay 16 bytes");
_Static_assert(offsetof(zcsr_rectf, x) == 0, "zcsr_rectf ABI: x offset");
_Static_assert(offsetof(zcsr_rectf, y) == 4, "zcsr_rectf ABI: y offset");
_Static_assert(offsetof(zcsr_rectf, w) == 8, "zcsr_rectf ABI: w offset");
_Static_assert(offsetof(zcsr_rectf, h) == 12, "zcsr_rectf ABI: h offset");
#endif

typedef struct zcsr_surface zcsr_surface; /* opaque native top-level surface */

/* Desktop: create the native surface. Android: create a logical handle and attach the
 * system-provided ANativeWindow separately. Returns NULL on failure.
 *
 * Threading: surface create/destroy is currently only supported from the engine
 * main thread. These functions are not thread-safe. */
zcsr_surface* zcsr_surface_create(const char* title, zcsr_rect bounds);

/* Create a non-layered, opaque presentation surface. On Win32 this avoids the
 * layered OpenGL path entirely (the overlay variant is created layered). */
zcsr_surface* zcsr_surface_create_opaque(const char* title, zcsr_rect bounds);
/* Threading: see zcsr_surface_create. Main thread only; not thread-safe. */
void          zcsr_surface_destroy(zcsr_surface*);
void*         zcsr_surface_native_handle(const zcsr_surface*); /* HWND / X11 Window / NSWindow* / ANativeWindow* */
/* Backend-owned drawing connection, so renderers (overlay) REUSE it instead of opening their
 * own per frame. X11: the `Display*`. Win32/Cocoa: NULL (the native handle is sufficient). */
void*         zcsr_surface_native_display(const zcsr_surface*);
void          zcsr_surface_pump_events(zcsr_surface*);
/* Android lifecycle binding.
 * The caller retains its own native-window reference. On success, the platform
 * module acquires an independent reference. Non-Android backends do not support it.
 */
bool zcsr_surface_attach_native(zcsr_surface* surface, void* native_window);
void zcsr_surface_detach_native(zcsr_surface* surface);

/* ------------------------------------------------------------------ */
/* Display enumeration and window management (additive).              */
/* ------------------------------------------------------------------ */

/* One physical output/monitor. Coordinates are desktop-layout pixels;
 * width/height are the output pixel dimensions (not the window client size).
 * Unknown fields use documented fallbacks: refresh_hz=0, dpi_scale=1.0f. */
typedef struct {
    int   id;
    char  name[64];
    int   x, y;
    int   width, height;
    int   refresh_hz;
    float dpi_scale;
    int   is_primary;
} zcsr_display_info;

typedef enum {
    ZCSR_WINDOW_WINDOWED   = 0, /* normal decorated window */
    ZCSR_WINDOW_BORDERLESS = 1, /* undecorated, no fullscreen state */
    ZCSR_WINDOW_FULLSCREEN = 2, /* borderless window filling a display; never
                                   changes the physical output mode */
} zcsr_window_mode;

/* Number of currently connected displays. Always returns at least 1; when the
 * platform cannot enumerate displays it reports a single unknown fallback. */
int  zcsr_display_count(void);

/* Read display `index` (0-based in enumeration order). Returns false and does
 * not touch `out` when out==NULL or index is out of range. All fields are
 * initialized on success; name is NUL-terminated. */
bool zcsr_display_get(int index, zcsr_display_info* out);

/* Change the window decoration/fullscreen mode. FULLSCREEN fills the current
 * display without changing physical output resolution. Unsupported platforms
 * (Android) return false. Invalid mode/surface returns false. */
bool zcsr_surface_set_mode(zcsr_surface* surface, zcsr_window_mode mode);

/* Set the window CLIENT area size in pixels (excludes title bar/borders).
 * Returns false for non-positive sizes, invalid surface, or while fullscreen. */
bool zcsr_surface_set_client_size(zcsr_surface* surface, int w, int h);

/* Set a draggable region in client-area coordinates for borderless windows.
 * When the user clicks and drags within this region, the window moves as if
 * the title bar was dragged. Pass x=y=w=h=0 to disable. Only meaningful on
 * Windows borderless mode; other platforms ignore and return false. */
bool zcsr_surface_set_drag_region(zcsr_surface* surface, int x, int y, int w, int h);

/* Move the window onto the display whose stable id is `display_id`. Returns
 * false before touching the window for an invalid/disconnected id. While
 * fullscreen, the window stays fullscreen on the target display and the
 * original restore snapshot is preserved. */
bool zcsr_surface_move_to_display(zcsr_surface* surface, int display_id);
/* 申请显示器刷新率（Hz）。仅独占全屏有意义：窗口/无边框模式下返回 false 且不改动。
 * 返回 true 只表示平台接受了请求，实际频率用 zcsr_display_get().refresh_hz 复核。 */
bool zcsr_surface_set_refresh_hz(zcsr_surface* surface, int hz);

/* Read the current CLIENT area size in pixels. Either output pointer may be
 * NULL. Invalid surface leaves outputs untouched. */
void zcsr_surface_get_client_size(const zcsr_surface* surface, int* w, int* h);

/* Current DPI scale for the window's display; 1.0f when unknown. */
float zcsr_surface_get_dpi_scale(const zcsr_surface* surface);

typedef void (*zcsr_dpi_changed_fn)(
    zcsr_surface* surface,
    float new_scale,
    void* user
);

/*
 * Registers the per-surface DPI callback.
 * A later registration replaces the previous callback.
 * Passing NULL unregisters the callback.
 * Registration does not invoke the callback immediately.
 * The callback runs synchronously during platform event dispatch.
 * Do NOT destroy the surface or modify the same window state inside
 * the callback; doing so may cause reentrancy issues.
 */
void zcsr_surface_set_dpi_callback(
    zcsr_surface* surface,
    zcsr_dpi_changed_fn callback,
    void* user
);

/*
 * Set minimum and maximum client-area sizes for the window.
 * A value of 0 means "no limit" on that axis.
 * Returns false for negative values or when min > max on the same axis.
 * On Windows the limits are hard-enforced (WM_GETMINMAXINFO).
 * On Linux they are WM hints (XSizeHints); the window manager may ignore them.
 * On Android/macOS this is unsupported and returns false.
 * Limits may be set while fullscreen; they take effect after leaving fullscreen.
 */
bool zcsr_surface_set_size_limits(
    zcsr_surface* surface,
    int min_w, int min_h,
    int max_w, int max_h
);

typedef enum {
    ZCSR_FOCUS_GAINED = 0,
    ZCSR_FOCUS_LOST = 1
} zcsr_focus_event;

typedef void (*zcsr_focus_fn)(
    zcsr_surface* surface,
    zcsr_focus_event event,
    void* user
);

/*
 * Registers one focus callback for a surface.
 * A later registration replaces the previous callback.
 * Passing NULL unregisters the callback.
 * The callback runs synchronously during event dispatch.
 *
 * Focus events may be repeated by the operating system;
 * applications should tolerate repeated GAINED or LOST events.
 * Do not destroy the surface or change its window state
 * reentrantly from this callback.
 *
 * All four desktop/mobile backends dispatch it: Win32, X11, Android, Wayland
 * (wl_keyboard enter/leave) and macOS (NSWindow key notifications).
 */
void zcsr_surface_set_focus_callback(
    zcsr_surface* surface,
    zcsr_focus_fn callback,
    void* user
);

/* Backend bridge: report focus obtained/lost when the OS focus signal lives in
 * another module (Wayland's wl_keyboard is owned by inputext). Not an app
 * setup call; normal Win32/X11/Android/Cocoa paths call this internally. */
void zcsr_surface_notify_focus(zcsr_surface* surface, bool focused);

#if defined(__ANDROID__)
#include <android/configuration.h>
/*
 * Internal platform bridge: converts NativeActivity focus commands into
 * engine focus events. Called only from android_main's onAppCmd handler.
 * Dispatches to all active surfaces' focus callbacks.
 */
void zcsr_platform_android_dispatch_focus(zcsr_focus_event event);
/* Push the current AConfiguration so DPI scale is derived from the real
 * device density bucket (density/160), not a hardcoded 1.0. */
void zcsr_platform_android_set_config(AConfiguration* config);
/* Fill the current display mode refresh rate from the Java Display API.
 * ANativeWindow exposes setFrameRate but no getFrameRate; without this the
 * platform record would have to guess 0 or repeat the requested value. */
void zcsr_platform_android_set_display_refresh_hz(int hz);
#endif

/* ---- Cursor control (additive) ----
 * Show/hide the system cursor, set a custom RGBA cursor bitmap, or reset to default.
 * Win32/X11/macOS support standard shapes; Win32 also supports a custom bitmap;
 * Wayland and Android return false rather than pretending support. */

typedef enum {
    ZCSR_CURSOR_ARROW = 0,
    ZCSR_CURSOR_IBEAM,
    ZCSR_CURSOR_CROSSHAIR,
    ZCSR_CURSOR_HAND,
    ZCSR_CURSOR_HIDDEN
} zcsr_cursor_shape;

/* Select a standard cursor. Cursor shape support is per-backend; query
 * ZCSR_PLATFORM_CAP_CURSOR_SHAPE before relying on it. */
bool zcsr_surface_set_cursor_shape(zcsr_surface* surface, zcsr_cursor_shape shape);

bool zcsr_surface_set_cursor_visible(zcsr_surface* surface, bool visible);

/* Set a custom cursor from RGBA8 pixel data. hot_x/hot_y is the click hotspot.
 * Pass NULL pixels to clear the custom cursor (same as reset). */
bool zcsr_surface_set_cursor_bitmap(zcsr_surface* surface,
                                    const unsigned char* rgba, int w, int h,
                                    int hot_x, int hot_y);

/* Restore the platform default cursor. */
bool zcsr_surface_reset_cursor(zcsr_surface* surface);

/* ---- Capability query (diagnostic; never a feature switch) ----
 * Reports what this build/backend actually implements. Missing bits mean the
 * caller must not claim that feature, not that the app has to call something
 * to enable it. */
enum {
    ZCSR_PLATFORM_CAP_DISPLAY       = 1u << 0,
    ZCSR_PLATFORM_CAP_INPUT         = 1u << 1,
    ZCSR_PLATFORM_CAP_FOCUS_EVENTS  = 1u << 2,
    ZCSR_PLATFORM_CAP_CONTENT_SIZE  = 1u << 3,
    ZCSR_PLATFORM_CAP_CURSOR_SHAPE  = 1u << 4,
    ZCSR_PLATFORM_CAP_CURSOR_BITMAP = 1u << 5,
    ZCSR_PLATFORM_CAP_CLIPBOARD     = 1u << 6,
    ZCSR_PLATFORM_CAP_IME_COMMIT    = 1u << 7,
    ZCSR_PLATFORM_CAP_SOFT_KEYBOARD = 1u << 8,
    ZCSR_PLATFORM_CAP_ASSETS        = 1u << 9
};
unsigned zcsr_platform_capabilities(void);

#endif /* ZCSR_PLATFORM_H */
