# INTEGRATION_API.md — zcsr_editor_domain 接入说明（供 C11 宿主复用）

> 适用对象：PVZ（C11、自有 OpenGL 即时模式渲染、CMake）以及任何不引入 Dear ImGui、
> 不嵌入 C++ 宿主的 C11 编辑器宿主。
> 本文描述本轮落地的可链接库、公共头、provider ops 签名语义、最小接入示例与禁止项。
> 架构背景与三方案对比见同目录 `AUDIT_PVZ_INTEGRATION.md`；推荐路径为方案 B。

## 1. 目标与边界

- **库目标名**：`zcsr_editor_domain`（静态库，C11）。
- **性质**：只含渲染中立 C 模块。**不链接** Dear ImGui、`zcsr_scene` / `zcsr_scene_io`、
  GL 上下文、OS 窗口 / Surface / HWND、C++ 宿主。
- **公共 umbrella 头**：`C:\Users\chen\Documents\GitHub\zcsr_editor\include\editor_domain.h`
  （集中聚合下列中性头；宿主只 `#include "editor_domain.h"` 即可）。
- **默认后端**：随库提供的 C11 kernel 适配器，直连注入的 `UIM_ComponentManager`；
  外部宿主可通过 `zcsr_DomainProviderOps` 注入自己的文档模型后端。
- **不变承诺**：现有 `uir_editor_*` / `uim_page_*` / `uim_node_*` 直连路径保持可用，
  现有 `zcsr_editor_kernel`、宿主可执行文件与既有测试行为不变。

## 2. 收录与排除清单（逐文件判定）

### 2.1 编入 `zcsr_editor_domain` 的源文件

| 源文件 | 职责 | 依赖 | 可纯 C 调用 |
|---|---|---|---|
| `src/editor_domain.c` | provider facade 与默认适配器（本轮新增） | UIM manager 类型 | 是 |
| `src/ui_editor.c` | 文档模型、选择集、命令/历史、画布状态、手势、命中、框选、overlay 命令 | `zcsr_uim`（manager/registry/document 头与符号） | 是（后端绑 manager） |
| `src/ui_hierarchy.c` | 层级树可见行/展开/选中视图状态 | `zcsr_uim`（只读 manager） | 是（后端绑 manager） |
| `src/ui_editor_interaction.c` | 纯 CPU 命中矩形 + 按压/点击/拖拽/悬停状态机 | 仅 stdlib（`math.h`/`string.h`）；头文件包含 manager 头但源码不使用 manager | 是（可直接复用） |
| `src/ui_editor_workspace.c` | 面板 dock / 标签 / 分隔条 / 视口模式布局数学 | UIM 基础类型 | 是 |
| `src/ui_editor_shell.c` | Shell 面板/命令/菜单/浮动面板/事件队列状态 | workspace 类型 | 是 |
| `src/ui_editor_shell_renderer.c` | `uim_EditorShellRenderOps` 帧派发 | shell 类型 + ops 表 | 是 |
| `src/ui_editor_shell_persist.c` | Shell 布局 blob 版本化 + CRC 编解码 | shell 类型 + stdlib | 是 |
| `src/ui_editor_viewport_host.c` | `uim_EditorViewportHostOps` 逻辑视口代理（不建窗口/上下文） | workspace 类型 + ops 表 | 是 |
| `src/ui_project_browser.c` | 项目/资产浏览器行模型、目录树状态、文件操作 | `uim_FileService` ABI（纯 C vtable） | 是（后端注入 FileService） |

### 2.2 排除在 domain 之外（仍在 `zcsr_editor_kernel` 或宿主层）

| 源文件 | 排除原因 |
|---|---|
| `src/editor_scene_io.c` | 绑定 engine `zcsr_scene` / `zcsr_scene_io` 文本格式 |
| `src/editor_scene_authoring.c` | 绑定 `zcsr_scene` 的增删/移动/变换命令 |
| `src/editor_scene_history.c` | 绑定 `zcsr_scene` 的快照历史环 |
| `src/editor_scene_prefab.c` | 绑定 `zcsr_scene` 的 prefab 实例化/保存 |
| `src/editor_project_container.c` | `.uiproj` 容器编解码（stdio），把 UIM 文档段与场景段打包在一起；中性 codec，列为后续可迁入候选，本轮保持在 kernel |
| `src/ui_editor_file_service_host.c` | engine `zcsr_file_service_t` → `uim_FileService` 桥接，引入 engine 文件服务类型 |
| `src/editor_host_win32.c` / `editor_host_posix.c` / `editor_host_cocoa.m` | OS 平台层（对话框/进程/路径），属 `zcsr_editor_host` |
| `src/editor_app.cpp` | 唯一 C++17 产品文件，Dear ImGui chrome；禁止进入 C11 domain |

## 3. 链接与传递依赖

### 3.1 `zcsr_editor_domain` 的 CMake 关系

- PUBLIC 链接：`zcsr_uim`（INTERFACE，聚合 `zcsr_uim_component` + `zcsr_uim_document`）、
  `zcsr_uim_project`（提供 `uim_file_service.c` 的 `uim_file_service_validate` 符号）。
- **不需要**：`zcsr_scene`、`zcsr_scene_io`、`zcsr_file_service`（engine 桥）、
  `zcsr_uim_project` 之外的项目文档/资产注册表、ImGui、`zcsr_editor_host`、任何 GL 目标。
- 头文件路径：domain PUBLIC 导出本仓 `include/` 与 UIM `include/`。
- 工具链：C11；MSVC 下沿用 `/experimental:c11atomics`（与既有 kernel 一致）。

### 3.2 UIM / runtime 以什么方式进来

- UIM 仍是源码 `add_subdirectory`（非 install 包）。链路：editor CMake →
  `zcsr_runtime` 子工程 → `add_subdirectory(UIM)`，产出 `zcsr_uim*` 目标。
- domain 本身不直接 `add_subdirectory` 任何仓库；它只链接已存在的 UIM 目标。
  宿主需先把 UIM（经 runtime 或直接）加进构建，再链接 `zcsr_editor_domain`。
- 新增 UIM 展示原子（已在 UIM `include/`，各自 INTERFACE 目标 `zcsr_uim_atom_<name>`，
  汇总于 `zcsr_uim_atoms`）：
  `uim_numeric_field.h`、`uim_dialog.h`、`uim_menu.h`、`uim_tree.h`、
  `uim_tooltip.h`、`uim_property_row.h`、`uim_splitter.h`。
  **需要控件时直接消费这些原子目标，不要在 PVZ 或本仓私造平行控件。**

### 3.3 PVZ 当前链接方式（现状，供迁移对照）

PVZ `CMakeLists.txt` 目前**不 `add_subdirectory` editor**，而是把两个 editor 源文件直接编进
自有静态库：`zcsr_editor_shell` 只编 `ui_editor_workspace.c` + `ui_editor_shell.c`；
`pvz_editor_app` 另编 UIM `uim_text_input.c`/`uim_file_service.c` 与
`ui_project_browser.c`/`ui_editor_file_service_host.c`。未链接 `zcsr_editor_kernel`、
`zcsr_uim` manager、`zcsr_uim_project`、`zcsr_scene`、ImGui。

## 4. 对外能力与接口速查

> 类型词汇全部来自 UIM 纯 C 头：`uim_Rect` / `uim_Point` / `uim_NodeId` / `uim_PageId` /
> `uim_NodeInfo` / `uim_NodeDesc` / `uim_Value` / `uim_Result` 等。

| 能力 | 头文件 | 关键入口 | 后端归属 |
|---|---|---|---|
| 文档模型读写 | `ui_editor.h` | `uir_editor_create / create_node / inspect_node / set_rect / delete_node / set_parent / set_visible / set_enabled / set_z_order ...` | 默认绑 manager；可经 `zcsr_DomainProviderOps` 替换 |
| 选择集 / 聚焦 | `ui_editor.h` | `uir_editor_select / get_selection / set_focus_node / get_focus_node` | 同上 |
| 命令栈 / 历史 | `ui_editor.h` | `uir_editor_undo / redo / clear_history / get_history_state` | 同上 |
| 视口（缩放/平移/吸附/网格/安全区） | `ui_editor.h` | `uir_editor_set_canvas_state / get_canvas_state / zoom_at / pan / canvas_to_page / page_to_canvas` | 默认后端持有画布状态；自定义后端自备视口变换 |
| 层级行 | `ui_hierarchy.h` | `uim_hierarchy_create / set_source / visible_count / get_row / handle_row_click / select_row / toggle_row / selected` | 只读 manager；行视图状态自持 |
| 项目/资产浏览器行 | `ui_project_browser.h` | `uim_project_browser_create / set_file_service / set_root / refresh / toggle_node / select / visible_count / get_node / create_dir / rename_selected / remove_selected` | 后端注入 `uim_FileService` |
| 框选 / 命中 | `ui_editor.h` | `uir_editor_canvas_hit_test / canvas_box_select / canvas_pointer_down/move/up/cancel / key_down` | 默认绑 manager；可经 provider 替换 |
| 交互状态机 | `ui_editor_interaction.h` | `uim_ui_interaction_reset / hit_add / begin_frame / update / update_edges / hover_id / press_id / clicked_id / released_id / drag_id ...` | 纯 CPU，直接复用 |
| 工作区 dock 布局 | `ui_editor_workspace.h` | `uim_workspace_init_default / set_bounds / build_frame / get_panel_view / activate_panel / dock_panel / close_panel / get_drop_target / pointer_down/move/up / viewport_*` | 自持布局状态 |
| Shell 面板/命令/事件 | `ui_editor_shell.h` | `uir_editor_shell_init_default / set_bounds / build_frame / register_panel / register_command / panel_show/hide/float/dock / reset_layout / pointer_* / key_down / poll_event / set_theme / get_center_host` | 自持 shell 状态 |
| Shell 渲染派发 | `ui_editor_shell_renderer.h` | `uir_editor_shell_render_frame` + `uim_EditorShellRenderOps` | 后端实现 ops |
| Shell 布局持久化 | `ui_editor_shell_persist.h` | `uir_editor_shell_layout_serialized_size / save / load` | 纯编解码 |
| 逻辑视口代理 | `ui_editor_viewport_host.h` | `uir_editor_viewport_host_init / sync / set_focus / process_input / render / destroy` + `uim_EditorViewportHostOps` | 后端实现 ops |
| Provider facade | `editor_domain.h` | `zcsr_domain_editor_create_default / create / destroy` + `zcsr_domain_*` 派发 + `zcsr_DomainProviderOps` | 默认适配器 / 自定义后端 |

## 5. Provider ops 精确签名与语义

### 5.1 `zcsr_DomainProviderOps`（文档模型 / 选择 / 命令 / 命中后端）

定义于 `include/editor_domain.h`。每个回调收到创建 facade 时传入的 `void *user`。

```c
#define ZCSR_DOMAIN_ABI_VERSION 1u

typedef struct zcsr_DomainProviderOps {
    uint32_t abi_version;
    uint32_t struct_size;

    /* 文档模型 */
    uim_Result (*create_node)(void *user, const uim_NodeDesc *desc,
                              uim_NodeId *out_id);
    uim_Result (*inspect_node)(void *user, uim_NodeId node_id,
                               uim_NodeInfo *out_info);
    uim_Result (*set_rect)(void *user, uim_NodeId node_id, uim_Rect rect);
    uim_Result (*delete_node)(void *user, uim_NodeId node_id);

    /* 选择集 */
    uim_Result (*get_selection)(void *user, const uim_NodeId **out_ids,
                                size_t *out_count);
    uim_Result (*set_selection)(void *user, const uim_NodeId *ids, size_t count);

    /* 命令栈 / 历史 */
    uim_Result (*undo)(void *user);
    uim_Result (*redo)(void *user);
    uim_Result (*history_state)(void *user, uim_EditorHistoryState *out_state);

    /* 命中 / 框选 */
    uim_Result (*hit_test)(void *user, uim_PageId page_id,
                           float canvas_x, float canvas_y, uim_NodeId *out_node_id);
    uim_Result (*box_select)(void *user, uim_PageId page_id,
                             uim_Rect canvas_rect, bool additive);
} zcsr_DomainProviderOps;
```

**语义约定**
- 全部同步，在宿主编辑器/UI 线程调用；返回 `uim_OK` 或 `uim_ERR_*`。
- `desc` / `ids` / `out_info` 等借用指针仅在调用期间有效；回调内不得留存。
- `get_selection` 回借内部数组视图，有效期到下一次 provider 变更；`count == 0` 表示空选择。
- `set_selection` 的 `ids` 在 `count == 0` 时可为 `NULL`。
- 未实现的槽位必须返回 `uim_ERR_UNSUPPORTED`；facade 对空槽位同样回 `uim_ERR_UNSUPPORTED`。
- 回调不得创建窗口、GL 上下文或渲染资源；只读写自己的文档模型。

**谁调用 / 何时调用**：facade `zcsr_domain_*` 方法在宿主每帧的编辑操作（建节点、改属性、
选择、撤销重做、点击/框选）时同步调用对应槽位。默认适配器把每个槽位转发到包内
`uim_Editor`（`uir_editor_*`）。

**生命周期**
```c
uim_Result zcsr_domain_editor_create_default(UIM_ComponentManager *manager,
                                             size_t history_capacity,
                                             zcsr_DomainEditor **out_editor);
uim_Result zcsr_domain_editor_create(const zcsr_DomainProviderOps *ops,
                                     void *user, zcsr_DomainEditor **out_editor);
void       zcsr_domain_editor_destroy(zcsr_DomainEditor *editor);
uim_Editor *zcsr_domain_editor_kernel(zcsr_DomainEditor *editor); /* 自定义后端返回 NULL */
```

### 5.2 `uim_EditorShellRenderOps`（Shell 面板绘制后端）

定义于 `include/ui_editor_shell_renderer.h`。

```c
#define uim_EDITOR_SHELL_RENDER_ABI_VERSION 1u

typedef struct uim_EditorShellRenderOps {
    uint32_t abi_version;
    uint32_t struct_size;
    uim_Result (*begin_frame)(void *user, void *renderer_context,
                              const uim_EditorShellFrame *frame,
                              const uim_EditorShellTheme *theme);
    uim_Result (*draw_element)(void *user, void *renderer_context,
                               const uim_EditorShellElement *element,
                               const uim_EditorShellTheme *theme);
    uim_Result (*draw_center_overlay)(void *user, void *renderer_context,
                                      const uim_EditorShellFrame *frame,
                                      const uim_EditorShellElement *center_element);
    uim_Result (*end_frame)(void *user, void *renderer_context);
} uim_EditorShellRenderOps;

uim_Result uir_editor_shell_render_frame(
    const uim_EditorShellFrame *frame, const uim_EditorShellTheme *theme,
    uim_ExternalViewManager *external_views, void *renderer_context,
    const uim_EditorShellRenderOps *ops, void *user);
```

- **谁调用**：宿主在自己的帧内调用 `uir_editor_shell_render_frame`；派发器按稳定 z_order
  依次回调 `draw_element`；中心宿主元素先由后端画底/边框，再由外部视图渲染。
- **职责边界**：后端负责裁剪与实际像素；`draw_center_overlay` 在中心视图之后、浮动面板
  之前绘制选择框/gizmo 等覆盖层。派发器**不**开始/呈现任何平台帧。
- **返回值**：`uim_OK` 继续；错误沿派发链返回。

### 5.3 `uim_EditorViewportHostOps`（逻辑视口后端）

定义于 `include/ui_editor_viewport_host.h`。

```c
#define uim_EDITOR_VIEWPORT_HOST_ABI_VERSION 1u

typedef struct uim_EditorViewportHostOps {
    uint32_t abi_version;
    uint32_t struct_size;
    uim_Result (*create_viewport)(void *user, uintptr_t *out_token,
                                 uint64_t *out_generation);
    uim_Result (*set_rect)(void *user, uintptr_t token, uint64_t generation,
                           uim_Rect editor_client_rect);
    uim_Result (*set_mode)(void *user, uintptr_t token, uint64_t generation,
                            uim_WorkspaceViewportMode mode);
    uim_Result (*set_visible)(void *user, uintptr_t token, uint64_t generation, bool visible);
    uim_Result (*set_focus)(void *user, uintptr_t token, uint64_t generation, bool focused);
    uim_Result (*set_input_route)(void *user, uintptr_t token, uint64_t generation,
                                  uim_EditorViewportInputRoute route);
    uim_Result (*process_input)(void *user, uintptr_t token, uint64_t generation,
                                 const uim_EditorViewportInput *input);
    uim_Result (*render)(void *user, uintptr_t token, uint64_t generation,
                          void *renderer_context, uim_Rect rect,
                          uim_WorkspaceViewportMode mode);
    void (*destroy_viewport)(void *user, uintptr_t token, uint64_t generation);
} uim_EditorViewportHostOps;
```

- **约束**：`create_viewport` 只能建逻辑视口/运行态视图；**禁止**建 OS 窗口、Surface、
  GL 上下文或调用任何平台窗口 API。`render` 在宿主已激活的渲染帧内、begin 之后、
  present 之前调用，只画进给定 `rect`；不得开始/结束/呈现外层帧。`destroy_viewport`
  只销毁逻辑视口状态，不得销毁主窗口或渲染上下文。
- **代际校验**：`token` + `generation` 标识视图代际；过期调用由代理层拒绝。

### 5.4 `uim_FileServiceOps`（文件系统后端）

定义于 UIM `include/uim_file_service.h`（domain 经浏览器消费该 ABI）。

```c
typedef struct uim_FileServiceOps {
    uim_FileResult (*stat_path)(void *user, const char *utf8_path, uim_FileStat *out_stat);
    uim_FileResult (*directory_open)(void *user, const char *utf8_path, uim_DirectoryHandle *out_handle);
    uim_FileResult (*directory_next)(void *user, uim_DirectoryHandle handle, uim_DirectoryEntry *out_entry,
                                     char *name_buffer, size_t name_capacity);
    uim_FileResult (*directory_close)(void *user, uim_DirectoryHandle handle);
    uim_FileResult (*create_directory)(void *user, const char *utf8_path);
    uim_FileResult (*remove_file)(void *user, const char *utf8_path);
    uim_FileResult (*remove_directory)(void *user, const char *utf8_path);
    uim_FileResult (*rename_path)(void *user, const char *utf8_from, const char *utf8_to);
    uim_FileResult (*open_read)(void *user, const char *utf8_path, uim_FileHandle *out_handle);
    uim_FileResult (*open_write_atomic)(void *user, const char *utf8_target, uim_FileHandle *out_handle);
    uim_FileResult (*read)(void *user, uim_FileHandle handle, void *buffer, size_t capacity, size_t *out_bytes_read);
    uim_FileResult (*write)(void *user, uim_FileHandle handle, const void *data, size_t size, size_t *out_bytes_written);
    uim_FileResult (*seek)(void *user, uim_FileHandle handle, int64_t offset, uim_FileSeekOrigin origin, uint64_t *out_position);
    uim_FileResult (*flush)(void *user, uim_FileHandle handle);
    uim_FileResult (*commit_atomic)(void *user, uim_FileHandle handle);
    uim_FileResult (*abort_atomic)(void *user, uim_FileHandle handle);
    uim_FileResult (*close)(void *user, uim_FileHandle handle);
} uim_FileServiceOps;

typedef struct uim_FileService {
    uint32_t abi_version; uint32_t struct_size; void *user; uim_FileServiceOps ops;
} uim_FileService;
uim_FileResult uim_file_service_validate(const uim_FileService *service);
```

- 路径 UTF-8，`/` 为规范分隔符；句柄为不透明非零令牌；全部同步；回调不留存调用方缓冲区。
- PVZ 若已用 engine `zcsr_file_service_t`，可继续用
  `ui_editor_file_service_host.c` 的 `uim_file_service_create_from_zcsr` 桥接（该桥接在
  kernel，不在 domain）；也可直接实现一张 `uim_FileServiceOps` 表接到自有文件层。

## 6. PVZ 侧：必须实现 vs 可直接复用

### 6.1 必须由 PVZ 实现 / 注入

| 组 | ops / 职责 | 说明 |
|---|---|---|
| 文件系统 | `uim_FileServiceOps`（或复用 engine 桥接） | 浏览器目录枚举/读写/改名/删除的后端；domain 不碰磁盘 |
| Shell 渲染后端 | `uim_EditorShellRenderOps` | 用 PVZ 自有 GL/即时模式把 frame 元素画出来；裁剪与像素归后端 |
| 逻辑视口后端 | `uim_EditorViewportHostOps` | 逻辑视口生命周期、输入路由、在给定 rect 内渲染；不建窗口/上下文 |
| 文档模型后端（二选一） | **(a)** 注入 UIM manager 走默认适配器；或 **(b)** 实现 `zcsr_DomainProviderOps` 对齐 PVZ 自己的关卡/单位模型 | 选 (b) 时，节点 id/矩形/选择/历史/命中都由 PVZ 模型提供 |

### 6.2 可直接复用，无需 PVZ 重写

- `ui_editor_interaction.c`：纯 CPU 命中/手势状态机，直接调用。
- `ui_editor_workspace.c` / `ui_editor_shell.c`：dock/面板/标签/分隔条/命令/事件布局数学。
- `ui_editor_shell_persist.c`：Shell 布局 blob 编解码（版本 + CRC）。
- `ui_editor_viewport_host.c`：视口代理与代际/路由状态机。
- `ui_project_browser.c`：浏览器行模型与目录树状态（文件后端注入即可）。
- `ui_hierarchy.c`：层级行展开/选中视图状态（数据源由后端提供）。
- 默认 `zcsr_DomainProviderOps` 适配器：在仍用 UIM manager 作为文档模型时免写后端。

### 6.3 本轮不在 domain 内、PVZ 需自行决策的部分

- **场景模型绑定**：`zcsr_scene` 相关 authoring/history/io/prefab 未入 domain；PVZ 的
  地图/格子/单位模型走自有 provider 对齐，或后续评估是否复用场景域。
- **Inspector 控件**：多选/抽屉/属性行/资产选择的表现层在 C++ 宿主，未中性化；需要时
  消费 UIM 原子 `uim_property_row.h` / `uim_numeric_field.h` / `uim_tree.h` 等自建控件。
- **文档项目 IO**：UIM 项目字节格式（`.uireproj`/`.uiproj`）与资产注册表在
  `zcsr_uim_project`；domain 只提供浏览器与 Shell 布局持久化，不含整文档存取。
- **Gizmo / 网格手柄 / marquee 绘制**：绘制在后端；kernel 只产出 overlay 命令数组
  （`uir_editor_build_overlay`）。

## 7. 最小 PVZ 接入示例（C，逐调用）

参照实现：`tests/test_editor_domain_provider.c`（headless，无 ImGui/窗口/GL）。

```c
#include "editor_domain.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    /* 1. 文档模型：默认后端使用注入的 UIM manager。PVZ 若走自定义模型，
       跳过 manager，改用 zcsr_domain_editor_create() 注入自己的 ops。 */
    UIM_ComponentManagerConfig cfg; memset(&cfg, 0, sizeof(cfg));
    cfg.initial_page_capacity = 2u;
    cfg.initial_node_capacity = 8u;
    UIM_ComponentManager *manager = NULL;
    uim_component_manager_create(&cfg, &manager);

    uim_PageId page = 0u;
    uim_page_create(manager, "main", &page);

    zcsr_DomainEditor *domain = NULL;
    zcsr_domain_editor_create_default(manager, 8u, &domain);
    uim_Editor *kernel = zcsr_domain_editor_kernel(domain); /* 默认后端可取内核 */

    /* 2. 画布视口状态（zoom/pan/网格/吸附/安全区）。 */
    uim_EditorCanvasState canvas; memset(&canvas, 0, sizeof(canvas));
    canvas.viewport = (uim_Rect){0, 0, 800, 600};
    canvas.zoom = 1.0f;
    canvas.grid_size = 16.0f;
    canvas.show_grid = true;
    uir_editor_set_canvas_state(kernel, &canvas);
    uir_editor_set_active_page(kernel, page);

    /* 3. 经 facade 建节点。 */
    uim_NodeDesc desc; memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.stable_key = "node_a";
    desc.local_rect = (uim_Rect){10, 10, 40, 20};
    desc.visible = true; desc.enabled = true;
    uim_NodeId node_a = 0;
    zcsr_domain_create_node(domain, &desc, &node_a);

    /* 4. 层级行读取。 */
    uim_Hierarchy *hier = uim_hierarchy_create();
    uim_hierarchy_set_source(hier, manager, node_a);
    int rows = uim_hierarchy_visible_count(hier);
    uim_HierRow row;
    if (rows > 0) uim_hierarchy_get_row(hier, 0, &row);
    uim_hierarchy_destroy(hier);

    /* 5. 命中 / 框选。 */
    uim_NodeId hit = 0;
    zcsr_domain_hit_test(domain, page, 30.0f, 20.0f, &hit);
    zcsr_domain_box_select(domain, page, (uim_Rect){0, 0, 60, 70}, false);

    /* 6. 撤销 / 重做。 */
    zcsr_domain_set_rect(domain, node_a, (uim_Rect){20, 20, 40, 20});
    uim_EditorHistoryState hist;
    zcsr_domain_history_state(domain, &hist);
    zcsr_domain_undo(domain);
    zcsr_domain_redo(domain);

    /* 7. Shell 布局持久化往返（纯编解码；文件 I/O 由宿主负责）。 */
    uim_EditorShell shell;
    uir_editor_shell_init_default(&shell, 1280.0f, 720.0f);
    size_t size = uir_editor_shell_layout_serialized_size();
    unsigned char *blob = malloc(size);
    size_t written = 0;
    uir_editor_shell_layout_save(&shell, blob, size, &written);
    uim_EditorShell restored;
    uir_editor_shell_init_default(&restored, 640.0f, 480.0f);
    uir_editor_shell_layout_load(&restored, blob, written);
    free(blob);

    /* 8. 渲染帧：后端实现 ShellRenderOps / ViewportHostOps 后在此派发。 */

    zcsr_domain_editor_destroy(domain);
    uim_component_manager_destroy(manager);
    return 0;
}
```

## 8. 给 PVZ 的 CMake 配置片段

> PVZ 已有 `ZCSR_UIM_DIR` / `ZCSR_RUNTIME_DIR` / `ZCSR_EDITOR_DIR` 缓存变量。
> 片段假设 UIM 目标已随 runtime 子工程进入构建（PVZ 现状已 `add_subdirectory(zcsr_runtime)`）。

```cmake
# --- 渲染中立编辑器 domain（无 ImGui / 无场景模型 / 无窗口） -----------------
# 方式一（推荐）：以子工程方式加入 editor，只链接 domain 目标；
# editor 子工程仍会定义 imgui/宿主等未使用目标，但 PVZ 产品目标不要链接它们。
if(NOT TARGET zcsr_editor_domain)
    set(ZCSR_ENGINE_DIR "${ZCSR_DIR}" CACHE PATH "" FORCE)
    add_subdirectory("${ZCSR_EDITOR_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/zcsr_editor_domain_build")
endif()

# PVZ 编辑器模块链接 domain；传递依赖由 domain PUBLIC 带出（zcsr_uim / zcsr_uim_project）.
target_link_libraries(pvz_editor_app PUBLIC zcsr_editor_domain)
target_include_directories(pvz_editor_app PUBLIC
    "${ZCSR_EDITOR_DIR}/include"
    "${ZCSR_UIM_DIR}/include")

# 需要展示原子时按名取用，不要私造平行控件：
#   target_link_libraries(pvz_editor_app PUBLIC zcsr_uim_atoms)
# 或单取：zcsr_uim_atom_property_row / zcsr_uim_atom_splitter /
#         zcsr_uim_atom_tree / zcsr_uim_atom_menu / zcsr_uim_atom_dialog /
#         zcsr_uim_atom_numeric_field / zcsr_uim_atom_tooltip
```

若暂不希望 `add_subdirectory` 整个 editor（避免定义未用的 ImGui/宿主目标），可沿用 PVZ
现状的直接源码编译，但源文件集合换成 domain 清单（与 `zcsr_editor_domain` 一致），并链接
`zcsr_uim` / `zcsr_uim_project`；不建议长期保留这种逐文件拷贝，目标式链接更不容易漏文件。

**迁移去重注意**（对照 PVZ 现状 `pvz_editor_app` 源文件清单）：
- 链接 `zcsr_editor_domain` 后，删除 PVZ 直接编译的 `ui_project_browser.c`（已在 domain 内），
  避免重复目标文件/符号。
- `uim_file_service.c` 由 `zcsr_uim_project` 提供；不要再在 PVZ 源清单里直接编它，
  否则静态归档内同一符号可能重复收录。
- `ui_editor_file_service_host.c`（engine `zcsr_file_service_t` 桥接）不在 domain 内；
  若 PVZ 继续走 engine 文件服务桥接，保留该文件单独编译；若自实现 `uim_FileServiceOps`，
  可移除该桥接文件。
- `ui_editor_workspace.c` / `ui_editor_shell.c` 已在 domain 内，PVZ 现有 `zcsr_editor_shell`
  两文件静态库可在迁移完成后退役。

## 9. 禁止事项（接入红线）

- **不建 OS 窗口 / Surface / GL 上下文**：视口后端 `render` 只在宿主已激活的帧内画进给定
  rect；不得 `create surface`、不得新建第二主循环。
- **不引入 Dear ImGui**：domain 与 PVZ 产品目标都不链接 `zcsr_imgui`；控件用 UIM 原子或
  PVZ 自有即时模式实现。
- **不改全局单例 `EditorApp`**：那是 C++ 宿主进程内状态；domain 无全局编辑器实例，
  存储由调用方持有（`uim_EditorShell` / `uim_Workspace` / `uim_Hierarchy` 等均为调用方分配）。
- **不跨模块抢上下文/主题/持久化路径**：ImGui 上下文、DPI 来源、Preferences 会话态、
  用户配置目录均归宿主；domain 只产出中性状态与矩形/命令。
- **不直接调 engine 场景类型**：domain 源码不得出现 `zcsr_scene*`；场景能力走 provider
  或后续评估迁入。
- **不私造 UIM 已有原子**：数字字段、对话框、菜单、树、tooltip、属性行、分隔条直接用
  `zcsr_uim_atom_*`。

## 10. 构建与测试实测（本轮）

- 独立构建目录：`build_domain_impl`（未触碰既有 `build_main` / `build_arch` /
  `build_audit_integration`）。
- 工具链：VS 18 2026 / MSVC 19.51.36260.0 / Windows SDK 10.0.26100.0 / CMake 4.3.1，Release x64。

```powershell
$cmake = "<VS18>/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe"
$ctest = "<VS18>/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe"

& $cmake -S <zcsr_editor> -B <zcsr_editor>/build_domain_impl `
  -G "Visual Studio 18 2026" -A x64 `
  -DZCSR_ENGINE_DIR=<engine> -DZCSR_UIM_DIR=<UIM> -DZCSR_RUNTIME_DIR=<runtime>
& $cmake --build <zcsr_editor>/build_domain_impl --config Release
& $ctest --test-dir <zcsr_editor>/build_domain_impl -C Release --output-on-failure
```

- 结果：**43/43 通过，0 失败**（既有 42 项全部保留，新增 `editor_domain_provider` 1 项）。
- 新增参照测试：`tests/test_editor_domain_provider.c`（可被 PVZ 复制参考）。
- 守卫测试全部通过：`editor_sources_built`、`editor_gl_debt_guard`、
  `editor_platform_owner_guard`、`editor_single_owner_guard`、
  `editor_scene_io_owner_guard`、`editor_scene_authoring_owner_guard`、
  `editor_cxx_surface_guard`。

## 11. 已知缺口与后续阶段

1. **自定义文档后端仅骨架验证**：`zcsr_DomainProviderOps` 已声明、默认适配器已实现并由
   headless 测试的 fake provider 验证分发；把 PVZ 关卡/单位模型映射到该 vtable 是下一阶段工作。
2. **场景域未迁入**：`editor_scene_*` 与 prefab/container 仍绑 `zcsr_scene`；PVZ 自有场景
   模型先经 provider 对齐语义，再决定是否复用场景 IO 格式。
3. **Inspector / 资产注册表 / 场景相机面板 / Console / Preferences** 表现层未中性化；
   需用 UIM 原子 + 自有 GL 后端逐步补齐。
4. **文档项目 IO**：整文档存取（UIM project 字节、资产注册表）不在 domain；浏览器文件
   后端与 Shell 布局持久化已可用。
