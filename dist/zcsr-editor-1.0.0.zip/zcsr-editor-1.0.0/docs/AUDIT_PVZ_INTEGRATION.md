# zcsr_editor × PVZ 编辑器复用 / 迁移能力审计

- 审计日期：2026-11-24
- 审计对象：`C:\Users\chen\Documents\GitHub\zcsr_editor`（C++/ImGui 完整编辑器宿主，Windows，CMake + VS2026）
- 复用目标：`C:\Users\chen\Documents\PVZ`（C11、自有 GL 即时模式渲染、CMake）
- 审计原则：只读。未修改任何源码；仅读取代码/文档、在独立 `build_audit_integration` 目录做 configure/build/ctest 验证。
- 关联仓库：engine `C:\Users\chen\Documents\GitHub\zero-coupling-signal-router`，UIM `C:\Users\chen\Documents\GitHub\UIM`，runtime `C:\Users\chen\Documents\GitHub\zcsr_runtime`。

## 0. 假设与口径

1. PVZ 是 C11 产品，渲染走 engine `zcsr_glrender` 即时模式 UI，**不链接 ImGui**；PVZ 侧目前只编译了 UIM 的 `uim_text_input.c`、`uim_file_service.c` 两个源文件，没有实例化 UIM `UIM_ComponentManager` 文档模型。
2. "可被纯 C 调用"指：对外头文件是 `extern "C"` 的 C ABI、实现为 `.c`、不依赖 ImGui/GL/窗口循环；但仍可能耦合到 UIM 头文件类型或 engine 具体类型（在矩阵中单独标注）。
3. 任务背景称"现有 41 项测试"；README 1.0 记 41，`EDITOR_PARITY.md` 记 42/42。本次实测为 **42/42**（见第 5 节），差异来自 runtime/UIM/player 子工程随配置纳入的测试数。
4. 本报告不替 PVZ 决定产品形态；推荐路径与分阶段步骤均以"可逆、可验证、不破坏现有测试"为前提。

## 1. 仓库与构建拓扑速览

### 1.1 zcsr_editor 源码分层（`src/`）

| 层 | 文件 | 语言 | 角色 |
|---|---|---|---|
| C++ 宿主 chrome | `editor_app.cpp` | C++17（唯一产品 `.cpp`，守卫 ≤5000 行） | ImGui 窗口/面板/Inspector/Gizmo/资产注册表/场景相机/Play 控制；持有全局单例 `EditorApp g` |
| 编辑器模型内核 | `ui_editor.c` | C11 | 选择集、手势状态、画布状态、撤销/重做、节点/组件命令、overlay 命令生成；接收外部注入的 `UIM_ComponentManager *receiver` |
| 层级树 | `ui_hierarchy.c` | C11 | 把 manager 子树展开成层级行；接收 `UIM_ComponentManager *` |
| 交互状态机 | `ui_editor_interaction.c` | C11 | 纯 CPU 命中 → 按压/点击/释放/拖拽/悬停状态机；调用方每帧注册命中矩形，不持 manager |
| 工作区布局 | `ui_editor_workspace.c` | C11 | dock 布局、面板/分栏/视图模式、frame 矩形；只依赖 UIM 头文件纯类型 |
| Shell 域 | `ui_editor_shell.c` | C11 | 面板注册/关闭/激活/拖拽/视图/事件；只依赖 UIM 头文件纯类型 |
| Shell 持久化 | `ui_editor_shell_persist.c` | C11 | shell 布局状态序列化为版本化、CRC 保护的可移植 blob；workspace 帧由状态重算 |
| Shell 渲染派发 | `ui_editor_shell_renderer.c` | C11 | `uim_EditorShellRenderOps` 后端回调分发；不含绘制实现 |
| 视口宿主代理 | `ui_editor_viewport_host.c` | C11 | `uim_EditorViewportHostOps` 后端回调代理；不含实现 |
| 项目/资产浏览器 | `ui_project_browser.c` | C11 | 目录树、刷新、新建/重命名/删除；依赖 `uim_FileService` ABI |
| 文件服务适配 | `ui_editor_file_service_host.c` | C11 | engine `zcsr_file_service_t` → UIM `uim_FileService` ABI 桥接 |
| 场景命令 | `editor_scene_authoring.c` | C11 | 对 `zcsr_scene*` 的盒/四边形/复制/移动/删除/资产属性命令 |
| 场景历史 | `editor_scene_history.c` | C11 | `zcsr_scene` 快照撤销/重做/基线/内容哈希 |
| 场景序列化 | `editor_scene_io.c` | C11 | engine `zcsr_scene_io` 的编辑器侧薄封装（`.uiscene` 文本格式） |
| Prefab | `editor_scene_prefab.c` | C11 | 单实体保存/按根位置实例化/失败回滚/FNV-1a 路径 id |
| 项目容器 | `editor_project_container.c` | C11 | `.uiproj` 打包（UIM 项目字节 + 场景文本）；stdio，Win32 仅用于 UTF-8 路径原子替换 |
| 平台边界 | `editor_host_win32.c` / `editor_host_posix.c` / `editor_host_cocoa.m` | C / ObjC | 原生打开/保存对话框、确认未保存、阻塞/非阻塞进程启动、可执行路径；唯一允许 `windows.h/commdlg.h` 的 C 层 |
| 入口 | `backends/zcsr/host_main.c` | C | `main` → `runtime()`；窗口/循环归 runtime shell |

### 1.2 CMake 目标与依赖（`CMakeLists.txt`）

- `zcsr_imgui`：vendored `third_party/imgui` + OpenGL3 后端，**仅 C++ 宿主目标链接**。
- `zcsr_editor_host`：`zcsr_platform`（macOS 另加 Cocoa）。
- `zcsr_editor_kernel`（PUBLIC）：`zcsr_uim`、`zcsr_scene`、`zcsr_scene_io`、`zcsr_file_service`；PRIVATE：`zcsr_uim_project`。
- 产品可执行目标：`zcsr_editor_kernel`、`zcsr_editor_host`、`zcsr_uim_project`、`zcsr_uim_page_view`、`zcsr_uim`、`zcsr_uim_zcsr_bridge`、`zcsr_runtime_shell`、`zcsr_task_scheduler`、`zcsr_frame_loop`、`zcsr_glrender`、`zcsr_platform`、`zcsr_input`、`zcsr_inputext`、`zcsr_image`、`zcsr_font`、`zcsr_ui`、`zcsr_core`、`zcsr_file_service`、`zcsr_asset`、`zcsr_audio`、`zcsr_music`、`zcsr_scene`、`zcsr_scene_io`、`zcsr_scene_submit`、`zcsr_game_two_dimensional`、`zcsr_tower_defense`、`zcsr_collision`、`zcsr_bench`、`zcsr_imgui`。
- UIM 不是安装包：由 `zcsr_runtime/CMakeLists.txt` 经 `add_subdirectory(${ZCSR_UIM_DIR} ...)` 源码引入；kernel 侧 include 目录追加 `${ZCSR_UIM_DIR}/include`。
- 安装规则把 `zcsr_editor_kernel` / `zcsr_editor_host` 导出为 `zcsr::zcsr_editor_kernel` / `zcsr::zcsr_editor_host`，但 kernel 仍要求 UIM/engine 目标同时存在。

### 1.3 运行时宿主模型

`editor_app.cpp` 的 `runtime()`（`editor_app.cpp:4658`）向 runtime shell 注册一个 `zcsr_runtime_shell_module`（`init/shutdown/frame/pointer/text/key/close_request`），窗口、表面、事件循环全部归 `zcsr_runtime_shell`；ImGui 上下文在 `init_cb` 创建（`editor_app.cpp:4557`），在 `shutdown_cb` 销毁（`editor_app.cpp:4614`）。PVZ 侧 `pvzeditor.c:7951` 注册的是**同一个** `zcsr_runtime_shell_module` ABI——两边宿主模型一致。

## 2. 能力矩阵

图例：
- **C 可调用**：头文件 C ABI、实现 `.c`。"是（限 UIM/engine 类型）"表示 C ABI 可用，但参数/内部状态绑定到 UIM manager 或 `zcsr_scene`，PVZ 直接链接前需要适配或换模型。
- **测试覆盖**：头less 测试目标名（ctest label `editor` 共 22 项）。

### 2.1 汇总表

| # | 能力 | 主要实现文件 | 语言 | 渲染/平台依赖 | 对外头文件 | C 可调用 | 测试覆盖 |
|---|---|---|---|---|---|---|---|
| 1 | 层级树 hierarchy | `ui_hierarchy.c`；模型侧 `ui_editor.c` | C11 | 仅 UIM manager；无 ImGui/GL/OS | `ui_hierarchy.h` | 是（限 `UIM_ComponentManager*`） | `editor_domains`（行展开/父子/折叠/选中） |
| 2 | 视口/画布：缩放/平移/吸附/网格 | `ui_editor.c`（`uim_EditorCanvasState`、坐标变换、overlay）；场景模式相机在 `editor_app.cpp` + engine `zcsr_scene_camera`/`zcsr_camera3d` | C11 + C++ 宿主 | C 侧纯计算；场景相机依赖 engine camera 模块；绘制在 ImGui | `ui_editor.h`、`ui_editor_workspace.h` | C 侧是（限 manager）；场景相机/绘制否 | `editor_model`（画布状态/坐标变换/手势）；场景相机 UI 无独立头less 测试 |
| 3 | Inspector 属性编辑 | 模型：`ui_editor.c`（节点/组件/属性命令）；控件：`editor_app.cpp` | C11 模型 + C++/ImGui 控件 | 控件依赖 ImGui、UIM `uim_text_input`、UIM 资产注册表 | `ui_editor.h` | 模型是（限 manager）；控件否 | 组件属性读写与撤销在 `editor_model`；多选/抽屉/资产选择控件无头less 测试 |
| 4 | 项目/资产浏览器 | `ui_project_browser.c`；文件桥接 `ui_editor_file_service_host.c`；资产注册表消费在 `editor_app.cpp` | C11 + C++ 宿主 | 仅 UIM FileService ABI + engine file_service；无 GL/ImGui | `ui_project_browser.h`、`ui_editor_file_service_host.h` | 是（FileService ABI 可替换实现） | `editor_shell_domains`（browser + engine file_service 后端）；资产注册表表现无测试 |
| 5 | 撤销重做 history | UI 文档：`ui_editor.c`（Edit 快照栈）；场景：`editor_scene_history.c` | C11 | UI 栈限 manager；场景栈限 `zcsr_scene`；无 ImGui | `ui_editor.h`、`editor_scene_history.h` | 是（分别限 manager / `zcsr_scene`） | `editor_model`（UI 撤销/重做/属性撤销）、`editor_scene_history` |
| 6 | 框选 rubber band | 模型：`ui_editor.c` `uir_editor_canvas_box_select` + marquee overlay；绘制：`editor_app.cpp` | C11 模型 + C++ 绘制 | C 侧限 manager；无 GL 依赖 | `ui_editor.h` | 是（限 manager） | **无**：`box_select`/marquee 未被任何测试调用（已 grep 确认 0 命中） |
| 7 | Gizmo | `editor_app.cpp`（UI Move/Rotate/Scale、场景地面手柄、ImDrawList 命中与拖拽） | C++17/ImGui | ImGui ImDrawList + engine `zcsr_camera3d`/`zcsr_scene_camera` | 无对外 C 头 | 否，绑在 C++ 宿主里 | 无（宿主内静态函数，无头less 测试） |
| 8 | 场景序列化 IO | `editor_scene_io.c`（engine `zcsr_scene_io` 薄封装） | C11 | engine `zcsr_scene` + `zcsr_scene_io`；stdio | `editor_scene_io.h` | 是（限 `zcsr_scene*`） | `editor_scene_io`（往返/坏输入/空场景/命名单文件）、`editor_scene_io_owner_guard` |
| 9 | Prefab | `editor_scene_prefab.c` | C11 | engine `zcsr_scene` + 场景 IO；stdio | `editor_scene_prefab.h` | 是（限 `zcsr_scene*`） | `editor_scene_prefab` |
| 10 | 项目容器 | `editor_project_container.c` | C11 | stdio；Win32 仅 UTF-8 路径 `MoveFileExW`；无 ImGui/GL | `editor_project_container.h` | 是（纯字节缓冲 + 路径） | `editor_project_container` |
| 11 | 文件服务 | `ui_editor_file_service_host.c`（engine → UIM ABI 桥）；UIM ABI 定义在 UIM 仓库 | C11 | engine `zcsr/file_service.h`；无 GL/ImGui | `ui_editor_file_service_host.h` | 是（双 ABI 之间可插拔后端） | `editor_shell_domains`；UIM 侧 `uim_file_service_abi` |
| 12 | UIM 集成 | 见 2.2 | 混合 | 见 2.2 | — | 混合 | 见 2.2 |

补充域（任务清单外但影响迁移判断）：

| 能力 | 文件 | 语言 | C 可调用 | 测试覆盖 |
|---|---|---|---|---|
| 工作区 dock/分栏/视图模式 | `ui_editor_workspace.c` | C11 | 是（仅 UIM 头文件纯类型） | `editor_shell_domains` |
| Shell 面板注册/事件/拖拽 | `ui_editor_shell.c` | C11 | 是（仅 UIM 头文件纯类型） | `editor_shell_domains` |
| Shell 布局持久化 blob | `ui_editor_shell_persist.c` | C11 | 是 | `editor_shell_domains` |
| Shell 渲染回调派发 | `ui_editor_shell_renderer.c` | C11 | 是（ops 由宿主/后端注入） | `editor_shell_domains` |
| 视口宿主回调代理 | `ui_editor_viewport_host.c` | C11 | 是（ops 由后端注入） | `editor_shell_domains` |
| 交互命中/状态机 | `ui_editor_interaction.c` | C11 | 是（纯 CPU，不持 manager） | `editor_domains` |
| 场景编辑命令 | `editor_scene_authoring.c` | C11 | 是（限 `zcsr_scene*`） | `editor_scene_authoring`、`editor_scene_authoring_owner_guard` |
| 平台宿主（文件对话框/未保存确认/进程启动） | `editor_host_win32.c` 等 | C/ObjC | 是（`editor_host.h` C ABI） | `editor_host` |

### 2.2 UIM 集成清单（消费了哪些模块/组件）

**Kernel C 层直接使用的 UIM 头/目标：**

| UIM 头 / 目标 | 使用位置 | 用途 |
|---|---|---|
| `uim_types.h`（纯类型，header-only） | 所有 shell/workspace/browser 头 | `uim_Result`、`uim_Rect`、`uim_Point`、`uim_Insets` |
| `uim_component_manager.h`（目标 `zcsr_uim`） | `ui_editor.c`、`ui_hierarchy.c`（`ui_editor_interaction.h` 保留该头包含但源码未使用 manager） | 节点/页面/组件/绑定的查询与变更：`uim_node_get`、`uim_page_get_node_count`、`uim_page_get_node_at`、`uim_page_resolve_layout`、组件属性读写、绑定读写等 |
| `uim_component_registry.h`（`zcsr_uim`） | `ui_editor.c`、`ui_editor_component_registry.h` | 组件描述符注册表查询 |
| `uim_file_service.h`（`zcsr_uim` ABI） | `ui_project_browser.c`、`ui_editor_file_service_host.c` | 目录枚举/读/写/删除/重命名 ABI |
| `uim_selection.h`（`zcsr_uim`） | `ui_selection.h` 转发 | 选择集类型 |
| `zcsr_uim_project`（PRIVATE 链接） | CMake 链接；当前 kernel 源码未发现直接调用其符号（疑似传递/历史保留），需在后续重构时复核 | 项目字节格式 |

**仅 C++ 宿主 `editor_app.cpp` 使用的 UIM 模块/目标：**

| UIM 头 / 目标 | 用途 |
|---|---|
| `uim_project.h` / `zcsr_uim_project` | 项目文件打包/拆包、页面集合读写 |
| `uim_asset_registry.h` / 资产记录 API | `.uirassets` 注册表、资产列表、导入/移除 |
| `uim_component_runtime.h` / `zcsr_uim` | 组件运行时描述、Play 前状态快照 |
| `uim_zcsr_runtime_bridge.h` / `zcsr_uim_zcsr_bridge` | UIM 组件 → engine runtime 桥接 |
| `uim_text_input.h` | 所有文本字段（重命名/过滤/节点名/Console）UTF-8 光标/选区/字段内撤销 |
| `uim_page_view` 目标 | 页面/视图运行时 |
| UIM 运行时控制（`uim_runtime_step` 等，经桥接） | Play/Pause/Resume/Step/Stop |

### 2.3 关键对外接口与签名（摘录）

**编辑器模型（`include/ui_editor.h`，C ABI，限 manager）**

```c
/* 生命周期；history_capacity 由调用方给定 */
uim_Result uir_editor_create(UIM_ComponentManager *receiver, size_t history_capacity, uim_Editor **out_editor);
void       uir_editor_destroy(uim_Editor *editor);

/* 选择 / 聚焦 */
uim_Result uir_editor_select(uim_Editor*, const uim_NodeId *ids, size_t count);
uim_Result uir_editor_get_selection(const uim_Editor*, uim_EditorSelection* out);
uim_Result uir_editor_set_focus_node(uim_Editor*, uim_NodeId);
uim_Result uir_editor_get_focus_node(const uim_Editor*, uim_NodeId* out);

/* 画布状态 / 缩放平移 / 坐标变换 / overlay 命令数组 */
uim_Result uir_editor_get_canvas_state(const uim_Editor*, uim_EditorCanvasState* out);
uim_Result uir_editor_set_canvas_state(uim_Editor*, const uim_EditorCanvasState*);
uim_Result uir_editor_zoom_at(uim_Editor*, float new_zoom, float canvas_x, float canvas_y);
uim_Result uir_editor_pan(uim_Editor*, float dx, float dy);
uim_Result uir_editor_canvas_to_page(const uim_Editor*, float cx, float cy, float* out_px, float* out_py);
uim_Result uir_editor_page_to_canvas(const uim_Editor*, float px, float py, float* out_cx, float* out_cy);
uim_Result uir_editor_build_overlay(const uim_Editor*, uim_PageId,
                                    uim_EditorOverlayCommand *out_commands, size_t capacity, size_t *out_count);

/* 命中 / 框选 / 指针手势 / 键 */
uim_Result uir_editor_canvas_hit_test(const uim_Editor*, uim_PageId, float cx, float cy, uim_NodeId* out);
uim_Result uir_editor_canvas_box_select(uim_Editor*, uim_PageId, uim_Rect canvas_rect, bool additive);
uim_Result uir_editor_canvas_pointer_down(uim_Editor*, uim_PageId, float cx, float cy, uint32_t modifiers);
uim_Result uir_editor_canvas_pointer_move(uim_Editor*, float cx, float cy);
uim_Result uir_editor_canvas_pointer_up(uim_Editor*, float cx, float cy);
uim_Result uir_editor_key_down(uim_Editor*, uim_EditorKey, uint32_t modifiers);

/* 撤销重做（UI 文档） */
uim_Result uir_editor_get_history_state(const uim_Editor*, uim_EditorHistoryState* out);
uim_Result uir_editor_undo(uim_Editor*);
uim_Result uir_editor_redo(uim_Editor*);
void       uir_editor_clear_history(uim_Editor*);

/* 节点 / 组件命令（属性编辑模型侧） */
uim_Result uir_editor_inspect_node(const uim_Editor*, uim_NodeId, uim_NodeInfo* out);
uim_Result uir_editor_create_node(uim_Editor*, const uim_NodeDesc*, uim_NodeId* out);
uim_Result uir_editor_duplicate_node(uim_Editor*, uim_NodeId, float offset_x, float offset_y, uim_NodeId* out);
uim_Result uir_editor_delete_node(uim_Editor*, uim_NodeId);
uim_Result uir_editor_move_node(uim_Editor*, uim_NodeId, float dx, float dy);
uim_Result uir_editor_resize_node(uim_Editor*, uim_NodeId, float width, float height);
uim_Result uir_editor_component_attach_registered(uim_Editor*, const struct uim_ComponentRegistry*,
                                                  uim_NodeId, uim_ComponentTypeId,
                                                  uim_ComponentInstanceId* out_instance_id);
uim_Result uir_editor_component_detach(uim_Editor*, uim_ComponentInstanceId);
uim_Result uir_editor_component_set_property(uim_Editor*, const struct uim_ComponentRegistry*,
                                              uim_ComponentInstanceId, uim_PropertyId, uim_Value);
```

**层级树（`include/ui_hierarchy.h`，限 manager）**

```c
uim_Hierarchy *uim_hierarchy_create(void);
void           uim_hierarchy_destroy(uim_Hierarchy *h);
void           uim_hierarchy_set_source(uim_Hierarchy *h, const UIM_ComponentManager *rec, uim_NodeId root_id);
int            uim_hierarchy_visible_count(const uim_Hierarchy *h);
bool           uim_hierarchy_get_row(const uim_Hierarchy *h, int index, uim_HierRow *out_row);
void           uim_hierarchy_handle_row_click(uim_Hierarchy *h, int row_index);
void           uim_hierarchy_select_row(uim_Hierarchy *h, int row_index);
void           uim_hierarchy_toggle_row(uim_Hierarchy *h, int row_index);
uim_NodeId     uim_hierarchy_selected(const uim_Hierarchy *h);
```

**项目浏览器（`include/ui_project_browser.h`，FileService ABI 可替换）**

```c
uim_ProjectBrowser *uim_project_browser_create(void);
void                uim_project_browser_destroy(uim_ProjectBrowser*);
uim_PBError         uim_project_browser_set_file_service(uim_ProjectBrowser*, const uim_FileService*);
uim_PBError         uim_project_browser_set_root(uim_ProjectBrowser*, const char *utf8_root);
uim_PBError         uim_project_browser_refresh(uim_ProjectBrowser*);
uim_PBError         uim_project_browser_create_dir(uim_ProjectBrowser*, const char *name);
uim_PBError         uim_project_browser_rename_selected(uim_ProjectBrowser*, const char *new_name);
uim_PBError         uim_project_browser_remove_selected(uim_ProjectBrowser*);
int                 uim_project_browser_visible_count(const uim_ProjectBrowser*);
uim_PBError         uim_project_browser_get_node(const uim_ProjectBrowser*, int idx, uim_PBVisibleNode*);
```

**场景域（`include/editor_scene_*.h`，限 `zcsr_scene*`）**

```c
/* authoring —— 返回 zcsr_editor_scene_change { bool changed; zcsr_entity_id id; } */
zcsr_editor_scene_change zcsr_editor_scene_add_box(zcsr_scene*, float x, float z, float w, float h, float r, float g, float b);
zcsr_editor_scene_change zcsr_editor_scene_add_asset(zcsr_scene*, float x, float z, float w, float h,
                                                      uint32_t kind, uint64_t prefab_id, uint64_t asset_id);
zcsr_editor_scene_change zcsr_editor_scene_add_quad(zcsr_scene*, float x, float z, float size, float r, float g, float b);
zcsr_editor_scene_change zcsr_editor_scene_duplicate(zcsr_scene*, zcsr_entity_id id, float dx, float dz);
zcsr_editor_scene_change zcsr_editor_scene_delete(zcsr_scene*, zcsr_entity_id id);
bool zcsr_editor_scene_move(zcsr_scene*, zcsr_entity_id id, float dx, float dz);
bool zcsr_editor_scene_set_y(zcsr_scene*, zcsr_entity_id id, float y);
bool zcsr_editor_scene_set_rotation(zcsr_scene*, zcsr_entity_id id, float rotation_deg);
bool zcsr_editor_scene_set_size(zcsr_scene*, zcsr_entity_id id, float w, float h);
bool zcsr_editor_scene_set_asset_ref(zcsr_scene*, zcsr_entity_id id, uint32_t kind, uint64_t prefab_id, uint64_t asset_id);
bool zcsr_editor_scene_set_quad(zcsr_scene*, zcsr_entity_id id, const zcsr_scene_point quad[4]);
bool zcsr_editor_scene_set_corner(zcsr_scene*, zcsr_entity_id id, int corner, float x, float y, float z);
bool zcsr_editor_scene_clear_quad(zcsr_scene*, zcsr_entity_id id);

/* history —— 手势 begin -> mutate -> commit/cancel；只存内容，不存相机/视口尺寸 */
zcsr_editor_scene_history* zcsr_editor_scene_history_create(void);
void    zcsr_editor_scene_history_destroy(zcsr_editor_scene_history*);
bool    zcsr_editor_scene_history_begin(zcsr_editor_scene_history*, const zcsr_scene*);
bool    zcsr_editor_scene_history_commit(zcsr_editor_scene_history*, const zcsr_scene*);
bool    zcsr_editor_scene_history_cancel(zcsr_editor_scene_history*, zcsr_scene*);
bool    zcsr_editor_scene_history_undo(zcsr_editor_scene_history*, zcsr_scene*);
bool    zcsr_editor_scene_history_redo(zcsr_editor_scene_history*, zcsr_scene*);
void    zcsr_editor_scene_history_reset(zcsr_editor_scene_history*, const zcsr_scene*);
size_t  zcsr_editor_scene_history_undo_count(const zcsr_editor_scene_history*);
size_t  zcsr_editor_scene_history_redo_count(const zcsr_editor_scene_history*);
bool    zcsr_editor_scene_history_has_pending(const zcsr_editor_scene_history*);
uint64_t zcsr_editor_scene_content_hash(const zcsr_scene*);

/* io —— .uiscene 文本格式；load 事务性，失败不改调用方场景；save 原子写 */
zcsr_editor_scene_io_result zcsr_editor_scene_serialize(const zcsr_scene*, char** out_text, size_t* out_size);
zcsr_editor_scene_io_result zcsr_editor_scene_deserialize(const char* text, size_t size, zcsr_scene*);
zcsr_editor_scene_io_result zcsr_editor_scene_save(const zcsr_scene*, const char* utf8_path);
zcsr_editor_scene_io_result zcsr_editor_scene_load(zcsr_scene*, const char* utf8_path);

/* prefab —— 普通 .uiscene 文件 + FNV-1a prefab_id；实例化失败回滚已加入实体 */
uint64_t zcsr_editor_prefab_id_from_path(const char* utf8_path);
bool     zcsr_editor_prefab_save_entity(const zcsr_scene*, zcsr_entity_id source_id, const char* utf8_path, uint64_t* out_prefab_id);
size_t   zcsr_editor_prefab_instantiate(zcsr_scene*, const char* utf8_path, float x, float z,
                                         zcsr_entity_id* out_ids, size_t capacity, uint64_t* out_prefab_id);

/* container —— 单文件 .uiproj：UIM 项目字节 + 场景文本；路径级原子写 */
zcsr_editor_container_result zcsr_editor_project_container_save(
    const char *utf8_path, const unsigned char *project, size_t project_size,
    const char *scene, size_t scene_size);
zcsr_editor_container_result zcsr_editor_project_container_load(
    const char *utf8_path, unsigned char **out_project, size_t *out_project_size,
    char **out_scene, size_t *out_scene_size);
bool zcsr_editor_project_container_probe(const char *utf8_path);
```

**渲染后端 / 视口宿主（现有 C ABI 插槽）**

```c
/* include/ui_editor_shell_renderer.h —— 由提供方实现；ABI 版本/结构大小字段必填 */
typedef struct uim_EditorShellRenderOps {
    uint32_t abi_version;
    uint32_t struct_size;
    uim_Result (*begin_frame)(void *user, void *renderer_context,
                              const uim_EditorShellFrame *frame,
                              const uim_EditorShellTheme *theme);
    uim_Result (*draw_element)(void *user, void *renderer_context,
                               const uim_EditorShellElement *element,
                               const uim_EditorShellTheme *theme);
    uim_Result (*draw_center_overlay)(void *user, void *renderer_context,
                                      const uim_EditorShellFrame *frame,
                                      const uim_EditorShellElement *center_element);
    uim_Result (*end_frame)(void *user, void *renderer_context);
} uim_EditorShellRenderOps;

/* 派发整帧；外部视图管理器 opaque，renderer_context 由宿主传入 */
uim_Result uir_editor_shell_render_frame(const uim_EditorShellFrame *frame,
                                         const uim_EditorShellTheme *theme,
                                         uim_ExternalViewManager *external_views,
                                         void *renderer_context,
                                         const uim_EditorShellRenderOps *ops, void *user);

/* include/ui_editor_viewport_host.h —— 由提供方实现；逻辑视口，不是 OS 窗口/Surface/GL 上下文 */
typedef struct uim_EditorViewportHostOps {
    uint32_t abi_version;
    uint32_t struct_size;
    uim_Result (*create_viewport)(void *user, uintptr_t *out_token, uint64_t *out_generation);
    uim_Result (*set_rect)(void *user, uintptr_t token, uint64_t generation, uim_Rect editor_client_rect);
    uim_Result (*set_mode)(void *user, uintptr_t token, uint64_t generation, uim_WorkspaceViewportMode mode);
    uim_Result (*set_visible)(void *user, uintptr_t token, uint64_t generation, bool visible);
    uim_Result (*set_focus)(void *user, uintptr_t token, uint64_t generation, bool focused);
    uim_Result (*set_input_route)(void *user, uintptr_t token, uint64_t generation, uim_EditorViewportInputRoute route);
    uim_Result (*process_input)(void *user, uintptr_t token, uint64_t generation,
                                const uim_EditorViewportInput *input);
    uim_Result (*render)(void *user, uintptr_t token, uint64_t generation,
                         void *renderer_context, uim_Rect rect, uim_WorkspaceViewportMode mode);
    void       (*destroy_viewport)(void *user, uintptr_t token, uint64_t generation);
} uim_EditorViewportHostOps;
```

视口宿主自身的同步/渲染入口：`uir_editor_viewport_host_init / _sync / _set_focus / _process_input / _render / _destroy`。输入事件结构为 `uim_EditorViewportInput`（type/x/y/wheel_delta/pointer_id/buttons/key/modifiers/text）。

**平台宿主（`include/editor_host.h`，C ABI）**

```c
editor_host* editor_host_create(zcsr_surface* surface);
void         editor_host_destroy(editor_host* host);
bool         editor_host_open_file(editor_host* host, const char* title, const char* extension,
                                    char* out_path, size_t out_capacity);
bool         editor_host_save_file(editor_host* host, const char* title, const char* extension,
                                   const char* suggested_name, char* out_path, size_t out_capacity);
editor_host_unsaved_choice editor_host_confirm_unsaved(editor_host* host, const char* title, const char* message);
bool         editor_host_executable_path(editor_host* host, char* out_path, size_t out_capacity);
bool         editor_host_run_process(editor_host* host, const char* command, const char* working_dir,
                                     char* output, size_t output_capacity, int* out_exit_code);
bool         editor_host_launch_process(editor_host* host, const char* command, const char* working_dir);
```

注：宿主 ABI 只有打开/保存文件对话框，**没有**目录选择器；进程交互分阻塞 `run_process` 与非阻塞 `launch_process`。

## 3. 接口可行性判定（PVZ 接入视角）

### 3.1 现有耦合盘点

1. **文档模型耦合在具体 `UIM_ComponentManager` 上**。`uir_editor_create` / `uim_hierarchy_create` / 交互模块接收外部 manager，内部直接调用 `uim_node_*`、`uim_page_*`、`uim_component_*`、`uim_binding_*`。PVZ 的文档是 `pvz_unit_data` + `pvz_level_set` + `pvz_map`，既不是 UIM manager 也不是 `zcsr_scene`。当前**没有**面向第三方文档模型的回调层。
2. **场景域耦合在 engine `zcsr_scene` 类型上**。authoring/history/io/prefab 全部以 `zcsr_scene*` 为参数；PVZ 的 CMake 链接列表未直接链接 `zcsr_scene`/`zcsr_scene_io`（见 5.4），地图模型自管。
3. **渲染/表现层全部在 C++ 宿主**。Inspector 控件、Gizmo、网格/手柄/marquee 绘制、资产注册表面板、场景相机面板、Console、Preferences UI 都在 `editor_app.cpp`，直接调 ImGui。kernel 只产出中性数据（overlay 命令、选择集、状态枚举、布局矩形），不负责画。
4. **已有两个 renderer-neutral 插槽**：`uim_EditorShellRenderOps`（shell 元素/中心 overlay 派发）与 `uim_EditorViewportHostOps`（视口生命周期/输入/渲染代理）。注意：zcsr 自己的 `editor_app.cpp` 当前**并未使用**这两个插槽（宿主直接画 ImGui 窗口），它们主要由 `editor_shell_domains` 测试驱动，PVZ 接入时相当于第一次在真实后端上落地。
5. **文件服务已经是 ABI 抽象**：`uim_FileService` 由 `ui_editor_file_service_host.c` 从 engine `zcsr_file_service_t` 桥出；PVZ 已在编译该适配层。

### 3.2 接入需要的 provider / host 回调

按"文档模型 → 选择 → 拾取 → 命令栈 → 渲染 → 文件/平台"分层：

**A. 文档模型读写（当前缺口最大，无现成 vtable）**

| 回调职责 | 当前 zcsr 内部实现位置 | 现状缺口 |
|---|---|---|
| 取根节点、子节点计数/按序取子 | `ui_hierarchy.c` `uim_hierarchy_set_source`（root_id 由调用方传入）、`ui_editor.c` `page_is_valid` | 直接调 `uim_page_get_node_count` / `uim_page_get_node_at`；需抽象为 provider 节点树读接口 |
| 读节点矩形/变换/可见/可用/z-order/父节点/名/类型 | `ui_editor.c` `node_world_rect`、`uir_editor_inspect_node` | 经 `uim_node_get`；需 provider get 属性接口 |
| 写节点矩形/变换/可见/可用/z-order/父节点/名 | `ui_editor.c` 各 `set_*` 命令 | 经 `uim_node_set_*` + 历史快照；需 provider set 属性接口 |
| 组件列表 / 属性 get / 属性 set / 挂载 / 卸载 | `ui_editor.c` `component_*` | 经 UIM 组件 API + 注册表；需 provider 组件接口 |
| 页面/节点迭代、布局解析 | `ui_editor.c` `uim_page_resolve_layout` 等 | 需 provider 页面接口或由 provider 侧自己完成布局 |
| 序列化 / 反序列化文档 | 项目：`editor_app.cpp` + UIM project；场景：`editor_scene_io.c` | 文档侧无 C 抽象；场景侧绑 `zcsr_scene` |

**B. 选择集**

| 回调职责 | 现状 |
|---|---|
| 读取当前选中 id 集合、设置选择、聚焦单节点 | kernel `uir_editor_get_selection/select/set_focus_node` 已存在，但 id 空间是 UIM `uim_NodeId`；provider 需把自己的实体标识映射进该空间，或选择集也抽象成 vtable。 |

**C. 拾取 / 命中测试**

| 回调职责 | 现状 |
|---|---|
| 屏幕坐标 → 世界坐标（含缩放/平移） | UI 模式：kernel `canvas_to_page/page_to_canvas`（纯数学，可复用）；场景模式：engine `zcsr_scene_camera_screen_to_ground` + `zcsr_scene_pick`（`editor_app.cpp:2791/2913/2985`）。 |
| 点命中实体 | `uir_editor_canvas_hit_test`（UI，经 manager 取世界矩形）；`zcsr_scene_pick`（engine）。PVZ 需提供自己的地图/格子命中，或在 adapter 里暴露世界矩形给 kernel。 |
| 框选求交集合 | `uir_editor_canvas_box_select`（UI，经 manager）；场景 marquee 在 `editor_app.cpp:2985` 用相机反投影后自行求交。 |

**D. 命令栈 / 历史**

| 回调职责 | 现状 |
|---|---|
| 手势开始 / 提交 / 取消 | kernel 内部 `gesture_begin_nodes` / `gesture_finish` / `gesture_clear`（指针手势快照），与 UIM 快照绑定；需 provider 命令栈接口承接。 |
| 撤销 / 重做 / 可否撤销重做 / 深度 | UI 文档：`uir_editor_undo/redo/get_history_state`；场景：`editor_scene_history.c`。两套分别绑 manager / `zcsr_scene`。 |

**E. 渲染后端**

| 回调职责 | 现状 |
|---|---|
| 在给定矩形内绘制文档/实体 | `uim_EditorViewportHostOps.render` / `uim_EditorShellRenderOps.draw_center_overlay` 插槽已定义；无 GL 实现。PVZ 用 `zcsr_glrender` 即时模式实现。 |
| 绘制 shell 面板/分隔/标题/拖拽态 | `uim_EditorShellRenderOps.draw_element` 插槽；PVZ 当前 `pvz_editor_shell.c` 自画矩形，可逐步替换为该 ops。 |
| 输入事件投递到视口 | `uim_EditorViewportHostOps.process_input`。 |

**F. 文件 / 平台**

| 回调职责 | 现状 |
|---|---|
| 目录枚举/读/写/删/改名 | `uim_FileService` ABI；PVZ 已桥接 engine file_service。 |
| 原生打开/保存文件对话框、未保存确认、进程启动、可执行路径 | `editor_host.h` C ABI，Win32 实现在 `editor_host_win32.c`；无目录选择器；PVZ 可复用或自供。 |

### 3.3 现成可直接链接（不改源码即可被 PVZ 引用）

- `ui_editor_workspace.c`（dock/分栏/视图 frame 矩形）—— PVZ 已链接。
- `ui_editor_shell.c`（面板注册/事件/拖拽）—— PVZ 已链接。
- `ui_editor_shell_persist.c`（布局 blob 存取）—— 未链接，可直接加源文件。
- `ui_editor_shell_renderer.c`（ops 派发）—— 可直接链接，由 PVZ 实现 ops。
- `ui_editor_viewport_host.c`（ops 代理）—— 可直接链接，由 PVZ 实现 ops。
- `ui_project_browser.c` + `ui_editor_file_service_host.c` —— PVZ 已编译。
- `editor_project_container.c` —— 纯 stdio/字节缓冲，可直接链接（不依赖 UIM manager）。
- `editor_host.h` C ABI（Win32 实现）—— 可按平台链接；依赖 `zcsr_platform` 表面。

### 3.4 必须先改造成抽象层才能复用

- `ui_editor.c`（模型/选择/历史/手势/overlay/框选/画布）：把对 `UIM_ComponentManager` 的直接调用收进一个 provider vtable（A/B/D 类回调），保留现有 UIM adapter 让 `editor_model` 等测试继续绿。
- `ui_hierarchy.c`：同一 provider 节点树接口。
- `ui_editor_interaction.c`：已是纯 CPU 命中/手势状态机，可直接复用；调用方每帧注册命中矩形并喂指针状态，无需随模型层抽象。
- 场景域 `editor_scene_authoring/history/io/prefab.c`：要么 PVZ 采用 `zcsr_scene` 作为关卡布局模型（直接复用），要么把场景操作也收进 provider vtable（工作量大，且 engine `zcsr_scene_io` 格式优势会丢失）。
- Inspector 控件 / Gizmo / overlay 绘制：C++/ImGui 表现层不可链接进 PVZ；需用 kernel 产出的中性数据（overlay 命令、节点信息、选择集）在 PVZ GL 即时模式上重画，Gizmo 数学可优先复用 PVZ 自己的 `pvz_editor_gizmo.c`。

### 3.5 当前接口缺口的具体函数与位置

| 缺口 | 位置 | 说明 |
|---|---|---|
| 文档模型读 vtable | `src/ui_editor.c` 内 `root`、`children`、`node_world_rect`、`uir_editor_inspect_node`；`src/ui_hierarchy.c:48` 起 | 全部直调 `uim_page_*`/`uim_node_get`；无回调注册点。 |
| 文档模型写 vtable | `src/ui_editor.c` 各 `set_*` / `component_*` 命令 | 直调 `uim_node_set_*`/`uim_component_*`；无回调注册点。 |
| 组件注册表适配 | `include/ui_editor_component_registry.h` → UIM registry | 描述符来源绑 UIM；PVZ 需自供组件元数据或适配。 |
| 场景模型替换点 | `src/editor_scene_authoring.c`、`editor_scene_history.c`、`editor_scene_io.c`、`editor_scene_prefab.c` | 签名固定 `zcsr_scene*`；无场景 provider 抽象。 |
| 视口渲染实现 | `include/ui_editor_viewport_host.h` ops 已声明；`src/editor_app.cpp` 未接线 | 真实 GL/即时模式后端实现缺失。 |
| Shell 渲染实现 | `include/ui_editor_shell_renderer.h` ops 已声明；宿主未接线 | PVZ GL 后端需实现 `begin_frame/draw_element/draw_center_overlay/end_frame`。 |
| 资产注册表 C 侧抽象 | `editor_app.cpp` 内 UIM `uir_AssetRegistry` 调用 | 资产导入/列表/移除目前在宿主；无独立 C 浏览器模型。 |
| 场景拾取/相机抽象 | `editor_app.cpp:1743` `pick_3d_at`、`:2913` `zcsr_scene_pick`、`:2791/2985` 相机反投影 | 绑 engine scene/camera；PVZ 地图拾取需自供。 |

## 4. 迁移路径方案

### 4.1 方案对比

| 维度 | A. PVZ 作为 provider 嵌入 zcsr_editor 宿主 | B. 抽取 zcsr C 层编辑模块为可复用库，PVZ 自有 GL 壳作后端 | C. PVZ 内对等重写 |
|---|---|---|---|
| 形态 | PVZ 编辑器成为 zcsr_editor C++/ImGui 宿主内的一种文档/模块 | kernel 按"纯域 / UIM 适配层 / 场景域"分层；PVZ 链接纯域 + 自实现后端与 provider adapter | PVZ 在自有 C11/GL 壳内重新实现选择/历史/手势/层级/浏览器/IO |
| 渲染栈 | 引入 ImGui + OpenGL3 后端 + vendored 第三方 | 不引入 ImGui；PVZ `zcsr_glrender` 即时模式实现 shell/视口 ops | 维持 PVZ 现状 |
| 文档模型 | 需把 PVZ 数据灌进 UIM manager，或宿主再开一类 provider 文档 | 定义文档 provider vtable；UIM 与 PVZ 各一个 adapter | 不动 zcsr |
| 可直接复用 | 宿主 chrome、Inspector、Gizmo、资产面板、Play 控制全套 | workspace/shell/persist/renderer/viewport/browser/container 直接复用；模型/选择/历史经 adapter 复用；场景域视模型取舍 | 无 |
| 成本 | 高：PVZ 产品栈接入 ImGui/UIM manager，数据模型与 UI 双向映射 | 中高：先抽 C 纯域库，再设计 provider ABI 与 PVZ adapter；场景域分步 | 高：从零补全 12 类能力，长期双份维护 |
| 风险 | 两套编辑历史/两套选择集并存；ImGui 上下文与窗口循环归属；PVZ 现有 GL 即时 UI 被废弃；PVZ 探测测试（workbench/拖拽/历史）需要随宿主改造 | ABI 不能泄漏 UIM 类型；固定容量/堆策略需复核；拆分过程须保持 22 项 editor 测试全绿；新增 C++ 核心受守卫约束 | 低即时风险，高长期风险：与 zcsr 已验证的格式/命令/校验持续漂移；PVZ 已复用的 browser/shell 被推翻 |
| 对现有测试影响 | zcsr 22 项 editor 测试理论上不受影响（新增 provider 模块）；PVZ 自有测试随壳改造可能大面积返工 | zcsr 测试必须保持全绿（adapter 行为等价）；PVZ 探测测试在每阶段回归 | zcsr 测试不受影响；PVZ 测试重写 |
| 架构边界契合 | 弱：zcsr 规则是"C11 持数据/格式/命令，C++ 只做 chrome"；把 PVZ 产品塞进 ImGui 宿主会反向抬高耦合 | 强：与现有分层一致，C 域可被 C11 工程复用 | 中：守住 PVZ 边界，但放弃上游积累 |

### 4.2 推荐路径

**推荐方案 B（抽取 C 层可复用库 + PVZ GL 后端 + provider adapter），分阶段落地；不推荐 A（宿主反向吞并）与 C（对等重写）。**

理由：
1. zcsr 现有可复用资产绝大多数本来就是 C11、renderer-neutral；PVZ 已经在直接编译其中两个域，说明这条接入路线已被工程验证可行。
2. 真正绑死的只有两处：`UIM_ComponentManager`（UI 文档模型）与 engine `zcsr_scene`（场景模型）。这两处用 provider vtable/adapter 隔离，不需要把 ImGui 或整个宿主搬进 PVZ。
3. 方案 A 会让 PVZ 被迫接受 ImGui/UIM 文档模型与 C++ 宿主生命周期，与 PVZ 现有 GL 即时 UI、自有历史/地图模型正面冲突；方案 C 重复造轮子并丢掉 `.uiscene`/`.uiproj`/prefab 等已测试格式。

### 4.3 分阶段落地步骤（每阶段可独立验证）

**阶段 0 — 基线固化（已完成于本次审计）**
- 独立目录 `build_audit_integration` configure/build/ctest 全绿（42/42，见第 5 节）。
- 产出本审计文档与 JSON；后续每阶段回归同一套命令。

**阶段 1 — 纯渲染中性域入库（不碰文档模型）**
- 把 `workspace / shell / persist / renderer / viewport_host / interaction` 整理成一个不依赖 manager 的 CMake 接口/静态库（当前 `zcsr_editor_kernel` 把纯域与 manager 域混在一起，先做文件级拆分）。
- PVZ 侧：在 `zcsr_editor_shell` 目标中补入 persist/renderer/viewport_host 源文件；用 `zcsr_glrender` 实现 `uim_EditorShellRenderOps`，替换 `pvz_editor_shell.c` 内自画矩形。
- 验证：zcsr ctest 全绿不变；PVZ 探测测试（workbench 布局、拖拽、浏览器）回归通过；PVZ 编辑器截图级对比布局一致。

**阶段 2 — 文档 provider vtable + PVZ adapter**
- 在 kernel 定义文档模型回调表（节点树/属性读写/组件/选择/拾取/命令栈，对应 3.2 A–D）；现有 UIM manager 实现为默认 adapter，行为等价。
- PVZ 实现 adapter：`pvz_unit_data`/`pvz_level_set`/`pvz_map` → vtable；选择集与实体 id 映射；地图命中接 PVZ 既有格子/路径拾取。
- 复用 kernel 的选择、手势、撤销/重做、overlay 生成；PVZ 历史模块（`pvz_editor_history.c`）逐步改接到同一命令栈或并存过渡。
- 验证：新增 headless 测试驱动 PVZ adapter（无 GL）；zcsr `editor_model`/`editor_domains` 等测试保持绿；PVZ 撤销/重做/多选/框选用例通过。

**阶段 3 — 场景模型决策（二选一，按 PVZ 关卡形态定）**
- 3a（推荐若关卡布局可迁移）：PVZ 关卡布局改用 `zcsr_scene`，直接复用 authoring/history/io/prefab/container；地图/格子规则作为场景之上的 provider 约束。
- 3b（保留 PVZ 自有场景）：把场景命令/历史/IO 也收进 provider vtable；`editor_scene_io.c`/`prefab.c` 暂不复用，仅在 PVZ 侧对齐其快照/哈希/回滚语义。
- 验证：场景往返序列化字节级测试；prefab 实例化失败回滚测试；历史 commit/undo/redo 基线测试。

**阶段 4 — 表现层补齐（Inspector 控件 / Gizmo / overlay 绘制）**
- 用 kernel overlay 命令与节点信息在 PVZ GL 即时模式上重画 Inspector 编辑器、网格/参考线/marquee；Gizmo 优先沿用 `pvz_editor_gizmo.c` 的命中/拖拽数学，手柄外观接 PVZ 风格。
- 资产注册表/项目面板接阶段 1 的浏览器域 + PVZ 自己的资产清单。
- 验证：PVZ 编辑器全功能 smoke（新建/编辑/保存/重开）；zcsr 守卫测试（无第二 C++ 核心、kernel 无 GL/OS 直连、单一 owner）保持通过。

## 5. 构建可行性实测

### 5.1 环境

- OS：Windows 10.0.19045；工具链：MSVC 19.51.36260.0（VS 18 2026 Professional）；Windows SDK 10.0.26100.0；CMake 4.3.1-msvc1。
- 独立构建目录：`C:\Users\chen\Documents\GitHub\zcsr_editor\build_audit_integration`（未触碰已有 `build_main` / `build_arch`）。

### 5.2 实测命令

```powershell
$cmake = "C:\Program Files\Microsoft Visual Studio\18\Professional\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
$ctest = "C:\Program Files\Microsoft Visual Studio\18\Professional\CommonExtensions\Microsoft\CMake\CMake\bin\ctest.exe"

# configure
& $cmake -S "C:\Users\chen\Documents\GitHub\zcsr_editor" `
  -B "C:\Users\chen\Documents\GitHub\zcsr_editor\build_audit_integration" `
  -G "Visual Studio 18 2026" -A x64 `
  -DZCSR_ENGINE_DIR="C:/Users/chen/Documents/GitHub/zero-coupling-signal-router" `
  -DZCSR_UIM_DIR="C:/Users/chen/Documents/GitHub/UIM" `
  -DZCSR_RUNTIME_DIR="C:/Users/chen/Documents/GitHub/zcsr_runtime"

# build (Release, 全量)
& $cmake --build "C:\Users\chen\Documents\GitHub\zcsr_editor\build_audit_integration" --config Release

# test
& $ctest --test-dir "C:\Users\chen\Documents\GitHub\zcsr_editor\build_audit_integration" -C Release --output-on-failure
```

日志：`build_audit_integration/build_audit.log`、`build_audit_integration/ctest_audit.log`。

### 5.3 实测结果

- configure：成功（3.8s），无依赖路径告警。
- build：退出码 0，无 error；产物含 `zcsr_editor.exe`、`zcsr_player.exe` 及全部测试可执行文件。
- **ctest：42/42 通过，0 失败，Total Test time (real) = 5.86s。**
- 标签分布：editor 22、uim 14、runtime 3（含 light2d 1）、player 2；另有 `editor_scene_prefab` 未挂任何标签（同属 editor 域，漏登记在 `ZCSR_EDITOR_TESTS` 列表中）。22 + 14 + 3 + 2 + 1 = 42。
- editor 标签 22 项：`editor_key_contract`、`editor_host`、`editor_page_runtime`、`editor_runtime_state`、`editor_project_roundtrip`、`editor_project_package`、`editor_project_v2`、`editor_project_legacy`、`editor_sources_built`、`editor_gl_debt_guard`、`editor_platform_owner_guard`、`editor_single_owner_guard`、`editor_model`、`editor_scene_io`、`editor_shell_domains`、`editor_scene_io_owner_guard`、`editor_scene_authoring`、`editor_scene_authoring_owner_guard`、`editor_scene_history`、`editor_domains`、`editor_project_container`、`editor_cxx_surface_guard`。未挂标签的 editor 域测试：`editor_scene_prefab`。
- 说明：任务背景记"41 项"，README 1.0 记 41，`EDITOR_PARITY.md` 记 42/42；本次以实测 42 为准。差异来自 runtime/UIM/player 子工程随当前配置纳入的测试集合。

### 5.4 依赖链接方式确认

**zcsr_editor ↔ UIM**
- 链接方式：**源码 `add_subdirectory`**，不是 install 包。链路：`zcsr_editor/CMakeLists.txt:31` `add_subdirectory(${ZCSR_RUNTIME_DIR})` → `zcsr_runtime/CMakeLists.txt:39` `add_subdirectory(${ZCSR_UIM_DIR})`。
- 引入的 UIM 目标：`zcsr_uim`（含 `zcsr_uim_component`/`zcsr_uim_core`）、`zcsr_uim_project`、`zcsr_uim_page_view`、`zcsr_uim_zcsr_bridge`；kernel PUBLIC 链接 `zcsr_uim`。
- 头文件路径：kernel 与 app 均追加 `${ZCSR_UIM_DIR}/include`。
- UIM 仓库实测存在于 `C:\Users\chen\Documents\GitHub\UIM`，CMake 目标与上述一致。

**PVZ ↔ zcsr_editor（现状，读 `C:\Users\chen\Documents\PVZ\CMakeLists.txt`）**
- 链接方式：**直接把 zcsr_editor 源文件编进 PVZ 自己的静态库**，未 `add_subdirectory(zcsr_editor)`、未用 install 包。
  - `zcsr_editor_shell` 静态库（`:263-266`）：编译 `ui_editor_workspace.c` + `ui_editor_shell.c`；include `${ZCSR_EDITOR_DIR}/include` 与 `${ZCSR_UIM_DIR}/include`。
  - `pvz_editor_app` 静态库（`:280-291`）：额外编译 UIM `uim_text_input.c`、`uim_file_service.c`，以及 zcsr_editor 的 `ui_project_browser.c`、`ui_editor_file_service_host.c`。
  - 链接库（`:293-305`）：`pvz_sim`、`zcsr_editor_shell`、`zcsr_runtime_shell`、`zcsr_glrender`、`zcsr_platform`、`zcsr_input`、`zcsr_inputext`、`zcsr_image`、`zcsr_font`、`zcsr_core`、`zcsr_file_service`。
- **未链接**：`zcsr_editor_kernel`、`zcsr_editor_host`、`zcsr_uim`（manager）、`zcsr_uim_project`、`zcsr_scene`、`zcsr_scene_io`、ImGui 目标。
- 缓存解析路径（`PVZ/build/CMakeCache.txt`）：`ZCSR_EDITOR_DIR=C:/Users/chen/Documents/GitHub/zcsr_editor`，`ZCSR_UIM_DIR=C:/Users/chen/Documents/GitHub/UIM`，`ZCSR_RUNTIME_DIR=.../zcsr_runtime`，`ZCSR_DIR=.../zero-coupling-signal-router`。
- PVZ 本地 stub（`src/pvz_editor_shell.c:357-377`）：为满足已编译 workspace/shell 中对 `uir_editor_get_canvas_state` / `uir_editor_set_canvas_state` / `uir_editor_zoom_at` / `uir_editor_pan` 的转发引用（`ui_editor_workspace.c:523-539`）而写的空实现；这四个函数本属于 kernel `uim_Editor`，PVZ 没有链接 kernel，故以 stub 占位。接入阶段 2 后这些 stub 应由真实 adapter 取代。

## 6. 风险清单（接入后可能破坏 zcsr_editor 现有行为的点）

1. **共享全局状态**
   - `editor_app.cpp` 内全局单例 `EditorApp g`（`:139`），另有 `g_node_serial`、`g_last_time`、`g_smoke_frames`/`g_frame_count` 等文件级静态；测试 hook（`ZCSR_EDITOR_KEY_TEST`）直接读写 `g`。
   - kernel C 域本身是实例作用域（`uim_Editor*`/`uim_Hierarchy*`/`uim_ProjectBrowser*` 等外部持有），但 `ui_editor.c` 内历史/选择/元数据在 `uim_Editor` 内堆分配；拆分时禁止把这些状态提升成文件级全局。
   - PVZ 侧 `g_editor` 单例与 zcsr `g` 若同进程共存，必须隔离在各自模块内，不得共享 manager/history/浏览器实例。

2. **ImGui 上下文**
   - 上下文在 `init_cb` 创建（`:4557`）、`shutdown_cb` 销毁（`:4614`）；`editor_key_contract` 测试也自建上下文。任何嵌入方式都必须保证一个进程只有一个 ImGui context、`NewFrame/Render` 配对；PVZ 不引入 ImGui 时不得触碰该上下文。

3. **窗口 / 事件循环**
   - 窗口、表面、帧循环、输入归 `zcsr_runtime_shell`；模块只能注册 `zcsr_runtime_shell_module` 回调（`runtime()` `:4658-4670`）。禁止第二套消息泵/表面；`editor_host_win32.c` 是唯一允许直接碰 Win32 窗口的 C 层。
   - 键事件路由：宿主 `key_cb` 自己占有 Escape/S（`:4517-4524`）；PVZ 模块若共用同一 shell，快捷键归属需明确，避免互相吞键。

4. **主题 / DPI / 字体**
   - DPI 唯一来源是 engine 平台表面 `zcsr_surface_get_dpi_scale`（`:4547-4554`）；ImGui 样式度量随 DPI 缩放。kernel 侧主题是 token/矩形数据；PVZ GL 后端需自行把 token 映射到自有配色与字号，不能假定 ImGui 样式存在。
   - 字体 atlas 由 ImGui OpenGL3 后端构建；headless 测试显式建默认 atlas（`:4686-4688`）。

5. **持久化路径与产物位置**
   - 演示工程路径按 exe 上级目录 `demo/rule_demo.uireproj` 推断（`:4603-4605`）；项目/场景/资产相对路径基于项目根。
   - Preferences 目前是会话内存设置，不跨进程持久化（见 `EDITOR_PARITY.md:34`）；自动保存只对已有路径生效。接入时不得依赖"偏好已落盘"。
   - 布局持久化 blob 由 `ui_editor_shell_persist.c` 序列化；格式版本需在两端一致，旧 blob 要能容错回退。

6. **UIM manager 生命周期与线程**
   - manager 由宿主 `uim_component_manager_create` 创建（`:1228`）、随文档销毁；kernel receiver 指针不持有所有权。adapter 化后必须明确创建/销毁顺序：先建 manager/文档 → 建 editor/hierarchy → 销毁顺序反向。
   - 当前未做并发隔离；接入后不得让 PVZ 模拟线程触碰编辑模型。

7. **固定容量与堆策略**
   - shell 面板/命令/元素、浏览器节点（256）、历史深度等均为固定上限；kernel 部分路径 malloc（如 `box_select` 数组）。复用前需复核 PVZ 文档规模是否超容量，错误码路径（`uim_ERR_RANGE/NOMEM/STATE`）要在 adapter 中如实上抛。

8. **架构守卫测试（接入时最容易被打破）**
   - `editor_gl_debt_guard`：kernel C 源不得直连 GL/OS。
   - `editor_platform_owner_guard`：Win32/commdlg 只允许在 host 层。
   - `editor_single_owner_guard` / `editor_scene_io_owner_guard` / `editor_scene_authoring_owner_guard`：所有权边界。
   - `editor_cxx_surface_guard`：产品 C++ 核心仅 1 个 `.cpp`，行数 ≤5000；新增 C++ 表现层会触线。
   - 任何抽取/适配都必须保持这些脚本通过；新增抽象优先落在 C11。

9. **格式兼容**
   - `.uiscene` 文本场景格式由 engine `zcsr_scene_io` 单一 schema；`.uiproj` 容器、`.uirassets` 注册表、prefab FNV-1a id 均已被测试锁定。PVZ 若复用这些文件，版本与校验规则必须跟随上游，不能私改写入端。

## 附录 A：测试 ↔ 能力映射（editor 域 23 项，其中 22 项挂 editor 标签，`editor_scene_prefab` 未挂标签）

| 测试目标 | 覆盖能力 | 被测对象 |
|---|---|---|
| `editor_key_contract` | 输入/快捷键路径（headless ImGui 上下文） | `editor_app.cpp` + kernel |
| `editor_host` | 平台宿主 ABI 契约 | `editor_host_win32.c` |
| `editor_page_runtime` | UIM 页面运行时 tick/暂停/步进/快照/注册表描述符 | UIM manager |
| `editor_runtime_state` | 快照恢复 + 3D 投影拾取 | UIM manager + engine |
| `editor_project_roundtrip/package/v2/legacy` | UIM 项目字节格式回归 | `zcsr_uim_project` |
| `editor_sources_built` | 源码构建清单守卫 | CMake 源列表 |
| `editor_gl_debt_guard` | kernel 无 GL/OS 直连守卫 | 脚本扫描 |
| `editor_platform_owner_guard` | Win32 归属守卫 | 脚本扫描 |
| `editor_single_owner_guard` | 单 owner 守卫 | 脚本扫描 |
| `editor_model` | 选择/移动/命中/手势/撤销重做/删除/复制/缩放/组件属性 | `ui_editor.c` |
| `editor_scene_io` | 场景序列化往返/坏输入/空场景/文件 | `editor_scene_io.c` + engine scene_io |
| `editor_shell_domains` | workspace/shell/persist/viewport host/browser | 各 C 域 |
| `editor_scene_io_owner_guard` | 场景 IO 所有权守卫 | 脚本扫描 |
| `editor_scene_authoring` | 场景盒/四边形/复制/移动/删除/资产属性 | `editor_scene_authoring.c` |
| `editor_scene_authoring_owner_guard` | 场景命令所有权守卫 | 脚本扫描 |
| `editor_scene_prefab` | prefab 保存/实例化/回滚 | `editor_scene_prefab.c` |
| `editor_scene_history` | 场景快照撤销/重做/基线/哈希 | `editor_scene_history.c` |
| `editor_domains` | 层级行展开/折叠/过滤 + 交互状态机 | `ui_hierarchy.c`、`ui_editor_interaction.c` |
| `editor_project_container` | `.uiproj` 打包/拆包/坏输入/上限 | `editor_project_container.c` |
| `editor_cxx_surface_guard` | C++ 表面规模/数量守卫 | 脚本扫描 |

未被 headless 测试覆盖：Inspector 多选/抽屉/资产选择控件、UI 与场景 Gizmo、`uir_editor_canvas_box_select` marquee 模型路径、资产注册表面板、场景相机编辑 UI、Console/Preferences UI。
