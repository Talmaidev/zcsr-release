# Guard: every src/*.c must be referenced by CMakeLists (a target), and no
# attic/*.c may be referenced. Run with:
#   cmake -DROOT=<repo> -P tools/check_sources_built.cmake
if(NOT DEFINED ROOT)
  message(FATAL_ERROR "ROOT is required")
endif()

file(READ "${ROOT}/CMakeLists.txt" cmake_txt)

file(GLOB src_files "${ROOT}/src/*.c")
foreach(src ${src_files})
  get_filename_component(name "${src}" NAME)
  string(FIND "${cmake_txt}" "src/${name}" pos)
  if(pos EQUAL -1)
    message(FATAL_ERROR "Source is not in any target: src/${name}")
  endif()
endforeach()

file(GLOB attic_files "${ROOT}/attic/*.c")
foreach(src ${attic_files})
  get_filename_component(name "${src}" NAME)
  string(FIND "${cmake_txt}" "attic/${name}" pos)
  if(NOT pos EQUAL -1)
    message(FATAL_ERROR "Attic source is referenced by CMake: attic/${name}")
  endif()
endforeach()

list(LENGTH src_files src_count)
message(STATUS "sources_built PASS (${src_count} sources)")
