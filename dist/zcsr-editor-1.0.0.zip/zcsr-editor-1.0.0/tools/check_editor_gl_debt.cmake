# Guard: editor chrome must not grow direct ZCSR GL drawing debt.
# The product chrome is Dear ImGui + one offscreen page texture; it may use
# glViewport/glClear for the texture target, but not a second hand-drawn UI.
# Run with: cmake -DROOT=<repo> -P tools/check_editor_gl_debt.cmake
if(NOT DEFINED ROOT)
  message(FATAL_ERROR "ROOT is required")
endif()

set(editor_app "${ROOT}/src/editor_app.cpp")
if(NOT EXISTS "${editor_app}")
  message(FATAL_ERROR "Missing ${editor_app}")
endif()

file(READ "${editor_app}" content)
string(REGEX MATCHALL "zcsr_gl_(fill_rect|draw_rect|draw_text|scissor)" matches "${content}")
list(LENGTH matches count)

set(BASELINE 0)
if(count GREATER BASELINE)
  message(FATAL_ERROR "editor direct GL chrome grew: ${count} > ${BASELINE}")
endif()
message(STATUS "editor_gl_debt PASS (${count} <= ${BASELINE})")
