# Guard: editor product code must not regress to direct OS/GL coupling.
# The platform boundary is editor_host.h + one backend per desktop OS.
if(NOT DEFINED ROOT)
  message(FATAL_ERROR "ROOT is required")
endif()

set(app "${ROOT}/src/editor_app.cpp")
file(READ "${app}" app_txt)

set(forbidden
  "windows.h"
  "commdlg.h"
  "GL/gl.h"
  "HWND"
  "MessageBoxW"
  "CreateProcessW"
  "GetTickCount64"
  "GetOpenFileNameW"
  "GetSaveFileNameW"
  "zcsr_surface_native_handle"
  "glViewport"
  "glClearColor"
  "glClear(")

foreach(token ${forbidden})
  string(FIND "${app_txt}" "${token}" pos)
  if(NOT pos EQUAL -1)
    message(FATAL_ERROR "editor_app.cpp contains forbidden platform token '${token}'. Move it into editor_host.")
  endif()
endforeach()

string(FIND "${app_txt}" "#include \"editor_host.h\"" host_include)
if(host_include EQUAL -1)
  message(FATAL_ERROR "editor_app.cpp must include editor_host.h.")
endif()

file(READ "${ROOT}/CMakeLists.txt" cmake_txt)
foreach(source "src/editor_host_win32.c" "src/editor_host_posix.c" "src/editor_host_cocoa.m")
  string(FIND "${cmake_txt}" "${source}" source_pos)
  if(source_pos EQUAL -1)
    message(FATAL_ERROR "CMakeLists.txt does not reference ${source}.")
  endif()
endforeach()
string(FIND "${cmake_txt}" "zcsr_editor_host" host_target)
if(host_target EQUAL -1)
  message(FATAL_ERROR "CMakeLists.txt does not define zcsr_editor_host.")
endif()

message(STATUS "editor_platform_owner_guard PASS")
