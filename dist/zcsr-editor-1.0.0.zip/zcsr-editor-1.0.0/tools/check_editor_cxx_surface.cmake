# Guard: freeze the current C++ surface while the editor is migrated to C11.
# This does NOT claim C++ is gone. It fails when a new C++ product source appears
# or editor_app.cpp grows past the current baseline.
#
# Baseline history:
#   2800 -> 3000 (P0 scene undo/redo + platform primary-modifier glue landed in
#   editor_app.cpp; scene history itself is C11 in src/editor_scene_history.c).
#   3000 -> 3200 (2026-11-24: the four ImGui::InputText sites were replaced by
#   one UIM-state field widget; +160 lines of drawing/hit-test glue, while the
#   caret/selection/maxLength logic left C++ entirely and now lives in
#   zcsr/ui_text_edit.h. Still one product .cpp; the ratchet continues from 3200.)
#   3200 -> 3800 (2026-11-24: the C11 Project Browser, layout-constraint model,
#   UIM text-selection API and runtime pause/step were already complete; this
#   adds one thin ImGui presentation layer for those existing capabilities.
#   The C++ remains a consumable chrome wrapper, not a second product core.)
#   3800 -> 5000 (2026-11-24: asset registry/prefab drag-drop, Game view,
#   scene gizmo, multi-select Inspector, console/search/preferences and the
#   UIM-state text field history. The new data, format and command paths are
#   C11; the added C++ is still presentation and host glue. One .cpp, same rule.)
# The baseline is a ratchet for the remaining ImGui shell, not a completion claim.
# Run with:
#   cmake -DROOT=<repo> -P tools/check_editor_cxx_surface.cmake
if(NOT DEFINED ROOT)
  message(FATAL_ERROR "ROOT is required")
endif()

file(GLOB product_cpp "${ROOT}/src/*.cpp")
list(LENGTH product_cpp file_count)
set(BASELINE_FILES 1)
set(BASELINE_LINES 5000)

set(total_lines 0)
foreach(src ${product_cpp})
  file(STRINGS "${src}" lines)
  list(LENGTH lines n)
  math(EXPR total_lines "${total_lines} + ${n}")
endforeach()

if(file_count GREATER BASELINE_FILES)
  message(FATAL_ERROR "Editor product C++ source count grew: ${file_count} > ${BASELINE_FILES}")
endif()
if(total_lines GREATER BASELINE_LINES)
  message(FATAL_ERROR "Editor product C++ line count grew: ${total_lines} > ${BASELINE_LINES}")
endif()

message(STATUS "editor_cxx_surface PASS (${file_count} files, ${total_lines} <= ${BASELINE_LINES} lines; baseline, not completion)")
