# Guard: freeze the current duplicate-owner baseline in the editor product.
# It does NOT claim the debt is fixed; it fails when a new window loop, shell
# instance, or history owner is added while the P0-P4 migration is in progress.
# Run with:
#   cmake -DROOT=<repo> -P tools/check_editor_single_owner.cmake
if(NOT DEFINED ROOT)
  message(FATAL_ERROR "ROOT is required")
endif()

file(GLOB src_files "${ROOT}/src/*.c")

function(count_occurrences out pattern)
  set(total 0)
  foreach(src ${src_files})
    file(READ "${src}" text)
    string(REGEX MATCHALL "${pattern}" hits "${text}")
    list(LENGTH hits n)
    math(EXPR total "${total} + ${n}")
  endforeach()
  set(${out} ${total} PARENT_SCOPE)
endfunction()

# 现在的产品路径只有一个 owner：zcsr_runtime_shell 拥有 surface 与主循环。
# editor_host/player_mode 只能作为 module 存在；一旦 src 里再出现 second
# surface/main-loop，构建即失败。
count_occurrences(surface_creates "zcsr_surface_create")
count_occurrences(main_loops "while[ \t]*\\(running\\)")
if(surface_creates GREATER 0)
  message(FATAL_ERROR "Editor src has ${surface_creates} zcsr_surface_create sites; only zcsr_runtime_shell may own a window")
endif()
if(main_loops GREATER 0)
  message(FATAL_ERROR "Editor src has ${main_loops} main loops; only zcsr_runtime_shell may own the loop")
endif()

# Exactly zero editor-shell owners. The 8-panel shell is a harness in the
# static test library, not product chrome.
count_occurrences(shell_types "uim_EditorShell[ \t]+g_shell")
count_occurrences(shell_inits "uir_editor_shell_init_default\\(&")
if(shell_types GREATER 0)
  message(FATAL_ERROR "Editor src has ${shell_types} uim_EditorShell instances; product must not instantiate the 8-panel shell")
endif()
if(shell_inits GREATER 0)
  message(FATAL_ERROR "Editor src has ${shell_inits} shell init sites; product must not instantiate the 8-panel shell")
endif()

# History is single-owner: one document snapshot ring (g_history). Property
# undo and command stack are archived; adding either back is a regression.
count_occurrences(cmd_stacks "uir_CommandStack[ \t]+g_cmd")
count_occurrences(snapshot_rings "EditorSnapshot[ \t]+g_history\\[")
count_occurrences(property_undos "uim_UndoRedo[ \t]*\\*[ \t]*g_undo")
math(EXPR history_owners "${cmd_stacks} + ${snapshot_rings} + ${property_undos}")
if(history_owners GREATER 1)
  message(FATAL_ERROR "Editor has ${history_owners} history owners; only g_history may remain")
endif()

message(STATUS "editor_single_owner PASS (surface=${surface_creates}, loop=${main_loops}, shell=${shell_types}, history=${history_owners})")
