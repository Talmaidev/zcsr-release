# Guard: scene mutations must go through C11 editor_scene_authoring.c.
# Read-only scene queries may remain in the shell.
# Run with:
#   cmake -DROOT=<repo> -P tools/check_editor_scene_authoring_owner.cmake
if(NOT DEFINED ROOT)
  message(FATAL_ERROR "ROOT is required")
endif()

set(c_owner "${ROOT}/src/editor_scene_authoring.c")
set(cpp_shell "${ROOT}/src/editor_app.cpp")
if(NOT EXISTS "${c_owner}")
  message(FATAL_ERROR "Missing C11 scene authoring owner: src/editor_scene_authoring.c")
endif()
if(NOT EXISTS "${cpp_shell}")
  message(FATAL_ERROR "Missing editor shell: src/editor_app.cpp")
endif()

file(READ "${cpp_shell}" cpp_text)
foreach(token "zcsr_scene_add(" "zcsr_scene_remove(" "zcsr_scene_set_quad(" "zcsr_scene_clear_quad(")
  string(FIND "${cpp_text}" "${token}" pos)
  if(NOT pos EQUAL -1)
    message(FATAL_ERROR "editor_app.cpp still mutates scene directly: ${token}")
  endif()
endforeach()

file(READ "${ROOT}/CMakeLists.txt" cmake_text)
string(FIND "${cmake_text}" "src/editor_scene_authoring.c" cmake_pos)
if(cmake_pos EQUAL -1)
  message(FATAL_ERROR "editor_scene_authoring.c is not referenced by CMakeLists.txt")
endif()

file(READ "${c_owner}" c_text)
string(FIND "${c_text}" "zcsr_editor_scene_add_box" owner_pos)
if(owner_pos EQUAL -1)
  message(FATAL_ERROR "editor_scene_authoring.c does not expose add_box")
endif()

message(STATUS "editor_scene_authoring_owner PASS")
