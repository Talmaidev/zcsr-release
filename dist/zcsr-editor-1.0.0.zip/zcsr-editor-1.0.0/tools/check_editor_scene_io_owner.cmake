# Guard: the `.uiscene` schema is owned by C11 engine scene_io; the editor
# keeps only a thin C11 name adapter. It must not drift back into editor_app.cpp
# or a C++ translation unit.
# Run with:
#   cmake -DROOT=<repo> -P tools/check_editor_scene_io_owner.cmake
if(NOT DEFINED ROOT)
  message(FATAL_ERROR "ROOT is required")
endif()

set(c_owner "${ROOT}/src/editor_scene_io.c")
set(cpp_owner "${ROOT}/src/editor_app.cpp")
set(engine_owner "${ROOT}/../zero-coupling-signal-router/modules/scene_io/scene_io.c")
set(engine_header "${ROOT}/../zero-coupling-signal-router/include/zcsr/scene_io.h")
if(NOT EXISTS "${c_owner}")
  message(FATAL_ERROR "Missing C11 scene IO adapter: src/editor_scene_io.c")
endif()
if(NOT EXISTS "${cpp_owner}")
  message(FATAL_ERROR "Missing editor app: src/editor_app.cpp")
endif()
if(NOT EXISTS "${engine_owner}" OR NOT EXISTS "${engine_header}")
  message(FATAL_ERROR "Missing engine scene IO owner: modules/scene_io/scene_io.c")
endif()

file(READ "${c_owner}" c_text)
string(FIND "${c_text}" "zcsr_scene_io_" adapter)
if(adapter EQUAL -1)
  message(FATAL_ERROR "editor_scene_io.c must delegate to zcsr_scene_io")
endif()

file(READ "${engine_owner}" engine_text)
string(FIND "${engine_text}" "ZCSRSCENE 1" marker_v1)
string(FIND "${engine_text}" "ZCSRSCENE 2" marker_v2)
if(marker_v1 EQUAL -1 OR marker_v2 EQUAL -1)
  message(FATAL_ERROR "engine scene_io.c does not own both ZCSRSCENE markers")
endif()

file(READ "${cpp_owner}" cpp_text)
foreach(token "_wfopen" "ZCSRSCENE 1" "ZCSRSCENE 2" "std::fgets" "std::sscanf")
  string(FIND "${cpp_text}" "${token}" pos)
  if(NOT pos EQUAL -1)
    message(FATAL_ERROR "editor_app.cpp still owns scene IO token: ${token}")
  endif()
endforeach()

file(READ "${ROOT}/CMakeLists.txt" cmake_text)
string(FIND "${cmake_text}" "src/editor_scene_io.c" cmake_pos)
if(cmake_pos EQUAL -1)
  message(FATAL_ERROR "editor_scene_io.c is not referenced by CMakeLists.txt")
endif()

message(STATUS "editor_scene_io_owner PASS")
