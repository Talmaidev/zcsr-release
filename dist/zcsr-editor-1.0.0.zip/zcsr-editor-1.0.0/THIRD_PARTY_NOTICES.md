# Third-Party Notices

The repository's own source code is licensed under AGPL-3.0 (see `LICENSE`).
The following vendored component keeps its original license.
AGPL-3.0 does not replace, relicense, or override those terms.

| Component | License | Location / notice |
| --- | --- | --- |
| Dear ImGui | MIT | `third_party/imgui/LICENSE.txt` |

When redistributing binaries, keep the applicable license text and notice next
to the binary package.
