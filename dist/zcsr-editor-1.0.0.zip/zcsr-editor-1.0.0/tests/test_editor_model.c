/* test_editor_model.c — headless proof that ui_editor.c is a real editor model.
 * This is the gate the old code never had: manager -> page -> node -> editor
 * selection -> move/undo/redo -> pointer gesture -> delete/duplicate. */
#include "ui_editor.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fail(const char *message)
{
    fprintf(stderr, "FAIL: %s\n", message);
    return 1;
}

static int make_node(UIM_ComponentManager *manager, uim_PageId page, uim_NodeId parent,
                     const char *key, float x, float y, float w, float h,
                     uim_NodeId *out)
{
    uim_NodeDesc desc;
    memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.parent_id = parent;
    desc.stable_key = key;
    desc.local_rect = (uim_Rect){ x, y, w, h };
    desc.visible = true;
    desc.enabled = true;
    return uim_node_create(manager, &desc, out);
}

static int node_rect(UIM_ComponentManager *manager, uim_NodeId id,
                     float *x, float *y)
{
    uim_NodeInfo info;
    uim_Result rc = uim_node_get(manager, id, &info);
    if (rc != uim_OK) return (int)rc;
    *x = info.local_rect.x;
    *y = info.local_rect.y;
    return 0;
}

int main(void)
{
    UIM_ComponentManagerConfig config;
    UIM_ComponentManager *manager = NULL;
    uim_Editor *editor = NULL;
    uim_EditorCanvasState canvas;
    uim_EditorHistoryState history;
    uim_EditorSelection selection;
    uim_NodeId page = 0u, root = 0u, button = 0u, duplicate = 0u, hit = 0u;
    float x = 0.0f, y = 0.0f;

    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 2u;
    config.initial_node_capacity = 8u;
    if (uim_component_manager_create(&config, &manager) != uim_OK)
        return fail("manager create");
    if (uim_page_create(manager, "main", &page) != uim_OK)
        return fail("page create");
    if (make_node(manager, page, 0u, "root", 0.0f, 0.0f, 800.0f, 600.0f, &root) != uim_OK)
        return fail("root create");
    if (make_node(manager, page, root, "button", 100.0f, 100.0f, 120.0f, 60.0f, &button) != uim_OK)
        return fail("button create");
    if (uir_editor_create(manager, 8u, &editor) != uim_OK)
        return fail("editor create");

    memset(&canvas, 0, sizeof(canvas));
    canvas.viewport = (uim_Rect){ 0.0f, 0.0f, 800.0f, 600.0f };
    canvas.zoom = 1.0f;
    canvas.grid_size = 16.0f;
    canvas.show_grid = true;
    if (uir_editor_set_canvas_state(editor, &canvas) != uim_OK)
        return fail("canvas state");
    if (uir_editor_set_active_page(editor, page) != uim_OK)
        return fail("active page");

    if (uir_editor_canvas_hit_test(editor, page, 160.0f, 130.0f, &hit) != uim_OK || hit != button)
        return fail("hit test");

    if (uir_editor_select(editor, &button, 1u) != uim_OK)
        return fail("select");
    if (uir_editor_get_selection(editor, &selection) != uim_OK ||
        selection.count != 1u || selection.ids[0] != button)
        return fail("selection contents");

    if (uir_editor_move_node(editor, button, 20.0f, 10.0f) != uim_OK)
        return fail("move");
    if (node_rect(manager, button, &x, &y) || x != 120.0f || y != 110.0f)
        return fail("move result");
    if (uir_editor_get_history_state(editor, &history) != uim_OK ||
        history.undo_count != 1u || history.redo_count != 0u)
        return fail("history after move");

    if (uir_editor_undo(editor) != uim_OK)
        return fail("undo move");
    if (node_rect(manager, button, &x, &y) || x != 100.0f || y != 100.0f)
        return fail("undo move result");
    if (uir_editor_redo(editor) != uim_OK)
        return fail("redo move");
    if (node_rect(manager, button, &x, &y) || x != 120.0f || y != 110.0f)
        return fail("redo move result");

    /* Pointer gesture: down/move/up must be one atomic undo entry. */
    if (uir_editor_canvas_pointer_down(editor, page, 160.0f, 130.0f, 0u) != uim_OK)
        return fail("pointer down");
    if (uir_editor_canvas_pointer_move(editor, 200.0f, 150.0f) != uim_OK)
        return fail("pointer move");
    if (uir_editor_canvas_pointer_up(editor, 200.0f, 150.0f) != uim_OK)
        return fail("pointer up");
    if (node_rect(manager, button, &x, &y) || x != 160.0f || y != 130.0f)
        return fail("gesture move result");
    if (uir_editor_get_history_state(editor, &history) != uim_OK ||
        history.undo_count != 2u)
        return fail("gesture history");
    if (uir_editor_undo(editor) != uim_OK)
        return fail("undo gesture");
    if (node_rect(manager, button, &x, &y) || x != 120.0f || y != 110.0f)
        return fail("undo gesture result");

    /* Delete and undo/redo must restore the node identity, not a copy. */
    if (uir_editor_delete_node(editor, button) != uim_OK)
        return fail("delete");
    {
        uim_NodeInfo info;
        if (uim_node_get(manager, button, &info) != uim_ERR_NOT_FOUND)
            return fail("delete did not remove node");
    }
    if (uir_editor_undo(editor) != uim_OK)
        return fail("undo delete");
    if (uir_editor_get_selection(editor, &selection) != uim_OK ||
        selection.count != 1u)
        return fail("undo delete selection");
    button = selection.ids[0]; /* delete/undo restores a new NodeId */
    if (node_rect(manager, button, &x, &y) || x != 120.0f || y != 110.0f)
        return fail("undo delete result");
    if (uir_editor_redo(editor) != uim_OK)
        return fail("redo delete");
    {
        uim_NodeInfo info;
        if (uim_node_get(manager, button, &info) != uim_ERR_NOT_FOUND)
            return fail("redo delete did not remove node");
    }

    if (uir_editor_undo(editor) != uim_OK)
        return fail("undo delete again");
    if (uir_editor_get_selection(editor, &selection) != uim_OK ||
        selection.count != 1u)
        return fail("undo delete again selection");
    button = selection.ids[0];
    if (uir_editor_select(editor, &button, 1u) != uim_OK)
        return fail("select before duplicate");
    if (uir_editor_duplicate_node(editor, button, 16.0f, 16.0f, &duplicate) != uim_OK ||
        duplicate == 0u)
        return fail("duplicate");
    if (uir_editor_undo(editor) != uim_OK)
        return fail("undo duplicate");
    {
        uim_NodeInfo info;
        if (uim_node_get(manager, duplicate, &info) != uim_ERR_NOT_FOUND)
            return fail("undo duplicate did not remove copy");
    }

    /* A full-page child must win over its root at the same point. This is the
     * "click selects bg instead of the node under the cursor" regression. */
    {
        uim_NodeId background = 0u;
        if (make_node(manager, page, root, "background", 0.0f, 0.0f, 800.0f, 600.0f,
                      &background) != uim_OK)
            return fail("background create");
        if (uir_editor_canvas_hit_test(editor, page, 400.0f, 300.0f, &hit) != uim_OK ||
            hit != background)
            return fail("background hit test");
    }

    /* Component attach/property/detach must be undoable. */
    {
        uim_NodeId component_node = 0u;
        uim_ComponentInstanceId instance = 0u;
        uim_Value value;
        uim_Value read_back;
        size_t component_count = 0u;
        if (make_node(manager, page, root, "component_node", 0.0f, 0.0f, 40.0f, 40.0f,
                      &component_node) != uim_OK)
            return fail("component node create");
        if (uim_component_instance_attach(manager, component_node, 0x00010003u, 1u,
                                           &instance) != uim_OK)
            return fail("component attach");
        memset(&value, 0, sizeof(value));
        value.type = uim_VALUE_INT64;
        value.as.integer = 7;
        if (uir_editor_component_set_property(editor, NULL, instance, 1u, value) != uim_OK)
            return fail("component property set through editor");
        if (uir_editor_undo(editor) != uim_OK)
            return fail("undo component property");
        memset(&read_back, 0, sizeof(read_back));
        if (uim_component_instance_get_property(manager, instance, 1u, &read_back) !=
                uim_ERR_NOT_FOUND)
            return fail("undo component property did not restore absence");
        if (uir_editor_redo(editor) != uim_OK)
            return fail("redo component property");
        if (uim_component_instance_get_property(manager, instance, 1u, &read_back) != uim_OK ||
            read_back.type != uim_VALUE_INT64 || read_back.as.integer != 7)
            return fail("redo component property value");
        if (uir_editor_component_detach(editor, instance) != uim_OK)
            return fail("component detach through editor");
        if (uim_node_component_count(manager, component_node, &component_count) != uim_OK ||
            component_count != 0u)
            return fail("component detach result");
        if (uir_editor_undo(editor) != uim_OK)
            return fail("undo component detach");
        if (uim_node_component_count(manager, component_node, &component_count) != uim_OK ||
            component_count != 1u)
            return fail("undo component detach count");
        if (uim_component_instance_get_property(manager, instance, 1u, &read_back) != uim_OK ||
            read_back.as.integer != 7)
            return fail("undo component detach did not restore value");
    }

    /* Right-edge handle must resize without stealing selection to the parent. */
    {
        uim_NodeId resize_node = 0u;
        uim_EditorSelection sel = {0};
        uim_EditorCanvasState canvas = {0};
        uim_NodeInfo info;
        if (make_node(manager, page, root, "resize_node", 100.0f, 100.0f, 120.0f, 60.0f,
                      &resize_node) != uim_OK)
            return fail("resize node create");
        canvas.viewport = (uim_Rect){0.0f, 0.0f, 960.0f, 600.0f};
        canvas.zoom = 1.0f;
        if (uir_editor_set_canvas_state(editor, &canvas) != uim_OK)
            return fail("resize canvas state");
        if (uir_editor_select(editor, &resize_node, 1u) != uim_OK)
            return fail("resize select");
        if (uir_editor_canvas_pointer_down(editor, page, 220.0f, 130.0f, 0u) != uim_OK)
            return fail("resize pointer down");
        if (uir_editor_canvas_pointer_move(editor, 260.0f, 130.0f) != uim_OK)
            return fail("resize pointer move");
        if (uir_editor_canvas_pointer_up(editor, 260.0f, 130.0f) != uim_OK)
            return fail("resize pointer up");
        if (uir_editor_inspect_node(editor, resize_node, &info) != uim_OK ||
            fabsf(info.local_rect.width - 160.0f) > 0.01f)
            return fail("resize width");
        if (uir_editor_get_selection(editor, &sel) != uim_OK || sel.count != 1u ||
            sel.ids[0] != resize_node)
            return fail("resize selection drift");
    }

    uir_editor_destroy(editor);
    uim_component_manager_destroy(manager);
    puts("editor_model: PASS");
    return 0;
}
