﻿#include "uim_project.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(_WIN32)
#  include <direct.h>
#  include <io.h>
#  include <process.h>
#  define TEST_MKDIR(p) _mkdir(p)
#else
#  include <sys/stat.h>
#  include <sys/types.h>
#  include <unistd.h>
#  define TEST_MKDIR(p) mkdir((p), 0777)
#endif

static int fail(const char *message) {
    fprintf(stderr, "FAIL: %s\n", message);
    return 1;
}

static bool test_file_exists(const char *path) {
#if defined(_WIN32)
    return _access(path, 0) == 0;
#else
    return access(path, F_OK) == 0;
#endif
}

static int make_temp_dir(char *out, size_t cap) {
#if defined(_WIN32)
    int pid = _getpid();
    snprintf(out, cap, "editor_project_test_%d", pid);
#else
    int pid = (int)getpid();
    snprintf(out, cap, "editor_project_test_%d", pid);
#endif
    TEST_MKDIR(out);
    return 0;
}

static int test_roundtrip(void) {
    char dir[256];
    char path[512];
    char loaded_name[UIR_PROJECT_NAME_CAP];
    char loaded_root_path[UIR_PROJECT_PATH_CAP];
    UIM_ComponentManager *manager = NULL;
    UIM_ComponentManager *loaded = NULL;
    UIM_ComponentManagerConfig config;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = 0u;
    uim_NodeId button = 0u;
    uim_NodeId loaded_root = 0u;
    uim_NodeId loaded_button = 0u;
    uim_PageId loaded_page = uim_PAGE_INVALID;
    uim_NodeInfo info;
    uim_ComponentInstanceInfo instance;
    uim_ComponentInstanceId instance_id = uim_COMPONENT_INSTANCE_INVALID;
    unsigned char payload[3] = { 1u, 2u, 3u };
    size_t instance_count = 0u;
    int rc;
    uim_PageId second_page = uim_PAGE_INVALID;
    uim_PageId loaded_second = uim_PAGE_INVALID;
    size_t loaded_pages = 0u;
    uim_NodeId second_root = 0u;

    make_temp_dir(dir, sizeof(dir));
    snprintf(path, sizeof(path), "%s/roundtrip.uireproj", dir);
    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 2u;
    config.initial_node_capacity = 4u;
    if (uim_component_manager_create(&config, &manager) != uim_OK) return fail("manager create");
    if (uim_page_create(manager, "main", &page) != uim_OK) return fail("page create");
    if (uim_page_create(manager, "second", &second_page) != uim_OK) return fail("second page create");
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.stable_key = "root";
        desc.component_id = 0u;
        desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 1280.0f, 800.0f };
        desc.visible = true;
        desc.enabled = true;
        if (uim_node_create(manager, &desc, &root) != uim_OK) return fail("root create");
    }
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = second_page;
        desc.stable_key = "second_root";
        desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 640.0f, 480.0f };
        desc.visible = true;
        desc.enabled = true;
        if (uim_node_create(manager, &desc, &second_root) != uim_OK) return fail("second root create");
    }
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.parent_id = root;
        desc.stable_key = "button";
        desc.component_id = 7u;
        desc.local_rect = (uim_Rect){ 10.0f, 20.0f, 100.0f, 40.0f };
        desc.layout.enabled = true;
        desc.layout.anchor_min_x = 0.5f;
        desc.layout.anchor_min_y = 0.5f;
        desc.layout.anchor_max_x = 0.5f;
        desc.layout.anchor_max_y = 0.5f;
        desc.layout.offset_left = -50.0f;
        desc.layout.offset_top = -20.0f;
        desc.layout.offset_right = -50.0f;
        desc.layout.offset_bottom = -20.0f;
        desc.visible = true;
        desc.enabled = false;
        desc.z_order = 4;
        desc.action_id = 99u;
        desc.child_order = 3u;
        desc.component_config = payload;
        desc.component_config_size = sizeof(payload);
        if (uim_node_create(manager, &desc, &button) != uim_OK) return fail("button create");
    }
    if (uim_component_instance_attach(manager, button, 42u, 2u, &instance_id) != uim_OK)
        return fail("component attach");
    {
        uim_NodeDesc desc;
        uim_NodeId cube = 0u;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.parent_id = root;
        desc.stable_key = "cube";
        desc.space = uim_SPACE_3D;
        desc.transform.position[0] = 1.5f;
        desc.transform.position[1] = 2.5f;
        desc.transform.position[2] = 3.5f;
        desc.transform.rotation[0] = 10.0f;
        desc.transform.rotation[1] = 20.0f;
        desc.transform.rotation[2] = 30.0f;
        desc.transform.scale[0] = 2.0f;
        desc.transform.scale[1] = 3.0f;
        desc.transform.scale[2] = 4.0f;
        desc.visible = true;
        desc.enabled = true;
        if (uim_node_create(manager, &desc, &cube) != uim_OK) return fail("cube create");
    }
    {
        uim_PageId pages[2] = { page, second_page };
        if (uir_project_save(manager, pages, 2u, path) != uim_OK) return fail("project save");
    }
    uim_component_manager_destroy(manager);
    manager = NULL;

    if (uir_project_load(path, &loaded, &loaded_page, &loaded_root,
                         loaded_root_path, sizeof(loaded_root_path),
                         loaded_name, sizeof(loaded_name)) != uim_OK)
        return fail("project load");
    if (loaded_page == uim_PAGE_INVALID || loaded_root == 0u) return fail("loaded entry");
    if (uim_page_count(loaded, &loaded_pages) != uim_OK || loaded_pages != 2u)
        return fail("loaded page count");
    if (uim_page_find(loaded, "second", &loaded_second) != uim_OK ||
        loaded_second == uim_PAGE_INVALID)
        return fail("loaded second page");
    {
        uim_NodeInfo child;
        if (uim_node_get_child(loaded, loaded_root, 0u, &child) != uim_OK)
            return fail("loaded child missing");
    }
    if (uim_node_find_stable_key(loaded, loaded_page, "button", &loaded_button) != uim_OK)
        return fail("loaded button missing");
    if (uim_node_get(loaded, loaded_button, &info) != uim_OK) return fail("loaded button get");
    if (info.local_rect.x != 10.0f || info.local_rect.y != 20.0f ||
        info.local_rect.width != 100.0f || info.local_rect.height != 40.0f)
        return fail("loaded rect mismatch");
    if (!info.layout.enabled || info.layout.anchor_min_x != 0.5f ||
        info.layout.offset_left != -50.0f)
        return fail("loaded layout mismatch");
    if (info.visible != true || info.enabled != false || info.z_order != 4 ||
        info.action_id != 99u || info.child_order != 3u)
        return fail("loaded flags mismatch");
    if (info.component_config_size != sizeof(payload) ||
        memcmp(info.component_config, payload, sizeof(payload)) != 0)
        return fail("loaded component config mismatch");
    if (uim_node_component_count(loaded, loaded_button, &instance_count) != uim_OK ||
        instance_count != 1u)
        return fail("loaded component count");
    if (uim_node_component_get_at(loaded, loaded_button, 0u, &instance) != uim_OK ||
        instance.type_id != 42u || instance.schema_version != 2u)
        return fail("loaded component instance");
    {
        uim_NodeId cube = 0u;
        uim_NodeInfo cube_info;
        if (uim_node_find_stable_key(loaded, loaded_page, "cube", &cube) != uim_OK)
            return fail("loaded cube missing");
        if (uim_node_get(loaded, cube, &cube_info) != uim_OK) return fail("loaded cube get");
        if (cube_info.space != uim_SPACE_3D ||
            cube_info.transform.position[0] != 1.5f ||
            cube_info.transform.position[1] != 2.5f ||
            cube_info.transform.position[2] != 3.5f ||
            cube_info.transform.rotation[0] != 10.0f ||
            cube_info.transform.rotation[1] != 20.0f ||
            cube_info.transform.rotation[2] != 30.0f ||
            cube_info.transform.scale[0] != 2.0f ||
            cube_info.transform.scale[1] != 3.0f ||
            cube_info.transform.scale[2] != 4.0f)
            return fail("loaded 3D transform mismatch");
    }
    if (strcmp(loaded_name, "roundtrip") != 0) return fail("loaded name mismatch");
    (void)rc;
    uim_component_manager_destroy(loaded);
    remove(path);
    return 0;
}

static int test_v2(void) {
    char dir[256];
    char path[512];
    UIM_ComponentManager *manager = NULL;
    UIM_ComponentManager *loaded = NULL;
    UIM_ComponentManagerConfig config;
    uim_PageId page = uim_PAGE_INVALID;
    uim_PageId second = uim_PAGE_INVALID;
    uim_PageId loaded_page = uim_PAGE_INVALID;
    uim_NodeId root = 0u;
    uim_NodeId label = 0u;
    uim_NodeId loaded_root = 0u;
    uim_NodeId loaded_label = 0u;
    uim_ComponentInstanceId instance = uim_COMPONENT_INSTANCE_INVALID;
    uim_ComponentInstanceId loaded_instance = uim_COMPONENT_INSTANCE_INVALID;
    uim_ComponentInstanceInfo instance_info;
    uim_Value value;
    uim_Value read_back;
    uim_BindingDesc binding;
    uim_BindingId binding_id = 0u;
    uim_BindingDesc loaded_binding;
    uim_PropertyId global_id = 0u;
    char loaded_name[UIR_PROJECT_NAME_CAP];
    char loaded_root_path[UIR_PROJECT_PATH_CAP];
    uim_NodeInfo info;
    size_t count = 0u;
    size_t property_count = 0u;
    uim_PropertyId property_id = 0u;
    int rc;

    make_temp_dir(dir, sizeof(dir));
    snprintf(path, sizeof(path), "%s/v2.uireproj", dir);
    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 2u;
    config.initial_node_capacity = 4u;
    if (uim_component_manager_create(&config, &manager) != uim_OK) return fail("v2 manager");
    if (uim_page_create(manager, "main", &page) != uim_OK) return fail("v2 main page");
    if (uim_page_create(manager, "second", &second) != uim_OK) return fail("v2 second page");
    memset(&info, 0, sizeof(info));
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.stable_key = "root";
        desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 1280.0f, 720.0f };
        desc.visible = true;
        desc.enabled = true;
        if (uim_node_create(manager, &desc, &root) != uim_OK) return fail("v2 root");
    }
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = second;
        desc.stable_key = "second_root";
        desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 640.0f, 480.0f };
        desc.visible = true;
        desc.enabled = true;
        if (uim_node_create(manager, &desc, &loaded_root) != uim_OK) return fail("v2 second root");
    }
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.parent_id = root;
        desc.stable_key = "label";
        desc.local_rect = (uim_Rect){ 12.0f, 24.0f, 300.0f, 40.0f };
        desc.visible = true;
        desc.enabled = true;
        desc.z_order = 7;
        if (uim_node_create(manager, &desc, &label) != uim_OK) return fail("v2 label");
    }
    if (uim_component_instance_attach(manager, label, 0x10003u, 1u, &instance) != uim_OK)
        return fail("v2 component attach");
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_STRING;
    value.as.string.data = "Hello v2";
    value.as.string.size = strlen("Hello v2");
    if (uim_component_instance_set_property(manager, instance, 1u, value) != uim_OK)
        return fail("v2 component property");
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_INT64;
    value.as.integer = 0xFF00FF00u;
    if (uim_component_instance_set_property(manager, instance, 2u, value) != uim_OK)
        return fail("v2 component int property");
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_INT64;
    value.as.integer = 42;
    if (uim_property_register_named(manager, 900u, "score", value) != uim_OK)
        return fail("v2 global property");
    memset(&binding, 0, sizeof(binding));
    binding.node_id = label;
    binding.property_id = 900u;
    binding.value_type = uim_VALUE_INT64;
    binding.direction = uim_BIND_READ;
    binding.initial_sync = uim_SYNC_INITIAL_ONLY;
    binding.state = uim_BINDING_ACTIVE;
    if (uim_binding_create(manager, &binding, &binding_id) != uim_OK || binding_id == 0u)
        return fail("v2 binding create");
    {
        uim_PageId pages[2] = { page, second };
        if (uir_project_save(manager, pages, 2u, path) != uim_OK) return fail("v2 save");
    }
    uim_component_manager_destroy(manager);
    manager = NULL;

    if (uir_project_load(path, &loaded, &loaded_page, &loaded_root,
                         loaded_root_path, sizeof(loaded_root_path),
                         loaded_name, sizeof(loaded_name)) != uim_OK)
        return fail("v2 load");
    if (loaded_page == uim_PAGE_INVALID || loaded_root == 0u) return fail("v2 entry page");
    {
        const char *key = NULL;
        if (uim_page_get_key(loaded, loaded_page, &key) != uim_OK || !key ||
            strcmp(key, "main") != 0)
            return fail("v2 entry page key");
    }
    if (uim_node_get(loaded, loaded_root, &info) != uim_OK ||
        info.local_rect.width != 1280.0f || info.local_rect.height != 720.0f)
        return fail("v2 root resolution");
    if (uim_node_find_stable_key(loaded, loaded_page, "label", &loaded_label) != uim_OK)
        return fail("v2 loaded label");
    if (uim_node_component_count(loaded, loaded_label, &count) != uim_OK || count != 1u)
        return fail("v2 loaded component count");
    if (uim_node_component_get_at(loaded, loaded_label, 0u, &instance_info) != uim_OK)
        return fail("v2 loaded component");
    loaded_instance = instance_info.instance_id;
    memset(&read_back, 0, sizeof(read_back));
    if (uim_component_instance_get_property(loaded, loaded_instance, 1u, &read_back) != uim_OK ||
        read_back.type != uim_VALUE_STRING ||
        read_back.as.string.size != strlen("Hello v2") ||
        memcmp(read_back.as.string.data, "Hello v2", strlen("Hello v2")) != 0)
        return fail("v2 string property roundtrip");
    memset(&read_back, 0, sizeof(read_back));
    if (uim_component_instance_get_property(loaded, loaded_instance, 2u, &read_back) != uim_OK ||
        read_back.type != uim_VALUE_INT64 || read_back.as.integer != 0xFF00FF00u)
        return fail("v2 int property roundtrip");
    if (uim_component_instance_property_count(loaded, loaded_instance, &property_count) != uim_OK ||
        property_count != 2u)
        return fail("v2 property count");
    if (uim_component_instance_property_get_at(loaded, loaded_instance, 0u, &property_id,
                                               &read_back) != uim_OK ||
        property_id != 1u)
        return fail("v2 property enumeration");
    if (uim_property_find_stable_key(loaded, "score", &global_id) != uim_OK ||
        global_id != 900u)
        return fail("v2 global property key");
    memset(&loaded_binding, 0, sizeof(loaded_binding));
    if (uim_binding_get(loaded, 1u, &loaded_binding) != uim_OK ||
        loaded_binding.node_id != loaded_label || loaded_binding.property_id != 900u) return fail("v2 binding roundtrip");
    if (strcmp(loaded_name, "v2") != 0) return fail("v2 name mismatch");
    (void)rc;
    uim_component_manager_destroy(loaded);
    remove(path);
    return 0;
}

typedef struct LegacyWriter {
    unsigned char data[1024];
    size_t size;
} LegacyWriter;

static void legacy_u8(LegacyWriter *w, unsigned char value) { w->data[w->size++] = value; }
static void legacy_u32(LegacyWriter *w, uint32_t value) {
    w->data[w->size++] = (unsigned char)(value & 0xffu);
    w->data[w->size++] = (unsigned char)((value >> 8) & 0xffu);
    w->data[w->size++] = (unsigned char)((value >> 16) & 0xffu);
    w->data[w->size++] = (unsigned char)((value >> 24) & 0xffu);
}
static void legacy_f32(LegacyWriter *w, float value) {
    uint32_t bits;
    memcpy(&bits, &value, sizeof(bits));
    legacy_u32(w, bits);
}
static void legacy_str(LegacyWriter *w, const char *value) {
    size_t n = strlen(value);
    legacy_u32(w, (uint32_t)n);
    memcpy(w->data + w->size, value, n);
    w->size += n;
}
static uint32_t legacy_hash(const unsigned char *data, size_t size) {
    uint32_t h = 2166136261u;
    size_t i;
    for (i = 0; i < size; ++i) {
        h ^= data[i];
        h *= 16777619u;
    }
    return h;
}

static int test_legacy_v1(void) {
    char dir[256];
    char path[512];
    LegacyWriter payload;
    FILE *file;
    uint32_t checksum;
    UIM_ComponentManager *loaded = NULL;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = 0u;
    uim_NodeInfo info;
    char name[UIR_PROJECT_NAME_CAP];
    char root_path[UIR_PROJECT_PATH_CAP];
    int i;

    make_temp_dir(dir, sizeof(dir));
    snprintf(path, sizeof(path), "%s/legacy_v1.uireproj", dir);
    memset(&payload, 0, sizeof(payload));
    legacy_str(&payload, "legacy");
    legacy_str(&payload, "main");
    legacy_u32(&payload, 1u);
    legacy_str(&payload, "main");
    legacy_u32(&payload, 1u);
    legacy_str(&payload, "root");
    legacy_str(&payload, "");
    legacy_u32(&payload, 0u);
    legacy_f32(&payload, 0.0f);
    legacy_f32(&payload, 0.0f);
    legacy_f32(&payload, 320.0f);
    legacy_f32(&payload, 240.0f);
    legacy_u8(&payload, 0u);
    for (i = 0; i < 8; ++i) legacy_f32(&payload, 0.0f);
    legacy_u8(&payload, 1u);
    legacy_u8(&payload, 1u);
    legacy_u32(&payload, 0u);
    legacy_u32(&payload, 0u);
    legacy_u32(&payload, 0u);
    legacy_u32(&payload, 0u);
    legacy_u32(&payload, 0u);
    checksum = legacy_hash(payload.data, payload.size);
    file = fopen(path, "wb");
    if (!file) return fail("legacy create");
    fwrite("UIRJ", 1u, 4u, file);
    {
        unsigned char version[4] = { 1u, 0u, 0u, 0u };
        unsigned char size[4];
        size[0] = (unsigned char)(payload.size & 0xffu);
        size[1] = (unsigned char)((payload.size >> 8) & 0xffu);
        size[2] = (unsigned char)((payload.size >> 16) & 0xffu);
        size[3] = (unsigned char)((payload.size >> 24) & 0xffu);
        fwrite(version, 1u, 4u, file);
        fwrite(size, 1u, 4u, file);
    }
    fwrite(payload.data, 1u, payload.size, file);
    {
        unsigned char tail[4];
        tail[0] = (unsigned char)(checksum & 0xffu);
        tail[1] = (unsigned char)((checksum >> 8) & 0xffu);
        tail[2] = (unsigned char)((checksum >> 16) & 0xffu);
        tail[3] = (unsigned char)((checksum >> 24) & 0xffu);
        fwrite(tail, 1u, 4u, file);
    }
    fclose(file);
    if (uir_project_load(path, &loaded, &page, &root, root_path, sizeof(root_path),
                         name, sizeof(name)) != uim_OK)
        return fail("legacy v1 load");
    if (page == uim_PAGE_INVALID || root == 0u) return fail("legacy entry");
    if (uim_node_get(loaded, root, &info) != uim_OK ||
        info.local_rect.width != 320.0f || info.local_rect.height != 240.0f)
        return fail("legacy root rect");
    if (strcmp(name, "legacy") != 0) return fail("legacy name");
    uim_component_manager_destroy(loaded);
    remove(path);
    return 0;
}

static int test_package(void) {
    char dir[256];
    char source_project[512];
    char fake_exe[512];
    char package[UIR_PROJECT_PATH_CAP];
    char project_dest[UIR_PROJECT_PATH_CAP];
    char player_dest[UIR_PROJECT_PATH_CAP];
    char manifest[UIR_PROJECT_PATH_CAP];
    char asset_source[512];
    char asset_dest[UIR_PROJECT_PATH_CAP];
    FILE *f;
    UIM_ComponentManager *manager = NULL;
    UIM_ComponentManagerConfig config;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = 0u;
    uir_AssetRecord asset_records[1];
    uir_AssetRegistry assets;

    make_temp_dir(dir, sizeof(dir));
    snprintf(source_project, sizeof(source_project), "%s/package.uireproj", dir);
    snprintf(fake_exe, sizeof(fake_exe), "%s/editor.exe", dir);
    snprintf(asset_source, sizeof(asset_source), "%s/asset.bin", dir);
    f = fopen(fake_exe, "wb");
    if (!f) return fail("fake exe create");
    fwrite("MZ", 1u, 2u, f);
    fclose(f);
    f = fopen(asset_source, "wb");
    if (!f) return fail("asset create");
    fwrite("ASSET", 1u, 5u, f);
    fclose(f);
    if (uir_asset_registry_init(&assets, asset_records, 1u) != uim_OK)
        return fail("asset registry init");
    if (uir_asset_registry_register(&assets, "asset.bin", UIR_ASSET_OTHER, NULL) != uim_OK)
        return fail("asset register");

    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 1u;
    config.initial_node_capacity = 1u;
    if (uim_component_manager_create(&config, &manager) != uim_OK) return fail("package manager");
    if (uim_page_create(manager, "main", &page) != uim_OK) return fail("package page");
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.stable_key = "root";
        desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 1280.0f, 800.0f };
        desc.visible = true;
        desc.enabled = true;
        if (uim_node_create(manager, &desc, &root) != uim_OK) return fail("package root");
    }
    {
        uim_PageId pages[1] = { page };
        if (uir_project_save(manager, pages, 1u, source_project) != uim_OK)
            return fail("package project save");
    }
    uim_component_manager_destroy(manager);

    if (uir_project_build_package(source_project, fake_exe, dir, dir, &assets,
                                  package, sizeof(package),
                                  project_dest, sizeof(project_dest),
                                  player_dest, sizeof(player_dest)) != uim_OK)
        return fail("package build");
    snprintf(manifest, sizeof(manifest), "%s/manifest.txt", package);
    snprintf(asset_dest, sizeof(asset_dest), "%sasset.bin", package);
    if (!test_file_exists(project_dest) || !test_file_exists(player_dest) ||
        !test_file_exists(manifest) || !test_file_exists(asset_dest))
        return fail("package files missing");
    remove(source_project);
    remove(fake_exe);
    remove(asset_source);
    remove(project_dest);
    remove(player_dest);
    remove(manifest);
    remove(asset_dest);
    return 0;
}

static int demo_attach(UIM_ComponentManager *manager, uim_NodeId node,
                       uim_ComponentTypeId type_id, const char *text, int64_t argb,
                       double font_size) {
    uim_ComponentInstanceId instance = uim_COMPONENT_INSTANCE_INVALID;
    uim_Value value;
    if (uim_component_instance_attach(manager, node, type_id, 1u, &instance) != uim_OK)
        return 1;
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_INT64;
    value.as.integer = argb;
    if (uim_component_instance_set_property(manager, instance, 2u, value) != uim_OK)
        return 1;
    if (type_id != 0x10006u &&
        uim_component_instance_set_property(manager, instance, 3u, value) != uim_OK)
        return 1;
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_FLOAT64;
    value.as.real = font_size;
    if (uim_component_instance_set_property(manager, instance, 7u, value) != uim_OK)
        return 1;
    if (text && text[0]) {
        memset(&value, 0, sizeof(value));
        value.type = uim_VALUE_STRING;
        value.as.string.data = text;
        value.as.string.size = strlen(text);
        if (uim_component_instance_set_property(manager, instance, 1u, value) != uim_OK)
            return 1;
    }
    return 0;
}

static int demo_attach_asset(UIM_ComponentManager *manager, uim_NodeId node,
                             const char *asset_path) {
    uim_ComponentInstanceId instance = uim_COMPONENT_INSTANCE_INVALID;
    uim_Value value;
    if (uim_component_instance_attach(manager, node, 0x10008u, 1u, &instance) != uim_OK)
        return 1;
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_STRING;
    value.as.string.data = asset_path;
    value.as.string.size = strlen(asset_path);
    return uim_component_instance_set_property(manager, instance, 6u, value) == uim_OK
               ? 0 : 1;
}

/* Small 24-bit checker BMP so the demo exercises a real decoded texture
 * instead of only the missing-asset placeholder. */
static int demo_write_bmp(const char *path) {
    unsigned char header[54];
    FILE *f;
    int x, y;
    memset(header, 0, sizeof(header));
    header[0] = 'B';
    header[1] = 'M';
    *(uint32_t *)(header + 2) = 54u + 64u * 64u * 3u;
    *(uint32_t *)(header + 10) = 54u;
    *(uint32_t *)(header + 14) = 40u;
    *(int32_t *)(header + 18) = 64;
    *(int32_t *)(header + 22) = 64;
    *(uint16_t *)(header + 26) = 1u;
    *(uint16_t *)(header + 28) = 24u;
    *(uint32_t *)(header + 34) = 64u * 64u * 3u;
    f = fopen(path, "wb");
    if (!f) return 1;
    if (fwrite(header, sizeof(header), 1u, f) != 1u) {
        fclose(f);
        return 1;
    }
    for (y = 63; y >= 0; --y) {
        for (x = 0; x < 64; ++x) {
            int cell = ((x / 16) + (y / 16)) & 1;
            unsigned char bgr[3];
            bgr[0] = cell ? 40u : 235u;
            bgr[1] = cell ? 96u : 132u;
            bgr[2] = cell ? 186u : 42u;
            if (fwrite(bgr, sizeof(bgr), 1u, f) != 1u) {
                fclose(f);
                return 1;
            }
        }
    }
    return fclose(f) == 0 ? 0 : 1;
}

/* Write the same 12-byte header + 32-byte fixed record layout used by
 * uir_asset_registry_save, so the editor opens the demo with its icon listed.
 * A fixture does not need the full FileService adapter. */
static int demo_write_assets_file(const char *path, const char *asset_name) {
    unsigned char header[12];
    unsigned char fixed[32];
    size_t path_len = strlen(asset_name);
    FILE *f;
    memset(header, 0, sizeof(header));
    memcpy(header, "UIRA", 4u);
    header[4] = 1u;
    header[8] = 1u;
    memset(fixed, 0, sizeof(fixed));
    {
        uint64_t id = 1u;
        uint32_t kind = 1u; /* UIR_ASSET_IMAGE */
        uint64_t size_bytes = 12342u;
        uint32_t path_size = (uint32_t)path_len;
        memcpy(fixed, &id, sizeof(id));
        memcpy(fixed + 8, &kind, sizeof(kind));
        memcpy(fixed + 16, &size_bytes, sizeof(size_bytes));
        memcpy(fixed + 24, &path_size, sizeof(path_size));
        memcpy(fixed + 28, &path_size, sizeof(path_size));
    }
    f = fopen(path, "wb");
    if (!f) return 1;
    if (fwrite(header, sizeof(header), 1u, f) != 1u ||
        fwrite(fixed, sizeof(fixed), 1u, f) != 1u ||
        fwrite(asset_name, path_len, 1u, f) != 1u ||
        fwrite(asset_name, path_len, 1u, f) != 1u) {
        fclose(f);
        return 1;
    }
    return fclose(f) == 0 ? 0 : 1;
}

static int make_demo_project(const char *out_dir, const char *editor_exe) {
    char source_project[512];
    char package[UIR_PROJECT_PATH_CAP];
    char project_dest[UIR_PROJECT_PATH_CAP];
    char player_dest[UIR_PROJECT_PATH_CAP];
    char icon_path[512];
    uir_AssetRecord asset_records[1];
    uir_AssetRegistry assets;
    UIM_ComponentManager *manager = NULL;
    UIM_ComponentManagerConfig config;
    uim_PageId page = uim_PAGE_INVALID;
    uim_PageId second_page = uim_PAGE_INVALID;
    uim_NodeId root = 0u;
    uim_NodeId second_root = 0u;
    uim_NodeId title = 0u;
    uim_NodeId button = 0u;
    uim_NodeId panel = 0u;
    uim_NodeId icon = 0u;
    uim_NodeDesc desc;

    if (!out_dir || !editor_exe) return fail("demo arguments");
#if defined(_WIN32)
    _mkdir(out_dir);
#else
    mkdir(out_dir, 0777);
#endif
    snprintf(source_project, sizeof(source_project), "%s/demo.uireproj", out_dir);

    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 2u;
    config.initial_node_capacity = 8u;
    if (uim_component_manager_create(&config, &manager) != uim_OK) return fail("demo manager");
    if (uim_page_create(manager, "main", &page) != uim_OK) return fail("demo page");
    if (uim_page_create(manager, "second", &second_page) != uim_OK) return fail("demo second page");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.stable_key = "screen";
    desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 960.0f, 600.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &root) != uim_OK) return fail("demo root");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.parent_id = root;
    desc.stable_key = "panel";
    desc.component_id = 1u;
    desc.local_rect = (uim_Rect){ 80.0f, 80.0f, 800.0f, 440.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &panel) != uim_OK) return fail("demo panel");
    if (demo_attach(manager, panel, 0x10001u, NULL, 0xFF1E2A38u, 0.0)) return fail("demo panel comp");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.parent_id = panel;
    desc.stable_key = "title";
    desc.component_id = 2u;
    desc.local_rect = (uim_Rect){ 24.0f, 24.0f, 360.0f, 48.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &title) != uim_OK) return fail("demo title");
    if (demo_attach(manager, title, 0x10006u, "Hello Player", 0xFFFFFFFFu, 22.0))
        return fail("demo title comp");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.parent_id = panel;
    desc.stable_key = "button";
    desc.component_id = 7u;
    desc.local_rect = (uim_Rect){ 24.0f, 120.0f, 180.0f, 48.0f };
    desc.visible = true;
    desc.enabled = true;
    desc.action_id = 2u;
    if (uim_node_create(manager, &desc, &button) != uim_OK) return fail("demo button");
    if (demo_attach(manager, button, 0x10002u, "Go Second", 0xFF2E4A6Eu, 18.0))
        return fail("demo button comp");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.parent_id = panel;
    desc.stable_key = "icon";
    desc.local_rect = (uim_Rect){ 24.0f, 220.0f, 128.0f, 128.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &icon) != uim_OK) return fail("demo icon");
    if (demo_attach_asset(manager, icon, "demo_icon.bmp")) return fail("demo icon comp");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = second_page;
    desc.stable_key = "second_screen";
    desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 960.0f, 600.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &second_root) != uim_OK) return fail("demo second root");
    {
        uim_NodeDesc label_desc;
        uim_NodeId second_label = 0u;
        memset(&label_desc, 0, sizeof(label_desc));
        label_desc.page_id = second_page;
        label_desc.parent_id = second_root;
        label_desc.stable_key = "second_label";
        label_desc.local_rect = (uim_Rect){ 40.0f, 40.0f, 320.0f, 40.0f };
        label_desc.visible = true;
        label_desc.enabled = true;
        if (uim_node_create(manager, &label_desc, &second_label) != uim_OK)
            return fail("demo second label");
        if (demo_attach(manager, second_label, 0x10006u, "Second Page", 0xFFB8D8FFu, 20.0))
            return fail("demo second label comp");
    }

    {
        uim_PageId pages[2] = { page, second_page };
        if (uir_project_save(manager, pages, 2u, source_project) != uim_OK)
            return fail("demo project save");
    }
    uim_component_manager_destroy(manager);

    snprintf(icon_path, sizeof(icon_path), "%s/demo_icon.bmp", out_dir);
    if (demo_write_bmp(icon_path)) return fail("demo icon write");
    snprintf(icon_path, sizeof(icon_path), "%s/.uirassets", out_dir);
    if (demo_write_assets_file(icon_path, "demo_icon.bmp"))
        return fail("demo asset file");
    if (uir_asset_registry_init(&assets, asset_records, 1u) != uim_OK)
        return fail("demo asset registry");
    if (uir_asset_registry_register(&assets, "demo_icon.bmp", UIR_ASSET_IMAGE, NULL) != uim_OK)
        return fail("demo asset register");

    if (uir_project_build_package(source_project, editor_exe, out_dir, out_dir, &assets,
                                  package, sizeof(package),
                                  project_dest, sizeof(project_dest),
                                  player_dest, sizeof(player_dest)) != uim_OK)
        return fail("demo package build");
    printf("DEMO_PROJECT=%s\n", source_project);
    printf("DEMO_PACKAGE=%s\n", package);
    printf("DEMO_PROJECT_COPY=%s\n", project_dest);
    printf("DEMO_PLAYER=%s\n", player_dest);
    (void)title;
    (void)button;
    (void)panel;
    (void)icon;
    (void)second_root;
    return 0;
}

int main(int argc, char **argv) {
    if (argc > 3 && strcmp(argv[1], "demo") == 0)
        return make_demo_project(argv[2], argv[3]);
    if (argc > 1 && strcmp(argv[1], "package") == 0) return test_package();
    if (argc > 1 && strcmp(argv[1], "v2") == 0) return test_v2();
    if (argc > 1 && strcmp(argv[1], "legacy") == 0) return test_legacy_v1();
    return test_roundtrip();
}
