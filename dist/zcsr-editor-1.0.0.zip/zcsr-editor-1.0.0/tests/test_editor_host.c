/* Headless contract test for editor_host: no window, no dialogs. */
#include <stdio.h>
#include <string.h>

#include "editor_host.h"

static int failures = 0;

#define CHECK(cond, msg) do { \
    if (!(cond)) { fprintf(stderr, "FAIL: %s\n", msg); ++failures; } \
} while (0)

int main(void) {
    editor_host* host = editor_host_create(NULL);
    CHECK(host != NULL, "editor_host_create(NULL) returns a host");
    if (!host) return 1;

    char exe[32768];
    CHECK(editor_host_executable_path(host, exe, sizeof(exe)), "executable path");
    CHECK(exe[0] != '\0', "executable path is not empty");

    char output[4096];
    int exit_code = 99;
#if defined(_WIN32)
    const char* command = "cmd /C echo editor-host-ok";
#else
    const char* command = "printf editor-host-ok";
#endif
    CHECK(editor_host_run_process(host, command, "", output, sizeof(output), &exit_code),
          "run_process starts");
    CHECK(exit_code == 0, "run_process exit code 0");
    CHECK(strstr(output, "editor-host-ok") != NULL, "run_process captures output");

    editor_host_destroy(host);
    if (failures == 0) {
        printf("editor_host: all checks passed\n");
        return 0;
    }
    printf("editor_host: %d failure(s)\n", failures);
    return 1;
}
