#include "editor_scene_prefab.h"
#include "editor_scene_authoring.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static zcsr_scene source;
static zcsr_scene target;

static int fail(const char *why) {
    fprintf(stderr, "prefab test failed: %s\n", why);
    return 1;
}

int main(void) {
    char path[256];
    zcsr_editor_scene_change change;
    zcsr_entity_id ids[4] = {0};
    uint64_t prefab_id = 0;
    size_t added;
    zcsr_scene_point quad[4];

    snprintf(path, sizeof(path), "prefab_test_%ld_%ld.uiscene",
             (long)time(NULL), (long)rand());
    zcsr_scene_init(&source);
    change = zcsr_editor_scene_add_box(&source, 2.0f, 3.0f, 2.0f, 1.0f,
                                       0.8f, 0.6f, 0.4f);
    if (!change.changed) return fail("add source");
    quad[0].x = 0.0f; quad[0].y = 0.0f; quad[0].z = 0.0f;
    quad[1].x = 2.0f; quad[1].y = 0.0f; quad[1].z = 0.0f;
    quad[2].x = 2.0f; quad[2].y = 0.0f; quad[2].z = 1.0f;
    quad[3].x = 0.0f; quad[3].y = 0.0f; quad[3].z = 1.0f;
    if (!zcsr_editor_scene_set_quad(&source, change.id, quad))
        return fail("set source quad");

    if (!zcsr_editor_prefab_save_entity(&source, change.id, path, &prefab_id))
        return fail("save prefab");
    if (prefab_id == 0) return fail("zero prefab id");
    if (prefab_id != zcsr_editor_prefab_id_from_path(path))
        return fail("prefab id hash mismatch");

    zcsr_scene_init(&target);
    added = zcsr_editor_prefab_instantiate(&target, path, 10.0f, 20.0f,
                                           ids, 4u, &prefab_id);
    if (added != 1u) return fail("instantiate count");
    if (ids[0] == 0) return fail("instantiate id");
    if (target.entities[0].kind != ZCSR_SCENE_KIND_PREFAB)
        return fail("prefab kind");
    if (target.entities[0].prefab_id != prefab_id)
        return fail("prefab back-reference");
    if (target.entities[0].x != 10.0f || target.entities[0].z != 20.0f)
        return fail("prefab root position");
    if (!zcsr_scene_has_quad(&target, ids[0]))
        return fail("prefab quad");

    remove(path);
    return 0;
}
