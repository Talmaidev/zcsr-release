/* test_editor_domain_provider.c — Headless reference host for zcsr_editor_domain.
 *
 * No Dear ImGui, no window, no GL context, no zcsr_scene. Links only the
 * renderer-neutral domain target. This test doubles as the copy-paste
 * reference implementation for a C11 host (e.g. PVZ):
 *
 *   1. build an in-memory document (UIM manager + page + nodes),
 *   2. open a default domain editor over it,
 *   3. read hierarchy rows, drive zoom/pan, marquee select, undo/redo,
 *   4. round-trip the shell layout blob,
 *   5. install a fake provider vtable and prove the facade dispatches to it.
 */
#include "editor_domain.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static int failures = 0;
#define CHECK(cond, what) do { \
    if (!(cond)) { printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, what); failures++; } \
} while (0)

/* ------------------------------------------------------------------------- */
/* Fake document backend: proves the provider vtable is reachable.           */
/* ------------------------------------------------------------------------- */

#define FAKE_MAX_NODES 8u

typedef struct FakeDoc {
    int create_calls;
    int inspect_calls;
    int set_rect_calls;
    int delete_calls;
    int get_sel_calls;
    int set_sel_calls;
    int undo_calls;
    int redo_calls;
    int history_calls;
    int hit_calls;
    int box_calls;

    uim_NodeId ids[FAKE_MAX_NODES];
    uim_Rect rects[FAKE_MAX_NODES];
    size_t node_count;

    uim_NodeId selection[FAKE_MAX_NODES];
    size_t selection_count;

    uim_EditorHistoryState history;
    uim_NodeId last_hit;
} FakeDoc;

static uim_Result fake_create_node(void *user, const uim_NodeDesc *desc,
                                    uim_NodeId *out_id)
{
    FakeDoc *f = (FakeDoc *)user;
    if (!desc || !out_id || f->node_count >= FAKE_MAX_NODES) return uim_ERR_RANGE;
    f->create_calls++;
    f->ids[f->node_count] = (uim_NodeId)(f->node_count + 1u);
    f->rects[f->node_count] = desc->local_rect;
    *out_id = f->ids[f->node_count];
    f->node_count++;
    return uim_OK;
}

static uim_Result fake_inspect_node(void *user, uim_NodeId node_id,
                                    uim_NodeInfo *out_info)
{
    FakeDoc *f = (FakeDoc *)user;
    size_t i;
    f->inspect_calls++;
    for (i = 0; i < f->node_count; ++i) {
        if (f->ids[i] == node_id) {
            memset(out_info, 0, sizeof(*out_info));
            out_info->id = node_id;
            out_info->local_rect = f->rects[i];
            return uim_OK;
        }
    }
    return uim_ERR_NOT_FOUND;
}

static uim_Result fake_set_rect(void *user, uim_NodeId node_id, uim_Rect rect)
{
    FakeDoc *f = (FakeDoc *)user;
    size_t i;
    f->set_rect_calls++;
    for (i = 0; i < f->node_count; ++i)
        if (f->ids[i] == node_id) { f->rects[i] = rect; return uim_OK; }
    return uim_ERR_NOT_FOUND;
}

static uim_Result fake_delete_node(void *user, uim_NodeId node_id)
{
    FakeDoc *f = (FakeDoc *)user;
    size_t i;
    f->delete_calls++;
    for (i = 0; i < f->node_count; ++i)
        if (f->ids[i] == node_id) { f->ids[i] = 0; return uim_OK; }
    return uim_ERR_NOT_FOUND;
}

static uim_Result fake_get_selection(void *user, const uim_NodeId **out_ids,
                                      size_t *out_count)
{
    FakeDoc *f = (FakeDoc *)user;
    f->get_sel_calls++;
    *out_ids = f->selection;
    *out_count = f->selection_count;
    return uim_OK;
}

static uim_Result fake_set_selection(void *user, const uim_NodeId *ids, size_t count)
{
    FakeDoc *f = (FakeDoc *)user;
    size_t i;
    f->set_sel_calls++;
    if (count > FAKE_MAX_NODES) return uim_ERR_RANGE;
    for (i = 0; i < count; ++i) f->selection[i] = ids[i];
    f->selection_count = count;
    return uim_OK;
}

static uim_Result fake_undo(void *user)
{
    FakeDoc *f = (FakeDoc *)user;
    f->undo_calls++;
    if (f->history.undo_count > 0) f->history.undo_count--;
    return uim_OK;
}

static uim_Result fake_redo(void *user)
{
    FakeDoc *f = (FakeDoc *)user;
    f->redo_calls++;
    f->history.redo_count++;
    return uim_OK;
}

static uim_Result fake_history_state(void *user, uim_EditorHistoryState *out)
{
    FakeDoc *f = (FakeDoc *)user;
    f->history_calls++;
    *out = f->history;
    return uim_OK;
}

static bool fake_rect_contains(const uim_Rect *r, float x, float y)
{
    return x >= r->x && y >= r->y && x <= r->x + r->width &&
           y <= r->y + r->height;
}

static uim_Result fake_hit_test(void *user, uim_PageId page, float cx, float cy,
                                 uim_NodeId *out)
{
    FakeDoc *f = (FakeDoc *)user;
    size_t i;
    (void)page;
    f->hit_calls++;
    for (i = 0; i < f->node_count; ++i) {
        if (f->ids[i] && fake_rect_contains(&f->rects[i], cx, cy)) {
            f->last_hit = f->ids[i];
            *out = f->ids[i];
            return uim_OK;
        }
    }
    return uim_ERR_NOT_FOUND;
}

static uim_Result fake_box_select(void *user, uim_PageId page, uim_Rect rect,
                                  bool additive)
{
    FakeDoc *f = (FakeDoc *)user;
    size_t i, n = 0;
    (void)page;
    f->box_calls++;
    if (!additive) f->selection_count = 0;
    for (i = 0; i < f->node_count; ++i) {
        uim_Rect r = f->rects[i];
        bool intersects = r.x < rect.x + rect.width &&
                         r.x + r.width > rect.x &&
                         r.y < rect.y + rect.height &&
                         r.y + r.height > rect.y;
        if (f->ids[i] && intersects && n < FAKE_MAX_NODES)
            f->selection[n++] = f->ids[i];
    }
    f->selection_count = n;
    return uim_OK;
}

static void fake_provider_init(FakeDoc *f, zcsr_DomainProviderOps *ops)
{
    memset(f, 0, sizeof(*f));
    memset(ops, 0, sizeof(*ops));
    ops->abi_version = ZCSR_DOMAIN_ABI_VERSION;
    ops->struct_size = sizeof(*ops);
    ops->create_node = fake_create_node;
    ops->inspect_node = fake_inspect_node;
    ops->set_rect = fake_set_rect;
    ops->delete_node = fake_delete_node;
    ops->get_selection = fake_get_selection;
    ops->set_selection = fake_set_selection;
    ops->undo = fake_undo;
    ops->redo = fake_redo;
    ops->history_state = fake_history_state;
    ops->hit_test = fake_hit_test;
    ops->box_select = fake_box_select;
}

/* ------------------------------------------------------------------------- */

static int make_node(UIM_ComponentManager *manager, uim_PageId page, uim_NodeId parent,
                     const char *key, float x, float y, float w, float h,
                     uim_NodeId *out)
{
    uim_NodeDesc desc;
    memset(&desc, 0, sizeof(desc));
    desc.page_id = page;
    desc.parent_id = parent;
    desc.stable_key = key;
    desc.local_rect = (uim_Rect){ x, y, w, h };
    desc.visible = true;
    desc.enabled = true;
    return uim_node_create(manager, &desc, out);
}

int main(void)
{
    UIM_ComponentManagerConfig config;
    UIM_ComponentManager *manager = NULL;
    uim_PageId page = 0u;
    uim_NodeId root = 0u, child_a = 0u, child_b = 0u, hit = 0u;
    zcsr_DomainEditor *domain = NULL;
    uim_Editor *kernel = NULL;
    uim_EditorCanvasState canvas;
    uim_EditorHistoryState history;
    const uim_NodeId *sel_ids = NULL;
    size_t sel_count = 0u;
    uim_Hierarchy *hier = NULL;
    uim_HierRow row;
    uim_NodeInfo info;
    uim_Result rc;

    /* 1. In-memory document. */
    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 2u;
    config.initial_node_capacity = 8u;
    CHECK(uim_component_manager_create(&config, &manager) == uim_OK, "manager create");
    CHECK(uim_page_create(manager, "main", &page) == uim_OK, "page create");

    /* 2. Default domain editor over the manager. */
    CHECK(zcsr_domain_editor_create_default(manager, 8u, &domain) == uim_OK,
          "domain editor create");
    kernel = zcsr_domain_editor_kernel(domain);
    CHECK(kernel != NULL, "default backend exposes kernel");

    CHECK(uir_editor_set_active_page(kernel, page) == uim_OK, "active page");
    memset(&canvas, 0, sizeof(canvas));
    canvas.viewport = (uim_Rect){ 0.0f, 0.0f, 800.0f, 600.0f };
    canvas.zoom = 1.0f;
    canvas.grid_size = 16.0f;
    canvas.show_grid = true;
    CHECK(uir_editor_set_canvas_state(kernel, &canvas) == uim_OK, "canvas state");

    /* 3. Add nodes through the facade. */
    {
        uim_NodeDesc desc;
        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.stable_key = "root";
        desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 800.0f, 600.0f };
        desc.visible = true;
        desc.enabled = true;
        CHECK(zcsr_domain_create_node(domain, &desc, &root) == uim_OK,
              "facade create root");

        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.parent_id = root;
        desc.stable_key = "child_a";
        desc.local_rect = (uim_Rect){ 10.0f, 10.0f, 40.0f, 20.0f };
        desc.visible = true;
        desc.enabled = true;
        CHECK(zcsr_domain_create_node(domain, &desc, &child_a) == uim_OK,
              "facade create child_a");

        memset(&desc, 0, sizeof(desc));
        desc.page_id = page;
        desc.parent_id = root;
        desc.stable_key = "child_b";
        desc.local_rect = (uim_Rect){ 10.0f, 40.0f, 40.0f, 20.0f };
        desc.visible = true;
        desc.enabled = true;
        CHECK(zcsr_domain_create_node(domain, &desc, &child_b) == uim_OK,
              "facade create child_b");
    }

    /* 4. Hierarchy rows readable. */
    hier = uim_hierarchy_create();
    CHECK(hier != NULL, "hierarchy create");
    uim_hierarchy_set_source(hier, manager, root);
    CHECK(uim_hierarchy_visible_count(hier) == 1, "root collapsed rows");
    CHECK(uim_hierarchy_get_row(hier, 0, &row) && row.node_id == root, "root row");
    uim_hierarchy_handle_row_click(hier, 0);
    CHECK(uim_hierarchy_visible_count(hier) == 3, "root expanded rows");
    CHECK(uim_hierarchy_get_row(hier, 1, &row) && row.node_id == child_a, "child_a row");
    CHECK(uim_hierarchy_get_row(hier, 2, &row) && row.node_id == child_b, "child_b row");
    uim_hierarchy_destroy(hier);

    /* 5. Viewport zoom / pan. zoom_at re-anchors the pan offset around the
     * cursor, so pan is verified as a delta against the post-zoom state. */
    {
        uim_EditorCanvasState before;
        CHECK(uir_editor_zoom_at(kernel, 2.0f, 400.0f, 300.0f) == uim_OK, "zoom at");
        CHECK(uir_editor_get_canvas_state(kernel, &canvas) == uim_OK, "canvas read back");
        CHECK(fabsf(canvas.zoom - 2.0f) < 0.01f, "zoom applied");
        before = canvas;
        CHECK(uir_editor_pan(kernel, 3.0f, 5.0f) == uim_OK, "pan");
        CHECK(uir_editor_get_canvas_state(kernel, &canvas) == uim_OK, "canvas after pan");
        CHECK(fabsf(canvas.pan_x - (before.pan_x + 3.0f)) < 0.01f &&
              fabsf(canvas.pan_y - (before.pan_y + 5.0f)) < 0.01f, "pan applied");
    }
    /* Restore zoom/pan for picking coordinates. */
    canvas.zoom = 1.0f;
    canvas.pan_x = 0.0f;
    canvas.pan_y = 0.0f;
    CHECK(uir_editor_set_canvas_state(kernel, &canvas) == uim_OK, "canvas reset");

    /* 6. Point hit through the facade. */
    CHECK(zcsr_domain_hit_test(domain, page, 30.0f, 20.0f, &hit) == uim_OK &&
          hit == child_a, "facade hit test child_a");

    /* 7. Marquee box select covers both children. */
    CHECK(zcsr_domain_box_select(domain, page,
                                 (uim_Rect){ 0.0f, 0.0f, 60.0f, 70.0f }, false) == uim_OK,
          "facade box select");
    CHECK(zcsr_domain_get_selection(domain, &sel_ids, &sel_count) == uim_OK,
          "facade get selection");
    {
        int found_a = 0, found_b = 0;
        size_t i;
        /* The full-page root also intersects the marquee, so the expected set
         * is root + child_a + child_b; both children must be present. */
        CHECK(sel_count == 3u, "marquee selects root + two children");
        for (i = 0; i < sel_count; ++i) {
            if (sel_ids[i] == child_a) found_a = 1;
            if (sel_ids[i] == child_b) found_b = 1;
        }
        CHECK(found_a && found_b, "marquee contains both children");
    }

    /* 8. Mutate, undo, redo through the facade. */
    CHECK(zcsr_domain_set_rect(domain, child_a,
                               (uim_Rect){ 20.0f, 20.0f, 40.0f, 20.0f }) == uim_OK,
          "facade set rect");
    CHECK(zcsr_domain_inspect_node(domain, child_a, &info) == uim_OK, "facade inspect");
    CHECK(fabsf(info.local_rect.x - 20.0f) < 0.01f, "set rect result");
    CHECK(zcsr_domain_history_state(domain, &history) == uim_OK, "history state");
    CHECK(history.undo_count >= 1u, "history after mutation");

    CHECK(zcsr_domain_undo(domain) == uim_OK, "facade undo");
    CHECK(zcsr_domain_inspect_node(domain, child_a, &info) == uim_OK, "inspect after undo");
    CHECK(fabsf(info.local_rect.x - 10.0f) < 0.01f, "undo restored rect");
    CHECK(zcsr_domain_redo(domain) == uim_OK, "facade redo");
    CHECK(zcsr_domain_inspect_node(domain, child_a, &info) == uim_OK, "inspect after redo");
    CHECK(fabsf(info.local_rect.x - 20.0f) < 0.01f, "redo restored rect");

    /* 9. Shell layout persist roundtrip (neutral codec, no document IO). */
    {
        uim_EditorShell shell, restored;
        size_t size = uir_editor_shell_layout_serialized_size();
        unsigned char *buffer = (unsigned char *)malloc(size);
        size_t written = 0u;
        CHECK(buffer != NULL, "persist buffer");
        if (buffer) {
            CHECK(uir_editor_shell_init_default(&shell, 1280.0f, 720.0f) == uim_OK,
                  "shell init");
            CHECK(uir_editor_shell_set_bounds(&shell, 1600.0f, 900.0f) == uim_OK,
                  "shell bounds");
            CHECK(uir_editor_shell_layout_save(&shell, buffer, size, &written) == uim_OK,
                  "shell layout save");
            CHECK(written == size, "persist full size");
            CHECK(uir_editor_shell_init_default(&restored, 640.0f, 480.0f) == uim_OK,
                  "restored shell init");
            CHECK(uir_editor_shell_layout_load(&restored, buffer, size) == uim_OK,
                  "shell layout load");
            CHECK(fabsf(restored.workspace.config.width - 1600.0f) < 0.01f,
                  "persist roundtrip bounds");
            free(buffer);
        }
    }

    zcsr_domain_editor_destroy(domain);
    domain = NULL;

    /* 10. Custom provider: facade dispatches every slot to the fake backend. */
    {
        FakeDoc fake;
        zcsr_DomainProviderOps fake_ops;
        zcsr_DomainEditor *custom = NULL;
        uim_NodeId n1 = 0u, n2 = 0u, fake_hit = 0u;
        const uim_NodeId *fake_sel = NULL;
        size_t fake_sel_count = 0u;
        uim_NodeDesc desc;
        uim_NodeInfo ninfo;

        fake_provider_init(&fake, &fake_ops);
        CHECK(zcsr_domain_editor_create(&fake_ops, &fake, &custom) == uim_OK,
              "custom provider create");
        CHECK(zcsr_domain_editor_kernel(custom) == NULL, "custom has no kernel");

        memset(&desc, 0, sizeof(desc));
        desc.stable_key = "a";
        desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 30.0f, 30.0f };
        CHECK(zcsr_domain_create_node(custom, &desc, &n1) == uim_OK, "fake create n1");
        desc.stable_key = "b";
        desc.local_rect = (uim_Rect){ 40.0f, 0.0f, 30.0f, 30.0f };
        CHECK(zcsr_domain_create_node(custom, &desc, &n2) == uim_OK, "fake create n2");

        CHECK(zcsr_domain_inspect_node(custom, n1, &ninfo) == uim_OK, "fake inspect");
        CHECK(zcsr_domain_set_rect(custom, n1,
                                   (uim_Rect){ 5.0f, 5.0f, 30.0f, 30.0f }) == uim_OK,
              "fake set rect");
        CHECK(zcsr_domain_set_selection(custom, &n1, 1u) == uim_OK, "fake select");
        CHECK(zcsr_domain_get_selection(custom, &fake_sel, &fake_sel_count) == uim_OK,
              "fake get selection");
        CHECK(fake_sel_count == 1u && fake_sel[0] == n1, "fake selection contents");
        CHECK(zcsr_domain_hit_test(custom, page, 10.0f, 10.0f, &fake_hit) == uim_OK &&
              fake_hit == n1, "fake hit test");
        CHECK(zcsr_domain_box_select(custom, page,
                                      (uim_Rect){ 0.0f, 0.0f, 80.0f, 30.0f }, false) == uim_OK,
              "fake box select");
        CHECK(zcsr_domain_get_selection(custom, &fake_sel, &fake_sel_count) == uim_OK,
              "fake selection after marquee");
        CHECK(fake_sel_count == 2u, "fake marquee two nodes");
        CHECK(zcsr_domain_undo(custom) == uim_OK, "fake undo");
        CHECK(zcsr_domain_redo(custom) == uim_OK, "fake redo");
        CHECK(zcsr_domain_history_state(custom, &history) == uim_OK, "fake history");
        CHECK(zcsr_domain_delete_node(custom, n2) == uim_OK, "fake delete");

        CHECK(fake.create_calls == 2 && fake.inspect_calls == 1 &&
              fake.set_rect_calls == 1 && fake.delete_calls == 1 &&
              fake.get_sel_calls == 2 && fake.set_sel_calls == 1 &&
              fake.undo_calls == 1 && fake.redo_calls == 1 &&
              fake.history_calls == 1 && fake.hit_calls == 1 && fake.box_calls == 1,
              "fake provider dispatch counters");

        zcsr_domain_editor_destroy(custom);
    }

    uim_component_manager_destroy(manager);

    if (failures == 0) {
        puts("editor_domain_provider: all checks passed");
        return 0;
    }
    printf("editor_domain_provider: %d failure(s)\n", failures);
    return 1;
}
