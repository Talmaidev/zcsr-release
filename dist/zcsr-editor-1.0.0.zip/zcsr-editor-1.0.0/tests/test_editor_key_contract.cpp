// Contract test for the real editor keyboard path.
//
// This drives key_cb() -> apply_editor_input() -> handle_shortcuts(), the same
// path used by the zcsr_window_game_run() module callback, with ZCSR_KEY_*
// values. It does not push directly into EditorApp::keys and does not call a
// headless mapping table.
#include <cstdio>
#include <cstring>
#include "imgui.h"
#include "zcsr/input.h"

extern "C" bool zcsr_editor_test_init(void);
extern "C" void zcsr_editor_test_shutdown(void);
extern "C" void zcsr_editor_test_set_save_path(const char *path);
extern "C" int zcsr_editor_test_make_child(void);
extern "C" int zcsr_editor_test_child_alive(void);
extern "C" int zcsr_editor_test_node_count(void);
extern "C" int zcsr_editor_test_playing(void);
extern "C" int zcsr_editor_test_dirty(void);
extern "C" void zcsr_editor_test_open_rename(void);
extern "C" void zcsr_editor_test_set_rename_name(const char *name);
extern "C" int zcsr_editor_test_rename_enter(void);
extern "C" void zcsr_editor_test_child_key(char *out, int cap);
extern "C" int zcsr_editor_test_owns_key(int key);
extern "C" void zcsr_editor_test_begin_key(int key, int ctrl, int shift);
extern "C" void zcsr_editor_test_dispatch(void);
extern "C" void zcsr_editor_test_idle(void);

static int g_failures = 0;

#define CHECK(cond, msg)                                                     \
    do {                                                                     \
        if (!(cond)) {                                                       \
            std::fprintf(stderr, "FAIL: %s (%s:%d)\n", msg, __FILE__, __LINE__); \
            ++g_failures;                                                    \
        }                                                                    \
    } while (0)

int main() {
    CHECK(zcsr_editor_test_init(), "editor test document init");

    // F5 must reach ImGui as a real press edge, toggle Play on then off.
    zcsr_editor_test_begin_key(ZCSR_KEY_F5, 0, 0);
    CHECK(ImGui::IsKeyPressed(ImGuiKey_F5, false), "ZCSR_KEY_F5 maps to ImGuiKey_F5 press");
    zcsr_editor_test_dispatch();
    CHECK(zcsr_editor_test_playing() == 1, "F5 starts Play");
    zcsr_editor_test_idle();
    zcsr_editor_test_begin_key(ZCSR_KEY_F5, 0, 0);
    zcsr_editor_test_dispatch();
    CHECK(zcsr_editor_test_playing() == 0, "second F5 stops Play");
    zcsr_editor_test_idle();

    // ESC stops Play and is owned by the editor (shell must not go home).
    zcsr_editor_test_begin_key(ZCSR_KEY_F5, 0, 0);
    zcsr_editor_test_dispatch();
    zcsr_editor_test_idle();
    CHECK(zcsr_editor_test_playing() == 1, "Play restarted for ESC test");
    zcsr_editor_test_begin_key(ZCSR_KEY_ESCAPE, 0, 0);
    CHECK(ImGui::IsKeyPressed(ImGuiKey_Escape, false), "ZCSR_KEY_ESCAPE maps to ImGuiKey_Escape");
    zcsr_editor_test_dispatch();
    CHECK(zcsr_editor_test_playing() == 0, "ESC stops Play");
    CHECK(zcsr_editor_test_owns_key(ZCSR_KEY_ESCAPE) == 1, "editor owns ESC");
    CHECK(zcsr_editor_test_owns_key(ZCSR_KEY_S) == 1, "editor owns S");
    CHECK(zcsr_editor_test_owns_key(ZCSR_KEY_F5) == 0, "editor does not own F5");
    zcsr_editor_test_idle();

    // Ctrl+S must save through the real shortcut path.
    zcsr_editor_test_set_save_path("editor_key_contract_project.uireproj");
    zcsr_editor_test_begin_key(ZCSR_KEY_S, 1, 0);
    CHECK(ImGui::GetIO().KeyCtrl, "Ctrl modifier visible to ImGui");
    CHECK(ImGui::IsKeyPressed(ImGuiKey_S, false), "ZCSR_KEY_S maps to ImGuiKey_S");
    zcsr_editor_test_dispatch();
    CHECK(zcsr_editor_test_dirty() == 0, "Ctrl+S saves (dirty cleared)");
    zcsr_editor_test_idle();

    // Delete must remove the selected child.
    CHECK(zcsr_editor_test_make_child() > 0, "test child created");
    // Enter in the rename modal commits the new name.
    zcsr_editor_test_open_rename();
    zcsr_editor_test_set_rename_name("renamed_by_enter");
    CHECK(zcsr_editor_test_rename_enter() == 1, "Enter closes rename modal");
    {
        char name[128];
        zcsr_editor_test_child_key(name, (int)sizeof(name));
        CHECK(std::strcmp(name, "renamed_by_enter") == 0, "Enter commits node rename");
    }
    int before = zcsr_editor_test_node_count();
    zcsr_editor_test_begin_key(ZCSR_KEY_DELETE, 0, 0);
    CHECK(ImGui::IsKeyPressed(ImGuiKey_Delete, false), "ZCSR_KEY_DELETE maps to ImGuiKey_Delete");
    zcsr_editor_test_dispatch();
    int after = zcsr_editor_test_node_count();
    CHECK(before > 0 && after == before - 1, "Delete removes selected node");
    CHECK(zcsr_editor_test_child_alive() == 0, "deleted child is gone");
    zcsr_editor_test_idle();

    // Enter and arrows are mapped and observed as presses.
    zcsr_editor_test_begin_key(ZCSR_KEY_ENTER, 0, 0);
    CHECK(ImGui::IsKeyPressed(ImGuiKey_Enter, false), "ZCSR_KEY_ENTER maps to ImGuiKey_Enter");
    zcsr_editor_test_dispatch();
    zcsr_editor_test_idle();
    zcsr_editor_test_begin_key(ZCSR_KEY_ARROW_DOWN, 0, 0);
    CHECK(ImGui::IsKeyPressed(ImGuiKey_DownArrow, false), "ZCSR_KEY_ARROW_DOWN maps to ImGuiKey_DownArrow");
    zcsr_editor_test_dispatch();
    zcsr_editor_test_idle();
    zcsr_editor_test_begin_key(ZCSR_KEY_ARROW_UP, 0, 0);
    CHECK(ImGui::IsKeyPressed(ImGuiKey_UpArrow, false), "ZCSR_KEY_ARROW_UP maps to ImGuiKey_UpArrow");
    zcsr_editor_test_dispatch();
    zcsr_editor_test_idle();

    // 27 is ZCSR_KEY_F2, not a native VK_ESCAPE. Native VK translation happens
    // at the producer boundary (test_input_keymap asserts VK 0x1B -> ESC); a
    // consumer receiving 27 must treat it as F2, not "reject Escape".
    zcsr_editor_test_begin_key(ZCSR_KEY_F2, 0, 0);
    CHECK(ImGui::IsKeyPressed(ImGuiKey_F2, false), "ZCSR_KEY_F2 is a valid engine key");
    zcsr_editor_test_dispatch();
    zcsr_editor_test_idle();

    // Out-of-range values must not reach ImGui as any key.
    zcsr_editor_test_begin_key(ZCSR_KEY_COUNT, 0, 0);
    CHECK(!ImGui::IsKeyPressed(ImGuiKey_Escape, false), "out-of-range code is not Escape");
    CHECK(!ImGui::IsKeyPressed(ImGuiKey_F2, false), "out-of-range code is not F2");
    zcsr_editor_test_dispatch();
    zcsr_editor_test_idle();

    // 116 is also outside ZCSR_KEY_* (F5 is 30), so it must not become F5.
    zcsr_editor_test_begin_key(116, 0, 0);
    CHECK(!ImGui::IsKeyPressed(ImGuiKey_F5, false), "116 is not a ZCSR key");
    zcsr_editor_test_dispatch();
    zcsr_editor_test_idle();

    zcsr_editor_test_shutdown();
    std::remove("editor_key_contract_project.uireproj");
    if (g_failures == 0) {
        std::printf("editor_key_contract: all checks passed\n");
        return 0;
    }
    std::printf("editor_key_contract: %d failure(s)\n", g_failures);
    return 1;
}
