#include "ui_selection.h"
#include "ui_hierarchy.h"
#include "ui_editor_interaction.h"

#include <stdio.h>
#include <string.h>

static int failures = 0;
#define CHECK(cond, what) do { if (!(cond)) { printf("FAIL: %s\n", what); failures++; } } while (0)

int main(void) {
    UIM_ComponentManager *m = NULL;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = 0;
    uim_NodeId child_a = 0;
    uim_NodeId child_b = 0;
    uim_NodeDesc desc;
    uim_Selection *sel;
    uim_Hierarchy *hier;
    uim_UiInteraction ui;
    uim_HierRow row;
    int clicked;

    CHECK(uim_component_manager_create(NULL, &m) == uim_OK, "manager create");
    CHECK(uim_page_create(m, "main", &page) == uim_OK, "page create");

    memset(&desc, 0, sizeof(desc));
    desc.stable_key = "root";
    desc.page_id = page;
    desc.local_rect = (uim_Rect){0.0f, 0.0f, 320.0f, 200.0f};
    desc.visible = true;
    desc.enabled = true;
    CHECK(uim_node_create(m, &desc, &root) == uim_OK, "root create");

    desc.stable_key = "child_a";
    desc.parent_id = root;
    desc.child_order = 0u;
    desc.local_rect = (uim_Rect){10.0f, 10.0f, 40.0f, 20.0f};
    CHECK(uim_node_create(m, &desc, &child_a) == uim_OK, "child a create");
    desc.stable_key = "child_b";
    desc.parent_id = root;
    desc.child_order = 1u;
    desc.local_rect = (uim_Rect){10.0f, 40.0f, 40.0f, 20.0f};
    CHECK(uim_node_create(m, &desc, &child_b) == uim_OK, "child b create");

    /* Selection: primary is the last added, capacity is bounded. */
    sel = uim_selection_create();
    CHECK(sel != NULL, "selection create");
    uim_selection_set(sel, root);
    uim_selection_add(sel, child_a);
    CHECK(uim_selection_get(sel) == child_a, "selection primary");
    CHECK(uim_selection_count(sel) == 2, "selection count");
    uim_selection_toggle(sel, child_a);
    CHECK(uim_selection_get(sel) == root, "toggle removes primary");
    uim_selection_toggle(sel, child_a);
    CHECK(uim_selection_contains(sel, child_a), "toggle adds");
    uim_selection_clear(sel);
    CHECK(!uim_selection_has_selection(sel), "selection clear");
    uim_selection_destroy(sel);

    /* Hierarchy: root collapsed shows one row; expanding shows children. */
    hier = uim_hierarchy_create();
    CHECK(hier != NULL, "hierarchy create");
    uim_hierarchy_set_source(hier, m, root);
    CHECK(uim_hierarchy_visible_count(hier) == 1, "root collapsed rows");
    CHECK(uim_hierarchy_get_row(hier, 0, &row) && row.node_id == root, "root row");
    CHECK(uim_hierarchy_get_row(hier, 0, &row) && row.has_children, "root has children");
    uim_hierarchy_handle_row_click(hier, 0);
    CHECK(uim_hierarchy_selected(hier) == root, "root selected");
    CHECK(uim_hierarchy_visible_count(hier) == 3, "root expanded rows");
    CHECK(uim_hierarchy_get_row(hier, 1, &row) && row.node_id == child_a, "child a row");
    CHECK(uim_hierarchy_get_row(hier, 2, &row) && row.node_id == child_b, "child b row");
    uim_hierarchy_select_row(hier, 1);
    CHECK(uim_hierarchy_selected(hier) == child_a, "child selected");
    uim_hierarchy_toggle_row(hier, 0);
    CHECK(uim_hierarchy_visible_count(hier) == 1, "root collapsed again");
    uim_hierarchy_destroy(hier);

    /* Interaction: press/click, drag threshold, release on target. */
    uim_ui_interaction_reset(&ui);
    CHECK(uim_ui_hit_add(&ui, uim_UI_REGION_RUNTIME, 10,
                         (uim_Rect){0.0f, 0.0f, 100.0f, 100.0f}, true) == 0,
          "hit add");
    uim_ui_begin_frame(&ui);
    CHECK(uim_ui_hit_add(&ui, uim_UI_REGION_RUNTIME, 10,
                         (uim_Rect){0.0f, 0.0f, 100.0f, 100.0f}, true) == 0,
          "hit add frame 2");
    clicked = uim_ui_update(&ui, 10.0f, 10.0f, true);
    CHECK(clicked == 10, "click on press");
    CHECK(uim_ui_press_id(&ui) == 10, "press id");
    uim_ui_begin_frame(&ui);
    CHECK(uim_ui_hit_add(&ui, uim_UI_REGION_RUNTIME, 10,
                         (uim_Rect){0.0f, 0.0f, 100.0f, 100.0f}, true) == 0,
          "hit add frame 3");
    clicked = uim_ui_update(&ui, 20.0f, 20.0f, true);
    CHECK(clicked == 10 && uim_ui_drag_id(&ui) == 10, "drag threshold");
    uim_ui_begin_frame(&ui);
    CHECK(uim_ui_hit_add(&ui, uim_UI_REGION_RUNTIME, 10,
                         (uim_Rect){0.0f, 0.0f, 100.0f, 100.0f}, true) == 0,
          "hit add frame 4");
    clicked = uim_ui_update(&ui, 20.0f, 20.0f, false);
    CHECK(clicked == 10 && uim_ui_released_id(&ui) == 10, "release on target");
    CHECK(uim_ui_released_edge(&ui), "release edge");
    uim_ui_begin_frame(&ui);
    CHECK(uim_ui_hit_add(&ui, uim_UI_REGION_RUNTIME, 10,
                         (uim_Rect){0.0f, 0.0f, 100.0f, 100.0f}, true) == 0,
          "hit add frame 5");
    clicked = uim_ui_update(&ui, 200.0f, 200.0f, false);
    CHECK(clicked == -1 && !uim_ui_released_edge(&ui), "release outside");

    uim_component_manager_destroy(m);
    if (failures == 0) {
        printf("editor_domains: all checks passed\n");
        return 0;
    }
    printf("editor_domains: %d failure(s)\n", failures);
    return 1;
}

