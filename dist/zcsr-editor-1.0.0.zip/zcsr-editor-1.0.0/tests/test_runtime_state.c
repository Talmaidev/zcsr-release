#include "uim_component_manager.h"
#include "uim_component_runtime.h"
#include "uim_component_registry.h"

#include <stdio.h>
#include <string.h>

static int fail(const char *msg) {
    printf("FAIL: %s\n", msg);
    return 1;
}

static bool project_fake(void *user, const UIM_ComponentManager *manager,
                         const uim_NodeInfo *info, uim_Rect *out_rect) {
    (void)user;
    (void)manager;
    if (info->space != uim_SPACE_3D) return false;
    *out_rect = (uim_Rect){0.0f, 0.0f, 100.0f, 100.0f};
    return true;
}

static bool text_is(const char *actual, size_t size, const char *expected) {
    return actual != NULL && size == strlen(expected) &&
           memcmp(actual, expected, size) == 0;
}

int main(void) {
    UIM_ComponentManager *manager = NULL;
    UIM_ComponentManagerConfig cfg = {0};
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = uim_NODE_INVALID;
    uim_NodeId button = uim_NODE_INVALID;
    uim_NodeId billboard = uim_NODE_INVALID;
    uim_ComponentInstanceId instance = uim_COMPONENT_INSTANCE_INVALID;
    uim_NodeDesc desc;
    uim_Value value;
    uim_NodeInfo info;
    uim_Transform3 transform;

    cfg.initial_node_capacity = 8;
    cfg.initial_page_capacity = 2;
    if (uim_component_manager_create(&cfg, &manager) != uim_OK) return fail("manager");
    if (uim_page_create(manager, "main", &page) != uim_OK) return fail("page");

    memset(&desc, 0, sizeof(desc));
    desc.stable_key = "root";
    desc.page_id = page;
    desc.component_id = uim_COMPONENT_PANEL;
    desc.local_rect = (uim_Rect){0, 0, 640, 480};
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &root) != uim_OK) return fail("root");

    memset(&desc, 0, sizeof(desc));
    desc.stable_key = "button";
    desc.page_id = page;
    desc.parent_id = root;
    desc.component_id = uim_COMPONENT_BUTTON;
    desc.local_rect = (uim_Rect){10, 20, 120, 40};
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &button) != uim_OK) return fail("button");
    if (uim_component_instance_attach(manager, button, uim_COMPONENT_BUTTON, 1u,
                                      &instance) != uim_OK) return fail("component");
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_STRING;
    value.as.string.data = "before";
    value.as.string.size = 6;
    if (uim_component_instance_set_property(manager, instance, uim_PROPERTY_TEXT,
                                            value) != uim_OK)
        return fail("text set");

    memset(&desc, 0, sizeof(desc));
    desc.stable_key = "billboard";
    desc.page_id = page;
    desc.parent_id = root;
    desc.space = uim_SPACE_3D;
    desc.transform.position[0] = 0.0f;
    desc.transform.position[1] = 0.0f;
    desc.transform.position[2] = 60.0f;
    desc.transform.scale[0] = 1.0f;
    desc.transform.scale[1] = 1.0f;
    desc.transform.scale[2] = 1.0f;
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(manager, &desc, &billboard) != uim_OK) return fail("billboard");

    if (uim_runtime_pick_ex(manager, page, 20.0f, 40.0f, project_fake, NULL) != billboard)
        return fail("3D pick");

    if (!uim_runtime_begin(manager, page)) return fail("begin");
    /* Runtime mutation must be fully rolled back, not only x/y. */
    if (uim_node_get(manager, button, &info) != uim_OK) return fail("read button");
    info.local_rect.width = 777.0f;
    info.local_rect.height = 333.0f;
    if (uim_node_set_rect(manager, button, info.local_rect) != uim_OK)
        return fail("mutate rect");
    value.as.string.data = "after";
    value.as.string.size = 5;
    if (uim_component_instance_set_property(manager, instance, uim_PROPERTY_TEXT,
                                            value) != uim_OK)
        return fail("mutate text");
    transform = (uim_Transform3){0};
    transform.position[2] = 5.0f;
    transform.scale[0] = transform.scale[1] = transform.scale[2] = 1.0f;
    if (uim_node_set_transform3(manager, billboard, &transform) != uim_OK)
        return fail("mutate transform");
    uim_runtime_end();

    if (uim_node_get(manager, button, &info) != uim_OK) return fail("read restored");
    if (info.local_rect.width != 120.0f || info.local_rect.height != 40.0f)
        return fail("rect restore");
    if (uim_component_instance_get_property(manager, instance, uim_PROPERTY_TEXT,
                                            &value) != uim_OK)
        return fail("text read");
    if (!text_is(value.as.string.data, value.as.string.size, "before"))
        return fail("text restore");
    if (uim_node_get_transform3(manager, billboard, &transform) != uim_OK)
        return fail("transform read");
    if (transform.position[2] != 60.0f) return fail("transform restore");

    uim_component_manager_destroy(manager);
    printf("runtime snapshot + 3D pick: PASS\n");
    return 0;
}
