#include "editor_scene_io.h"

#include <math.h>
#include <stdio.h>
#include <string.h>

static int failures = 0;

#define CHECK(cond, msg)                                                    \
    do {                                                                    \
        if (!(cond)) {                                                      \
            fprintf(stderr, "FAIL: %s (%s:%d)\n", msg, __FILE__, __LINE__); \
            ++failures;                                                     \
        }                                                                   \
    } while (0)

static int nearf(float a, float b) {
    return fabsf(a - b) < 1e-4f;
}

static void write_text(const char *path, const char *text) {
    FILE *f = fopen(path, "wb");
    if (!f) return;
    fputs(text, f);
    fclose(f);
}

static void test_roundtrip(void) {
    const char *path = "editor_scene_io_test.uiscene";
    static zcsr_scene src;
    static zcsr_scene loaded;
    zcsr_scene_entity e;
    zcsr_scene_point q[4];
    zcsr_editor_scene_io_result rc;

    zcsr_scene_init(&src);
    src.camera.target_x = 1.5f;
    src.camera.target_y = 0.25f;
    src.camera.target_z = -2.0f;
    src.camera.yaw_deg = 33.0f;
    src.camera.pitch_deg = 27.0f;
    src.camera.roll_deg = 4.0f;
    src.camera.distance = 18.0f;
    src.camera.ortho_size = 9.5f;
    src.camera.view_w = 640;
    src.camera.view_h = 480;

    memset(&e, 0, sizeof(e));
    e.id = 7;
    e.x = -3.0f;
    e.y = 0.5f;
    e.z = 2.0f;
    e.w = 1.25f;
    e.h = 2.5f;
    e.rotation_deg = 12.0f;
    e.pivot_x = 0.25f;
    e.pivot_y = 0.75f;
    e.layer = 3;
    e.order = 4;
    e.tint_r = 0.1f;
    e.tint_g = 0.2f;
    e.tint_b = 0.3f;
    e.tint_a = 0.4f;
    e.texture = 42u;
    e.visible = true;
    e.kind = ZCSR_SCENE_KIND_PREFAB;
    e.prefab_id = 0x1020304050607080ull;
    e.asset_id = 0x8877665544332211ull;
    CHECK(zcsr_scene_add(&src, &e) == 7, "entity 7 add");

    memset(&e, 0, sizeof(e));
    e.id = 9;
    e.x = 4.0f;
    e.z = -1.0f;
    e.w = 2.0f;
    e.h = 2.0f;
    e.tint_a = 1.0f;
    e.layer = 1;
    e.visible = false;
    CHECK(zcsr_scene_add(&src, &e) == 9, "entity 9 add");

    q[0].x = -4.0f; q[0].y = 0.0f; q[0].z = 3.0f;
    q[1].x = -2.0f; q[1].y = 0.0f; q[1].z = 3.0f;
    q[2].x = -2.0f; q[2].y = 1.0f; q[2].z = 1.0f;
    q[3].x = -4.0f; q[3].y = 1.0f; q[3].z = 1.0f;
    CHECK(zcsr_scene_set_quad(&src, 7, q), "quad 7 set");

    rc = zcsr_editor_scene_save(&src, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_OK, "save ok");

    zcsr_scene_init(&loaded);
    loaded.count = 123;
    rc = zcsr_editor_scene_load(&loaded, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_OK, "load ok");
    CHECK(loaded.count == 2, "entity count");
    CHECK(loaded.quad_count == 1, "quad count");
    CHECK(nearf(loaded.camera.target_x, 1.5f), "camera target_x");
    CHECK(nearf(loaded.camera.target_z, -2.0f), "camera target_z");
    CHECK(nearf(loaded.camera.yaw_deg, 33.0f), "camera yaw");
    CHECK(loaded.camera.view_w == 640, "camera view_w");
    CHECK(loaded.camera.view_h == 480, "camera view_h");

    {
        const zcsr_scene_entity *got = zcsr_scene_get_const(&loaded, 7);
        zcsr_scene_point got_q[4];
        CHECK(got != NULL, "entity 7 present");
        if (got) {
            CHECK(nearf(got->x, -3.0f), "entity x");
            CHECK(nearf(got->w, 1.25f), "entity w");
            CHECK(got->layer == 3 && got->order == 4, "layer/order");
            CHECK(nearf(got->tint_a, 0.4f), "tint a");
            CHECK(got->texture == 42u, "texture id");
            CHECK(got->visible, "visible");
            CHECK(got->kind == ZCSR_SCENE_KIND_PREFAB, "kind");
            CHECK(got->prefab_id == 0x1020304050607080ull, "prefab id");
            CHECK(got->asset_id == 0x8877665544332211ull, "asset id");
        }
        CHECK(zcsr_scene_entity_quad(&loaded, 7, got_q), "quad readable");
        CHECK(nearf(got_q[0].x, -4.0f) && nearf(got_q[2].y, 1.0f),
              "quad corners");
    }

    {
        const zcsr_scene_entity *got = zcsr_scene_get_const(&loaded, 9);
        CHECK(got != NULL, "entity 9 present");
        if (got) CHECK(!got->visible, "hidden stays hidden");
    }

    remove(path);
}

static void test_rejects_bad_input(void) {
    const char *path = "editor_scene_io_bad.uiscene";
    static zcsr_scene scene;
    static zcsr_scene before;
    zcsr_editor_scene_io_result rc;

    zcsr_scene_init(&before);
    before.count = 77;

    write_text(path, "ZCSRSCENE 3\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_HEADER, "bad version rejected");
    CHECK(scene.count == 77, "bad header is transactional");

    write_text(path, "ZCSRSCENE 1\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_RECORD, "missing camera rejected");
    CHECK(scene.count == 77, "missing camera is transactional");

    write_text(path,
               "ZCSRSCENE 1\n"
               "camera 0 0 0 0 45 0 20 8 1\n"
               "camera 0 0 0 0 45 0 20 8 1\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_RECORD, "duplicate camera rejected");

    write_text(path,
               "ZCSRSCENE 1\n"
               "camera 0 0 0 0 45 0 20 8 1\n"
               "entity 7 0 0 0 1 1 0 0.5 0.5 0 0 1 1 1 1 0 1\n"
               "quad 7 0 0 0 1 0 0 1 1 0 0 1 0\n"
               "quad 7 0 0 0 1 0 0 1 1 0 0 1 0\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_RECORD, "duplicate quad rejected");

    write_text(path, "ZCSRSCENE 1\nentity 7 0 0\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_RECORD, "short entity rejected");
    CHECK(scene.count == 77, "bad entity is transactional");

    write_text(path,
               "ZCSRSCENE 1\n"
               "entity 7 0 0 0 1 1 0 0.5 0.5 0 0 1 1 1 1 0 1\n"
               "entity 7 0 0 0 1 1 0 0.5 0.5 0 0 1 1 1 1 0 1\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_RECORD, "duplicate id rejected");
    CHECK(scene.count == 77, "duplicate id is transactional");

    write_text(path,
               "ZCSRSCENE 1\n"
               "quad 7 0 0 0 1 0 0 1 1 0 0 1 0\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_RECORD, "quad without entity rejected");

    write_text(path, "ZCSRSCENE 1\nbogus 1\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_BAD_RECORD, "unknown record rejected");

    write_text(path, "ZCSRSCENE 1\r\ncamera 0 0 0 0 0 0 20 8 1\r\n");
    scene = before;
    rc = zcsr_editor_scene_load(&scene, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_OK, "CRLF accepted");
    CHECK(scene.count == 0, "CRLF camera-only scene");

    remove(path);
}

static void test_empty_scene(void) {
    const char *path = "editor_scene_io_empty.uiscene";
    static zcsr_scene src;
    static zcsr_scene loaded;
    zcsr_editor_scene_io_result rc;

    zcsr_scene_init(&src);
    rc = zcsr_editor_scene_save(&src, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_OK, "empty save");
    zcsr_scene_init(&loaded);
    loaded.count = 55;
    rc = zcsr_editor_scene_load(&loaded, path);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_OK, "empty load");
    CHECK(loaded.count == 0, "empty count");
    remove(path);
}

static void test_named_file(const char *path) {
    static zcsr_scene scene;
    zcsr_editor_scene_io_result rc;
    zcsr_scene_init(&scene);
    rc = zcsr_editor_scene_load(&scene, path);
    printf("%s: %s, entities=%zu, quads=%zu\n", path,
           zcsr_editor_scene_io_result_name(rc), scene.count,
           scene.quad_count);
    CHECK(rc == ZCSR_EDITOR_SCENE_IO_OK, "named scene loads");
}

int main(int argc, char **argv) {
    if (argc == 2) {
        test_named_file(argv[1]);
        return failures == 0 ? 0 : 1;
    }

    test_roundtrip();
    test_rejects_bad_input();
    test_empty_scene();

    CHECK(strcmp(zcsr_editor_scene_io_result_name(ZCSR_EDITOR_SCENE_IO_OK),
                 "ok") == 0,
          "result name ok");
    CHECK(strcmp(zcsr_editor_scene_io_result_name(
                     ZCSR_EDITOR_SCENE_IO_BAD_RECORD),
                 "bad record") == 0,
          "result name bad record");

    CHECK(zcsr_editor_scene_save(NULL, "x.uiscene") ==
              ZCSR_EDITOR_SCENE_IO_INVALID_ARGUMENT,
          "null scene rejected");
    CHECK(zcsr_editor_scene_load(NULL, "x.uiscene") ==
              ZCSR_EDITOR_SCENE_IO_INVALID_ARGUMENT,
          "null scene load rejected");

    if (failures == 0) {
        printf("editor_scene_io: PASS\n");
        return 0;
    }
    fprintf(stderr, "editor_scene_io: %d failure(s)\n", failures);
    return 1;
}
