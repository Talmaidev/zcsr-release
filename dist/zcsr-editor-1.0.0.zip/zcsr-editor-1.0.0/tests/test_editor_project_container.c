#include "editor_project_container.h"
#include "editor_scene_io.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures = 0;
#define CHECK(cond, what) do { if (!(cond)) { printf("FAIL: %s\n", what); failures++; } } while (0)

int main(void) {
    const char *path = "editor_container_test.uiproj";
    const unsigned char project[] = "UIRJ synthetic-project-payload";
    zcsr_scene *scene;
    zcsr_scene *loaded;
    zcsr_scene_entity e;
    char *scene_text = NULL;
    size_t scene_size = 0u;
    unsigned char *read_project = NULL;
    size_t read_project_size = 0u;
    char *read_scene = NULL;
    size_t read_scene_size = 0u;
    zcsr_editor_container_result crc;

    scene = (zcsr_scene *)calloc(1u, sizeof(*scene));
    loaded = (zcsr_scene *)calloc(1u, sizeof(*loaded));
    CHECK(scene != NULL && loaded != NULL, "scene allocation");
    zcsr_scene_init(scene);
    memset(&e, 0, sizeof(e));
    e.id = 11;
    e.w = 32.0f;
    e.h = 16.0f;
    e.visible = true;
    e.kind = ZCSR_SCENE_KIND_PREFAB;
    e.prefab_id = 77u;
    e.asset_id = 88u;
    CHECK(zcsr_scene_add(scene, &e) == 11, "scene entity add");
    scene->camera.view_h = 480;
    CHECK(zcsr_editor_scene_serialize(scene, &scene_text, &scene_size) ==
          ZCSR_EDITOR_SCENE_IO_OK, "scene serialize");

    crc = zcsr_editor_project_container_save(path, project,
                                             sizeof(project) - 1u,
                                             scene_text, scene_size);
    CHECK(crc == ZCSR_EDITOR_CONTAINER_OK, "container save");
    CHECK(zcsr_editor_project_container_probe(path), "container probe");

    crc = zcsr_editor_project_container_load(path, &read_project,
                                             &read_project_size, &read_scene,
                                             &read_scene_size);
    CHECK(crc == ZCSR_EDITOR_CONTAINER_OK, "container load");
    CHECK(read_project_size == sizeof(project) - 1u &&
          memcmp(read_project, project, read_project_size) == 0,
          "project bytes roundtrip");
    CHECK(read_scene_size == scene_size, "scene bytes size");
    CHECK(zcsr_editor_scene_deserialize(read_scene, read_scene_size, loaded) ==
          ZCSR_EDITOR_SCENE_IO_OK, "scene bytes decode");
    CHECK(loaded->count == 1u && loaded->entities[0].prefab_id == 77u &&
          loaded->entities[0].asset_id == 88u, "scene fields roundtrip");
    CHECK(loaded->camera.view_h == 480, "camera view_h roundtrip");

    free(scene);
    free(loaded);
    free(scene_text);
    free(read_project);
    free(read_scene);
    remove(path);

    if (failures == 0) {
        printf("editor_project_container: all checks passed\n");
        return 0;
    }
    printf("editor_project_container: %d failure(s)\n", failures);
    return 1;
}
