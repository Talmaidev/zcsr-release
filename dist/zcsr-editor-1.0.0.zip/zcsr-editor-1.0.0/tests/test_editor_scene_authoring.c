#include "editor_scene_authoring.h"

#include <math.h>
#include <stdio.h>
#include <string.h>

static int failures = 0;
static zcsr_scene scene; /* fixed-capacity; keep off the test thread stack */

#define CHECK(cond, msg)                                                    \
    do {                                                                    \
        if (!(cond)) {                                                      \
            fprintf(stderr, "FAIL: %s (%s:%d)\n", msg, __FILE__, __LINE__); \
            ++failures;                                                     \
        }                                                                   \
    } while (0)

static int nearf(float a, float b) { return fabsf(a - b) < 1e-4f; }

static void test_box_quad_duplicate(void) {
    zcsr_editor_scene_change change;
    zcsr_scene_point q[4];

    zcsr_scene_init(&scene);
    change = zcsr_editor_scene_add_box(&scene, 1.0f, 2.0f, 3.0f, 4.0f,
                                      0.1f, 0.2f, 0.3f);
    CHECK(change.changed && change.id == 1, "add box id");
    CHECK(scene.count == 1, "add box count");
    {
        const zcsr_scene_entity *e = zcsr_scene_get_const(&scene, 1);
        CHECK(e != NULL, "box exists");
        if (e) {
            CHECK(nearf(e->x, 1.0f) && nearf(e->z, 2.0f), "box position");
            CHECK(nearf(e->w, 3.0f) && nearf(e->h, 4.0f), "box size");
            CHECK(e->layer == 0 && e->order == 0, "box order");
            CHECK(e->visible, "box visible");
        }
    }

    change = zcsr_editor_scene_add_quad(&scene, 5.0f, 6.0f, 2.0f,
                                        0.4f, 0.5f, 0.6f);
    CHECK(change.changed && change.id == 2, "add quad id");
    CHECK(scene.quad_count == 1, "add quad override");
    CHECK(zcsr_scene_entity_quad(&scene, 2, q), "quad readable");
    CHECK(nearf(q[0].x, 4.0f) && nearf(q[2].z, 7.3f), "default quad shape");

    change = zcsr_editor_scene_duplicate(&scene, 2, 1.0f, -1.0f);
    CHECK(change.changed && change.id == 3, "duplicate id");
    CHECK(scene.count == 3, "duplicate count");
    CHECK(zcsr_scene_has_quad(&scene, 3), "duplicate quad");
    {
        zcsr_scene_point copy_q[4];
        CHECK(zcsr_scene_entity_quad(&scene, 3, copy_q), "duplicate quad readable");
        CHECK(nearf(copy_q[0].x, q[0].x + 1.0f) &&
                  nearf(copy_q[2].z, q[2].z - 1.0f),
              "duplicate quad offset");
    }
}

static void test_move_and_quad_edit(void) {
    zcsr_scene_point q[4];
    zcsr_scene_point before[4];
    zcsr_editor_scene_change change;
    bool ok;

    zcsr_scene_init(&scene);
    change = zcsr_editor_scene_add_quad(&scene, 0.0f, 0.0f, 2.0f,
                                        1.0f, 1.0f, 1.0f);
    CHECK(change.changed, "quad setup");

    CHECK(zcsr_scene_entity_quad(&scene, 1, before), "read before move");
    ok = zcsr_editor_scene_move(&scene, 1, 2.0f, -3.0f);
    CHECK(ok, "move quad");
    {
        const zcsr_scene_entity *e = zcsr_scene_get_const(&scene, 1);
        CHECK(e && nearf(e->x, 2.0f) && nearf(e->z, -3.0f), "quad entity moved");
    }
    CHECK(zcsr_scene_entity_quad(&scene, 1, q), "read after move");
    CHECK(nearf(q[0].x, before[0].x + 2.0f) &&
              nearf(q[0].z, before[0].z - 3.0f),
          "quad corners moved");

    CHECK(zcsr_scene_entity_quad(&scene, 1, q), "read before height");
    CHECK(zcsr_editor_scene_set_y(&scene, 1, q[0].y + 2.0f), "set height");
    {
        const zcsr_scene_entity *e = zcsr_scene_get_const(&scene, 1);
        CHECK(e && nearf(e->y, 2.0f), "entity height stored");
    }
    {
        zcsr_scene_point after[4];
        CHECK(zcsr_scene_entity_quad(&scene, 1, after), "read after height");
        CHECK(nearf(after[0].y, q[0].y + 2.0f) &&
                  nearf(after[0].x, q[0].x),
              "quad shifted on Y only");
    }
    CHECK(!zcsr_editor_scene_set_y(&scene, 1, NAN), "non-finite height rejected");

    CHECK(zcsr_editor_scene_set_corner(&scene, 1, 2, 9.0f, 1.0f, 8.0f),
          "set corner");
    CHECK(zcsr_scene_entity_quad(&scene, 1, q), "read corner");
    CHECK(nearf(q[2].x, 9.0f) && nearf(q[2].y, 1.0f) && nearf(q[2].z, 8.0f),
          "corner changed");
    CHECK(nearf(q[0].x, before[0].x + 2.0f), "other corner preserved");

    CHECK(!zcsr_editor_scene_set_corner(&scene, 1, 4, 0.0f, 0.0f, 0.0f),
          "bad corner index rejected");
    CHECK(!zcsr_editor_scene_set_corner(&scene, 1, 0, NAN, 0.0f, 0.0f),
          "non-finite corner rejected");
    CHECK(!zcsr_editor_scene_set_quad(&scene, 99, before),
          "missing entity quad rejected");

    CHECK(zcsr_editor_scene_clear_quad(&scene, 1), "clear quad");
    CHECK(!zcsr_scene_has_quad(&scene, 1), "quad cleared");
}

static void test_delete_and_rejections(void) {
    zcsr_editor_scene_change change;

    zcsr_scene_init(&scene);
    CHECK(zcsr_editor_scene_add_box(&scene, 0, 0, 1, 1, 1, 1, 1).changed,
          "delete setup");
    change = zcsr_editor_scene_delete(&scene, 1);
    CHECK(change.changed && change.id == 0, "delete clears selection");
    CHECK(scene.count == 0, "delete removed entity");

    change = zcsr_editor_scene_delete(&scene, 99);
    CHECK(!change.changed, "delete missing is no-op");
    change = zcsr_editor_scene_duplicate(&scene, 99, 1, 1);
    CHECK(!change.changed, "duplicate missing is no-op");
    change = zcsr_editor_scene_add_box(&scene, NAN, 0, 1, 1, 1, 1, 1);
    CHECK(!change.changed, "non-finite add rejected");
    change = zcsr_editor_scene_add_quad(&scene, 0, 0, 0, 1, 1, 1);
    CHECK(!change.changed, "zero-size quad rejected");
}

static void test_asset_size_rotation(void) {
    zcsr_editor_scene_change change;
    zcsr_scene_point q[4];
    zcsr_scene_init(&scene);
    change = zcsr_editor_scene_add_asset(&scene, 4.0f, 5.0f, 2.0f, 1.0f,
                                         ZCSR_SCENE_KIND_SPRITE, 0u, 7u);
    CHECK(change.changed && change.id != 0, "add asset");
    {
        const zcsr_scene_entity *e = zcsr_scene_get_const(&scene, change.id);
        CHECK(e && e->kind == ZCSR_SCENE_KIND_SPRITE && e->asset_id == 7u,
              "asset reference");
    }
    CHECK(zcsr_editor_scene_set_asset_ref(&scene, change.id,
                                          ZCSR_SCENE_KIND_PREFAB, 11u, 3u),
          "set asset ref");
    {
        const zcsr_scene_entity *e = zcsr_scene_get_const(&scene, change.id);
        CHECK(e && e->kind == ZCSR_SCENE_KIND_PREFAB && e->prefab_id == 11u &&
                  e->asset_id == 3u,
              "asset ref updated");
    }
    CHECK(zcsr_editor_scene_set_size(&scene, change.id, 4.0f, 2.0f), "set size");
    CHECK(zcsr_editor_scene_set_rotation(&scene, change.id, 90.0f), "set rotation");
    CHECK(zcsr_scene_entity_quad(&scene, change.id, q), "rotated quad readable");
    {
        const zcsr_scene_entity *e = zcsr_scene_get_const(&scene, change.id);
        CHECK(e && nearf(e->rotation_deg, 90.0f), "rotation stored");
    }
    CHECK(isfinite(q[0].x) && isfinite(q[0].z), "rotated quad finite");
    CHECK(!zcsr_editor_scene_set_size(&scene, change.id, -1.0f, 1.0f),
          "negative size rejected");
    CHECK(!zcsr_editor_scene_set_rotation(&scene, change.id, NAN),
          "non-finite rotation rejected");
    CHECK(!zcsr_editor_scene_set_asset_ref(&scene, 99, ZCSR_SCENE_KIND_SPRITE, 0u, 0u),
          "missing asset ref rejected");
}

int main(void) {
    test_box_quad_duplicate();
    test_move_and_quad_edit();
    test_delete_and_rejections();
    test_asset_size_rotation();

    if (failures == 0) {
        printf("editor_scene_authoring: PASS\n");
        return 0;
    }
    fprintf(stderr, "editor_scene_authoring: %d failure(s)\n", failures);
    return 1;
}
