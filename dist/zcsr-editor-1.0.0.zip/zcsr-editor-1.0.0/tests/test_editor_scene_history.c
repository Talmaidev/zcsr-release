#include "editor_scene_history.h"
#include "zcsr/scene.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures = 0;
#define CHECK(cond, msg)                                                     \
    do {                                                                     \
        if (!(cond)) {                                                       \
            fprintf(stderr, "FAIL: %s (%s:%d)\n", msg, __FILE__, __LINE__);  \
            ++failures;                                                      \
        }                                                                    \
    } while (0)

static zcsr_entity_id add_entity(zcsr_scene* scene, float x) {
    zcsr_scene_entity e;
    memset(&e, 0, sizeof(e));
    e.x = x;
    e.z = 0.0f;
    e.y = 0.0f;
    e.w = 1.0f;
    e.h = 1.0f;
    e.rotation_deg = 0.0f;
    e.pivot_x = 0.5f;
    e.pivot_y = 0.5f;
    e.tint_r = e.tint_g = e.tint_b = e.tint_a = 1.0f;
    e.visible = true;
    return zcsr_scene_add(scene, &e);
}

int main(void) {
    zcsr_scene* scene;
    zcsr_editor_scene_history* history;
    zcsr_entity_id first;
    zcsr_entity_id second;
    zcsr_scene_camera camera_before;

    scene = (zcsr_scene*)calloc(1, sizeof(*scene));
    CHECK(scene != NULL, "scene allocation");
    if (!scene) return 1;
    zcsr_scene_init(scene);
    history = zcsr_editor_scene_history_create();
    CHECK(history != NULL, "history allocation");
    if (!history) {
        free(scene);
        return 1;
    }

    /* One committed gesture = one undo entry. */
    CHECK(zcsr_editor_scene_history_begin(history, scene) == true, "begin add 1");
    first = add_entity(scene, 1.0f);
    CHECK(first != 0, "add first");
    CHECK(zcsr_editor_scene_history_commit(history, scene) == true, "commit add 1");
    CHECK(zcsr_editor_scene_history_undo_count(history) == 1, "one undo entry");

    camera_before = scene->camera;
    scene->camera.target_x += 10.0f;
    CHECK(zcsr_editor_scene_history_undo(history, scene) == true, "undo add 1");
    CHECK(scene->count == 0, "undo removes entity");
    CHECK(scene->camera.target_x == camera_before.target_x + 10.0f,
          "undo preserves camera");
    CHECK(zcsr_editor_scene_history_redo_count(history) == 1, "one redo entry");

    CHECK(zcsr_editor_scene_history_redo(history, scene) == true, "redo add 1");
    CHECK(scene->count == 1 && scene->entities[0].id == first, "redo restores entity");

    /* A no-op gesture must not create an entry. */
    CHECK(zcsr_editor_scene_history_begin(history, scene) == true, "begin no-op");
    CHECK(zcsr_editor_scene_history_commit(history, scene) == false, "no-op not recorded");
    CHECK(zcsr_editor_scene_history_undo_count(history) == 1, "no-op keeps count");

    /* Cancel restores pre-gesture content. */
    CHECK(zcsr_editor_scene_history_begin(history, scene) == true, "begin cancel");
    second = add_entity(scene, 2.0f);
    CHECK(second != 0, "add second");
    CHECK(zcsr_editor_scene_history_cancel(history, scene) == true, "cancel restores");
    CHECK(scene->count == 1, "cancel removes second");

    /* New edit after undo clears redo. */
    CHECK(zcsr_editor_scene_history_undo(history, scene) == true, "undo again");
    CHECK(zcsr_editor_scene_history_begin(history, scene) == true, "begin after undo");
    second = add_entity(scene, 3.0f);
    CHECK(second != 0, "add after undo");
    CHECK(zcsr_editor_scene_history_commit(history, scene) == true, "commit after undo");
    CHECK(zcsr_editor_scene_history_redo_count(history) == 0, "redo cleared");

    /* next_id must not be rewound by undo. */
    CHECK(scene->next_id > second, "next_id remains high-water");

    /* A move over a populated scene must keep every entity; undo is not a
     * "restore the previous count" operation. */
    {
        zcsr_scene* populated;
        zcsr_editor_scene_history* move_history;
        zcsr_entity_id a, b, c;
        populated = (zcsr_scene*)calloc(1, sizeof(*populated));
        CHECK(populated != NULL, "populated scene allocation");
        if (!populated) return 1;
        zcsr_scene_init(populated);
        a = add_entity(populated, -3.0f);
        b = add_entity(populated, 0.0f);
        c = add_entity(populated, 3.0f);
        CHECK(a != 0 && b != 0 && c != 0, "populate three entities");
        {
            zcsr_scene_point quad[4] = {
                {2.0f, 0.0f, -1.0f},
                {4.5f, 0.0f, -0.8f},
                {4.0f, 0.0f, 1.3f},
                {1.4f, 0.0f, 0.7f}
            };
            CHECK(zcsr_scene_set_quad(populated, c, quad) == true,
                  "explicit quad on third entity");
        }
        move_history = zcsr_editor_scene_history_create();
        CHECK(move_history != NULL, "move history allocation");
        if (move_history) {
            CHECK(zcsr_editor_scene_history_begin(move_history, populated) == true,
                  "begin move over populated scene");
            populated->entities[0].x = -1.0f;
            populated->entities[0].z = -1.0f;
            CHECK(zcsr_editor_scene_history_commit(move_history, populated) == true,
                  "commit populated move");
            CHECK(zcsr_editor_scene_history_undo(move_history, populated) == true,
                  "undo populated move");
            CHECK(populated->count == 3, "undo keeps all three entities");
            CHECK(populated->entities[0].id == a &&
                  populated->entities[1].id == b &&
                  populated->entities[2].id == c,
                  "undo keeps entity identity");
            CHECK(populated->entities[0].x == -3.0f &&
                  populated->entities[0].z == 0.0f,
                  "undo restores the moved position");
            CHECK(populated->quad_count == 1 &&
                  zcsr_scene_has_quad(populated, c),
                  "undo keeps the explicit quad");
            CHECK(zcsr_editor_scene_history_redo(move_history, populated) == true,
                  "redo populated move");
            CHECK(populated->count == 3, "redo keeps all three entities");
            CHECK(populated->entities[0].x == -1.0f &&
                  populated->entities[0].z == -1.0f,
                  "redo reapplies the move");
            CHECK(populated->quad_count == 1 &&
                  zcsr_scene_has_quad(populated, c),
                  "redo keeps the explicit quad");
            zcsr_editor_scene_history_destroy(move_history);
        }
        free(populated);
    }

    zcsr_editor_scene_history_destroy(history);
    free(scene);
    if (failures == 0) {
        printf("editor_scene_history: all checks passed\n");
        return 0;
    }
    printf("editor_scene_history: %d failure(s)\n", failures);
    return 1;
}
