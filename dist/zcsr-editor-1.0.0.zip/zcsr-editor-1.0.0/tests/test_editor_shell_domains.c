#include "ui_editor_workspace.h"
#include "ui_editor_shell.h"
#include "ui_editor_shell_persist.h"
#include "ui_editor_viewport_host.h"
#include "ui_project_browser.h"
#include "ui_editor_file_service_host.h"
#include "zcsr/file_service.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static int failures;
#define CHECK(x) do { if (!(x)) { printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #x); failures++; } } while (0)

static void test_workspace(void)
{
    uim_Workspace ws;
    uim_WorkspaceFrame frame;
    uim_WorkspacePanelView view;
    CHECK(uim_workspace_init_default(&ws, NULL) == uim_OK);
    CHECK(uim_workspace_build_frame(&ws, &frame) == uim_OK);
    CHECK(frame.panel_count >= 8);
    CHECK(uim_workspace_get_panel_view(&frame, uim_WORKSPACE_PANEL_SCENE, &view) == uim_OK);
    CHECK(view.active && view.content_rect.width > 0.0f && view.content_rect.height > 0.0f);
    CHECK(uim_workspace_activate_panel(&ws, uim_WORKSPACE_PANEL_GAME) == uim_OK);
    CHECK(ws.viewport_mode == uim_WORKSPACE_VIEW_GAME);
    CHECK(uim_workspace_build_frame(&ws, &frame) == uim_OK);
    CHECK(uim_workspace_get_panel_view(&frame, uim_WORKSPACE_PANEL_GAME, &view) == uim_OK);
    CHECK(view.active);

    CHECK(frame.splitter_count > 0);
    uim_WorkspaceSplitterView split = frame.splitters[0];
    float before = ws.nodes[split.node_id].ratio;
    CHECK(uim_workspace_pointer_down(&ws, &frame, split.rect.x + 1.0f, split.rect.y + 1.0f) == uim_OK);
    CHECK(ws.active_splitter == split.node_id);
    CHECK(uim_workspace_pointer_move(&ws, split.rect.x + 80.0f, split.rect.y + 1.0f) == uim_OK);
    CHECK(ws.nodes[split.node_id].ratio != before);
    CHECK(uim_workspace_pointer_up(&ws) == uim_OK);

    CHECK(uim_workspace_dock_panel(&ws, uim_WORKSPACE_PANEL_INSPECTOR,
                                   uim_WORKSPACE_PANEL_PROJECT, uim_WORKSPACE_DOCK_CENTER) == uim_OK);
    CHECK(uim_workspace_build_frame(&ws, &frame) == uim_OK);
    CHECK(uim_workspace_get_panel_view(&frame, uim_WORKSPACE_PANEL_INSPECTOR, &view) == uim_OK);
    CHECK(uim_workspace_get_drop_target(&frame, view.content_rect.x + 1.0f,
                                       view.content_rect.y + view.content_rect.height * 0.5f,
                                       &view.panel_id, &(uim_WorkspaceDockZone){0}) == uim_OK);
    CHECK(uim_workspace_close_panel(&ws, uim_WORKSPACE_PANEL_CONSOLE) == uim_OK);
    CHECK(uim_workspace_get_panel_title(&ws, uim_WORKSPACE_PANEL_SCENE, (const char **)&view) == uim_OK);
}

static void test_shell(void)
{
    uim_EditorShell shell;
    uim_EditorShellFrame frame;
    uim_EditorShellEvent event;
    uim_Rect center;
    uim_WorkspaceViewportMode mode;
    CHECK(uir_editor_shell_init_default(&shell, 1280.0f, 720.0f) == uim_OK);
    CHECK(uir_editor_shell_build_frame(&shell, &frame) == uim_OK);
    CHECK(frame.element_count > 10);
    CHECK(frame.center_host_rect.width > 0.0f);
    CHECK(uir_editor_shell_get_center_host(&shell, &center, &mode) == uim_OK);
    CHECK(center.width == frame.center_host_rect.width);

    uim_EditorShellCommandDesc cmd = {200, "Save", 1, uim_SHELL_COMMAND_MENU | uim_SHELL_COMMAND_ENABLED,
                                      'S', uim_SHELL_MOD_CTRL, 0};
    CHECK(uir_editor_shell_register_command(&shell, &cmd) == uim_OK);
    CHECK(uir_editor_shell_key_down(&shell, 'S', uim_SHELL_MOD_CTRL) == uim_OK);
    CHECK(uir_editor_shell_poll_event(&shell, &event) == uim_OK);
    CHECK(event.type == uim_SHELL_EVENT_COMMAND && event.command_id == 200);

    /* The C shell must build and dispatch real menu items; this is the path
     * the PVZ editor uses, not the C++/ImGui host. */
    CHECK(uir_editor_shell_build_frame(&shell, &frame) == uim_OK);
    CHECK(uir_editor_shell_pointer_down(&shell, 20.0f, 10.0f, 0u) == uim_OK);
    CHECK(shell.open_menu == uim_SHELL_MENU_FILE);
    CHECK(uir_editor_shell_pointer_up(&shell, 20.0f, 10.0f) == uim_OK);
    CHECK(shell.open_menu == uim_SHELL_MENU_FILE);
    CHECK(uir_editor_shell_build_frame(&shell, &frame) == uim_OK);
    {
        const uim_EditorShellElement *item = NULL;
        for (size_t i = 0; i < frame.element_count; ++i)
            if (frame.elements[i].kind == uim_SHELL_ELEMENT_MENU_ITEM &&
                frame.elements[i].command_id == 200)
                item = &frame.elements[i];
        CHECK(item != NULL);
        if (item) {
            CHECK(uir_editor_shell_pointer_down(&shell,
                                               item->rect.x + 5.0f,
                                               item->rect.y + 5.0f, 0u) == uim_OK);
            CHECK(shell.capture == uim_SHELL_CAPTURE_MENU_ITEM);
            CHECK(uir_editor_shell_pointer_up(&shell,
                                             item->rect.x + 5.0f,
                                             item->rect.y + 5.0f) == uim_OK);
            CHECK(uir_editor_shell_poll_event(&shell, &event) == uim_OK);
            CHECK(event.type == uim_SHELL_EVENT_COMMAND && event.command_id == 200);
            CHECK(shell.open_menu == uim_SHELL_MENU_NONE);
        }
    }

    /* Pointer-driven tab drag/drop must dock through the shell, not only
     * through a direct panel_dock() call. */
    uim_WorkspacePanelView project_view, scene_view, moved_view;
    CHECK(uim_workspace_get_panel_view(&shell.workspace_frame, uim_WORKSPACE_PANEL_PROJECT, &project_view) == uim_OK);
    CHECK(uim_workspace_get_panel_view(&shell.workspace_frame, uim_WORKSPACE_PANEL_SCENE, &scene_view) == uim_OK);
    CHECK(uir_editor_shell_pointer_down(&shell,
                                       project_view.tab_rect.x + project_view.tab_rect.width * 0.5f,
                                       project_view.tab_rect.y + project_view.tab_rect.height * 0.5f,
                                       0u) == uim_OK);
    CHECK(shell.capture == uim_SHELL_CAPTURE_TAB);
    CHECK(shell.drag_panel == uim_WORKSPACE_PANEL_PROJECT);
    CHECK(uir_editor_shell_pointer_move(&shell, shell.pointer_down_x + 20.0f,
                                        shell.pointer_down_y) == uim_OK);
    CHECK(shell.drag_started);
    CHECK(uir_editor_shell_pointer_up(&shell,
                                     scene_view.content_rect.x + scene_view.content_rect.width * 0.5f,
                                     scene_view.content_rect.y + scene_view.content_rect.height * 0.5f) == uim_OK);
    CHECK(uir_editor_shell_build_frame(&shell, &frame) == uim_OK);
    CHECK(uim_workspace_get_panel_view(&shell.workspace_frame, uim_WORKSPACE_PANEL_PROJECT, &moved_view) == uim_OK);
    CHECK(uim_workspace_get_panel_view(&shell.workspace_frame, uim_WORKSPACE_PANEL_SCENE, &scene_view) == uim_OK);
    CHECK(moved_view.group_node == scene_view.group_node);

    CHECK(uir_editor_shell_panel_hide(&shell, uim_WORKSPACE_PANEL_CONSOLE) == uim_OK);
    CHECK(uir_editor_shell_panel_show(&shell, uim_WORKSPACE_PANEL_CONSOLE) == uim_OK);
    CHECK(uir_editor_shell_panel_float(&shell, uim_WORKSPACE_PANEL_INSPECTOR,
                                      (uim_Rect){100, 100, 300, 400}) == uim_OK);
    CHECK(shell.floating_count == 1);
    CHECK(uir_editor_shell_panel_dock(&shell, uim_WORKSPACE_PANEL_INSPECTOR,
                                      uim_WORKSPACE_PANEL_SCENE, uim_WORKSPACE_DOCK_RIGHT) == uim_OK);
    CHECK(uir_editor_shell_set_center_maximized(&shell, true) == uim_OK);
    CHECK(uir_editor_shell_reset_layout(&shell) == uim_OK);
    CHECK(uir_editor_shell_build_frame(&shell, &frame) == uim_OK);
}

static void test_persist(void)
{
    uim_EditorShell shell;
    CHECK(uir_editor_shell_init_default(&shell, 1280.0f, 720.0f) == uim_OK);
    CHECK(uir_editor_shell_set_bounds(&shell, 1600.0f, 900.0f) == uim_OK);
    size_t size = uir_editor_shell_layout_serialized_size();
    unsigned char *buffer = (unsigned char *)malloc(size);
    CHECK(buffer != NULL);
    if (!buffer) return;
    size_t written = 0;
    CHECK(uir_editor_shell_layout_save(&shell, buffer, size, &written) == uim_OK);
    CHECK(written == size);
    CHECK(uir_editor_shell_layout_save(&shell, buffer, size - 1, &written) == uim_ERR_BUFFER);
    uim_EditorShell restored;
    CHECK(uir_editor_shell_init_default(&restored, 640.0f, 480.0f) == uim_OK);
    CHECK(uir_editor_shell_layout_load(&restored, buffer, size) == uim_OK);
    CHECK(restored.workspace.root == shell.workspace.root);
    CHECK(restored.workspace.config.width == 1600.0f);
    buffer[size / 2] ^= 0x40;
    CHECK(uir_editor_shell_layout_load(&restored, buffer, size) == uim_ERR_STATE);
    free(buffer);
}

typedef struct FakeViewport {
    int creates, rects, modes, visible, focus, route, inputs, renders, destroys;
} FakeViewport;

static uim_Result vp_create(void *u, uintptr_t *token, uint64_t *gen)
{
    FakeViewport *f = (FakeViewport *)u;
    f->creates++; *token = 0x1234; *gen = 7; return uim_OK;
}
static uim_Result vp_rect(void *u, uintptr_t t, uint64_t g, uim_Rect r)
{ FakeViewport *f = (FakeViewport *)u; f->rects++; return t == 0x1234 && g == 7 && r.width > 0 ? uim_OK : uim_ERR_STATE; }
static uim_Result vp_mode(void *u, uintptr_t t, uint64_t g, uim_WorkspaceViewportMode m)
{ (void)t; (void)g; (void)m; ((FakeViewport *)u)->modes++; return uim_OK; }
static uim_Result vp_visible(void *u, uintptr_t t, uint64_t g, bool v)
{ (void)t; (void)g; (void)v; ((FakeViewport *)u)->visible++; return uim_OK; }
static uim_Result vp_focus(void *u, uintptr_t t, uint64_t g, bool v)
{ (void)t; (void)g; (void)v; ((FakeViewport *)u)->focus++; return uim_OK; }
static uim_Result vp_route(void *u, uintptr_t t, uint64_t g, uim_EditorViewportInputRoute r)
{ (void)t; (void)g; (void)r; ((FakeViewport *)u)->route++; return uim_OK; }
static uim_Result vp_input(void *u, uintptr_t t, uint64_t g, const uim_EditorViewportInput *i)
{ (void)t; (void)g; (void)i; ((FakeViewport *)u)->inputs++; return uim_OK; }
static uim_Result vp_render(void *u, uintptr_t t, uint64_t g, void *ctx, uim_Rect r, uim_WorkspaceViewportMode m)
{ (void)t; (void)g; (void)ctx; (void)r; (void)m; ((FakeViewport *)u)->renders++; return uim_OK; }
static void vp_destroy(void *u, uintptr_t t, uint64_t g)
{ (void)t; (void)g; ((FakeViewport *)u)->destroys++; }

static void test_viewport(void)
{
    uim_Workspace ws;
    uim_WorkspaceFrame frame;
    FakeViewport fake = {0};
    uim_EditorViewportHost host;
    uim_EditorViewportHostOps ops = {uim_EDITOR_VIEWPORT_HOST_ABI_VERSION, sizeof(ops),
        vp_create, vp_rect, vp_mode, vp_visible, vp_focus, vp_route, vp_input, vp_render, vp_destroy};
    CHECK(uim_workspace_init_default(&ws, NULL) == uim_OK);
    CHECK(uim_workspace_build_frame(&ws, &frame) == uim_OK);
    CHECK(uir_editor_viewport_host_init(&host, &ops, &fake) == uim_OK);
    CHECK(uir_editor_viewport_host_sync(&host, &ws, &frame, true) == uim_OK);
    CHECK(fake.creates == 1 && fake.rects >= 1 && fake.visible >= 1);
    CHECK(uir_editor_viewport_host_sync(&host, &ws, &frame, true) == uim_OK);
    CHECK(fake.rects == 1);
    uim_EditorViewportInput input = {uim_EDITOR_VIEWPORT_POINTER_MOVE, 10, 20, 0, 1, 0, 0, 0, NULL, 0};
    CHECK(uir_editor_viewport_host_process_input(&host, &input) == uim_OK);
    CHECK(fake.inputs == 1);
    CHECK(uir_editor_viewport_host_render(&host, NULL) == uim_OK);
    CHECK(fake.renders == 1);
    uir_editor_viewport_host_destroy(&host);
    CHECK(fake.destroys == 1 && host.token == 0);
}

static void test_browser(void)
{
    zcsr_file_service_t *zfs = zcsr_file_service_create();
    uim_FileService fs;
    uim_ProjectBrowser *pb;
    uim_PBVisibleNode node;
    char root[512];
    CHECK(zfs != NULL);
    if (!zfs) return;
    CHECK(uim_file_service_create_from_zcsr(zfs, &fs) == uim_FILE_OK);
    CHECK(uim_file_service_validate(&fs) == uim_FILE_OK);
    const char *tmp = getenv("TEMP");
    if (!tmp) tmp = getenv("TMPDIR");
    if (!tmp) tmp = "/tmp";
    snprintf(root, sizeof(root), "%s/zcsr_pb_test_%lu_%ld", tmp,
             (unsigned long)rand(), (long)time(NULL));
    for (char *p = root; *p; ++p) if (*p == '\\') *p = '/';
    (void)fs.ops.remove_directory(fs.user, root);
    CHECK(fs.ops.create_directory(fs.user, root) == uim_FILE_OK);
    CHECK(uim_file_service_set_base_path(&fs, root) == uim_FILE_OK);
    pb = uim_project_browser_create();
    CHECK(pb != NULL);
    if (!pb) return;
    CHECK(uim_project_browser_set_file_service(pb, &fs) == uim_PB_OK);
    CHECK(uim_project_browser_set_root(pb, root) == uim_PB_OK);
    CHECK(uim_project_browser_visible_count(pb) >= 1);
    CHECK(uim_project_browser_create_dir(pb, "maps") == uim_PB_OK);
    CHECK(uim_project_browser_visible_count(pb) >= 2);
    CHECK(uim_project_browser_toggle_node(pb, 1));
    CHECK(uim_project_browser_refresh(pb) == uim_PB_OK);
    CHECK(uim_project_browser_get_node(pb, 1, &node) == uim_PB_OK);
    CHECK(node.is_dir && node.expanded);
    uim_project_browser_select(pb, 1);
    CHECK(uim_project_browser_selected_index(pb) == 1);
    CHECK(uim_project_browser_rename_selected(pb, "levels") == uim_PB_OK);
    CHECK(uim_project_browser_visible_count(pb) >= 2);
    CHECK(uim_project_browser_get_node(pb, 1, &node) == uim_PB_OK);
    CHECK(strcmp(node.name, "levels") == 0);
    /* Renaming a nested node keeps it in its parent directory. */
    char nested[600];
    snprintf(nested, sizeof(nested), "%s/levels/deep", root);
    CHECK(fs.ops.create_directory(fs.user, nested) == uim_FILE_OK);
    CHECK(uim_project_browser_refresh(pb) == uim_PB_OK);
    CHECK(uim_project_browser_toggle_node(pb, 1));
    /* A selected directory is the parent for a new folder. */
    CHECK(uim_project_browser_create_dir_in_selected(pb, "inner") == uim_PB_OK);
    int inner_index = -1;
    for (int i = 0; i < uim_project_browser_visible_count(pb); ++i) {
        uim_PBVisibleNode n;
        if (uim_project_browser_get_node(pb, i, &n) == uim_PB_OK &&
            strcmp(n.rel_path, "levels/inner") == 0) { inner_index = i; break; }
    }
    CHECK(inner_index > 0);
    if (inner_index > 0) {
        char inner[600];
        snprintf(inner, sizeof(inner), "%s/levels/inner", root);
        (void)fs.ops.remove_directory(fs.user, inner);
        CHECK(uim_project_browser_refresh(pb) == uim_PB_OK);
    }
    int deep_index = -1;
    for (int i = 0; i < uim_project_browser_visible_count(pb); ++i) {
        uim_PBVisibleNode n;
        if (uim_project_browser_get_node(pb, i, &n) == uim_PB_OK &&
            strcmp(n.rel_path, "levels/deep") == 0) { deep_index = i; break; }
    }
    CHECK(deep_index > 0);
    if (deep_index > 0) {
        uim_project_browser_select(pb, deep_index);
        CHECK(uim_project_browser_rename_selected(pb, "deeper") == uim_PB_OK);
        /* Rename collapses the expansion set; expand the parent again before
         * asserting the child stayed under it. */
        CHECK(uim_project_browser_refresh(pb) == uim_PB_OK);
        CHECK(uim_project_browser_toggle_node(pb, 1));
        int found_nested = 0;
        for (int i = 0; i < uim_project_browser_visible_count(pb); ++i) {
            uim_PBVisibleNode n;
            if (uim_project_browser_get_node(pb, i, &n) == uim_PB_OK) {
                if (strcmp(n.rel_path, "levels/deeper") == 0) found_nested = 1;
                if (strcmp(n.rel_path, "deeper") == 0) found_nested = -1;
            }
        }
        CHECK(found_nested == 1);
        /* Remove the nested child first; the API intentionally refuses a
         * non-empty directory delete. */
        char deeper[600];
        snprintf(deeper, sizeof(deeper), "%s/levels/deeper", root);
        (void)fs.ops.remove_directory(fs.user, deeper);
        CHECK(uim_project_browser_refresh(pb) == uim_PB_OK);
    }
    uim_project_browser_select(pb, 1);
    CHECK(uim_project_browser_selected_index(pb) == 1);
    CHECK(uim_project_browser_remove_selected(pb) == uim_PB_OK);
    CHECK(uim_project_browser_get_node(pb, -1, &node) == uim_PB_ERR_INVALID_INDEX);
    uim_project_browser_destroy(pb);
    (void)fs.ops.remove_directory(fs.user, root);
    uim_file_service_destroy(&fs);
    zcsr_file_service_destroy(zfs);
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("workspace\n");
    test_workspace();
    printf("shell\n");
    test_shell();
    printf("persist\n");
    test_persist();
    printf("viewport\n");
    test_viewport();
    printf("browser\n");
    test_browser();
    if (failures) { printf("%d failure(s)\n", failures); return 1; }
    printf("editor shell domains PASS\n");
    return 0;
}
