#include "uim_component_runtime.h"
#include "ui_editor_component_registry.h"

#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

static int fail(const char *message) {
    fprintf(stderr, "FAIL: %s\n", message);
    return 1;
}

static bool nearly(float a, float b) {
    return fabsf(a - b) <= 0.01f;
}

static int setup(UIM_ComponentManager **out_manager,
                 uim_PageId *out_page,
                 uim_NodeId *out_mover,
                 uim_NodeId *out_static) {
    UIM_ComponentManagerConfig config;
    uim_NodeDesc desc;
    uim_NodeId root = uim_NODE_INVALID;
    uim_ComponentInstanceId motion = uim_COMPONENT_INSTANCE_INVALID;
    uim_Value value;

    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 2u;
    config.initial_node_capacity = 8u;
    if (uim_component_manager_create(&config, out_manager) != uim_OK)
        return fail("manager create");
    if (uim_page_create(*out_manager, "main", out_page) != uim_OK)
        return fail("page create");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = *out_page;
    desc.stable_key = "root";
    desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 1920.0f, 1080.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(*out_manager, &desc, &root) != uim_OK)
        return fail("root create");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = *out_page;
    desc.parent_id = root;
    desc.stable_key = "mover";
    desc.local_rect = (uim_Rect){ 100.0f, 100.0f, 80.0f, 40.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(*out_manager, &desc, out_mover) != uim_OK)
        return fail("mover create");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = *out_page;
    desc.parent_id = root;
    desc.stable_key = "static";
    desc.local_rect = (uim_Rect){ 300.0f, 300.0f, 80.0f, 40.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(*out_manager, &desc, out_static) != uim_OK)
        return fail("static create");

    if (uim_component_instance_attach(*out_manager, *out_mover, uim_COMPONENT_MOTION, 1u,
                                      &motion) != uim_OK)
        return fail("motion attach");

    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_FLOAT64;
    value.as.real = 200.0;
    if (uim_component_instance_set_property(*out_manager, motion, uim_PROPERTY_VX, value) != uim_OK)
        return fail("set vx");
    value.as.real = 0.0;
    if (uim_component_instance_set_property(*out_manager, motion, uim_PROPERTY_VY, value) != uim_OK)
        return fail("set vy");
    return 0;
}

static int test_registry_motion_descriptor(void) {
    uim_ComponentRegistryConfig config;
    uim_ComponentRegistry *registry = NULL;
    uim_ComponentTypeDesc desc;
    int rc = 0;

    memset(&config, 0, sizeof(config));
    if (uim_component_registry_create(&config, &registry) != uim_OK)
        return fail("registry create");
    if (uim_component_registry_register_builtins(registry) != uim_OK)
        rc = fail("registry register builtins");
    if (rc == 0 && uim_component_registry_get(registry, uim_COMPONENT_MOTION, &desc) != uim_OK)
        rc = fail("motion descriptor missing");
    if (rc == 0) {
        if (desc.property_count != 2u) rc = fail("motion property count");
        if (rc == 0 && desc.properties[0].property_id != uim_PROPERTY_VX)
            rc = fail("motion property[0] not vx");
        if (rc == 0 && desc.properties[1].property_id != uim_PROPERTY_VY)
            rc = fail("motion property[1] not vy");
        if (rc == 0 && desc.properties[0].value_type != uim_VALUE_FLOAT64)
            rc = fail("motion vx type");
        if (rc == 0 && desc.properties[1].value_type != uim_VALUE_FLOAT64)
            rc = fail("motion vy type");
        if (rc == 0 && strcmp(desc.properties[0].stable_key, "vx") != 0)
            rc = fail("motion vx stable key");
        if (rc == 0 && strcmp(desc.properties[1].stable_key, "vy") != 0)
            rc = fail("motion vy stable key");
    }
    uim_component_registry_destroy(registry);
    return rc;
}

static int test_tick_moves_and_restores(void) {
    UIM_ComponentManager *manager = NULL;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId mover = uim_NODE_INVALID;
    uim_NodeId stat = uim_NODE_INVALID;
    uim_NodeInfo info;
    int rc;

    rc = setup(&manager, &page, &mover, &stat);
    if (rc != 0) {
        if (manager) uim_component_manager_destroy(manager);
        return rc;
    }

    if (!uim_runtime_begin(manager, page)) {
        uim_component_manager_destroy(manager);
        return fail("uim_runtime_begin");
    }

    /* dt is clamped to 0.05s: 200 px/s -> +10 px. */
    uim_runtime_tick(manager, page, 1.0);
    if (uim_node_get(manager, mover, &info) != uim_OK) rc = fail("mover get");
    if (rc == 0 && !nearly(info.local_rect.x, 110.0f)) rc = fail("tick x after 1s clamp");
    if (rc == 0 && !nearly(info.local_rect.y, 100.0f)) rc = fail("tick y must not change");

    /* zero/negative dt must not move anything. */
    uim_runtime_tick(manager, page, 0.0);
    uim_runtime_tick(manager, page, -0.5);
    if (uim_node_get(manager, mover, &info) != uim_OK) rc = fail("mover get 2");
    if (rc == 0 && !nearly(info.local_rect.x, 110.0f)) rc = fail("zero dt moved node");

    /* A node without Motion stays put. */
    if (uim_node_get(manager, stat, &info) != uim_OK) rc = fail("static get");
    if (rc == 0 && !nearly(info.local_rect.x, 300.0f)) rc = fail("static node moved");

    /* Pause freezes the page; step advances exactly one 1/60s frame. */
    uim_runtime_set_paused(true);
    uim_runtime_tick(manager, page, 0.05);
    if (uim_node_get(manager, mover, &info) != uim_OK) rc = fail("mover get 3");
    if (rc == 0 && !nearly(info.local_rect.x, 110.0f)) rc = fail("paused tick moved node");
    uim_runtime_step(manager, page);
    if (uim_node_get(manager, mover, &info) != uim_OK) rc = fail("mover get 4");
    if (rc == 0 && !nearly(info.local_rect.x, 110.0f + 200.0f / 60.0f))
        rc = fail("step x delta");
    if (rc == 0 && !uim_runtime_paused()) rc = fail("step must keep paused state");

    /* Resume. */
    uim_runtime_set_paused(false);
    uim_runtime_tick(manager, page, 0.05);
    if (uim_node_get(manager, mover, &info) != uim_OK) rc = fail("mover get 5");
    if (rc == 0 && !nearly(info.local_rect.x, 110.0f + 200.0f / 60.0f + 10.0f))
        rc = fail("resume x delta");

    /* end restores the authored position exactly. */
    uim_runtime_end();
    if (uim_node_get(manager, mover, &info) != uim_OK) rc = fail("mover get 6");
    if (rc == 0 && !nearly(info.local_rect.x, 100.0f)) rc = fail("end x restore");
    if (rc == 0 && !nearly(info.local_rect.y, 100.0f)) rc = fail("end y restore");

    uim_component_manager_destroy(manager);
    return rc;
}

static int test_begin_guards(void) {
    UIM_ComponentManager *manager = NULL;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId mover = uim_NODE_INVALID;
    uim_NodeId stat = uim_NODE_INVALID;
    int rc = setup(&manager, &page, &mover, &stat);

    if (rc != 0) {
        if (manager) uim_component_manager_destroy(manager);
        return rc;
    }
    if (uim_runtime_begin(manager, uim_PAGE_INVALID))
        rc = fail("begin must reject invalid page");
    if (uim_runtime_begin(NULL, page))
        rc = fail("begin must reject null manager");
    uim_runtime_end();   /* safe without a session */
    uim_runtime_tick(manager, page, 0.05);   /* no session -> must not move */
    {
        uim_NodeInfo info;
        if (uim_node_get(manager, mover, &info) != uim_OK) rc = fail("guard mover get");
        if (rc == 0 && !nearly(info.local_rect.x, 100.0f)) rc = fail("tick without session moved");
    }
    uim_component_manager_destroy(manager);
    return rc;
}

static uim_ComponentInstanceId attach(UIM_ComponentManager *manager, uim_NodeId node,
                                     uim_ComponentTypeId type) {
    uim_ComponentInstanceId instance = uim_COMPONENT_INSTANCE_INVALID;
    if (uim_component_instance_attach(manager, node, type, 1u, &instance) != uim_OK)
        return uim_COMPONENT_INSTANCE_INVALID;
    return instance;
}

static bool set_int(UIM_ComponentManager *manager, uim_ComponentInstanceId instance,
                    uim_PropertyId property, int64_t v) {
    uim_Value value;
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_INT64;
    value.as.integer = v;
    return uim_component_instance_set_property(manager, instance, property, value) == uim_OK;
}

static bool set_float(UIM_ComponentManager *manager, uim_ComponentInstanceId instance,
                      uim_PropertyId property, double v) {
    uim_Value value;
    memset(&value, 0, sizeof(value));
    value.type = uim_VALUE_FLOAT64;
    value.as.real = v;
    return uim_component_instance_set_property(manager, instance, property, value) == uim_OK;
}

static bool get_int(UIM_ComponentManager *manager, uim_ComponentInstanceId instance,
                    uim_PropertyId property, int64_t *out) {
    uim_Value value;
    if (uim_component_instance_get_property(manager, instance, property, &value) != uim_OK)
        return false;
    if (value.type != uim_VALUE_INT64) return false;
    *out = value.as.integer;
    return true;
}

/* 三节点场景：attacker 带 click/same_row/damage，target 同行带 Health，bystander 远处。 */
static int setup_rule_scene(UIM_ComponentManager **out_manager, uim_PageId *out_page,
                            uim_NodeId *out_attacker, uim_NodeId *out_target,
                            uim_NodeId *out_bystander, uim_ComponentInstanceId *out_target_hp) {
    UIM_ComponentManagerConfig config;
    uim_NodeDesc desc;
    uim_NodeId root = uim_NODE_INVALID;
    uim_ComponentInstanceId rule;
    uim_ComponentInstanceId attacker_hp;
    uim_ComponentInstanceId bystander_hp;

    memset(&config, 0, sizeof(config));
    config.initial_page_capacity = 2u;
    config.initial_node_capacity = 8u;
    if (uim_component_manager_create(&config, out_manager) != uim_OK)
        return fail("rule manager create");
    if (uim_page_create(*out_manager, "main", out_page) != uim_OK) return fail("rule page");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = *out_page;
    desc.stable_key = "root";
    desc.local_rect = (uim_Rect){ 0.0f, 0.0f, 1920.0f, 1080.0f };
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(*out_manager, &desc, &root) != uim_OK) return fail("rule root");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = *out_page;
    desc.parent_id = root;
    desc.stable_key = "attacker";
    desc.local_rect = (uim_Rect){ 100.0f, 100.0f, 80.0f, 40.0f };   /* 中心 y=120 */
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(*out_manager, &desc, out_attacker) != uim_OK) return fail("attacker");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = *out_page;
    desc.parent_id = root;
    desc.stable_key = "target";
    desc.local_rect = (uim_Rect){ 300.0f, 105.0f, 80.0f, 40.0f };   /* 中心 y=125，差 5 */
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(*out_manager, &desc, out_target) != uim_OK) return fail("target");

    memset(&desc, 0, sizeof(desc));
    desc.page_id = *out_page;
    desc.parent_id = root;
    desc.stable_key = "bystander";
    desc.local_rect = (uim_Rect){ 100.0f, 700.0f, 80.0f, 40.0f };   /* 不同行 */
    desc.visible = true;
    desc.enabled = true;
    if (uim_node_create(*out_manager, &desc, out_bystander) != uim_OK) return fail("bystander");

    rule = attach(*out_manager, *out_attacker, uim_COMPONENT_RULE);
    if (rule == 0u) return fail("attach rule");
    if (!set_int(*out_manager, rule, uim_PROPERTY_TRIGGER, uim_RULE_TRIGGER_CLICK)) return fail("trigger");
    if (!set_int(*out_manager, rule, uim_PROPERTY_SELECTOR, uim_RULE_SELECT_SAME_ROW)) return fail("selector");
    if (!set_int(*out_manager, rule, uim_PROPERTY_EFFECT, uim_RULE_EFFECT_DAMAGE)) return fail("effect");
    if (!set_int(*out_manager, rule, uim_PROPERTY_AMOUNT, 3)) return fail("amount");

    attacker_hp = attach(*out_manager, *out_attacker, uim_COMPONENT_HEALTH);
    if (attacker_hp == 0u) return fail("attacker health");
    if (!set_int(*out_manager, attacker_hp, uim_PROPERTY_HP, 10)) return fail("attacker hp");

    *out_target_hp = attach(*out_manager, *out_target, uim_COMPONENT_HEALTH);
    if (*out_target_hp == 0u) return fail("target health");
    if (!set_int(*out_manager, *out_target_hp, uim_PROPERTY_HP, 5)) return fail("target hp");

    bystander_hp = attach(*out_manager, *out_bystander, uim_COMPONENT_HEALTH);
    if (bystander_hp == 0u) return fail("bystander health");
    if (!set_int(*out_manager, bystander_hp, uim_PROPERTY_HP, 5)) return fail("bystander hp");
    return 0;
}

static int test_registry_rule_health_descriptors(void) {
    uim_ComponentRegistryConfig config;
    uim_ComponentRegistry *registry = NULL;
    uim_ComponentTypeDesc desc;
    int rc = 0;

    memset(&config, 0, sizeof(config));
    if (uim_component_registry_create(&config, &registry) != uim_OK)
        return fail("rule registry create");
    if (uim_component_registry_register_builtins(registry) != uim_OK)
        rc = fail("rule registry builtins");
    if (rc == 0 && uim_component_registry_get(registry, uim_COMPONENT_RULE, &desc) != uim_OK)
        rc = fail("rule descriptor missing");
    if (rc == 0 && desc.property_count != 7u) rc = fail("rule property count");
    if (rc == 0 && desc.properties[0].property_id != uim_PROPERTY_TRIGGER)
        rc = fail("rule property[0] not trigger");
    if (rc == 0 && uim_component_registry_get(registry, uim_COMPONENT_HEALTH, &desc) != uim_OK)
        rc = fail("health descriptor missing");
    if (rc == 0 && desc.property_count != 1u) rc = fail("health property count");
    if (rc == 0 && desc.properties[0].property_id != uim_PROPERTY_HP)
        rc = fail("health property[0] not hp");
    uim_component_registry_destroy(registry);
    return rc;
}

static int test_click_same_row_damage(void) {
    UIM_ComponentManager *manager = NULL;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId attacker = uim_NODE_INVALID;
    uim_NodeId target = uim_NODE_INVALID;
    uim_NodeId bystander = uim_NODE_INVALID;
    uim_ComponentInstanceId target_hp = 0u;
    uim_NodeInfo info;
    int64_t hp = 0;
    int rc;

    rc = setup_rule_scene(&manager, &page, &attacker, &target, &bystander, &target_hp);
    if (rc != 0) { if (manager) uim_component_manager_destroy(manager); return rc; }
    if (!uim_runtime_begin(manager, page)) {
        uim_component_manager_destroy(manager);
        return fail("rule begin");
    }

    /* 点 attacker 的中心 (140,120)：命中必须是 attacker，同行目标掉 3 血。 */
    if (uim_runtime_click(manager, page, 140.0f, 120.0f) != attacker)
        rc = fail("pick attacker");
    if (rc == 0 && !get_int(manager, target_hp, uim_PROPERTY_HP, &hp)) rc = fail("read target hp");
    if (rc == 0 && hp != 2) rc = fail("same-row damage 3 -> 2");
    {
        uim_ComponentInstanceId bystander_hp = 0u;
        size_t count = 0u;
        size_t i;
        (void)uim_node_component_count(manager, bystander, &count);
        for (i = 0; i < count; ++i) {
            uim_ComponentInstanceInfo instance;
            if (uim_node_component_get_at(manager, bystander, i, &instance) == uim_OK &&
                instance.type_id == uim_COMPONENT_HEALTH) bystander_hp = instance.instance_id;
        }
        if (rc == 0 && !get_int(manager, bystander_hp, uim_PROPERTY_HP, &hp))
            rc = fail("read bystander hp");
        if (rc == 0 && hp != 5) rc = fail("same-row hit bystander");
    }

    /* 第二下把 hp 打到 0：节点隐藏。 */
    (void)uim_runtime_click(manager, page, 140.0f, 120.0f);
    if (rc == 0 && !get_int(manager, target_hp, uim_PROPERTY_HP, &hp)) rc = fail("read target hp 2");
    if (rc == 0 && hp != 0) rc = fail("second hit hp must clamp to 0");
    if (uim_node_get(manager, target, &info) != uim_OK) rc = fail("target get");
    if (rc == 0 && info.visible) rc = fail("hp<=0 must hide target");

    /* 退出播放：位置、可见性、hp 全部还原。 */
    uim_runtime_end();
    if (uim_node_get(manager, target, &info) != uim_OK) rc = fail("target get after end");
    if (rc == 0 && !info.visible) rc = fail("end must restore visibility");
    if (rc == 0 && !get_int(manager, target_hp, uim_PROPERTY_HP, &hp)) rc = fail("hp after end");
    if (rc == 0 && hp != 5) rc = fail("end must restore hp");
    uim_component_manager_destroy(manager);
    return rc;
}

static int test_ballistic_tick_rule_uses_radius(void) {
    UIM_ComponentManager *manager = NULL;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId attacker = uim_NODE_INVALID;
    uim_NodeId target = uim_NODE_INVALID;
    uim_NodeId bystander = uim_NODE_INVALID;
    uim_ComponentInstanceId target_hp = 0u;
    uim_ComponentInstanceId rule;
    uim_NodeInfo info;
    int64_t hp = 0;
    int rc;

    rc = setup_rule_scene(&manager, &page, &attacker, &target, &bystander, &target_hp);
    if (rc != 0) { if (manager) uim_component_manager_destroy(manager); return rc; }

    /* 把 attacker 的规则换成 tick / radius / destroy，半径 300 只覆盖 target（中心距 ~200）。 */
    rule = 0u;
    {
        size_t count = 0u;
        size_t i;
        (void)uim_node_component_count(manager, attacker, &count);
        for (i = 0; i < count; ++i) {
            uim_ComponentInstanceInfo instance;
            if (uim_node_component_get_at(manager, attacker, i, &instance) == uim_OK &&
                instance.type_id == uim_COMPONENT_RULE) rule = instance.instance_id;
        }
    }
    if (rule == 0u) { uim_component_manager_destroy(manager); return fail("find rule"); }
    (void)set_int(manager, rule, uim_PROPERTY_TRIGGER, uim_RULE_TRIGGER_TICK);
    (void)set_int(manager, rule, uim_PROPERTY_SELECTOR, uim_RULE_SELECT_RADIUS);
    (void)set_int(manager, rule, uim_PROPERTY_EFFECT, uim_RULE_EFFECT_DESTROY);
    (void)set_float(manager, rule, uim_PROPERTY_RADIUS, 300.0);

    if (!uim_runtime_begin(manager, page)) {
        uim_component_manager_destroy(manager);
        return fail("tick rule begin");
    }
    (void)uim_runtime_click(manager, page, 140.0f, 120.0f);   /* click 不应触发 tick 规则 */
    if (uim_node_get(manager, target, &info) != uim_OK) rc = fail("target get tick");
    if (rc == 0 && !info.visible) rc = fail("click must not fire tick rule");

    uim_runtime_tick(manager, page, 0.05);
    if (uim_node_get(manager, target, &info) != uim_OK) rc = fail("target get after tick");
    if (rc == 0 && info.visible) rc = fail("tick radius rule must hide target");
    if (uim_node_get(manager, bystander, &info) != uim_OK) rc = fail("bystander get");
    if (rc == 0 && !info.visible) rc = fail("radius 300 must not reach bystander");
    if (rc == 0 && !get_int(manager, target_hp, uim_PROPERTY_HP, &hp)) rc = fail("hp tick");
    if (rc == 0 && hp != 5) rc = fail("destroy must not change hp");

    uim_runtime_end();
    if (uim_node_get(manager, target, &info) != uim_OK) rc = fail("target get end tick");
    if (rc == 0 && !info.visible) rc = fail("end must restore tick-rule visibility");
    uim_component_manager_destroy(manager);
    return rc;
}

static int test_goto_request(void) {
    UIM_ComponentManager *manager = NULL;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId attacker = uim_NODE_INVALID;
    uim_NodeId target = uim_NODE_INVALID;
    uim_NodeId bystander = uim_NODE_INVALID;
    uim_ComponentInstanceId target_hp = 0u;
    uim_ComponentInstanceId rule = 0u;
    int rc;

    rc = setup_rule_scene(&manager, &page, &attacker, &target, &bystander, &target_hp);
    if (rc != 0) { if (manager) uim_component_manager_destroy(manager); return rc; }
    {
        size_t count = 0u;
        size_t i;
        (void)uim_node_component_count(manager, attacker, &count);
        for (i = 0; i < count; ++i) {
            uim_ComponentInstanceInfo instance;
            if (uim_node_component_get_at(manager, attacker, i, &instance) == uim_OK &&
                instance.type_id == uim_COMPONENT_RULE) rule = instance.instance_id;
        }
    }
    (void)set_int(manager, rule, uim_PROPERTY_EFFECT, uim_RULE_EFFECT_GOTO);
    (void)set_int(manager, rule, uim_PROPERTY_TARGET_PAGE, 2);
    if (!uim_runtime_begin(manager, page)) {
        uim_component_manager_destroy(manager);
        return fail("goto begin");
    }
    (void)uim_runtime_click(manager, page, 140.0f, 120.0f);
    if (uim_runtime_take_goto_request() != 2) rc = fail("goto request must be 2");
    if (rc == 0 && uim_runtime_take_goto_request() != 0) rc = fail("goto request must clear");
    uim_runtime_end();
    uim_component_manager_destroy(manager);
    return rc;
}

int main(void) {
    int rc;
    rc = test_registry_motion_descriptor();
    if (rc != 0) return rc;
    rc = test_tick_moves_and_restores();
    if (rc != 0) return rc;
    rc = test_begin_guards();
    if (rc != 0) return rc;
    rc = test_registry_rule_health_descriptors();
    if (rc != 0) return rc;
    rc = test_click_same_row_damage();
    if (rc != 0) return rc;
    rc = test_ballistic_tick_rule_uses_radius();
    if (rc != 0) return rc;
    rc = test_goto_request();
    if (rc != 0) return rc;
    printf("OK: page_runtime motion/tick/pause/step/restore + rule click/same-row/health/goto\n");
    return 0;
}
