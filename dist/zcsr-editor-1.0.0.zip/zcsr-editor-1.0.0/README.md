# zcsr_editor

ZCSR 的独立编辑器宿主。它负责窗口、页面编辑、工程文件、资产和编辑命令，不把 engine、UIM、runtime 或 tools 的源码复制进来。

## 仓库关系

```
zcsr_editor                         开发者入口
  ├── UIM                           UI Instance Model + page manager
  ├── zcsr_runtime                  窗口、主循环、宿主生命周期
  ├── zcsr_tools                    debug overlay + 2.5D workspace
  └── zero-coupling-signal-router   引擎静态库与契约头
```

最终开发者只需要启动 `zcsr_editor`。另外四个仓库是它链接的库，不单独作为产品入口。

## 模块

| 目标 / 目录 | 职责 | 入口 |
|---|---|---|
| `zcsr_imgui` | 编辑器专用 vendored Dear ImGui（docking 分支）。player/runtime 不链接它。 | `third_party/imgui/` |
| `zcsr_editor_kernel` | 页面编辑模型：workspace、selection、hierarchy、project browser、viewport host、交互和 shell 持久化。 | `src/ui_editor.c`、`include/ui_editor*.h` |
| `zcsr_editor` | 开发者入口可执行程序：Win32/OpenGL 窗口宿主和 ImGui chrome。窗口与主循环由 runtime shell 提供，不再自建第二套 host。 | `backends/zcsr/host_main.c`、`src/editor_app.cpp` |
| `zcsr_runtime_shell` | 外部依赖：唯一窗口/主循环、输入泵、模块生命周期。editor 内的旧 host/player/command/undo 栈已移除。 | `zcsr_runtime_shell.h` |
| `tests/` + `tools/*.cmake` | 1.0 稳定测试和三个 guard：源码必须被编入、GL 债务边界、单一 owner。 | `ctest` |

## 平台范围

**当前编辑器是 Windows-only。** `src/editor_app.cpp` 直接包含 `windows.h`、
`commdlg.h` 和 `GL/gl.h`，并使用 Win32 文件对话框与窗口句柄；没有 Linux/macOS
编辑器宿主实现。非 Windows 编译会在 `editor_app.cpp` 的显式 `#error` 处停止，
不会静默产生“看似可跨平台”的构建。引擎库和 runtime 仍可跨平台构建，但
`zcsr_editor` 本产品不声明 Linux/macOS 支持，也没有对应的编译或 smoke 证据。

## 依赖

编辑器通过 CMake cache 变量定位三个仓库：

| 变量 | 默认值 | 用途 |
|---|---|---|
| `ZCSR_ENGINE_DIR` | 同目录兄弟仓库 `../zero-coupling-signal-router` | 引擎仓库根目录 |
| `ZCSR_UIM_DIR` | 同目录兄弟仓库 `../UIM` | UIM / page manager |
| `ZCSR_RUNTIME_DIR` | 同目录兄弟仓库 `../zcsr_runtime` | runtime shell |

`zcsr_tools` 是游戏专用工具层，编辑器不链接。

换机器或换路径时，在配置阶段覆盖即可，不需要改 `CMakeLists.txt`。

## 构建

```powershell
cmake -S . -B build_main -G "Visual Studio 18 2026" -A x64 `
  -DZCSR_ENGINE_DIR="C:/path/to/zero-coupling-signal-router" `
  -DZCSR_UIM_DIR="C:/path/to/UIM" `
  -DZCSR_RUNTIME_DIR="C:/path/to/zcsr_runtime"

cmake --build build_main --config Release
ctest --test-dir build_main -C Release --output-on-failure
```

可执行文件在 `build_main/Release/zcsr_editor.exe`。

## 1.0 范围

- 稳定 CTest 为 20 项：键盘契约、工程 roundtrip/package/v2/legacy、page runtime、runtime state、editor model，以及源码/OpenGL 债务/单一 owner 三个 guard。
- 已移除产品不引用的 `ui_editor_resize.c/.h`、`ui_editor_snap.c/.h` 及对应测试，也移除了 `make_rule_demo` 和 `probe_editor_model` 目标；产品基础 resize/grid 仍在 `ui_editor.c` 的 `uir_editor_resize_node` 和 `canvas.snap_to_grid/grid_size` 中。
- 非 Windows 构建在 `editor_app.cpp` 的显式 `#error` 停止；1.0 不声明 Linux/macOS 编辑器支持。
- `docs/` 只保存模块实现与契约说明；模块用法以本 README 为准。

## 运行

```powershell
.\build_main\Release\zcsr_editor.exe
```

编辑器是开发者入口。引擎仓库只提供库和测试，不提供产品级可执行程序；不要再从 `game_test` 或引擎 demo 启动。
