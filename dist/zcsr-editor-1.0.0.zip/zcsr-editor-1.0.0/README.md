# zcsr_editor

Version: 1.0.0. The `main` branch is the canonical history.

ZCSR editor **workspace module**. It is hosted by `zcsr_runtime_shell`, which
owns the one OS window, surface and main loop. The editor owns authoring UI,
document editing, asset browsing and editor commands. It does not create a
second window, a second surface or a second main loop. It does not copy engine,
UIM, runtime or tools source into this repository.

The words below keep one meaning throughout this README:

- **runtime host**: the only owner of the OS window, surface and main loop.
- **editor workspace**: the authoring UI that runs as a runtime module. It is
not the host.
- **UI document**: persisted page, component placement and asset data.
- **setting page**: one group of setting rows.
- **setting page container**: the independent owner of setting page instances. It is not a route stack and does not own menu, UI document, scene or runtime.
- **CMake Run**: configure and build a CMake target, then launch it. It is not a
private package step.

## 仓库关系

```
zcsr_editor                         editor workspace module (runtime-hosted)
  ├── UIM                           smallest UI component manager
  ├── zcsr_runtime                   runtime host: one window, one main loop
  ├── zcsr_tools                    developer tool layer (not linked by editor)
  └── zero-coupling-signal-router   2.5D engine libraries and contract headers
```

最终开发者启动的是 runtime host；editor 是它加载的工作区模块。`zcsr_tools`
不是 editor 依赖，editor 只按需链接 scene authoring 或明确的 tool target。

## 模块

| 目标 / 目录 | 职责 | 入口 |
|---|---|---|
| `zcsr_imgui` | 编辑器专用 vendored Dear ImGui（docking 分支）。player/runtime 不链接它。 | `third_party/imgui/` |
| `zcsr_editor_kernel` | UI document editing model, C11 `.uiscene` text IO owner and C11 scene authoring commands: workspace, selection, hierarchy, project browser, viewport host, interaction, shell persistence, add/duplicate/delete/move/quad edits. It does not own the OS window. | `src/ui_editor.c`、`src/editor_scene_io.c`、`src/editor_scene_authoring.c`、`include/ui_editor*.h`、`include/editor_scene_io.h`、`include/editor_scene_authoring.h` |
| `zcsr_editor` | Editor workspace module hosted by `zcsr_runtime_shell`: ImGui chrome and authoring UI. The runtime host owns the window and main loop; this target must not create a second host. | `backends/zcsr/host_main.c`、`src/editor_app.cpp` |
| `zcsr_runtime_shell` | External dependency: the only window/main-loop owner, input pump and module lifecycle. The old editor host/player/command/undo stack is removed. | `zcsr_runtime_shell.h` |
| `editor_host` | Editor-owned platform boundary: native file pickers, unsaved confirm, process launch and executable path. One C ABI with Win32 / Linux / macOS backends; no second window or GL context. | `editor_host.h` |
| `zcsr_scene_camera` | External dependency: 2.5D scene camera, world→screen, screen→ground and screen→arbitrary horizontal plane. Not a 3D renderer. | `scene_camera.h` |
| `zcsr_scene` | External dependency: fixed-capacity 2.5D entity list, explicit four-corner quad overrides and stable draw order. The editor owns authoring commands, not scene storage semantics. | `scene.h` |
| `zcsr_scene_render` | External dependency: scene order → ordered rectangle or four-corner quad instances with UV, tint, texture and average depth; `zcsr_scene_draw_quads` submits the quad path through GL. Not a 3D renderer. | `scene_render.h` |
| `tests/` + `tools/*.cmake` | Stable tests and guards: sources must be compiled, GL debt boundary, single owner, platform owner, scene IO owner, scene authoring owner, C++ surface baseline. `editor_host_test` is headless; `editor_scene_io_test` and `editor_scene_authoring_test` are headless; the IO test can also parse a named `.uiscene` file without opening a window. | `ctest` |

## 平台范围

编辑器交付 Windows、Linux、macOS 三个桌面平台，不包含 Android。

产品层 `src/editor_app.cpp` 不再包含 `windows.h`、`commdlg.h`、`GL/gl.h`，不再强转 `HWND`，也不再自己实现文件对话框、进程启动、消息框或计时。这些平台能力统一走 `include/editor_host.h` 的 C ABI：

| 平台 | host 实现 |
|---|---|
| Windows | `src/editor_host_win32.c`（Win32 / commdlg） |
| Linux | `src/editor_host_posix.c`（zenity/kdialog；Kali 走 XDG desktop portal） |
| macOS | `src/editor_host_posix.c` + `src/editor_host_cocoa.m`（NSOpenPanel/NSSavePanel/NSAlert） |

窗口、输入泵和主循环仍只由 `zcsr_runtime_shell` 拥有；editor host 不创建第二个窗口。Windows Debug/Release 构建、host 契约测试和完整 CTest 44/44 已通过。Linux `linux-x11` 当前 HEAD 已在 Kali 7.2.15 / GCC 16.2 上重新构建并跑完 CTest 44/44；`editor_smoke_30` 在 Xvfb 下创建 1280x720 窗口、30 帧后退出，GLX 使用 llvmpipe 软件渲染。旧版“Intel UHD 630 硬件渲染 + 原生文件对话框 + F6 Player”记录属于历史 HEAD，不能替代当前软件渲染结果；Linux 物理 GPU 仍需单独验证。macOS 分支已完成 Cocoa 原生对话框实现和 stub 语法编译，但 macOS 完整构建、启动 smoke 仍需真实 Mac 验证，当前状态为未验证。

Linux X11 的字母键码曾把 evdev 的 QWERTY 物理位置误当成字母顺序，导致 O 映射成 Y、S 映射成 B，Ctrl+O/S 全部失效；`modules/input/input_keymap.c` 已按三行 QWERTY 表修正，`tests/test_input_keymap.c` 覆盖全部 26 个字母。`zcsr_player` 的 CMake 输出目录也改为单配置生成器落在构建根、多配置生成器落在 `Debug/Release` 子目录，Run 不再构建成功却找不到文件。


## 依赖

编辑器通过 CMake cache 变量定位三个仓库：

| 变量 | 默认值 | 用途 |
|---|---|---|
| `ZCSR_ENGINE_DIR` | 同目录兄弟仓库 `../zero-coupling-signal-router` | 引擎仓库根目录 |
| `ZCSR_UIM_DIR` | 同目录兄弟仓库 `../UIM` | UIM smallest UI component manager; setting page container optional |
| `ZCSR_RUNTIME_DIR` | 同目录兄弟仓库 `../zcsr_runtime` | runtime shell |

`zcsr_tools` 是游戏专用工具层，编辑器不链接。

换机器或换路径时，在配置阶段覆盖即可，不需要改 `CMakeLists.txt`。

平台原生依赖属于 engine 后端，不属于 editor 产品层：

| 平台 | 编译期依赖 | 运行期依赖 |
|---|---|---|
| Windows | Windows SDK、OpenGL（`opengl32`/`gdi32`） | 无额外 |
| Linux X11 | `libx11-dev`、`libgl1-mesa-dev`（GLX）；`libxrandr-dev` 可选，仅用于刷新率查询和独占全屏模式切换 | `zenity` 或 `kdialog` 文件选择器 |
| Linux Wayland | `wayland-client`、`wayland-scanner`、`wayland-protocols`（`xdg-shell.xml`）、`wayland-egl`、`egl`、`xkbcommon` | 同上 |
| Linux 音频 | ALSA 开发包，或 PipeWire + SPA 开发包 | 对应音频服务 |
| macOS | Xcode Command Line Tools、Cocoa/OpenGL/CoreAudio/AudioToolbox/AudioUnit/GameController frameworks | 无额外（Cocoa 原生面板） |

Linux 的 X11/GLX 与 Wayland/EGL 是两套可选窗口后端。X11 只要求 `libx11-dev` + `libgl1-mesa-dev`；XRandR 是可选能力，缺 `libxrandr-dev` 不会禁用 X11，只关闭刷新率查询和独占全屏模式切换。两套后端都探测不到时回退 `ZCSR_LINUX_WINDOW_BACKEND=none`，所有库和 headless 测试仍能构建，但不会创建 GL 窗口。这不是“Windows-only 代码”，而是 Linux 宿主缺少原生开发包时的显式降级。

## 构建

```powershell
cmake -S . -B ..\zcsr-build\zcsr_editor\main -G "Visual Studio 18 2026" -A x64 `
  -DZCSR_ENGINE_DIR="C:/path/to/zero-coupling-signal-router" `
  -DZCSR_UIM_DIR="C:/path/to/UIM" `
  -DZCSR_RUNTIME_DIR="C:/path/to/zcsr_runtime"

cmake --build ..\zcsr-build\zcsr_editor\main --config Release
ctest --test-dir ..\zcsr-build\zcsr_editor\main -C Release --output-on-failure
```

可执行文件在 `..\zcsr-build\zcsr_editor\main\Release\zcsr_editor.exe`。构建目录必须在仓库外；源码内 `build_main/` 会被 configure guard 拒绝。

Linux/macOS 使用同一份 CMakeLists，不传 `-G`，由系统选择生成器：

```bash
cmake -S . -B ../zcsr-build/zcsr_editor/main \
  -DZCSR_ENGINE_DIR=/path/to/zero-coupling-signal-router \
  -DZCSR_UIM_DIR=/path/to/UIM \
  -DZCSR_RUNTIME_DIR=/path/to/zcsr_runtime
cmake --build ../zcsr-build/zcsr_editor/main -j
ctest --test-dir ../zcsr-build/zcsr_editor/main --output-on-failure
```

Linux 有窗口的配置需要显式选择后端并安装开发包：

```bash
sudo apt-get install libx11-dev libgl1-mesa-dev zenity
# 可选：libxrandr-dev，只有需要刷新率查询/独占全屏模式切换时才装
cmake --preset linux-x11
cmake --build --preset linux-x11 -j
```

Linux `linux-x11` 当前 HEAD 已在 Kali 7.2.15 / GCC 16.2 上重新构建并跑完 editor CTest 44/44；Xvfb 下 `editor_smoke_30` 创建 1280x720 窗口、30 帧后退出，GLX 使用 llvmpipe 软件渲染。旧版“Intel UHD 630 硬件渲染 + 原生文件对话框”是历史 HEAD 的 smoke，不能替代当前软件渲染结果；Linux 物理 GPU 仍需单独验证。Linux headless 配置同样通过：完整 `zcsr_editor` 目标构建通过，6 项 headless 定向测试通过；headless 只证明编译和契约，不证明窗口启动。macOS 未验证。

Linux 文件对话框优先调用 `zenity`，缺失时回退 `kdialog`；它们是运行期依赖，不是编译期依赖。Kali 上已实际打开原生 `Open/Save ZCSR UI Project` 面板（zenity 走 XDG desktop portal），验证了 `.uireproj` 过滤器、取消、保存自动补扩展名、保存后打开回读。macOS 使用 `editor_host_cocoa.m` 的 `NSOpenPanel/NSSavePanel/NSAlert`，不再调用 `osascript`；已完成 Objective-C 语法编译检查，但真实 macOS 构建和启动仍需 Mac 主机。



## 编辑器面板

- **Project / Assets**：左侧下半区由 C11 `ui_project_browser.c` 提供目录树、展开/选择、刷新、选中目录内新建、原位重命名和删除；C++ chrome 只绘制和转发操作。重命名不再把嵌套节点搬回根目录；删除非空目录仍按文件服务语义拒绝。
- **Inspector**：字符串属性支持 `ASSET_PICKER`（原生文件对话框 + 项目相对路径）、`MULTILINE_TEXT`（Ctrl+Enter 提交）和 `VECTOR2/VECTOR3`（字符串 `x, y[, z]` 契约）；整数属性支持 `DROPDOWN`（`numeric_min..numeric_max`，上限 64 项）。资产选择器不把绝对路径硬编码进项目。
- **锚点**：Inspector 可开关 `anchors`，编辑 anchor min/max 与 LTRB offset；数据仍由 `uim_LayoutConstraints` 和 C11 布局解析器拥有。UI 节点没有 pivot 字段，pivot 仍只在 Scene 实体 Inspector 中。
- **Play**：`Play` 后工具栏变为 `Pause/Resume`、`Step`、`Stop`；`Step` 会先暂停再推进一帧。底层的暂停/单步仍是 `uim_runtime_set_paused` / `uim_runtime_step`。
- **3D Gizmo**：`W/E/R` 切换 Move/Rotate/Scale，拖对应 X/Y/Z 轴修改选中实体；Local/World 与网格吸附仍未实现。
- **文本字段**：单击定位光标、拖拽选区、Shift+方向键扩展选区、Home/End、水平滚动；多行字段保留同一 `uim_TextInput` 状态，不引入第二套编辑实现。
- **Run**：仍只走 CMake Debug 构建 + 启动 `zcsr_player`；`Ctrl+F5` 和 `F6` 都是这条路径。编辑器 UI 已移除 `Export package` 入口；`editor_project_package` 仅作为 UIM 包格式的回归测试保留，不是产品构建路径。

## Scene 模式

同一个 `zcsr_editor` 在同一个 runtime window 内切换 UI 模式与 Scene 模式，不新建窗口、不新建 surface、不新建主循环。

- **Scene 列表**：`+Box`、`+Quad`、`Dup`、`Del`。`Quad` 建立默认四边形，然后写入四个显式世界坐标角点。
- **选择与移动**：LMB 在网格视口选择；拖动实体改变 x/z；拖动四角手柄改变显式四边形；MMB 平移相机，滚轮缩放。
- **Inspector**：位置、尺寸、rotation、pivot、layer、order、tint、texture、visible；`explicit quad` 开关和四个角点的 x/y/z 可编辑。`Reset quad from rectangle` 回到默认矩形。
- **Scene Camera**：target、yaw、pitch、roll、distance、ortho 全部可编辑；`Reset camera` 恢复默认视角。
- **文件**：`Save scene` / `Save scene as` / `Open scene` 读写 `.uiscene`。文件编码是 UTF-8 文本，第一行是 `ZCSRSCENE 1`；`camera`、`entity`、`quad` 每行一条。格式由 C11 `src/editor_scene_io.c` 拥有；加载是事务性的，未知记录、重复 id、缺少实体的 quad、截断字段都会拒绝，失败时原场景不变。`.uiscene` 是 editor authoring 格式，不是 engine 的正式 runtime scene 格式。
- **Run**：`Run (CMake Debug)` / F6 先用 `cmake --build <build-dir> --config Debug --target zcsr_player` 构建，再启动同一构建目录的 `zcsr_player.exe`。`<build-dir>` 是仓库外的构建目录；Run 不打包、不打开工程文件、不写本地构建日志，日志只在编辑器内存 console 中。

## 1.0 范围

- 稳定 CTest 为 44 项 in the current editor+runtime+UIM configuration: keyboard contract, host contract, project roundtrip/package/v2/legacy, runtime state, editor model, scene IO roundtrip/transactionality, scene authoring add/duplicate/delete/move/quad edits, Project Browser rename/delete, scene IO and authoring owner guards, platform owner guard, C++ surface baseline guard, and the source/OpenGL debt/single-owner guards. `editor_project_package` is only a UIM package-format regression test, not an editor build command.
- `editor_app.cpp` remains the C++/Dear ImGui chrome consumed on top of the C11 products. This round raises the ratchet from 3200 to 3800 lines for the Project/Inspector/Play presentation layer only; the C11 Project Browser, layout model, runtime pause/step and text selection state stay in C11/UIM. It still does not allow a second C++ product core.
- 已移除产品不引用的 `ui_editor_resize.c/.h`、`ui_editor_snap.c/.h` 及对应测试，也移除了 `make_rule_demo` 和 `probe_editor_model` 目标；产品基础 resize/grid 仍在 `ui_editor.c` 的 `uir_editor_resize_node` 和 `canvas.snap_to_grid/grid_size` 中。
- 非 Windows 构建不再被 `editor_app.cpp` 的 `#error` 挡住；平台差异收口到 `src/editor_host_win32.c` / `src/editor_host_posix.c` / `src/editor_host_cocoa.m`。Windows/Linux 已完成构建、定向测试与真实窗口 smoke；macOS 的 Cocoa 面板已实现并完成 stub 语法编译，仍待真实 Mac 构建。
- `docs/` 只保存模块实现与契约说明；模块用法以本 README 为准。

## 运行

```powershell
..\zcsr-build\zcsr_editor\main\Release\zcsr_editor.exe
```

GUI smoke / 自动化验收必须让 editor 自己退出，避免留下占满 CPU 的窗口进程：

```powershell
..\zcsr-build\zcsr_editor\main\Release\zcsr_editor.exe --smoke-frames 30
..\zcsr-build\zcsr_editor\main\Release\zcsr_editor.exe --autoquit
```

`--smoke-frames N` 在第 N 帧渲染完成后调用 `zcsr_runtime_shell_request_exit()`；`--autoquit` 等价于 150 帧。该路径用于测试，不弹未保存确认；正常交互启动仍走原有未保存提示。

编辑器是开发者入口。引擎仓库只提供库和测试，不提供产品级可执行程序；不要再从 `game_test` 或引擎 demo 启动。

## License

本项目按 GNU Affero General Public License v3.0（AGPL-3.0）授权，完整许可证文本见仓库根目录 `LICENSE`。版权行：Copyright (C) 2026 Talmaidev。

`third_party/` 下第三方组件保留其原有许可（见各自目录与 `THIRD_PARTY_NOTICES.md`）。
