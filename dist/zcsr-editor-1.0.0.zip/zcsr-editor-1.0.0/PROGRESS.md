# ZCSR Editor 收口进度

实测时间：2026-11-25（Windows / VS 18 2026 / Release）
口径：极简、直接、性能优先；数据/格式/命令在 C11，C++ 只做一层可被第三方消费的 chrome。

## 本轮目标

- [x] Game 独立视图 + 分辨率/运行统计
- [x] Prefab / 资产引用 / 导入 / 拖放
- [x] Gizmo Local/World、网格吸附、场景 gizmo
- [x] 节点 Copy/Paste、sibling 上移/下移
- [x] 多选 Inspector
- [x] Console 过滤/清空
- [x] Hierarchy / Project 搜索
- [x] Preferences（网格、吸附、缩放、自动保存）
- [x] 通用 Property Drawer、列表、枚举标签
- [x] 文本字段双击选词、字段内 undo/redo、多行垂直导航、IME 锚点
- [x] 统一构建 + 全量 CTest

## 验收结果

- editor Release：44/44
- UIM：13/13
- engine：67 注册 / 66 通过 + 1 跳过（`audio_switch` 硬件依赖；串行 `-j4` 连跑通过）
- runtime：16/16
- tools：13/13
- 五个主仓合计：152 通过 + 1 跳过 / 0 失败
- RTS 已归档，不纳入本轮
- editor smoke `--smoke-frames 30 --autoquit`：输出 30 帧，exit 0；`editor_smoke_30` 已进 CTest
- C++ 表面守卫：1 个产品 `.cpp`，守卫通过；精确行数以 `editor_cxx_surface_guard` 输出为准

## 边界

- 这是可用的极简作者层，不是 Unity 功能对齐。
- Game 是 ImGui 相机投影/贴图窗口，不是独立 FBO 运行时。
- Prefab 是普通 `.uiscene` + 稳定路径哈希，不做覆盖/变体/编辑模式。
- 资产列表支持导入/注册/拖入场景；图集缩略图、音频试听不做。
- Inspector 的列表用换行字符串编辑，底层仍是 UIM string，不新增第二套数组模型。
- Preferences 目前是会话内存设置，自动保存只在已有路径时生效。
