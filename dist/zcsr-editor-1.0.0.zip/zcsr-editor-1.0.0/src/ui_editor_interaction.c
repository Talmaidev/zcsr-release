#include "ui_editor_interaction.h"

#include <math.h>
#include <string.h>

static bool hit_contains(uim_Rect r, float x, float y) {
    return x >= r.x && y >= r.y && x <= r.x + r.width && y <= r.y + r.height;
}

static int hit_test(const uim_UiInteraction *ui, float x, float y) {
    size_t i;
    if (!ui) return -1;
    for (i = ui->target_count; i > 0u; --i) {
        const uim_UiHitTarget *t = &ui->targets[i - 1u];
        if (t->enabled && t->id >= 0 && hit_contains(t->rect, x, y)) return t->id;
    }
    return -1;
}

void uim_ui_interaction_reset(uim_UiInteraction *ui) {
    if (!ui) return;
    memset(ui, 0, sizeof(*ui));
    ui->hover_id = -1;
    ui->press_id = -1;
    ui->clicked_id = -1;
    ui->released_id = -1;
    ui->drag_id = -1;
    ui->drag_threshold = 4.0f;
}

int uim_ui_hit_add(uim_UiInteraction *ui, int region, int id, uim_Rect rect, bool enabled) {
    uim_UiHitTarget *target;
    if (!ui || id < 0 || ui->target_count >= uim_UI_MAX_TARGETS) return -1;
    if (!isfinite(rect.x) || !isfinite(rect.y) ||
        !isfinite(rect.width) || !isfinite(rect.height) ||
        rect.width < 0.0f || rect.height < 0.0f) return -1;
    target = &ui->targets[ui->target_count];
    target->rect = rect;
    target->id = id;
    target->region = region;
    target->enabled = enabled;
    return (int)ui->target_count++;
}

void uim_ui_begin_frame(uim_UiInteraction *ui) {
    if (!ui) return;
    ui->target_count = 0u;
    ui->hover_id = -1;
    ui->clicked_id = -1;
    ui->released_id = -1;
    ui->drag_id = -1;
    ui->released_edge = false;
}

static void press(uim_UiInteraction *ui, int hover, float x, float y) {
    ui->press_id = hover;
    ui->press_x = x;
    ui->press_y = y;
    ui->dragging = false;
    ui->clicked_id = hover;
}

static void release(uim_UiInteraction *ui, int hover) {
    ui->released_edge = true;
    ui->released_id = (ui->press_id >= 0 && ui->press_id == hover) ? hover : -1;
    ui->press_id = -1;
    ui->dragging = false;
}

static void drag_if_needed(uim_UiInteraction *ui, float x, float y) {
    float dx;
    float dy;
    if (ui->press_id < 0 || ui->dragging) return;
    dx = x - ui->press_x;
    dy = y - ui->press_y;
    if (dx * dx + dy * dy > ui->drag_threshold * ui->drag_threshold) {
        ui->dragging = true;
        ui->drag_id = ui->press_id;
    }
}

int uim_ui_update(uim_UiInteraction *ui, float x, float y, bool left_down) {
    bool was_down;
    int hover;
    if (!ui) return -1;
    was_down = ui->left_down;
    hover = hit_test(ui, x, y);
    ui->hover_id = hover;
    ui->clicked_id = -1;
    ui->released_id = -1;
    ui->drag_id = -1;
    ui->released_edge = false;

    if (!was_down && left_down) {
        press(ui, hover, x, y);
    } else if (was_down && left_down) {
        drag_if_needed(ui, x, y);
    } else if (was_down && !left_down) {
        release(ui, hover);
    }
    ui->left_down = left_down;
    return uim_ui_clicked_id(ui) >= 0 ? uim_ui_clicked_id(ui) :
           (uim_ui_released_id(ui) >= 0 ? uim_ui_released_id(ui) :
            (uim_ui_drag_id(ui) >= 0 ? uim_ui_drag_id(ui) : hover));
}

int uim_ui_update_edges(uim_UiInteraction *ui, float x, float y, bool left_down,
                        bool left_pressed, bool left_released) {
    int hover;
    if (!ui) return -1;
    hover = hit_test(ui, x, y);
    ui->hover_id = hover;
    ui->clicked_id = -1;
    ui->released_id = -1;
    ui->drag_id = -1;
    ui->released_edge = false;

    if (left_pressed || (!ui->left_down && left_down)) {
        press(ui, hover, x, y);
    } else if (ui->press_id >= 0 && left_down) {
        drag_if_needed(ui, x, y);
    }
    if (left_released || (ui->left_down && !left_down)) {
        release(ui, hover);
    }
    ui->left_down = left_down;
    return uim_ui_clicked_id(ui) >= 0 ? uim_ui_clicked_id(ui) :
           (uim_ui_released_id(ui) >= 0 ? uim_ui_released_id(ui) :
            (uim_ui_drag_id(ui) >= 0 ? uim_ui_drag_id(ui) : hover));
}

int uim_ui_hover_id(const uim_UiInteraction *ui) { return ui ? ui->hover_id : -1; }
int uim_ui_press_id(const uim_UiInteraction *ui) { return ui ? ui->press_id : -1; }
int uim_ui_clicked_id(const uim_UiInteraction *ui) { return ui ? ui->clicked_id : -1; }
int uim_ui_released_id(const uim_UiInteraction *ui) { return ui ? ui->released_id : -1; }
bool uim_ui_released_edge(const uim_UiInteraction *ui) { return ui && ui->released_edge; }
int uim_ui_drag_id(const uim_UiInteraction *ui) { return ui ? ui->drag_id : -1; }

bool uim_ui_is_hovered(const uim_UiInteraction *ui, int id) {
    return ui && id >= 0 && ui->hover_id == id;
}

bool uim_ui_is_dragging(const uim_UiInteraction *ui, int id) {
    return ui && id >= 0 && ui->dragging && ui->press_id == id;
}
