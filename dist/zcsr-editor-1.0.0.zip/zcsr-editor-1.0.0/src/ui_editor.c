#include "ui_editor.h"
#include "uim_component_registry.h"

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef enum EditKind { EDIT_NODE=1, EDIT_SETTING=2, EDIT_NODE_BATCH=3, EDIT_NODE_TREE_CREATE=4, EDIT_NODE_TREE_DELETE=5, EDIT_COMPONENTS=6 } EditKind;
typedef struct EditorNodeMeta { uim_NodeId id; char *display_name; bool expanded; } EditorNodeMeta;
typedef struct ComponentPropSnapshot { uim_PropertyId id; uim_Value value; } ComponentPropSnapshot;
typedef struct ComponentSnapshot {
    uim_ComponentInstanceInfo info;
    ComponentPropSnapshot *props;
    size_t prop_count;
} ComponentSnapshot;
typedef struct ComponentListSnapshot {
    uim_NodeId node_id;
    ComponentSnapshot *items;
    size_t count;
} ComponentListSnapshot;
typedef struct NodeSnapshot { uim_NodeInfo info; void *config; char *stable_key; bool has_binding; uim_BindingDesc binding; } NodeSnapshot;
typedef enum EditorGestureMode { GESTURE_NONE=0, GESTURE_MOVE, GESTURE_RESIZE, GESTURE_BOX } EditorGestureMode;
typedef struct EditorGesture {
    EditorGestureMode mode;
    uim_PageId page_id;
    float start_canvas_x, start_canvas_y, last_canvas_x, last_canvas_y, start_page_x, start_page_y;
    uint32_t modifiers;
    uint32_t handle_index;
    NodeSnapshot *before;
    size_t count;
} EditorGesture;
typedef struct Edit {
    EditKind kind;
    uim_NodeId node_id;
    NodeSnapshot before_node, after_node;
    uim_PropertyId property_id;
    uim_Value before_value, after_value;
    NodeSnapshot *before_batch, *after_batch;
    size_t batch_count;
    ComponentListSnapshot before_components, after_components;
    uim_ComponentInstanceId component_instance;
    uim_PropertyId component_property;
} Edit;
struct uim_Editor {
    UIM_ComponentManager *receiver;
    uim_NodeId *selection;
    size_t selection_count;
    Edit *history;
    size_t history_count, history_cursor, history_cap;
    uim_NodeId focus_node;
    uim_EditorCanvasState canvas;
    uim_EditorGuide *guides;
    size_t guide_count;
    uim_PageId active_page;
    EditorNodeMeta *meta; size_t meta_count, meta_cap;
    uint64_t duplicate_serial;
    EditorGesture gesture;
};

static uim_Result node_world_rect(const UIM_ComponentManager *r, uim_NodeId id, uim_Rect *out, bool require_visible);
static void value_release(uim_Value *v){if(v&&v->type==uim_VALUE_STRING)free((void*)v->as.string.data);if(v)memset(v,0,sizeof(*v));}
static uim_Result value_clone(uim_Value *out,uim_Value v){*out=(uim_Value){0};if(v.type==uim_VALUE_STRING){char*p;if(v.as.string.size==SIZE_MAX)return uim_ERR_RANGE;p=(char*)malloc(v.as.string.size+1);if(!p)return uim_ERR_NOMEM;if(v.as.string.size)memcpy(p,v.as.string.data,v.as.string.size);p[v.as.string.size]='\0';*out=v;out->as.string.data=p;}else *out=v;return uim_OK;}
static void component_list_release(ComponentListSnapshot *s){size_t i,j;if(!s)return;for(i=0;i<s->count;i++){for(j=0;j<s->items[i].prop_count;j++)value_release(&s->items[i].props[j].value);free(s->items[i].props);}free(s->items);memset(s,0,sizeof(*s));}
static uim_Result component_list_capture(uim_Editor *e,uim_NodeId node,ComponentListSnapshot *out){size_t count=0,i,j;uim_Result rc;memset(out,0,sizeof(*out));out->node_id=node;rc=uim_node_component_count(e->receiver,node,&count);if(rc!=uim_OK)return rc;if(count>SIZE_MAX/sizeof(*out->items))return uim_ERR_RANGE;if(count){out->items=(ComponentSnapshot*)calloc(count,sizeof(*out->items));if(!out->items)return uim_ERR_NOMEM;}for(i=0;i<count;i++){uim_ComponentInstanceInfo info;size_t props=0;rc=uim_node_component_get_at(e->receiver,node,i,&info);if(rc!=uim_OK)goto fail;out->items[i].info=info;rc=uim_component_instance_property_count(e->receiver,info.instance_id,&props);if(rc!=uim_OK)goto fail;if(props>SIZE_MAX/sizeof(*out->items[i].props)){rc=uim_ERR_RANGE;goto fail;}if(props){out->items[i].props=(ComponentPropSnapshot*)calloc(props,sizeof(*out->items[i].props));if(!out->items[i].props){rc=uim_ERR_NOMEM;goto fail;}}for(j=0;j<props;j++){uim_PropertyId id=0;uim_Value v={0};rc=uim_component_instance_property_get_at(e->receiver,info.instance_id,j,&id,&v);if(rc!=uim_OK)goto fail;out->items[i].props[j].id=id;rc=value_clone(&out->items[i].props[j].value,v);if(rc!=uim_OK)goto fail;out->items[i].prop_count++;}out->count++;}return uim_OK;
fail:
    component_list_release(out);return rc;}
static uim_Result component_list_restore(uim_Editor *e,const ComponentListSnapshot *s){size_t i,j,current=0;uim_Result rc;if(!e||!s)return uim_ERR_ARGUMENT;rc=uim_node_component_count(e->receiver,s->node_id,&current);if(rc!=uim_OK)return rc;while(current>0u){uim_ComponentInstanceInfo info;rc=uim_node_component_get_at(e->receiver,s->node_id,0,&info);if(rc!=uim_OK)return rc;rc=uim_component_instance_detach(e->receiver,info.instance_id);if(rc!=uim_OK)return rc;current--;}for(i=0;i<s->count;i++){rc=uim_component_instance_restore(e->receiver,&s->items[i].info);if(rc!=uim_OK)return rc;for(j=0;j<s->items[i].prop_count;j++){rc=uim_component_instance_set_property(e->receiver,s->items[i].info.instance_id,s->items[i].props[j].id,s->items[i].props[j].value);if(rc!=uim_OK)return rc;}}return uim_OK;}
static void snapshot_release(NodeSnapshot *s){if(s){free(s->config);free(s->stable_key);memset(s,0,sizeof(*s));}}
static void edit_release(Edit *e){size_t i;if(!e)return;snapshot_release(&e->before_node);snapshot_release(&e->after_node);for(i=0;i<e->batch_count;i++){if(e->before_batch)snapshot_release(&e->before_batch[i]);if(e->after_batch)snapshot_release(&e->after_batch[i]);}free(e->before_batch);free(e->after_batch);value_release(&e->before_value);value_release(&e->after_value);component_list_release(&e->before_components);component_list_release(&e->after_components);memset(e,0,sizeof(*e));}
static uim_Result snapshot_node(uim_Editor*e,uim_NodeId id,NodeSnapshot*out){uim_Result rc;memset(out,0,sizeof(*out));rc=uim_node_get(e->receiver,id,&out->info);if(rc!=uim_OK)return rc;if(out->info.stable_key){size_t n=strlen(out->info.stable_key)+1;out->stable_key=(char*)malloc(n);if(!out->stable_key)return uim_ERR_NOMEM;memcpy(out->stable_key,out->info.stable_key,n);out->info.stable_key=out->stable_key;}if(out->info.component_config_size){out->config=malloc(out->info.component_config_size);if(!out->config){snapshot_release(out);return uim_ERR_NOMEM;}memcpy(out->config,out->info.component_config,out->info.component_config_size);}out->info.component_config=NULL;if(out->info.binding_id){rc=uim_binding_get(e->receiver,out->info.binding_id,&out->binding);if(rc!=uim_OK){snapshot_release(out);return rc;}out->has_binding=true;}return uim_OK;}
static uim_Result restore_node(uim_Editor*e,const NodeSnapshot*s){uim_Result rc;rc=uim_node_set_parent(e->receiver,s->info.id,s->info.parent_id);if(rc!=uim_OK)return rc;if((rc=uim_node_set_space(e->receiver,s->info.id,s->info.space))!=uim_OK)return rc;if(s->info.space==uim_SPACE_3D){if((rc=uim_node_set_transform3(e->receiver,s->info.id,&s->info.transform))!=uim_OK)return rc;}else{if((rc=uim_node_set_rect(e->receiver,s->info.id,s->info.local_rect))!=uim_OK)return rc;}if((rc=uim_node_set_layout_constraints(e->receiver,s->info.id,s->info.layout))!=uim_OK)return rc;if((rc=uim_node_set_visible(e->receiver,s->info.id,s->info.visible))!=uim_OK)return rc;if((rc=uim_node_set_enabled(e->receiver,s->info.id,s->info.enabled))!=uim_OK)return rc;if((rc=uim_node_set_z_order(e->receiver,s->info.id,s->info.z_order))!=uim_OK)return rc;if((rc=uim_node_set_action_id(e->receiver,s->info.id,s->info.action_id))!=uim_OK)return rc;if((rc=uim_node_set_child_order(e->receiver,s->info.id,s->info.child_order))!=uim_OK)return rc;return uim_node_set_component_config(e->receiver,s->info.id,s->config,s->info.component_config_size);}
static uim_Result history_push(uim_Editor*e,Edit*entry){size_t i;if(e->history_cursor<e->history_count){for(i=e->history_cursor;i<e->history_count;i++)edit_release(&e->history[i]);e->history_count=e->history_cursor;}if(!e->history_cap){edit_release(entry);return uim_OK;}if(e->history_count==e->history_cap){edit_release(&e->history[0]);memmove(e->history,e->history+1,(e->history_count-1)*sizeof(Edit));e->history_count--;if(e->history_cursor)e->history_cursor--;}e->history[e->history_count++]=*entry;memset(entry,0,sizeof(*entry));e->history_cursor=e->history_count;return uim_OK;}
static uim_Result node_edit_begin(uim_Editor*e,uim_NodeId id,Edit*x){memset(x,0,sizeof(*x));x->kind=EDIT_NODE;x->node_id=id;return snapshot_node(e,id,&x->before_node);}
static uim_Result node_edit_end(uim_Editor*e,Edit*x){uim_Result rc= snapshot_node(e,x->node_id,&x->after_node);if(rc!=uim_OK){(void)restore_node(e,&x->before_node);edit_release(x);return rc;}return history_push(e,x);}
static uim_Result edit_set_rect(uim_Editor*e,uim_NodeId id,uim_Rect rect){Edit x;uim_Result rc;if(!e||!isfinite(rect.x)||!isfinite(rect.y)||!isfinite(rect.width)||!isfinite(rect.height)||rect.width<0||rect.height<0)return uim_ERR_ARGUMENT;if(e->canvas.snap_to_grid&&e->canvas.grid_size>0.0f){rect.x=roundf(rect.x/e->canvas.grid_size)*e->canvas.grid_size;rect.y=roundf(rect.y/e->canvas.grid_size)*e->canvas.grid_size;}rc=node_edit_begin(e,id,&x);if(rc!=uim_OK)return rc;if(x.before_node.info.local_rect.x==rect.x&&x.before_node.info.local_rect.y==rect.y&&x.before_node.info.local_rect.width==rect.width&&x.before_node.info.local_rect.height==rect.height){edit_release(&x);return uim_OK;}rc=uim_node_set_rect(e->receiver,id,rect);if(rc!=uim_OK){edit_release(&x);return rc;}return node_edit_end(e,&x);}
static void snapshot_array_release(NodeSnapshot *a, size_t count) {
    size_t i; if (!a) return; for (i=0;i<count;i++) snapshot_release(&a[i]); free(a);
}

typedef struct NodeCandidate { uim_NodeId id; uint32_t depth; uint32_t child_order; } NodeCandidate;
static bool candidate_depth(const UIM_ComponentManager *r, uim_NodeInfo n, uim_NodeId root, uint32_t *out_depth) {
    uint32_t depth=0; uim_NodeId parent=n.id;
    if(n.id==root){*out_depth=0;return true;}
    while(parent){uim_NodeInfo cur;if(uim_node_get(r,parent,&cur)!=uim_OK)return false;parent=cur.parent_id;if(!parent)break;depth++;if(parent==root){*out_depth=depth;return true;}}
    return false;
}
static uim_Result snapshot_tree(uim_Editor *e, uim_NodeId root, NodeSnapshot **out, size_t *out_count) {
    uim_NodeInfo root_info,n; size_t page_count,i,count=0,j; NodeCandidate *items=NULL; NodeSnapshot *snaps=NULL; uim_Result rc;
    if(!e||!root||!out||!out_count)return uim_ERR_ARGUMENT;
    *out=NULL;*out_count=0;
    if((rc=uim_node_get(e->receiver,root,&root_info))!=uim_OK)return rc;
    if((rc=uim_page_get_node_count(e->receiver,root_info.page_id,&page_count))!=uim_OK)return rc;
    if(page_count>SIZE_MAX/sizeof(*items))return uim_ERR_RANGE;
    items=page_count?(NodeCandidate*)calloc(page_count,sizeof(*items)):NULL;
    if(page_count&&!items)return uim_ERR_NOMEM;
    for(i=0;i<page_count;i++){
        uint32_t depth;
        if((rc=uim_page_get_node_at(e->receiver,root_info.page_id,i,&n))!=uim_OK){free(items);return rc;}
        if(candidate_depth(e->receiver,n,root,&depth)){items[count++]=(NodeCandidate){n.id,depth,n.child_order};}
    }
    if(!count){free(items);return uim_ERR_NOT_FOUND;}
    for(i=0;i<count;i++)for(j=i+1;j<count;j++)if(items[j].depth<items[i].depth||(items[j].depth==items[i].depth&&items[j].child_order<items[i].child_order)){NodeCandidate t=items[i];items[i]=items[j];items[j]=t;}
    snaps=(NodeSnapshot*)calloc(count,sizeof(*snaps));if(!snaps){free(items);return uim_ERR_NOMEM;}
    for(i=0;i<count;i++){rc=snapshot_node(e,items[i].id,&snaps[i]);if(rc!=uim_OK){snapshot_array_release(snaps,count);free(items);return rc;}}
    free(items);*out=snaps;*out_count=count;return uim_OK;
}
static void selection_remove_ids(uim_Editor *e,const NodeSnapshot *snaps,size_t count) {
    size_t i=0,j;while(i<e->selection_count){bool remove=false;for(j=0;j<count;j++)if(e->selection[i]==snaps[j].info.id){remove=true;break;}if(remove){memmove(&e->selection[i],&e->selection[i+1],(e->selection_count-i-1)*sizeof(uim_NodeId));e->selection_count--;}else i++;}
    for(j=0;j<count;j++)if(e->focus_node==snaps[j].info.id)e->focus_node=uim_NODE_INVALID;
}
static uim_Result restore_tree(uim_Editor *e,NodeSnapshot *snaps,size_t count,uim_NodeId *out_root) {
    uim_NodeId *old_ids=NULL,*new_ids=NULL;size_t i,j;uim_Result rc=uim_OK;uim_NodeId root_new=0;
    if(!e||!snaps||!count)return uim_ERR_ARGUMENT;
    if(count>SIZE_MAX/sizeof(*old_ids))return uim_ERR_RANGE;
    old_ids=(uim_NodeId*)malloc(count*sizeof(*old_ids));new_ids=(uim_NodeId*)calloc(count,sizeof(*new_ids));
    if(!old_ids||!new_ids){free(old_ids);free(new_ids);return uim_ERR_NOMEM;}
    for(i=0;i<count;i++)old_ids[i]=snaps[i].info.id;
    for(i=0;i<count;i++){
        uim_NodeDesc d;uim_NodeId parent=snaps[i].info.parent_id;
        for(j=0;j<i;j++)if(old_ids[j]==parent){parent=new_ids[j];break;}
        memset(&d,0,sizeof(d));d.stable_key=snaps[i].stable_key;d.page_id=snaps[i].info.page_id;d.component_id=snaps[i].info.component_id;d.parent_id=parent;d.local_rect=snaps[i].info.local_rect;d.visible=snaps[i].info.visible;d.enabled=snaps[i].info.enabled;d.z_order=snaps[i].info.z_order;d.action_id=snaps[i].info.action_id;d.child_order=snaps[i].info.child_order;d.component_config=snaps[i].config;d.component_config_size=snaps[i].info.component_config_size;
        rc=uim_node_create(e->receiver,&d,&new_ids[i]);if(rc!=uim_OK)goto rollback;
        if(i==0)root_new=new_ids[i];
        if(snaps[i].has_binding){uim_BindingDesc b=snaps[i].binding;b.node_id=new_ids[i];{uim_BindingId bid;rc=uim_binding_restore(e->receiver,&b,&bid);if(rc!=uim_OK)goto rollback;}}
    }
    for(i=0;i<count;i++){
        uim_NodeInfo now;uim_NodeId new_parent=snaps[i].info.parent_id;
        for(j=0;j<i;j++)if(old_ids[j]==new_parent){new_parent=new_ids[j];break;}
        snaps[i].info.id=new_ids[i];snaps[i].info.parent_id=new_parent;
        if(snaps[i].has_binding){snaps[i].binding.node_id=new_ids[i];if(uim_node_get(e->receiver,new_ids[i],&now)==uim_OK)snaps[i].info.binding_id=now.binding_id;}
    }
    if(out_root)*out_root=root_new;
    free(old_ids);free(new_ids);return uim_OK;
rollback:
    if(root_new)(void)uim_node_destroy(e->receiver,root_new);
    free(old_ids);free(new_ids);return rc;
}

static uim_Result snapshot_array(uim_Editor *e,const uim_NodeId *ids,size_t count,NodeSnapshot **out) {
    NodeSnapshot *a; size_t i; uim_Result rc;
    if(!e||(!ids&&count)||!out)return uim_ERR_ARGUMENT;
    *out=NULL;
    if(count>SIZE_MAX/sizeof(*a))return uim_ERR_RANGE;
    a=count?(NodeSnapshot*)calloc(count,sizeof(*a)):NULL;if(count&&!a)return uim_ERR_NOMEM;
    for(i=0;i<count;i++){rc=snapshot_node(e,ids[i],&a[i]);if(rc!=uim_OK){snapshot_array_release(a,count);return rc;}}
    *out=a;return uim_OK;
}
static uim_Result restore_array(uim_Editor *e,const NodeSnapshot *a,size_t count) {
    size_t i;
    uim_Result rc;
    NodeSnapshot *backup = NULL;
    if(!e||(!a&&count))return uim_ERR_ARGUMENT;
    if(!count)return uim_OK;
    {
        uim_NodeId *ids=(uim_NodeId*)malloc(count*sizeof(*ids));
        if(!ids)return uim_ERR_NOMEM;
        for(i=0;i<count;i++)ids[i]=a[i].info.id;
        rc=snapshot_array(e,ids,count,&backup);
        free(ids);
        if(rc!=uim_OK)return rc;
    }
    for(i=0;i<count;i++){
        rc=restore_node(e,&a[i]);
        if(rc!=uim_OK){size_t j;for(j=0;j<count;j++)(void)restore_node(e,&backup[j]);snapshot_array_release(backup,count);return rc;}
    }
    snapshot_array_release(backup,count);
    return uim_OK;
}
static uim_Result apply_rect_batch(uim_Editor *e,const uim_NodeId *ids,const uim_Rect *rects,size_t count) {
    Edit x; size_t i; uim_Result rc; bool changed=false; uim_Rect *normalized;
    if(!e||(!ids&&count)||(!rects&&count)||count==0)return uim_ERR_ARGUMENT;
    if(count>SIZE_MAX/sizeof(*normalized))return uim_ERR_RANGE;
    normalized=(uim_Rect*)malloc(count*sizeof(*normalized));if(!normalized)return uim_ERR_NOMEM;
    for(i=0;i<count;i++){
        normalized[i]=rects[i];
        if(!isfinite(normalized[i].x)||!isfinite(normalized[i].y)||!isfinite(normalized[i].width)||!isfinite(normalized[i].height)||normalized[i].width<0||normalized[i].height<0){free(normalized);return uim_ERR_ARGUMENT;}
        if(e->canvas.snap_to_grid&&e->canvas.grid_size>0.0f){normalized[i].x=roundf(normalized[i].x/e->canvas.grid_size)*e->canvas.grid_size;normalized[i].y=roundf(normalized[i].y/e->canvas.grid_size)*e->canvas.grid_size;}
    }
    memset(&x,0,sizeof(x));x.kind=EDIT_NODE_BATCH;x.batch_count=count;
    rc=snapshot_array(e,ids,count,&x.before_batch);if(rc!=uim_OK){free(normalized);return rc;}
    x.after_batch=(NodeSnapshot*)calloc(count,sizeof(*x.after_batch));if(!x.after_batch){edit_release(&x);free(normalized);return uim_ERR_NOMEM;}
    for(i=0;i<count;i++){
        uim_Rect r=normalized[i];
        if(x.before_batch[i].info.local_rect.x==r.x&&x.before_batch[i].info.local_rect.y==r.y&&x.before_batch[i].info.local_rect.width==r.width&&x.before_batch[i].info.local_rect.height==r.height)continue;
        rc=uim_node_set_rect(e->receiver,ids[i],r);
        if(rc!=uim_OK){(void)restore_array(e,x.before_batch,i);edit_release(&x);free(normalized);return rc;}
        changed=true;
    }
    free(normalized);
    if(!changed){edit_release(&x);return uim_OK;}
    for(i=0;i<count;i++){rc=snapshot_node(e,ids[i],&x.after_batch[i]);if(rc!=uim_OK){(void)restore_array(e,x.before_batch,count);edit_release(&x);return rc;}}
    return history_push(e,&x);
}

uim_Result uir_editor_create(UIM_ComponentManager*r,size_t cap,uim_Editor**out){uim_Editor*e;if(!r||!out)return uim_ERR_ARGUMENT;*out=NULL;e=(uim_Editor*)calloc(1,sizeof(*e));if(!e)return uim_ERR_NOMEM;e->receiver=r;e->history_cap=cap;e->canvas.zoom=1.0f;e->canvas.viewport=(uim_Rect){0,0,1,1};if(cap){e->history=(Edit*)calloc(cap,sizeof(Edit));if(!e->history){free(e);return uim_ERR_NOMEM;}}*out=e;return uim_OK;}
void uir_editor_destroy(uim_Editor*e){size_t i;if(!e)return;snapshot_array_release(e->gesture.before,e->gesture.count);for(i=0;i<e->history_count;i++)edit_release(&e->history[i]);for(i=0;i<e->meta_count;i++)free(e->meta[i].display_name);free(e->meta);free(e->selection);free(e->guides);free(e->history);free(e);}
uim_Result uir_editor_select(uim_Editor*e,const uim_NodeId*ids,size_t count){size_t i,j;uim_NodeId*p=NULL;uim_PageId page=0;if(!e||(!ids&&count))return uim_ERR_ARGUMENT;if(count>SIZE_MAX/sizeof(*p))return uim_ERR_RANGE;if(count){p=(uim_NodeId*)malloc(count*sizeof(*p));if(!p)return uim_ERR_NOMEM;for(i=0;i<count;i++){uim_NodeInfo n;if(!ids[i]||uim_node_get(e->receiver,ids[i],&n)!=uim_OK){free(p);return uim_ERR_NOT_FOUND;}if(i==0)page=n.page_id;else if(page!=n.page_id){free(p);return uim_ERR_ARGUMENT;}for(j=0;j<i;j++)if(ids[j]==ids[i]){free(p);return uim_ERR_EXISTS;}p[i]=ids[i];}}free(e->selection);e->selection=p;e->selection_count=count;return uim_OK;}
uim_Result uir_editor_get_selection(const uim_Editor*e,uim_EditorSelection*out){if(!e||!out)return uim_ERR_ARGUMENT;out->ids=e->selection;out->count=e->selection_count;return uim_OK;}
uim_Result uir_editor_set_focus_node(uim_Editor*e,uim_NodeId id){uim_NodeInfo n;if(!e)return uim_ERR_ARGUMENT;if(id&&uim_node_get(e->receiver,id,&n)!=uim_OK)return uim_ERR_NOT_FOUND;e->focus_node=id;return uim_OK;}
uim_Result uir_editor_get_focus_node(const uim_Editor*e,uim_NodeId*out){if(!e||!out)return uim_ERR_ARGUMENT;if(e->focus_node){uim_NodeInfo n;if(uim_node_get(e->receiver,e->focus_node,&n)!=uim_OK)return uim_ERR_STALE;}*out=e->focus_node;return uim_OK;}
uim_Result uir_editor_set_canvas_state(uim_Editor*e,const uim_EditorCanvasState*s){if(!e||!s||!isfinite(s->viewport.x)||!isfinite(s->viewport.y)||!isfinite(s->viewport.width)||!isfinite(s->viewport.height)||s->viewport.width<=0||s->viewport.height<=0||!isfinite(s->zoom)||s->zoom<0.05f||s->zoom>16.0f||!isfinite(s->pan_x)||!isfinite(s->pan_y)||!isfinite(s->grid_size)||s->grid_size<0||!isfinite(s->safe_area.x)||!isfinite(s->safe_area.y)||!isfinite(s->safe_area.width)||!isfinite(s->safe_area.height)||s->safe_area.width<0||s->safe_area.height<0)return uim_ERR_ARGUMENT;e->canvas=*s;return uim_OK;}
uim_Result uir_editor_get_canvas_state(const uim_Editor*e,uim_EditorCanvasState*out){if(!e||!out)return uim_ERR_ARGUMENT;*out=e->canvas;return uim_OK;}
uim_Result uir_editor_zoom_at(uim_Editor*e,float zoom,float cx,float cy){float px,py,pan_x,pan_y;if(!e||!isfinite(zoom)||zoom<0.05f||zoom>16.0f||!isfinite(cx)||!isfinite(cy))return uim_ERR_ARGUMENT;px=(cx-e->canvas.viewport.x-e->canvas.pan_x)/e->canvas.zoom;py=(cy-e->canvas.viewport.y-e->canvas.pan_y)/e->canvas.zoom;pan_x=cx-e->canvas.viewport.x-px*zoom;pan_y=cy-e->canvas.viewport.y-py*zoom;if(!isfinite(px)||!isfinite(py)||!isfinite(pan_x)||!isfinite(pan_y))return uim_ERR_RANGE;e->canvas.zoom=zoom;e->canvas.pan_x=pan_x;e->canvas.pan_y=pan_y;return uim_OK;}
uim_Result uir_editor_pan(uim_Editor*e,float dx,float dy){float x,y;if(!e||!isfinite(dx)||!isfinite(dy))return uim_ERR_ARGUMENT;x=e->canvas.pan_x+dx;y=e->canvas.pan_y+dy;if(!isfinite(x)||!isfinite(y))return uim_ERR_RANGE;e->canvas.pan_x=x;e->canvas.pan_y=y;return uim_OK;}
uim_Result uir_editor_set_guides(uim_Editor*e,const uim_EditorGuide*g,size_t count){size_t i;uim_EditorGuide*copy=NULL;if(!e||(!g&&count)||count>SIZE_MAX/sizeof(*g))return uim_ERR_ARGUMENT;for(i=0;i<count;i++)if(!isfinite(g[i].position))return uim_ERR_ARGUMENT;if(count){copy=(uim_EditorGuide*)malloc(count*sizeof(*copy));if(!copy)return uim_ERR_NOMEM;memcpy(copy,g,count*sizeof(*copy));}free(e->guides);e->guides=copy;e->guide_count=count;return uim_OK;}
uim_Result uir_editor_get_guide(const uim_Editor*e,size_t i,uim_EditorGuide*out){if(!e||!out)return uim_ERR_ARGUMENT;if(i>=e->guide_count)return uim_ERR_NOT_FOUND;*out=e->guides[i];return uim_OK;}
uim_Result uir_editor_canvas_to_page(const uim_Editor*e,float x,float y,float*out_x,float*out_y){float px,py;if(!e||!out_x||!out_y||!isfinite(x)||!isfinite(y))return uim_ERR_ARGUMENT;px=(x-e->canvas.viewport.x-e->canvas.pan_x)/e->canvas.zoom;py=(y-e->canvas.viewport.y-e->canvas.pan_y)/e->canvas.zoom;if(!isfinite(px)||!isfinite(py))return uim_ERR_RANGE;*out_x=px;*out_y=py;return uim_OK;}
uim_Result uir_editor_page_to_canvas(const uim_Editor*e,float x,float y,float*out_x,float*out_y){float cx,cy;if(!e||!out_x||!out_y||!isfinite(x)||!isfinite(y))return uim_ERR_ARGUMENT;cx=e->canvas.viewport.x+e->canvas.pan_x+x*e->canvas.zoom;cy=e->canvas.viewport.y+e->canvas.pan_y+y*e->canvas.zoom;if(!isfinite(cx)||!isfinite(cy))return uim_ERR_RANGE;*out_x=cx;*out_y=cy;return uim_OK;}
uim_Result uir_editor_inspect_node(const uim_Editor*e,uim_NodeId id,uim_NodeInfo*out){if(!e)return uim_ERR_ARGUMENT;return uim_node_get(e->receiver,id,out);}
uim_Result uir_editor_get_child_count(const uim_Editor*e,uim_NodeId parent,size_t*out){size_t i,n=0;uim_NodeInfo child;if(!e||!parent||!out)return uim_ERR_ARGUMENT;if(uim_node_get(e->receiver,parent,&child)!=uim_OK)return uim_ERR_NOT_FOUND;for(i=0;;i++){if(uim_node_get_child(e->receiver,parent,i,&child)==uim_ERR_NOT_FOUND)break;n++;}*out=n;return uim_OK;}
uim_Result uir_editor_get_child_at(const uim_Editor*e,uim_NodeId parent,size_t index,uim_NodeInfo*out){if(!e)return uim_ERR_ARGUMENT;return uim_node_get_child(e->receiver,parent,index,out);}
uim_Result uir_editor_create_node(uim_Editor*e,const uim_NodeDesc*d,uim_NodeId*out){Edit x;uim_Result rc;NodeSnapshot*snap=NULL;size_t count=0;if(!e||!d||!out)return uim_ERR_ARGUMENT;*out=0;rc=uim_node_create(e->receiver,d,out);if(rc!=uim_OK)return rc;rc=snapshot_tree(e,*out,&snap,&count);if(rc!=uim_OK){(void)uim_node_destroy(e->receiver,*out);*out=0;return rc;}memset(&x,0,sizeof(x));x.kind=EDIT_NODE_TREE_CREATE;x.batch_count=count;x.after_batch=snap;rc=history_push(e,&x);if(rc!=uim_OK){(void)uim_node_destroy(e->receiver,*out);*out=0;return rc;}return uim_OK;}
uim_Result uir_editor_duplicate_node(uim_Editor*e,uim_NodeId source,float dx,float dy,uim_NodeId*out){
    NodeSnapshot *source_tree=NULL,*created_tree=NULL;size_t count=0,created_count=0,i,j;uim_NodeId *old_ids=NULL,*new_ids=NULL,root_new=0;char **keys=NULL;const char*page_key=NULL;uint64_t serial;uim_Result rc;
    if(!e||!out||!isfinite(dx)||!isfinite(dy))return uim_ERR_ARGUMENT;
    *out=0;
    rc=snapshot_tree(e,source,&source_tree,&count);if(rc!=uim_OK)return rc;
    if(count>SIZE_MAX/sizeof(*old_ids)||count>SIZE_MAX/sizeof(*keys)){rc=uim_ERR_RANGE;goto done;}
    old_ids=(uim_NodeId*)malloc(count*sizeof(*old_ids));new_ids=(uim_NodeId*)calloc(count,sizeof(*new_ids));keys=(char**)calloc(count,sizeof(*keys));
    if(!old_ids||!new_ids||!keys){rc=uim_ERR_NOMEM;goto done;}
    if((rc=uim_page_get_key(e->receiver,source_tree[0].info.page_id,&page_key))!=uim_OK)goto done;
    for(i=0;i<count;i++)old_ids[i]=source_tree[i].info.id;
    serial=e->duplicate_serial;
    for(;;){bool collision=false;if(serial==UINT64_MAX){rc=uim_ERR_RANGE;goto done;}serial++;
        for(i=0;i<count;i++){
            char buffer[4097];int n;
            if(source_tree[i].stable_key)n=snprintf(buffer,sizeof(buffer),"%s.copy.%llu",source_tree[i].stable_key,(unsigned long long)serial);
            else n=snprintf(buffer,sizeof(buffer),"%s.editor-copy.%llu.%zu",page_key,(unsigned long long)serial,i);
            if(n<0||(size_t)n>=sizeof(buffer)){rc=uim_ERR_RANGE;goto done;}
            keys[i]=(char*)malloc((size_t)n+1);if(!keys[i]){rc=uim_ERR_NOMEM;goto done;}memcpy(keys[i],buffer,(size_t)n+1);
            {uim_NodeId existing;if(uim_node_find_stable_key(e->receiver,source_tree[0].info.page_id,keys[i],&existing)==uim_OK)collision=true;}
            for(j=0;j<i;j++)if(strcmp(keys[j],keys[i])==0)collision=true;
        }
        if(!collision)break;
        for(i=0;i<count;i++){free(keys[i]);keys[i]=NULL;}
    }
    for(i=0;i<count;i++){
        uim_NodeDesc d;uim_NodeId parent=source_tree[i].info.parent_id;
        for(j=0;j<i;j++)if(old_ids[j]==parent){parent=new_ids[j];break;}
        memset(&d,0,sizeof(d));d.stable_key=keys[i];d.page_id=source_tree[i].info.page_id;d.component_id=source_tree[i].info.component_id;d.parent_id=parent;d.local_rect=source_tree[i].info.local_rect;
        if(i==0){d.local_rect.x+=dx;d.local_rect.y+=dy;if(!isfinite(d.local_rect.x)||!isfinite(d.local_rect.y)){rc=uim_ERR_RANGE;goto rollback;}}
        d.visible=source_tree[i].info.visible;d.enabled=source_tree[i].info.enabled;d.z_order=source_tree[i].info.z_order;d.action_id=source_tree[i].info.action_id;d.child_order=source_tree[i].info.child_order;
        d.component_config=source_tree[i].config;d.component_config_size=source_tree[i].info.component_config_size;
        rc=uim_node_create(e->receiver,&d,&new_ids[i]);if(rc!=uim_OK)goto rollback;if(i==0)root_new=new_ids[i];
        if(source_tree[i].has_binding){uim_BindingDesc b=source_tree[i].binding;uim_BindingId bid;b.node_id=new_ids[i];rc=uim_binding_restore(e->receiver,&b,&bid);if(rc!=uim_OK)goto rollback;}
    }
    rc=snapshot_tree(e,root_new,&created_tree,&created_count);if(rc!=uim_OK)goto rollback;
    if(created_count!=count){rc=uim_ERR_STATE;goto rollback;}
    {Edit x;memset(&x,0,sizeof(x));x.kind=EDIT_NODE_TREE_CREATE;x.batch_count=created_count;x.after_batch=created_tree;created_tree=NULL;rc=history_push(e,&x);if(rc!=uim_OK)goto rollback;}
    e->duplicate_serial=serial;*out=root_new;(void)uir_editor_select(e,out,1);rc=uim_OK;goto done;
rollback:
    if(root_new)(void)uim_node_destroy(e->receiver,root_new);
done:
    if(keys){for(i=0;i<count;i++)free(keys[i]);}free(keys);free(old_ids);free(new_ids);snapshot_array_release(source_tree,count);snapshot_array_release(created_tree,created_count);return rc;
}
uim_Result uir_editor_delete_node(uim_Editor*e,uim_NodeId id){Edit x;NodeSnapshot*snaps=NULL;size_t count=0;uim_Result rc;if(!e||!id)return uim_ERR_ARGUMENT;rc=snapshot_tree(e,id,&snaps,&count);if(rc!=uim_OK)return rc;rc=uim_node_destroy(e->receiver,id);if(rc!=uim_OK){snapshot_array_release(snaps,count);return rc;}selection_remove_ids(e,snaps,count);memset(&x,0,sizeof(x));x.kind=EDIT_NODE_TREE_DELETE;x.batch_count=count;x.before_batch=snaps;return history_push(e,&x);}
uim_Result uir_editor_set_rect(uim_Editor*e,uim_NodeId id,uim_Rect rect){return edit_set_rect(e,id,rect);}

uim_Result uir_editor_set_transform3(uim_Editor *e, uim_NodeId id, const uim_Transform3 *transform) {
    Edit edit;
    uim_Result rc;
    if (!e || !id || !transform) return uim_ERR_ARGUMENT;
    if (!isfinite(transform->position[0]) || !isfinite(transform->position[1]) ||
        !isfinite(transform->position[2]) || !isfinite(transform->rotation[0]) ||
        !isfinite(transform->rotation[1]) || !isfinite(transform->rotation[2]) ||
        !isfinite(transform->scale[0]) || !isfinite(transform->scale[1]) ||
        !isfinite(transform->scale[2]))
        return uim_ERR_ARGUMENT;
    rc = node_edit_begin(e, id, &edit);
    if (rc != uim_OK) return rc;
    rc = uim_node_set_transform3(e->receiver, id, transform);
    if (rc != uim_OK) { edit_release(&edit); return rc; }
    return node_edit_end(e, &edit);
}

uim_Result uir_editor_set_space(uim_Editor *e, uim_NodeId id, uim_Space space) {
    Edit edit;
    uim_Result rc;
    if (!e || !id || space < uim_SPACE_2D || space > uim_SPACE_3D) return uim_ERR_ARGUMENT;
    rc = node_edit_begin(e, id, &edit);
    if (rc != uim_OK) return rc;
    rc = uim_node_set_space(e->receiver, id, space);
    if (rc != uim_OK) { edit_release(&edit); return rc; }
    return node_edit_end(e, &edit);
}
uim_Result uir_editor_set_layout_constraints(uim_Editor *e, uim_NodeId id, uim_LayoutConstraints constraints) {
    Edit edit;
    uim_NodeInfo current;
    uim_Result rc;
    if (!e || !id) return uim_ERR_ARGUMENT;
    if ((rc = uim_node_get(e->receiver, id, &current)) != uim_OK) return rc;
    if (current.layout.enabled == constraints.enabled &&
        current.layout.anchor_min_x == constraints.anchor_min_x &&
        current.layout.anchor_min_y == constraints.anchor_min_y &&
        current.layout.anchor_max_x == constraints.anchor_max_x &&
        current.layout.anchor_max_y == constraints.anchor_max_y &&
        current.layout.offset_left == constraints.offset_left &&
        current.layout.offset_top == constraints.offset_top &&
        current.layout.offset_right == constraints.offset_right &&
        current.layout.offset_bottom == constraints.offset_bottom) return uim_OK;
    if ((rc = node_edit_begin(e, id, &edit)) != uim_OK) return rc;
    rc = uim_node_set_layout_constraints(e->receiver, id, constraints);
    if (rc != uim_OK) { edit_release(&edit); return rc; }
    return node_edit_end(e, &edit);
}

uim_Result uir_editor_resolve_page_layout(uim_Editor *e, uim_PageId page_id,
                                           float viewport_width, float viewport_height) {
    NodeSnapshot *before = NULL, *after = NULL;
    Edit edit;
    size_t count = 0, i;
    bool changed = false;
    uim_Result rc;
    if (!e || !page_id || !isfinite(viewport_width) || !isfinite(viewport_height) ||
        viewport_width <= 0.0f || viewport_height <= 0.0f) return uim_ERR_ARGUMENT;
    if ((rc = uim_page_get_node_count(e->receiver, page_id, &count)) != uim_OK) return rc;
    if (!count) return uim_OK;
    if (count > SIZE_MAX / sizeof(*before)) return uim_ERR_RANGE;
    before = (NodeSnapshot *)calloc(count, sizeof(*before));
    after = (NodeSnapshot *)calloc(count, sizeof(*after));
    if (!before || !after) { free(before); free(after); return uim_ERR_NOMEM; }
    for (i = 0; i < count; ++i) {
        uim_NodeInfo node;
        if ((rc = uim_page_get_node_at(e->receiver, page_id, i, &node)) != uim_OK ||
            (rc = snapshot_node(e, node.id, &before[i])) != uim_OK) goto fail;
    }
    rc = uim_page_resolve_layout(e->receiver, page_id, viewport_width, viewport_height);
    if (rc != uim_OK) goto fail;
    for (i = 0; i < count; ++i) {
        rc = snapshot_node(e, before[i].info.id, &after[i]);
        if (rc != uim_OK) {
            for (size_t j = 0; j < count; ++j) (void)restore_node(e, &before[j]);
            goto fail;
        }
        if (before[i].info.local_rect.x != after[i].info.local_rect.x ||
            before[i].info.local_rect.y != after[i].info.local_rect.y ||
            before[i].info.local_rect.width != after[i].info.local_rect.width ||
            before[i].info.local_rect.height != after[i].info.local_rect.height) changed = true;
    }
    if (!changed) { rc = uim_OK; goto fail; }
    memset(&edit, 0, sizeof(edit));
    edit.kind = EDIT_NODE_BATCH;
    edit.batch_count = count;
    edit.before_batch = before;
    edit.after_batch = after;
    before = NULL;
    after = NULL;
    return history_push(e, &edit);
fail:
    snapshot_array_release(before, count);
    snapshot_array_release(after, count);
    return rc;
}
uim_Result uir_editor_move_node(uim_Editor*e,uim_NodeId id,float dx,float dy){uim_NodeInfo n;if(!e||!isfinite(dx)||!isfinite(dy))return uim_ERR_ARGUMENT;if(uim_node_get(e->receiver,id,&n)!=uim_OK)return uim_ERR_NOT_FOUND;n.local_rect.x+=dx;n.local_rect.y+=dy;return edit_set_rect(e,id,n.local_rect);}
static bool node_is_descendant_of(const UIM_ComponentManager *r, uim_NodeId node, uim_NodeId ancestor) {
    uim_NodeInfo info;
    size_t count = 0, page_count = 0;
    if (uim_node_get(r, node, &info) != uim_OK) return false;
    if (uim_page_get_node_count(r, info.page_id, &page_count) != uim_OK) return false;
    while (info.parent_id) {
        if (info.parent_id == ancestor) return true;
        if (count++ >= page_count || uim_node_get(r, info.parent_id, &info) != uim_OK) return false;
    }
    return false;
}
static uim_Result selected_move_roots(uim_Editor *e, uim_NodeId **out_ids, size_t *out_count) {
    uim_NodeId *ids;
    size_t i,j,n=0;
    if (!e || !out_ids || !out_count) return uim_ERR_ARGUMENT;
    *out_ids=NULL;*out_count=0;
    if (!e->selection_count) return uim_OK;
    if (e->selection_count>SIZE_MAX/sizeof(*ids)) return uim_ERR_RANGE;
    ids=(uim_NodeId*)malloc(e->selection_count*sizeof(*ids));
    if(!ids)return uim_ERR_NOMEM;
    for(i=0;i<e->selection_count;i++){
        bool covered=false;
        for(j=0;j<e->selection_count;j++)if(i!=j&&node_is_descendant_of(e->receiver,e->selection[i],e->selection[j])){covered=true;break;}
        if(!covered)ids[n++]=e->selection[i];
    }
    *out_ids=ids;*out_count=n;return uim_OK;
}
static void gesture_clear(uim_Editor *e) {
    if(!e)return;
    snapshot_array_release(e->gesture.before,e->gesture.count);
    memset(&e->gesture,0,sizeof(e->gesture));
}
static uim_Result gesture_begin_nodes(uim_Editor *e, EditorGestureMode mode, uim_PageId page,
                                      float cx,float cy,float px,float py,
                                      const uim_NodeId *ids,size_t count,uint32_t handle,uint32_t modifiers) {
    uim_Result rc;
    if(!e||(!ids&&count)||!count)return uim_ERR_ARGUMENT;
    gesture_clear(e);
    rc=snapshot_array(e,ids,count,&e->gesture.before);
    if(rc!=uim_OK){gesture_clear(e);return rc;}
    e->gesture.mode=mode;e->gesture.page_id=page;e->gesture.start_canvas_x=cx;e->gesture.start_canvas_y=cy;
    e->gesture.last_canvas_x=cx;e->gesture.last_canvas_y=cy;
    e->gesture.start_page_x=px;e->gesture.start_page_y=py;e->gesture.handle_index=handle;
    e->gesture.modifiers=modifiers;e->gesture.count=count;
    return uim_OK;
}
static uim_Result gesture_apply(uim_Editor *e,float cx,float cy) {
    float px,py,dx,dy;size_t i,changed=0;uim_Result rc;
    if(!e||e->gesture.mode==GESTURE_NONE)return uim_ERR_STATE;
    if(e->gesture.mode==GESTURE_BOX)return uim_OK;
    if((rc=uir_editor_canvas_to_page(e,cx,cy,&px,&py))!=uim_OK)return rc;
    dx=px-e->gesture.start_page_x;dy=py-e->gesture.start_page_y;
    for(i=0;i<e->gesture.count;i++){
        NodeSnapshot *s=&e->gesture.before[i];uim_Rect r=s->info.local_rect;
        if(e->gesture.mode==GESTURE_MOVE){r.x+=dx;r.y+=dy;}
        else {
            float left=r.x,top=r.y,right=r.x+r.width,bottom=r.y+r.height;
            switch(e->gesture.handle_index){
                case 0:left=fminf(right,left+dx);top=fminf(bottom,top+dy);break;
                case 1:top=fminf(bottom,top+dy);break;
                case 2:right=fmaxf(left,right+dx);top=fminf(bottom,top+dy);break;
                case 3:right=fmaxf(left,right+dx);break;
                case 4:right=fmaxf(left,right+dx);bottom=fmaxf(top,bottom+dy);break;
                case 5:bottom=fmaxf(top,bottom+dy);break;
                case 6:left=fminf(right,left+dx);bottom=fmaxf(top,bottom+dy);break;
                case 7:left=fminf(right,left+dx);break;
                default:return uim_ERR_ARGUMENT;
            }
            if(e->canvas.snap_to_grid&&e->canvas.grid_size>0.0f){float g=e->canvas.grid_size;
                if(e->gesture.handle_index==0||e->gesture.handle_index==6||e->gesture.handle_index==7)left=roundf(left/g)*g;
                if(e->gesture.handle_index==0||e->gesture.handle_index==1||e->gesture.handle_index==2)top=roundf(top/g)*g;
                if(e->gesture.handle_index==2||e->gesture.handle_index==3||e->gesture.handle_index==4)right=roundf(right/g)*g;
                if(e->gesture.handle_index==4||e->gesture.handle_index==5||e->gesture.handle_index==6)bottom=roundf(bottom/g)*g;
            }
            r=(uim_Rect){left,top,fmaxf(0.0f,right-left),fmaxf(0.0f,bottom-top)};
        }
        if(e->gesture.mode==GESTURE_MOVE&&e->canvas.snap_to_grid&&e->canvas.grid_size>0.0f){r.x=roundf(r.x/e->canvas.grid_size)*e->canvas.grid_size;r.y=roundf(r.y/e->canvas.grid_size)*e->canvas.grid_size;}
        if(!isfinite(r.x)||!isfinite(r.y)||!isfinite(r.width)||!isfinite(r.height)||r.width<0||r.height<0){rc=uim_ERR_RANGE;goto rollback;}
        rc=uim_node_set_rect(e->receiver,s->info.id,r);if(rc!=uim_OK)goto rollback;changed++;
    }
    (void)changed;
    return uim_OK;
rollback:
    for(i=0;i<e->gesture.count;i++)(void)uim_node_set_rect(e->receiver,e->gesture.before[i].info.id,e->gesture.before[i].info.local_rect);
    return rc;
}
static uim_Result gesture_finish( uim_Editor *e) {
    Edit x;size_t i;uim_Result rc;bool changed=false;
    memset(&x,0,sizeof(x));x.kind=EDIT_NODE_BATCH;x.batch_count=e->gesture.count;x.before_batch=e->gesture.before;e->gesture.before=NULL;
    x.after_batch=(NodeSnapshot*)calloc(x.batch_count,sizeof(*x.after_batch));
    if(!x.after_batch){e->gesture.before=x.before_batch;x.before_batch=NULL;gesture_clear(e);return uim_ERR_NOMEM;}
    for(i=0;i<x.batch_count;i++){
        rc=snapshot_node(e,x.before_batch[i].info.id,&x.after_batch[i]);
        if(rc!=uim_OK){size_t j;for(j=0;j<x.batch_count;j++)(void)uim_node_set_rect(e->receiver,x.before_batch[j].info.id,x.before_batch[j].info.local_rect);edit_release(&x);gesture_clear(e);return rc;}
        if(memcmp(&x.before_batch[i].info.local_rect,&x.after_batch[i].info.local_rect,sizeof(uim_Rect))!=0)changed=true;
    }
    memset(&e->gesture,0,sizeof(e->gesture));
    if(!changed){edit_release(&x);return uim_OK;}
    return history_push(e,&x);
}
uim_Result uir_editor_move_selection(uim_Editor*e,float dx,float dy){size_t i,n=0;uim_NodeInfo info;uim_NodeId*ids=NULL;uim_Rect*rects=NULL;uim_Result rc;if(!e||!isfinite(dx)||!isfinite(dy)||!e->selection_count)return uim_ERR_ARGUMENT;rc=selected_move_roots(e,&ids,&n);if(rc!=uim_OK)return rc;if(!n){free(ids);return uim_OK;}if(n>SIZE_MAX/sizeof(*rects)){free(ids);return uim_ERR_RANGE;}rects=(uim_Rect*)malloc(n*sizeof(*rects));if(!rects){free(ids);return uim_ERR_NOMEM;}for(i=0;i<n;i++){if(uim_node_get(e->receiver,ids[i],&info)!=uim_OK){free(ids);free(rects);return uim_ERR_NOT_FOUND;}rects[i]=info.local_rect;rects[i].x+=dx;rects[i].y+=dy;}rc=apply_rect_batch(e,ids,rects,n);free(ids);free(rects);return rc;}
uim_Result uir_editor_resize_node(uim_Editor*e,uim_NodeId id,float w,float h){uim_NodeInfo n;if(!e||!isfinite(w)||!isfinite(h)||w<0||h<0)return uim_ERR_ARGUMENT;if(uim_node_get(e->receiver,id,&n)!=uim_OK)return uim_ERR_NOT_FOUND;n.local_rect.width=w;n.local_rect.height=h;return edit_set_rect(e,id,n.local_rect);}
uim_Result uir_editor_set_component_config(uim_Editor*e,uim_NodeId id,const void*data,size_t n){Edit x;uim_Result rc;if(!e||(!data&&n))return uim_ERR_ARGUMENT;if((rc=node_edit_begin(e,id,&x))!=uim_OK)return rc;if((rc=uim_node_set_component_config(e->receiver,id,data,n))!=uim_OK){edit_release(&x);return rc;}return node_edit_end(e,&x);}
static uim_Result component_edit_push(uim_Editor *e, uim_NodeId node,
                                      uim_ComponentInstanceId instance,
                                      uim_PropertyId property,
                                      ComponentListSnapshot *before, bool coalesce) {
    Edit edit;
    ComponentListSnapshot after;
    uim_Result rc;
    memset(&edit, 0, sizeof(edit));
    memset(&after, 0, sizeof(after));
    edit.kind = EDIT_COMPONENTS;
    edit.node_id = node;
    edit.component_instance = instance;
    edit.component_property = property;
    edit.before_components = *before;
    memset(before, 0, sizeof(*before));
    rc = component_list_capture(e, node, &after);
    if (rc != uim_OK) {
        (void)component_list_restore(e, &edit.before_components);
        edit_release(&edit);
        return rc;
    }
    edit.after_components = after;
    if (coalesce && property != 0u && e->history_cursor == e->history_count &&
        e->history_count > 0u) {
        Edit *last = &e->history[e->history_count - 1u];
        if (last->kind == EDIT_COMPONENTS && last->component_instance == instance &&
            last->component_property == property) {
            component_list_release(&last->after_components);
            last->after_components = edit.after_components;
            memset(&edit.after_components, 0, sizeof(edit.after_components));
            edit_release(&edit);
            return uim_OK;
        }
    }
    rc = history_push(e, &edit);
    if (rc != uim_OK) {
        (void)component_list_restore(e, &edit.before_components);
        edit_release(&edit);
    }
    return rc;
}

uim_Result uir_editor_component_attach_registered(uim_Editor *e, const uim_ComponentRegistry *registry,
                                                  uim_NodeId node_id, uim_ComponentTypeId type_id,
                                                  uim_ComponentInstanceId *out_instance_id) {
    ComponentListSnapshot before;
    uim_ComponentInstanceId instance = uim_COMPONENT_INSTANCE_INVALID;
    uim_Result rc;
    if (!e || !registry || !node_id || !out_instance_id) return uim_ERR_ARGUMENT;
    *out_instance_id = uim_COMPONENT_INSTANCE_INVALID;
    memset(&before, 0, sizeof(before));
    rc = component_list_capture(e, node_id, &before);
    if (rc != uim_OK) return rc;
    rc = uim_component_instance_attach_registered(e->receiver, registry, node_id, type_id, &instance);
    if (rc != uim_OK) {
        component_list_release(&before);
        return rc;
    }
    rc = component_edit_push(e, node_id, instance, 0u, &before, false);
    if (rc != uim_OK) return rc;
    *out_instance_id = instance;
    return uim_OK;
}

uim_Result uir_editor_component_detach(uim_Editor *e, uim_ComponentInstanceId instance) {
    uim_ComponentInstanceInfo info;
    ComponentListSnapshot before;
    uim_Result rc;
    if (!e || !instance) return uim_ERR_ARGUMENT;
    rc = uim_component_instance_get(e->receiver, instance, &info);
    if (rc != uim_OK) return rc;
    memset(&before, 0, sizeof(before));
    rc = component_list_capture(e, info.node_id, &before);
    if (rc != uim_OK) return rc;
    rc = uim_component_instance_detach(e->receiver, instance);
    if (rc != uim_OK) {
        component_list_release(&before);
        return rc;
    }
    return component_edit_push(e, info.node_id, instance, 0u, &before, false);
}

uim_Result uir_editor_component_set_property(uim_Editor *e, const uim_ComponentRegistry *registry,
                                             uim_ComponentInstanceId instance,
                                             uim_PropertyId property, uim_Value value) {
    uim_ComponentInstanceInfo info;
    ComponentListSnapshot before;
    uim_Result rc;
    if (!e || !instance || !property) return uim_ERR_ARGUMENT;
    rc = uim_component_instance_get(e->receiver, instance, &info);
    if (rc != uim_OK) return rc;
    memset(&before, 0, sizeof(before));
    rc = component_list_capture(e, info.node_id, &before);
    if (rc != uim_OK) return rc;
    rc = registry ? uim_component_instance_set_property_checked(e->receiver, registry, instance, property, value)
                  : uim_component_instance_set_property(e->receiver, instance, property, value);
    if (rc != uim_OK) {
        component_list_release(&before);
        return rc;
    }
    return component_edit_push(e, info.node_id, instance, property, &before, true);
}
uim_Result uir_editor_set_setting_pending(uim_Editor*e,uim_PropertyId id,uim_Value v){uim_SettingState st;Edit x;uim_Result rc;if(!e||!id)return uim_ERR_ARGUMENT;if((rc=uim_setting_get_state(e->receiver,id,&st))!=uim_OK)return rc;memset(&x,0,sizeof(x));x.kind=EDIT_SETTING;x.property_id=id;if((rc=value_clone(&x.before_value,st.pending))!=uim_OK)return rc;if(uim_value_equal(st.pending,v)){edit_release(&x);return uim_OK;}if((rc=uim_setting_set_pending(e->receiver,id,v))!=uim_OK){edit_release(&x);return rc;}if((rc=uim_setting_get_state(e->receiver,id,&st))!=uim_OK){(void)uim_setting_set_pending(e->receiver,id,x.before_value);edit_release(&x);return rc;}if((rc=value_clone(&x.after_value,st.pending))!=uim_OK){(void)uim_setting_set_pending(e->receiver,id,x.before_value);edit_release(&x);return rc;}return history_push(e,&x);}
uim_Result uir_editor_get_setting_state(const uim_Editor*e,uim_PropertyId id,uim_SettingState*out){if(!e)return uim_ERR_ARGUMENT;return uim_setting_get_state(e->receiver,id,out);}
static uim_Result node_simple_mutation(uim_Editor*e,uim_NodeId id,int op,int32_t number,bool flag){Edit x;uim_Result rc;uim_NodeInfo n;if(!e)return uim_ERR_ARGUMENT;if((rc=node_edit_begin(e,id,&x))!=uim_OK)return rc;n=x.before_node.info;if((op==1&&n.visible==flag)||(op==2&&n.enabled==flag)||(op==3&&n.z_order==number)||(op==4&&n.child_order==(uint32_t)number)){edit_release(&x);return uim_OK;}switch(op){case 1:rc=uim_node_set_visible(e->receiver,id,flag);break;case 2:rc=uim_node_set_enabled(e->receiver,id,flag);break;case 3:rc=uim_node_set_z_order(e->receiver,id,number);break;case 4:rc=uim_node_set_child_order(e->receiver,id,(uint32_t)number);break;case 5:rc=uim_node_set_parent(e->receiver,id,(uim_NodeId)(uint64_t)(uint32_t)number);break;default:rc=uim_ERR_ARGUMENT;break;}if(rc!=uim_OK){edit_release(&x);return rc;}return node_edit_end(e,&x);}
uim_Result uir_editor_set_visible(uim_Editor*e,uim_NodeId id,bool v){return node_simple_mutation(e,id,1,0,v);}
uim_Result uir_editor_set_enabled(uim_Editor*e,uim_NodeId id,bool v){return node_simple_mutation(e,id,2,0,v);}
uim_Result uir_editor_set_z_order(uim_Editor*e,uim_NodeId id,int32_t z){return node_simple_mutation(e,id,3,z,false);}
uim_Result uir_editor_set_child_order(uim_Editor*e,uim_NodeId id,uint32_t order){Edit x;uim_Result rc;if(!e)return uim_ERR_ARGUMENT;if((rc=node_edit_begin(e,id,&x))!=uim_OK)return rc;if(x.before_node.info.child_order==order){edit_release(&x);return uim_OK;}if((rc=uim_node_set_child_order(e->receiver,id,order))!=uim_OK){edit_release(&x);return rc;}return node_edit_end(e,&x);}
uim_Result uir_editor_set_parent(uim_Editor*e,uim_NodeId id,uim_NodeId parent){Edit x;uim_Rect old_world,new_parent_world={0};uim_Rect new_local;uim_Result rc;if(!e||!id)return uim_ERR_ARGUMENT;if((rc=node_edit_begin(e,id,&x))!=uim_OK)return rc;if(x.before_node.info.parent_id==parent){edit_release(&x);return uim_OK;}if((rc=node_world_rect(e->receiver,id,&old_world,false))!=uim_OK){edit_release(&x);return rc;}if(parent){if((rc=node_world_rect(e->receiver,parent,&new_parent_world,false))!=uim_OK){edit_release(&x);return rc;}}new_local=x.before_node.info.local_rect;new_local.x=old_world.x-new_parent_world.x;new_local.y=old_world.y-new_parent_world.y;if(!isfinite(new_local.x)||!isfinite(new_local.y)){edit_release(&x);return uim_ERR_RANGE;}rc=uim_node_set_parent(e->receiver,id,parent);if(rc!=uim_OK){edit_release(&x);return rc;}rc=uim_node_set_rect(e->receiver,id,new_local);if(rc!=uim_OK){(void)restore_node(e,&x.before_node);edit_release(&x);return rc;}return node_edit_end(e,&x);}
static uim_Result sibling_extreme(uim_Editor*e,uim_NodeId id,bool front){uim_NodeInfo n,other;size_t count,i;int32_t value;uim_Result rc;if(!e)return uim_ERR_ARGUMENT;if(uim_node_get(e->receiver,id,&n)!=uim_OK)return uim_ERR_NOT_FOUND;if((rc=uim_page_get_node_count(e->receiver,n.page_id,&count))!=uim_OK)return rc;value=n.z_order;for(i=0;i<count;i++){if(uim_page_get_node_at(e->receiver,n.page_id,i,&other)!=uim_OK)return uim_ERR_STATE;if(other.parent_id==n.parent_id){if(front&&other.z_order>value)value=other.z_order;if(!front&&other.z_order<value)value=other.z_order;}}if(front){if(value==INT32_MAX)return uim_ERR_RANGE;value++;}else{if(value==INT32_MIN)return uim_ERR_RANGE;value--;}return uir_editor_set_z_order(e,id,value);}
uim_Result uir_editor_bring_to_front(uim_Editor*e,uim_NodeId id){return sibling_extreme(e,id,true);}
uim_Result uir_editor_send_to_back(uim_Editor*e,uim_NodeId id){return sibling_extreme(e,id,false);}
uim_Result uir_editor_align_selection(uim_Editor*e,uim_EditorAlign a){size_t i;uim_NodeInfo ref,n;uim_NodeId*ids;uim_Rect*rects;uim_Result rc;if(!e||e->selection_count<2)return uim_ERR_ARGUMENT;if(a<uim_EDITOR_ALIGN_LEFT||a>uim_EDITOR_ALIGN_BOTTOM)return uim_ERR_ARGUMENT;if(uim_node_get(e->receiver,e->selection[0],&ref)!=uim_OK)return uim_ERR_NOT_FOUND;if(e->selection_count>SIZE_MAX/sizeof(*ids)||e->selection_count>SIZE_MAX/sizeof(*rects))return uim_ERR_RANGE;ids=(uim_NodeId*)malloc(e->selection_count*sizeof(*ids));rects=(uim_Rect*)malloc(e->selection_count*sizeof(*rects));if(!ids||!rects){free(ids);free(rects);return uim_ERR_NOMEM;}for(i=0;i<e->selection_count;i++){if(uim_node_get(e->receiver,e->selection[i],&n)!=uim_OK){free(ids);free(rects);return uim_ERR_NOT_FOUND;}if(n.page_id!=ref.page_id||n.parent_id!=ref.parent_id){free(ids);free(rects);return uim_ERR_ARGUMENT;}ids[i]=n.id;rects[i]=n.local_rect;if(i==0)continue;switch(a){case uim_EDITOR_ALIGN_LEFT:rects[i].x=ref.local_rect.x;break;case uim_EDITOR_ALIGN_HCENTER:rects[i].x=ref.local_rect.x+(ref.local_rect.width-rects[i].width)*0.5f;break;case uim_EDITOR_ALIGN_RIGHT:rects[i].x=ref.local_rect.x+ref.local_rect.width-rects[i].width;break;case uim_EDITOR_ALIGN_TOP:rects[i].y=ref.local_rect.y;break;case uim_EDITOR_ALIGN_VCENTER:rects[i].y=ref.local_rect.y+(ref.local_rect.height-rects[i].height)*0.5f;break;case uim_EDITOR_ALIGN_BOTTOM:rects[i].y=ref.local_rect.y+ref.local_rect.height-rects[i].height;break;default:break;}}rc=apply_rect_batch(e,ids,rects,e->selection_count);free(ids);free(rects);return rc;}
typedef struct SortNode { uim_NodeInfo info; float pos; } SortNode;
uim_Result uir_editor_distribute_selection(uim_Editor*e,uim_EditorAxis axis){size_t i,j,n;SortNode*a;uim_NodeInfo ref;uim_NodeId*ids;uim_Rect*rects;double total=0,gap;float start,end,cursor;uim_Result rc;if(!e||(axis!=uim_EDITOR_AXIS_HORIZONTAL&&axis!=uim_EDITOR_AXIS_VERTICAL)||e->selection_count<3)return uim_ERR_ARGUMENT;n=e->selection_count;if(n>SIZE_MAX/sizeof(*a)||n>SIZE_MAX/sizeof(*ids)||n>SIZE_MAX/sizeof(*rects))return uim_ERR_RANGE;a=(SortNode*)calloc(n,sizeof(*a));ids=(uim_NodeId*)malloc(n*sizeof(*ids));rects=(uim_Rect*)malloc(n*sizeof(*rects));if(!a||!ids||!rects){free(a);free(ids);free(rects);return uim_ERR_NOMEM;}if(uim_node_get(e->receiver,e->selection[0],&ref)!=uim_OK){free(a);free(ids);free(rects);return uim_ERR_NOT_FOUND;}for(i=0;i<n;i++){if(uim_node_get(e->receiver,e->selection[i],&a[i].info)!=uim_OK){free(a);free(ids);free(rects);return uim_ERR_NOT_FOUND;}if(a[i].info.page_id!=ref.page_id||a[i].info.parent_id!=ref.parent_id){free(a);free(ids);free(rects);return uim_ERR_ARGUMENT;}a[i].pos=axis==uim_EDITOR_AXIS_HORIZONTAL?a[i].info.local_rect.x:a[i].info.local_rect.y;}for(i=0;i<n;i++)for(j=i+1;j<n;j++)if(a[j].pos<a[i].pos){SortNode t=a[i];a[i]=a[j];a[j]=t;}start=a[0].pos;end=axis==uim_EDITOR_AXIS_HORIZONTAL?a[n-1].info.local_rect.x+a[n-1].info.local_rect.width:a[n-1].info.local_rect.y+a[n-1].info.local_rect.height;for(i=0;i<n;i++)total+=axis==uim_EDITOR_AXIS_HORIZONTAL?a[i].info.local_rect.width:a[i].info.local_rect.height;gap=((double)end-start-total)/(double)(n-1);cursor=start;for(i=0;i<n;i++){double node_size=axis==uim_EDITOR_AXIS_HORIZONTAL?a[i].info.local_rect.width:a[i].info.local_rect.height;ids[i]=a[i].info.id;rects[i]=a[i].info.local_rect;if(i>0&&i+1<n){if(axis==uim_EDITOR_AXIS_HORIZONTAL)rects[i].x=cursor;else rects[i].y=cursor;}cursor+=(float)node_size+(float)gap;}rc=apply_rect_batch(e,ids,rects,n);free(a);free(ids);free(rects);return rc;}
uim_Result uir_editor_undo(uim_Editor*e){
    Edit*x;uim_Result rc;uim_NodeId restored=0;
    if(!e)return uim_ERR_ARGUMENT;
    if(!e->history_cursor)return uim_ERR_NOT_FOUND;
    x=&e->history[e->history_cursor-1];
    if(x->kind==EDIT_NODE)rc=restore_node(e,&x->before_node);
    else if(x->kind==EDIT_NODE_BATCH)rc=restore_array(e,x->before_batch,x->batch_count);
    else if(x->kind==EDIT_NODE_TREE_CREATE){rc=uim_node_destroy(e->receiver,x->after_batch[0].info.id);if(rc==uim_OK)selection_remove_ids(e,x->after_batch,x->batch_count);}
    else if(x->kind==EDIT_NODE_TREE_DELETE){rc=restore_tree(e,x->before_batch,x->batch_count,&restored);if(rc==uim_OK){(void)uir_editor_select(e,&restored,1);e->focus_node=restored;}}
    else if(x->kind==EDIT_COMPONENTS)rc=component_list_restore(e,&x->before_components);
    else rc=uim_setting_set_pending(e->receiver,x->property_id,x->before_value);
    if(rc==uim_OK)e->history_cursor--;
    return rc;
}
uim_Result uir_editor_redo(uim_Editor*e){
    Edit*x;uim_Result rc;uim_NodeId restored=0;
    if(!e)return uim_ERR_ARGUMENT;
    if(e->history_cursor>=e->history_count)return uim_ERR_NOT_FOUND;
    x=&e->history[e->history_cursor];
    if(x->kind==EDIT_NODE)rc=restore_node(e,&x->after_node);
    else if(x->kind==EDIT_NODE_BATCH)rc=restore_array(e,x->after_batch,x->batch_count);
    else if(x->kind==EDIT_NODE_TREE_CREATE){rc=restore_tree(e,x->after_batch,x->batch_count,&restored);if(rc==uim_OK){(void)uir_editor_select(e,&restored,1);e->focus_node=restored;}}
    else if(x->kind==EDIT_NODE_TREE_DELETE){rc=uim_node_destroy(e->receiver,x->before_batch[0].info.id);if(rc==uim_OK)selection_remove_ids(e,x->before_batch,x->batch_count);}
    else if(x->kind==EDIT_COMPONENTS)rc=component_list_restore(e,&x->after_components);
    else rc=uim_setting_set_pending(e->receiver,x->property_id,x->after_value);
    if(rc==uim_OK)e->history_cursor++;
    return rc;
}
void uir_editor_clear_history(uim_Editor*e){size_t i;if(!e)return;for(i=0;i<e->history_count;i++)edit_release(&e->history[i]);e->history_count=e->history_cursor=0;}

/* -----------------------------------------------------------------------------------------
 * Hierarchy presentation metadata. This is Editor-owned state, not Receiver node state.
 * ----------------------------------------------------------------------------------------- */
static EditorNodeMeta *meta_find(uim_Editor *e, uim_NodeId id) {
    size_t i;
    for (i = 0; i < e->meta_count; ++i) if (e->meta[i].id == id) return &e->meta[i];
    return NULL;
}
static const EditorNodeMeta *meta_find_c(const uim_Editor *e, uim_NodeId id) {
    size_t i;
    for (i = 0; i < e->meta_count; ++i) if (e->meta[i].id == id) return &e->meta[i];
    return NULL;
}
static uim_Result meta_get_or_add(uim_Editor *e, uim_NodeId id, EditorNodeMeta **out) {
    EditorNodeMeta *m;
    if (!e || !id || !out) return uim_ERR_ARGUMENT;
    m = meta_find(e, id);
    if (m) { *out = m; return uim_OK; }
    if (e->meta_count == SIZE_MAX / sizeof(*e->meta)) return uim_ERR_RANGE;
    if (e->meta_count == e->meta_cap) {
        size_t cap = e->meta_cap ? e->meta_cap * 2 : 16;
        EditorNodeMeta *p;
        if (cap < e->meta_cap || cap > SIZE_MAX / sizeof(*p)) return uim_ERR_RANGE;
        p = (EditorNodeMeta *)realloc(e->meta, cap * sizeof(*p));
        if (!p) return uim_ERR_NOMEM;
        e->meta = p; e->meta_cap = cap;
    }
    m = &e->meta[e->meta_count++]; memset(m, 0, sizeof(*m));
    m->id = id; m->expanded = true; *out = m; return uim_OK;
}
static bool page_is_valid(const UIM_ComponentManager *r, uim_PageId id) {
    size_t count;
    return id != uim_PAGE_INVALID && uim_page_get_node_count(r, id, &count) == uim_OK;
}
uim_Result uir_editor_set_active_page(uim_Editor *e, uim_PageId id) {
    if (!e || !id) return uim_ERR_ARGUMENT;
    if (!page_is_valid(e->receiver, id)) return uim_ERR_NOT_FOUND;
    if (e->active_page != id) {
        e->active_page = id;
        (void)uir_editor_select(e, NULL, 0);
        e->focus_node = uim_NODE_INVALID;
    }
    return uim_OK;
}
uim_Result uir_editor_get_active_page(const uim_Editor *e, uim_PageId *out) {
    if (!e || !out) return uim_ERR_ARGUMENT;
    if (e->active_page && !page_is_valid(e->receiver, e->active_page)) return uim_ERR_STALE;
    *out = e->active_page; return uim_OK;
}
uim_Result uir_editor_hierarchy_set_name(uim_Editor *e, uim_NodeId id, const char *name) {
    EditorNodeMeta *m; char *copy = NULL; uim_NodeInfo n; uim_Result rc;
    if (!e || !id || !name) return uim_ERR_ARGUMENT;
    if (uim_node_get(e->receiver, id, &n) != uim_OK) return uim_ERR_NOT_FOUND;
    if (strlen(name) > 4096) return uim_ERR_RANGE;
    if (name[0]) { size_t len = strlen(name) + 1; copy = (char *)malloc(len); if (!copy) return uim_ERR_NOMEM; memcpy(copy, name, len); }
    rc = meta_get_or_add(e, id, &m); if (rc != uim_OK) { free(copy); return rc; }
    free(m->display_name); m->display_name = copy; return uim_OK;
}
uim_Result uir_editor_hierarchy_set_expanded(uim_Editor *e, uim_NodeId id, bool expanded) {
    EditorNodeMeta *m; uim_NodeInfo n; uim_Result rc;
    if (!e || !id) return uim_ERR_ARGUMENT;
    if (uim_node_get(e->receiver, id, &n) != uim_OK) return uim_ERR_NOT_FOUND;
    rc = meta_get_or_add(e, id, &m); if (rc != uim_OK) return rc;
    m->expanded = expanded; return uim_OK;
}
static uim_Result hierarchy_fill(const uim_Editor *e, uim_NodeId id, uint32_t depth, uim_EditorHierarchyItem *out) {
    uim_NodeInfo n; size_t count; const EditorNodeMeta *m;
    if (depth > UINT32_MAX - 1) return uim_ERR_RANGE;
    if (uim_node_get(e->receiver, id, &n) != uim_OK) return uim_ERR_STALE;
    if (uir_editor_get_child_count(e, id, &count) != uim_OK) return uim_ERR_STATE;
    memset(out, 0, sizeof(*out)); out->node = n; out->depth = depth; out->has_children = count != 0;
    m = meta_find_c(e, id); out->expanded = m ? m->expanded : true;
    out->display_name = (m && m->display_name) ? m->display_name : n.stable_key;
    return uim_OK;
}
typedef struct HierFrame { uim_NodeId id; uint32_t depth; size_t next_child; bool entered; } HierFrame;
static uim_Result hierarchy_build(const uim_Editor *e, uim_NodeId **out_ids, uint32_t **out_depths, size_t *out_count) {
    uim_PageId page; size_t count, i, used = 0, sp = 0; uim_NodeInfo n;
    uim_NodeId *ids = NULL; uint32_t *depths = NULL; HierFrame *stack = NULL;
    uim_Result rc;
    if (!e || !out_ids || !out_depths || !out_count) return uim_ERR_ARGUMENT;
    *out_ids = NULL; *out_depths = NULL; *out_count = 0;
    page = e->active_page;
    if (!page) { if (!e->selection_count) return uim_OK; if (uim_node_get(e->receiver,e->selection[0],&n)!=uim_OK)return uim_ERR_STALE; page=n.page_id; }
    if (uim_page_get_node_count(e->receiver, page, &count) != uim_OK) return uim_ERR_STALE;
    if (!count) return uim_OK;
    if (count > SIZE_MAX / sizeof(*ids) || count > SIZE_MAX / sizeof(*stack)) return uim_ERR_RANGE;
    ids = (uim_NodeId *)malloc(count * sizeof(*ids)); depths = (uint32_t *)malloc(count * sizeof(*depths));
    stack = (HierFrame *)malloc(count * sizeof(*stack));
    if (!ids || !depths || !stack) { free(ids); free(depths); free(stack); return uim_ERR_NOMEM; }
    for (i = 0; i < count; ++i) {
        if ((rc = uim_page_get_node_at(e->receiver, page, i, &n)) != uim_OK) goto fail;
        if (n.parent_id == uim_NODE_INVALID) {
            stack[sp++] = (HierFrame){ n.id, 0, 0, false };
            while (sp) {
                HierFrame *f = &stack[sp - 1];
                uim_EditorHierarchyItem hi;
                if (!f->entered) {
                    if (used >= count) { rc = uim_ERR_STATE; goto fail; }
                    ids[used] = f->id; depths[used] = f->depth; used++; f->entered = true;
                    if ((rc = hierarchy_fill(e, f->id, f->depth, &hi)) != uim_OK) goto fail;
                    if (!hi.expanded) { sp--; continue; }
                }
                if (uim_node_get_child(e->receiver, f->id, f->next_child, &n) == uim_OK) {
                    f->next_child++;
                    if (sp >= count) { rc = uim_ERR_STATE; goto fail; }
                    stack[sp++] = (HierFrame){ n.id, f->depth + 1, 0, false };
                } else sp--;
            }
        }
    }
    free(stack); *out_ids = ids; *out_depths = depths; *out_count = used; return uim_OK;
fail:
    free(ids); free(depths); free(stack); return rc;
}
uim_Result uir_editor_hierarchy_get_item(const uim_Editor *e, uim_NodeId id, uim_EditorHierarchyItem *out) {
    uim_NodeInfo n; uint32_t depth = 0; uim_NodeId p;
    if (!e || !id || !out) return uim_ERR_ARGUMENT;
    if (uim_node_get(e->receiver, id, &n) != uim_OK) return uim_ERR_NOT_FOUND;
    p = n.parent_id;
    while (p) { uim_NodeInfo parent; if (depth == UINT32_MAX - 1) return uim_ERR_RANGE; if (uim_node_get(e->receiver,p,&parent)!=uim_OK)return uim_ERR_STALE; depth++; p=parent.parent_id; }
    return hierarchy_fill(e,id,depth,out);
}
uim_Result uir_editor_hierarchy_get_visible_count(const uim_Editor *e, size_t *out) {
    uim_NodeId *ids; uint32_t *depths; size_t count; uim_Result rc;
    if (!e || !out) return uim_ERR_ARGUMENT;
    rc = hierarchy_build(e,&ids,&depths,&count); if (rc != uim_OK) return rc;
    free(ids); free(depths); *out = count; return uim_OK;
}
uim_Result uir_editor_hierarchy_get_visible_at(const uim_Editor *e, size_t index, uim_EditorHierarchyItem *out) {
    uim_NodeId *ids; uint32_t *depths; size_t count; uim_Result rc;
    if (!e || !out) return uim_ERR_ARGUMENT;
    rc = hierarchy_build(e,&ids,&depths,&count); if (rc != uim_OK) return rc;
    if (index >= count) { free(ids); free(depths); return uim_ERR_NOT_FOUND; }
    rc = hierarchy_fill(e,ids[index],depths[index],out); free(ids); free(depths); return rc;
}

/* -----------------------------------------------------------------------------------------
 * Page-space geometry, parent transforms, hit testing and box selection.
 * ----------------------------------------------------------------------------------------- */
static uim_Result node_world_rect(const UIM_ComponentManager *r, uim_NodeId id, uim_Rect *out, bool require_visible) {
    uim_NodeInfo current;
    uim_Rect world;
    size_t page_count = 0, steps = 0;
    uim_Result rc;
    if (!r || !id || !out) return uim_ERR_ARGUMENT;
    rc = uim_node_get(r, id, &current);
    if (rc != uim_OK) return rc;
    world = current.local_rect;
    if (require_visible && !current.visible) return uim_ERR_NOT_FOUND;
    rc = uim_page_get_node_count(r, current.page_id, &page_count);
    if (rc != uim_OK) return rc;
    while (current.parent_id) {
        uim_NodeInfo parent;
        if (steps++ >= page_count) return uim_ERR_STATE; /* corrupted/cyclic hierarchy guard */
        rc = uim_node_get(r, current.parent_id, &parent);
        if (rc != uim_OK) return uim_ERR_STALE;
        if (parent.page_id != current.page_id) return uim_ERR_STATE;
        if (require_visible && !parent.visible) return uim_ERR_NOT_FOUND;
        world.x += parent.local_rect.x;
        world.y += parent.local_rect.y;
        if (!isfinite(world.x) || !isfinite(world.y)) return uim_ERR_RANGE;
        current = parent;
    }
    *out = world;
    return uim_OK;
}
static bool rect_contains_point(uim_Rect r,float x,float y){return x>=r.x&&y>=r.y&&x<r.x+r.width&&y<r.y+r.height;}
static bool rect_intersects(uim_Rect a,uim_Rect b){return a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;}
static uint32_t node_depth(const UIM_ComponentManager*r,uim_NodeInfo n){uint32_t d=0;while(n.parent_id&&d<UINT32_MAX-1){if(uim_node_get(r,n.parent_id,&n)!=uim_OK)break;d++;}return d;}
uim_Result uir_editor_canvas_hit_test(const uim_Editor *e, uim_PageId page, float cx, float cy, uim_NodeId *out){float px,py;size_t count,i;uim_NodeInfo n,best={0};uint32_t best_depth=0;bool found=false;uim_Result rc;if(!e||!page||!out||!isfinite(cx)||!isfinite(cy))return uim_ERR_ARGUMENT;*out=0;if((rc=uir_editor_canvas_to_page(e,cx,cy,&px,&py))!=uim_OK)return rc;if((rc=uim_page_get_node_count(e->receiver,page,&count))!=uim_OK)return rc;for(i=0;i<count;i++){uim_Rect w;uint32_t depth;if(uim_page_get_node_at(e->receiver,page,i,&n)!=uim_OK)return uim_ERR_STATE;if(node_world_rect(e->receiver,n.id,&w,true)!=uim_OK||!rect_contains_point(w,px,py))continue;depth=node_depth(e->receiver,n);if(!found||depth>best_depth||(depth==best_depth&&(n.z_order>best.z_order||(n.z_order==best.z_order&&n.child_order>best.child_order)))){best=n;best_depth=depth;found=true;}}if(found)*out=best.id;return found?uim_OK:uim_ERR_NOT_FOUND;}
uim_Result uir_editor_canvas_box_select(uim_Editor *e, uim_PageId page, uim_Rect canvas_rect, bool additive){float x1,y1,x2,y2;uim_Rect p;size_t count,i,base=0,nout=0;uim_NodeId*ids;uim_EditorSelection sel;uim_Result rc;if(!e||!page||!isfinite(canvas_rect.x)||!isfinite(canvas_rect.y)||!isfinite(canvas_rect.width)||!isfinite(canvas_rect.height)||canvas_rect.width<0||canvas_rect.height<0)return uim_ERR_ARGUMENT;if((rc=uir_editor_canvas_to_page(e,canvas_rect.x,canvas_rect.y,&x1,&y1))!=uim_OK)return rc;if((rc=uir_editor_canvas_to_page(e,canvas_rect.x+canvas_rect.width,canvas_rect.y+canvas_rect.height,&x2,&y2))!=uim_OK)return rc;p=(uim_Rect){x1,y1,x2-x1,y2-y1};if((rc=uim_page_get_node_count(e->receiver,page,&count))!=uim_OK)return rc;if(additive){if((rc=uir_editor_get_selection(e,&sel))!=uim_OK)return rc;base=sel.count;}if(count>SIZE_MAX/sizeof(*ids)-base)return uim_ERR_RANGE;ids=(uim_NodeId*)malloc((count+base)*sizeof(*ids));if(count+base&&!ids)return uim_ERR_NOMEM;if(additive)for(i=0;i<base;i++)ids[nout++]=sel.ids[i];for(i=0;i<count;i++){uim_NodeInfo n;uim_Rect w;bool duplicate=false;size_t j;if(uim_page_get_node_at(e->receiver,page,i,&n)!=uim_OK){free(ids);return uim_ERR_STATE;}if(node_world_rect(e->receiver,n.id,&w,true)!=uim_OK||!rect_intersects(w,p))continue;for(j=0;j<nout;j++)if(ids[j]==n.id){duplicate=true;break;}if(!duplicate)ids[nout++]=n.id;}rc=uir_editor_select(e,ids,nout);free(ids);if(rc==uim_OK)e->active_page=page;return rc;}

static uim_Result selection_toggle(uim_Editor *e,uim_NodeId id,bool add){size_t i;for(i=0;i<e->selection_count;i++)if(e->selection[i]==id){if(add)return uim_OK;memmove(&e->selection[i],&e->selection[i+1],(e->selection_count-i-1)*sizeof(*e->selection));e->selection_count--;return uim_OK;}if(add){uim_NodeId*next=(uim_NodeId*)realloc(e->selection,(e->selection_count+1)*sizeof(*next));if(!next)return uim_ERR_NOMEM;e->selection=next;e->selection[e->selection_count++]=id;}return uim_OK;}
uim_Result uir_editor_canvas_pointer_down(uim_Editor*e,uim_PageId page,float cx,float cy,uint32_t mods){float px,py;uim_NodeId hit=0;uim_Result rc;uim_EditorSelection sel;size_t i;uint32_t handle=UINT32_MAX;if(!e||!page||!isfinite(cx)||!isfinite(cy)||(mods&~(uint32_t)(uim_EDITOR_MOD_SHIFT|uim_EDITOR_MOD_CTRL|uim_EDITOR_MOD_ALT)))return uim_ERR_ARGUMENT;if(e->gesture.mode!=GESTURE_NONE)return uim_ERR_STATE;if(!page_is_valid(e->receiver,page))return uim_ERR_NOT_FOUND;if(e->active_page!=page&&(rc=uir_editor_set_active_page(e,page))!=uim_OK)return rc;if((rc=uir_editor_canvas_to_page(e,cx,cy,&px,&py))!=uim_OK)return rc;if((rc=uir_editor_get_selection(e,&sel))!=uim_OK)return rc;if(sel.count==1){uim_Rect w;float x[8],y[8];if(node_world_rect(e->receiver,sel.ids[0],&w,true)==uim_OK){x[0]=w.x;x[1]=w.x+w.width*.5f;x[2]=w.x+w.width;x[3]=w.x+w.width;x[4]=w.x+w.width;x[5]=w.x+w.width*.5f;x[6]=w.x;x[7]=w.x;y[0]=w.y;y[1]=w.y;y[2]=w.y;y[3]=w.y+w.height*.5f;y[4]=w.y+w.height;y[5]=w.y+w.height;y[6]=w.y+w.height;y[7]=w.y+w.height*.5f;for(i=0;i<8;i++){float hx,hy;if(uir_editor_page_to_canvas(e,x[i],y[i],&hx,&hy)!=uim_OK)return uim_ERR_RANGE;if(fabsf(cx-hx)<=10.0f&&fabsf(cy-hy)<=10.0f){handle=(uint32_t)i;break;}}}}if(handle!=UINT32_MAX){uim_NodeId id=sel.ids[0];return gesture_begin_nodes(e,GESTURE_RESIZE,page,cx,cy,px,py,&id,1,handle,mods);}rc=uir_editor_canvas_hit_test(e,page,cx,cy,&hit);if(rc==uim_OK){bool selected=false;for(i=0;i<sel.count;i++)if(sel.ids[i]==hit){selected=true;break;}if(mods&uim_EDITOR_MOD_SHIFT){if((rc=selection_toggle(e,hit,!selected))!=uim_OK)return rc;if(selected)return uim_OK;}else if(!selected){if((rc=uir_editor_select(e,&hit,1))!=uim_OK)return rc;}if((rc=uir_editor_set_focus_node(e,hit))!=uim_OK)return rc;{uim_NodeId*roots=NULL;size_t n=0;rc=selected_move_roots(e,&roots,&n);if(rc==uim_OK&&n)rc=gesture_begin_nodes(e,GESTURE_MOVE,page,cx,cy,px,py,roots,n,0,mods);free(roots);return rc;}}if(rc!=uim_ERR_NOT_FOUND)return rc;if(!(mods&uim_EDITOR_MOD_SHIFT)){if((rc=uir_editor_select(e,NULL,0))!=uim_OK)return rc;}e->gesture.mode=GESTURE_BOX;e->gesture.page_id=page;e->gesture.start_canvas_x=cx;e->gesture.start_canvas_y=cy;e->gesture.last_canvas_x=cx;e->gesture.last_canvas_y=cy;e->gesture.modifiers=mods;return uim_OK;}
uim_Result uir_editor_canvas_pointer_move(uim_Editor*e,float cx,float cy){uim_Result rc;if(!e||!isfinite(cx)||!isfinite(cy))return uim_ERR_ARGUMENT;if(e->gesture.mode==GESTURE_NONE)return uim_ERR_STATE;rc=gesture_apply(e,cx,cy);if(rc==uim_OK){e->gesture.last_canvas_x=cx;e->gesture.last_canvas_y=cy;}return rc;}
uim_Result uir_editor_canvas_pointer_up(uim_Editor*e,float cx,float cy){uim_Result rc;if(!e||!isfinite(cx)||!isfinite(cy))return uim_ERR_ARGUMENT;if(e->gesture.mode==GESTURE_NONE)return uim_ERR_STATE;if(e->gesture.mode==GESTURE_BOX){float x=e->gesture.start_canvas_x,y=e->gesture.start_canvas_y,w=cx-x,h=cy-y;bool additive=(e->gesture.modifiers&uim_EDITOR_MOD_SHIFT)!=0;uim_PageId page=e->gesture.page_id;gesture_clear(e);if(w<0){x+=w;w=-w;}if(h<0){y+=h;h=-h;}return uir_editor_canvas_box_select(e,page,(uim_Rect){x,y,w,h},additive);}rc=gesture_apply(e,cx,cy);if(rc!=uim_OK){(void)uir_editor_canvas_pointer_cancel(e);return rc;}return gesture_finish(e);}
uim_Result uir_editor_canvas_pointer_cancel(uim_Editor*e){size_t i;uim_Result rc=uim_OK;if(!e)return uim_ERR_ARGUMENT;for(i=0;i<e->gesture.count;i++){uim_Result x=uim_node_set_rect(e->receiver,e->gesture.before[i].info.id,e->gesture.before[i].info.local_rect);if(x!=uim_OK&&rc==uim_OK)rc=x;}gesture_clear(e);return rc;}
uim_Result uir_editor_key_down(uim_Editor*e,uim_EditorKey key,uint32_t mods){uim_EditorSelection sel;uim_Result rc;float step=(mods&uim_EDITOR_MOD_SHIFT)?10.0f:1.0f;if(!e||key<uim_EDITOR_KEY_ESCAPE||key>uim_EDITOR_KEY_D||(mods&~(uint32_t)(uim_EDITOR_MOD_SHIFT|uim_EDITOR_MOD_CTRL|uim_EDITOR_MOD_ALT)))return uim_ERR_ARGUMENT;if(key==uim_EDITOR_KEY_ESCAPE){if(e->gesture.mode!=GESTURE_NONE)return uir_editor_canvas_pointer_cancel(e);return uir_editor_select(e,NULL,0);}if((mods&uim_EDITOR_MOD_CTRL)&&key==uim_EDITOR_KEY_Z)return (mods&uim_EDITOR_MOD_SHIFT)?uir_editor_redo(e):uir_editor_undo(e);if((mods&uim_EDITOR_MOD_CTRL)&&key==uim_EDITOR_KEY_Y)return uir_editor_redo(e);if((mods&uim_EDITOR_MOD_CTRL)&&key==uim_EDITOR_KEY_D){if(uir_editor_get_selection(e,&sel)!=uim_OK||sel.count!=1)return uim_ERR_STATE;{uim_NodeId dup=0;return uir_editor_duplicate_node(e,sel.ids[0],16,16,&dup);}}if(key==uim_EDITOR_KEY_DELETE){if(uir_editor_get_selection(e,&sel)!=uim_OK||sel.count!=1)return uim_ERR_STATE;return uir_editor_delete_node(e,sel.ids[0]);}if(key==uim_EDITOR_KEY_LEFT||key==uim_EDITOR_KEY_RIGHT||key==uim_EDITOR_KEY_UP||key==uim_EDITOR_KEY_DOWN){float dx=0,dy=0;if(!e->selection_count)return uim_ERR_NOT_FOUND;if(key==uim_EDITOR_KEY_LEFT)dx=-step;else if(key==uim_EDITOR_KEY_RIGHT)dx=step;else if(key==uim_EDITOR_KEY_UP)dy=-step;else dy=step;rc=uir_editor_move_selection(e,dx,dy);return rc;}return uim_ERR_UNSUPPORTED;}
uim_Result uir_editor_reorder_node(uim_Editor*e,uim_NodeId id,size_t new_index){
    typedef struct Sibling { uim_NodeInfo info; } Sibling;
    uim_NodeInfo target,n;
    Sibling *siblings=NULL;
    NodeSnapshot *before=NULL,*after=NULL;
    size_t page_count=0,count=0,i,j,old_index=SIZE_MAX;
    uim_Result rc;
    Edit edit;
    if(!e||!id)return uim_ERR_ARGUMENT;
    if((rc=uim_node_get(e->receiver,id,&target))!=uim_OK)return rc;
    if((rc=uim_page_get_node_count(e->receiver,target.page_id,&page_count))!=uim_OK)return rc;
    if(page_count>SIZE_MAX/sizeof(*siblings)||page_count>SIZE_MAX/sizeof(NodeSnapshot))return uim_ERR_RANGE;
    siblings=page_count?(Sibling*)malloc(page_count*sizeof(*siblings)):NULL;
    if(page_count&&!siblings)return uim_ERR_NOMEM;
    for(i=0;i<page_count;i++){
        if(uim_page_get_node_at(e->receiver,target.page_id,i,&n)!=uim_OK){rc=uim_ERR_STATE;goto done;}
        if(n.parent_id==target.parent_id)siblings[count++].info=n;
    }
    if(!count){rc=uim_ERR_NOT_FOUND;goto done;}
    for(i=0;i<count;i++)for(j=i+1;j<count;j++){
        if(siblings[j].info.child_order<siblings[i].info.child_order||
           (siblings[j].info.child_order==siblings[i].info.child_order&&siblings[j].info.id<siblings[i].info.id)){
            Sibling t=siblings[i];siblings[i]=siblings[j];siblings[j]=t;
        }
    }
    for(i=0;i<count;i++)if(siblings[i].info.id==id){old_index=i;break;}
    if(old_index==SIZE_MAX){rc=uim_ERR_NOT_FOUND;goto done;}
    if(new_index>=count){rc=uim_ERR_RANGE;goto done;}
    if(new_index==old_index){rc=uim_OK;goto done;}
    if(count>UINT32_MAX){rc=uim_ERR_RANGE;goto done;}
    before=(NodeSnapshot*)calloc(count,sizeof(*before));after=(NodeSnapshot*)calloc(count,sizeof(*after));
    if(!before||!after){rc=uim_ERR_NOMEM;goto done;}
    for(i=0;i<count;i++){rc=snapshot_node(e,siblings[i].info.id,&before[i]);if(rc!=uim_OK)goto done;}
    {
        Sibling moved=siblings[old_index];
        if(old_index<new_index)memmove(&siblings[old_index],&siblings[old_index+1],(new_index-old_index)*sizeof(*siblings));
        else memmove(&siblings[new_index+1],&siblings[new_index],(old_index-new_index)*sizeof(*siblings));
        siblings[new_index]=moved;
    }
    for(i=0;i<count;i++){
        rc=uim_node_set_child_order(e->receiver,siblings[i].info.id,(uint32_t)i);
        if(rc!=uim_OK){for(j=0;j<count;j++)(void)restore_node(e,&before[j]);goto done;}
    }
    for(i=0;i<count;i++){rc=snapshot_node(e,siblings[i].info.id,&after[i]);if(rc!=uim_OK){for(j=0;j<count;j++)(void)restore_node(e,&before[j]);goto done;}}
    memset(&edit,0,sizeof(edit));edit.kind=EDIT_NODE_BATCH;edit.batch_count=count;edit.before_batch=before;edit.after_batch=after;before=NULL;after=NULL;
    rc=history_push(e,&edit);
done:
    free(siblings);snapshot_array_release(before,count);snapshot_array_release(after,count);return rc;
}

uim_Result uir_editor_get_history_state(const uim_Editor *e, uim_EditorHistoryState *out) {
    if (!e || !out) return uim_ERR_ARGUMENT;
    out->undo_count = e->history_cursor;
    out->redo_count = e->history_count - e->history_cursor;
    out->capacity = e->history_cap;
    return uim_OK;
}

typedef struct OverlayBuffer {
    uim_EditorOverlayCommand *items;
    size_t count, capacity;
} OverlayBuffer;
static uim_Result overlay_append(OverlayBuffer *b, uim_EditorOverlayCommand c) {
    if (b->count == b->capacity) {
        size_t cap = b->capacity ? b->capacity * 2 : 64;
        uim_EditorOverlayCommand *p;
        if (cap < b->capacity || cap > SIZE_MAX / sizeof(*p)) return uim_ERR_RANGE;
        p = (uim_EditorOverlayCommand *)realloc(b->items, cap * sizeof(*p));
        if (!p) return uim_ERR_NOMEM;
        b->items = p; b->capacity = cap;
    }
    b->items[b->count++] = c;
    return uim_OK;
}
static uim_Result overlay_line(OverlayBuffer *b, uim_EditorOverlayType type, float x1, float y1, float x2, float y2) {
    uim_EditorOverlayCommand c; memset(&c, 0, sizeof(c)); c.type=type;c.x1=x1;c.y1=y1;c.x2=x2;c.y2=y2;return overlay_append(b,c);
}
static uim_Result overlay_rect(OverlayBuffer *b, uim_EditorOverlayType type, uim_NodeId id, uim_Rect rect) {
    uim_EditorOverlayCommand c; memset(&c, 0, sizeof(c)); c.type=type;c.node_id=id;c.rect=rect;return overlay_append(b,c);
}
static uim_Result overlay_handles(OverlayBuffer *b, uim_NodeId id, uim_Rect r) {
    const float h=10.0f, x[8]={r.x,r.x+r.width*0.5f,r.x+r.width,r.x+r.width,r.x+r.width,r.x+r.width*0.5f,r.x,r.x};
    const float y[8]={r.y,r.y,r.y,r.y+r.height*0.5f,r.y+r.height,r.y+r.height,r.y+r.height,r.y+r.height*0.5f};
    size_t i; uim_Result rc;
    for(i=0;i<8;i++){uim_EditorOverlayCommand c;memset(&c,0,sizeof(c));c.type=uim_EDITOR_OVERLAY_RESIZE_HANDLE;c.node_id=id;c.handle_index=(uint32_t)i;c.rect=(uim_Rect){x[i]-h*0.5f,y[i]-h*0.5f,h,h};rc=overlay_append(b,c);if(rc!=uim_OK)return rc;}
    return uim_OK;
}
uim_Result uir_editor_build_overlay(const uim_Editor *e, uim_PageId page,
                                    uim_EditorOverlayCommand *out, size_t capacity, size_t *out_count) {
    OverlayBuffer b={0}; uim_Result rc=uim_OK; float minx,miny,maxx,maxy; size_t count,i; uim_NodeInfo n;
    if(!e||!page||!out_count||(!out&&capacity))return uim_ERR_ARGUMENT;
    if((rc=uim_page_get_node_count(e->receiver,page,&count))!=uim_OK)return rc;
    if((rc=uir_editor_canvas_to_page(e,e->canvas.viewport.x,e->canvas.viewport.y,&minx,&miny))!=uim_OK)goto done;
    if((rc=uir_editor_canvas_to_page(e,e->canvas.viewport.x+e->canvas.viewport.width,e->canvas.viewport.y+e->canvas.viewport.height,&maxx,&maxy))!=uim_OK)goto done;
    if(e->canvas.show_grid&&e->canvas.grid_size>0.0f){
        double nx=floor((double)maxx/e->canvas.grid_size)-ceil((double)minx/e->canvas.grid_size)+1.0;
        double ny=floor((double)maxy/e->canvas.grid_size)-ceil((double)miny/e->canvas.grid_size)+1.0;
        size_t sx=(nx>4096.0)?(size_t)ceil(nx/4096.0):1, sy=(ny>4096.0)?(size_t)ceil(ny/4096.0):1;
        double k; size_t ix=0;
        for(k=ceil((double)minx/e->canvas.grid_size);k<=(double)floor((double)maxx/e->canvas.grid_size)&&ix<4096;k+=sx,ix++){
            float px=(float)(k*e->canvas.grid_size),cx,cy1,cx2,cy2;
            if(uir_editor_page_to_canvas(e,px,miny,&cx,&cy1)!=uim_OK||uir_editor_page_to_canvas(e,px,maxy,&cx2,&cy2)!=uim_OK){rc=uim_ERR_RANGE;goto done;}
            if((rc=overlay_line(&b,uim_EDITOR_OVERLAY_GRID_LINE,cx,cy1,cx2,cy2))!=uim_OK)goto done;
        }
        ix=0;
        for(k=ceil((double)miny/e->canvas.grid_size);k<=(double)floor((double)maxy/e->canvas.grid_size)&&ix<4096;k+=sy,ix++){
            float py=(float)(k*e->canvas.grid_size),cx1,cy,cx2,cy2;
            if(uir_editor_page_to_canvas(e,minx,py,&cx1,&cy)!=uim_OK||uir_editor_page_to_canvas(e,maxx,py,&cx2,&cy2)!=uim_OK){rc=uim_ERR_RANGE;goto done;}
            if((rc=overlay_line(&b,uim_EDITOR_OVERLAY_GRID_LINE,cx1,cy,cx2,cy2))!=uim_OK)goto done;
        }
    }
    for(i=0;i<e->guide_count;i++){
        float x1,y1,x2,y2;const uim_EditorGuide*g=&e->guides[i];
        if(g->vertical){if(uir_editor_page_to_canvas(e,g->position,miny,&x1,&y1)!=uim_OK||uir_editor_page_to_canvas(e,g->position,maxy,&x2,&y2)!=uim_OK){rc=uim_ERR_RANGE;goto done;}}
        else {if(uir_editor_page_to_canvas(e,minx,g->position,&x1,&y1)!=uim_OK||uir_editor_page_to_canvas(e,maxx,g->position,&x2,&y2)!=uim_OK){rc=uim_ERR_RANGE;goto done;}}
        if((rc=overlay_line(&b,uim_EDITOR_OVERLAY_GUIDE_LINE,x1,y1,x2,y2))!=uim_OK)goto done;
    }
    if(e->canvas.safe_area_enabled){uim_Rect r=e->canvas.safe_area;float x1,y1,x2,y2;if(uir_editor_page_to_canvas(e,r.x,r.y,&x1,&y1)!=uim_OK||uir_editor_page_to_canvas(e,r.x+r.width,r.y+r.height,&x2,&y2)!=uim_OK){rc=uim_ERR_RANGE;goto done;}if((rc=overlay_rect(&b,uim_EDITOR_OVERLAY_SAFE_AREA,0,(uim_Rect){x1,y1,x2-x1,y2-y1}))!=uim_OK)goto done;}
    for(i=0;i<count;i++){
        uim_Rect world;float x1,y1,x2,y2;bool selected=false;size_t j;
        if(uim_page_get_node_at(e->receiver,page,i,&n)!=uim_OK){rc=uim_ERR_STATE;goto done;}
        if(node_world_rect(e->receiver,n.id,&world,true)!=uim_OK)continue;
        if(uir_editor_page_to_canvas(e,world.x,world.y,&x1,&y1)!=uim_OK||uir_editor_page_to_canvas(e,world.x+world.width,world.y+world.height,&x2,&y2)!=uim_OK){rc=uim_ERR_RANGE;goto done;}
        if((rc=overlay_rect(&b,uim_EDITOR_OVERLAY_NODE_BOUNDS,n.id,(uim_Rect){x1,y1,x2-x1,y2-y1}))!=uim_OK)goto done;
        for(j=0;j<e->selection_count;j++)if(e->selection[j]==n.id){selected=true;break;}
        if(selected){if((rc=overlay_rect(&b,uim_EDITOR_OVERLAY_SELECTED_BOUNDS,n.id,(uim_Rect){x1,y1,x2-x1,y2-y1}))!=uim_OK)goto done;if((rc=overlay_handles(&b,n.id,(uim_Rect){x1,y1,x2-x1,y2-y1}))!=uim_OK)goto done;}
        if(e->focus_node==n.id){if((rc=overlay_rect(&b,uim_EDITOR_OVERLAY_FOCUS_BOUNDS,n.id,(uim_Rect){x1,y1,x2-x1,y2-y1}))!=uim_OK)goto done;}
    }
    if(e->gesture.mode==GESTURE_BOX && e->gesture.page_id==page){
        float x1=fminf(e->gesture.start_canvas_x,e->gesture.last_canvas_x);
        float y1=fminf(e->gesture.start_canvas_y,e->gesture.last_canvas_y);
        float x2=fmaxf(e->gesture.start_canvas_x,e->gesture.last_canvas_x);
        float y2=fmaxf(e->gesture.start_canvas_y,e->gesture.last_canvas_y);
        if((rc=overlay_rect(&b,uim_EDITOR_OVERLAY_SELECTION_MARQUEE,0,(uim_Rect){x1,y1,x2-x1,y2-y1}))!=uim_OK)goto done;
    }
    *out_count=b.count;
    if(!out||capacity<b.count){rc=(b.count>capacity)?uim_ERR_BUFFER:uim_OK;goto done;}
    if(b.count)memcpy(out,b.items,b.count*sizeof(*out));
done:
    if(rc!=uim_OK&&rc!=uim_ERR_BUFFER)*out_count=0;
    free(b.items);return rc;
}
