#include "ui_hierarchy.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct uim_Hierarchy {
    const UIM_ComponentManager *rec;
    uim_NodeId root;
    uim_NodeId expanded[uim_HIER_MAX_EXPANDED];
    size_t expanded_count;
    uim_NodeId selected;
};

typedef struct HierMeta {
    uim_NodeId id;
    int depth;
    bool has_children;
    bool is_expanded;
} HierMeta;

uim_Hierarchy *uim_hierarchy_create(void) {
    return (uim_Hierarchy *)calloc(1u, sizeof(uim_Hierarchy));
}

void uim_hierarchy_destroy(uim_Hierarchy *h) {
    free(h);
}

void uim_hierarchy_set_source(uim_Hierarchy *h, const UIM_ComponentManager *rec,
                              uim_NodeId root_id) {
    if (!h) return;
    h->rec = rec;
    h->root = root_id;
    h->expanded_count = 0;
    h->selected = root_id;
}

static bool node_info(const UIM_ComponentManager *rec, uim_NodeId id, uim_NodeInfo *out) {
    return rec && id != uim_NODE_INVALID && uim_node_get(rec, id, out) == uim_OK;
}

static bool has_children(const UIM_ComponentManager *rec, uim_NodeId id) {
    uim_NodeInfo parent;
    size_t count = 0u;
    size_t i;
    if (!node_info(rec, id, &parent)) return false;
    if (uim_page_get_node_count(rec, parent.page_id, &count) != uim_OK) return false;
    for (i = 0u; i < count; ++i) {
        uim_NodeInfo child;
        if (uim_page_get_node_at(rec, parent.page_id, i, &child) == uim_OK &&
            child.parent_id == id) return true;
    }
    return false;
}

static bool is_expanded(const uim_Hierarchy *h, uim_NodeId id) {
    size_t i;
    for (i = 0u; i < h->expanded_count; ++i)
        if (h->expanded[i] == id) return true;
    return false;
}

static void collect_rows(const uim_Hierarchy *h, uim_NodeId id, int depth,
                         HierMeta *rows, size_t *count) {
    size_t index = 0u;
    uim_NodeId child = uim_NODE_INVALID;
    if (!h || !rows || !count || id == uim_NODE_INVALID ||
        *count >= uim_HIER_MAX_VISIBLE) return;
    if (depth > 127) return;
    rows[*count].id = id;
    rows[*count].depth = depth;
    rows[*count].has_children = has_children(h->rec, id);
    rows[*count].is_expanded = is_expanded(h, id);
    (*count)++;
    if (!is_expanded(h, id)) return;
    while (*count < uim_HIER_MAX_VISIBLE) {
        uim_NodeInfo info;
        if (uim_node_get_child(h->rec, id, index, &info) != uim_OK) break;
        index++;
        child = info.id;
        collect_rows(h, child, depth + 1, rows, count);
    }
    (void)child;
}

static size_t rows_of(const uim_Hierarchy *h, HierMeta *rows, size_t cap) {
    size_t count = 0u;
    if (!h || !rows || cap == 0u) return 0u;
    if (h->root == uim_NODE_INVALID) return 0u;
    collect_rows(h, h->root, 0, rows, &count);
    return count;
}

static bool row_at(const uim_Hierarchy *h, int index, HierMeta *out) {
    HierMeta rows[uim_HIER_MAX_VISIBLE];
    size_t count;
    if (!h || !out || index < 0) return false;
    count = rows_of(h, rows, uim_HIER_MAX_VISIBLE);
    if ((size_t)index >= count) return false;
    *out = rows[index];
    return true;
}

static void toggle_expanded(uim_Hierarchy *h, uim_NodeId id) {
    size_t i;
    if (!h || id == uim_NODE_INVALID) return;
    for (i = 0u; i < h->expanded_count; ++i) {
        if (h->expanded[i] == id) {
            if (i + 1u < h->expanded_count) {
                memmove(&h->expanded[i], &h->expanded[i + 1u],
                        (h->expanded_count - i - 1u) * sizeof(h->expanded[0]));
            }
            h->expanded_count--;
            return;
        }
    }
    if (h->expanded_count < uim_HIER_MAX_EXPANDED)
        h->expanded[h->expanded_count++] = id;
}

void uim_hierarchy_handle_row_click(uim_Hierarchy *h, int row_index) {
    HierMeta row;
    if (!h || !row_at(h, row_index, &row)) return;
    h->selected = row.id;
    if (row.has_children) toggle_expanded(h, row.id);
}

void uim_hierarchy_select_row(uim_Hierarchy *h, int row_index) {
    HierMeta row;
    if (!h || !row_at(h, row_index, &row)) return;
    h->selected = row.id;
}

void uim_hierarchy_clear_selection(uim_Hierarchy *h) {
    if (h) h->selected = uim_NODE_INVALID;
}

void uim_hierarchy_toggle_row(uim_Hierarchy *h, int row_index) {
    HierMeta row;
    if (!h || !row_at(h, row_index, &row) || !row.has_children) return;
    toggle_expanded(h, row.id);
}

int uim_hierarchy_visible_count(const uim_Hierarchy *h) {
    HierMeta rows[uim_HIER_MAX_VISIBLE];
    return (int)rows_of(h, rows, uim_HIER_MAX_VISIBLE);
}

bool uim_hierarchy_get_row(const uim_Hierarchy *h, int index, uim_HierRow *out_row) {
    HierMeta row;
    uim_NodeInfo info;
    if (!h || !out_row || !row_at(h, index, &row)) return false;
    memset(out_row, 0, sizeof(*out_row));
    out_row->node_id = row.id;
    out_row->depth = row.depth;
    out_row->is_expanded = row.is_expanded;
    out_row->has_children = row.has_children;
    out_row->selected = row.id == h->selected;
    if (node_info(h->rec, row.id, &info)) {
        out_row->type_id = info.component_id;
        if (info.stable_key && info.stable_key[0]) {
            snprintf(out_row->node_name, sizeof(out_row->node_name), "%s",
                     info.stable_key);
        } else {
            snprintf(out_row->node_name, sizeof(out_row->node_name), "node %llu",
                     (unsigned long long)row.id);
        }
    }
    return true;
}

uim_NodeId uim_hierarchy_selected(const uim_Hierarchy *h) {
    return h ? h->selected : uim_NODE_INVALID;
}
