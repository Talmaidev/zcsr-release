/* editor_host_win32.c — Win32 implementation of the editor host boundary.
 *
 * This is the only editor source allowed to include windows.h/commdlg.h.
 * editor_app.cpp talks to editor_host.h instead of HWND/OPENFILENAME directly.
 */
#define NOMINMAX
#include <windows.h>
#include <commdlg.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

#include "editor_host.h"
#include "zcsr/platform.h"

struct editor_host {
    HWND owner;
};

static wchar_t* host_wide_from_utf8(const char* text) {
    if (!text) return NULL;
    int n = MultiByteToWideChar(CP_UTF8, 0, text, -1, NULL, 0);
    if (n <= 0) return NULL;
    wchar_t* out = (wchar_t*)malloc((size_t)n * sizeof(wchar_t));
    if (!out) return NULL;
    MultiByteToWideChar(CP_UTF8, 0, text, -1, out, n);
    return out;
}

static bool host_utf8_from_wide(const wchar_t* text, char* out, size_t capacity) {
    if (!out || capacity == 0) return false;
    out[0] = '\0';
    if (!text) return false;
    int n = WideCharToMultiByte(CP_UTF8, 0, text, -1, NULL, 0, NULL, NULL);
    if (n <= 0 || (size_t)n > capacity) return false;
    WideCharToMultiByte(CP_UTF8, 0, text, -1, out, n, NULL, NULL);
    return true;
}

static void host_build_filter(const char* extension, wchar_t* out, size_t capacity) {
    if (!out || capacity == 0) return;
    wchar_t* p = out;
    size_t left = capacity;
    int n;
    out[0] = L'\0';
    if (!extension || !extension[0]) {
        n = _snwprintf(p, left, L"All Files (*.*)");
        if (n < 0 || (size_t)n + 2 >= left) return;
        p += n + 1;
        left -= (size_t)n + 1;
        n = _snwprintf(p, left, L"*.*");
        if (n < 0 || (size_t)n + 2 >= left) return;
        p += n + 1;
        left -= (size_t)n + 1;
        *p = L'\0';
        return;
    }
    wchar_t wide_ext[64];
    if (MultiByteToWideChar(CP_UTF8, 0, extension, -1, wide_ext, 64) <= 0) return;
    n = _snwprintf(p, left, L"ZCSR Files (*.%ls)", wide_ext);
    if (n < 0 || (size_t)n + 2 >= left) return;
    p += n + 1;
    left -= (size_t)n + 1;
    n = _snwprintf(p, left, L"*.%ls", wide_ext);
    if (n < 0 || (size_t)n + 2 >= left) return;
    p += n + 1;
    left -= (size_t)n + 1;
    n = _snwprintf(p, left, L"All Files (*.*)");
    if (n < 0 || (size_t)n + 2 >= left) return;
    p += n + 1;
    left -= (size_t)n + 1;
    n = _snwprintf(p, left, L"*.*");
    if (n < 0 || (size_t)n + 2 >= left) return;
    p += n + 1;
    *p = L'\0';
}

editor_host* editor_host_create(zcsr_surface* surface) {
    editor_host* host = (editor_host*)calloc(1, sizeof(*host));
    if (!host) return NULL;
    host->owner = surface ? (HWND)zcsr_surface_native_handle(surface) : NULL;
    return host;
}

void editor_host_destroy(editor_host* host) {
    free(host);
}

bool editor_host_open_file(editor_host* host, const char* title, const char* extension,
                           char* out_path, size_t out_capacity) {
    if (!host || !out_path || out_capacity == 0) return false;
    wchar_t file[32768] = {0};
    wchar_t filter[512];
    wchar_t* wide_title = host_wide_from_utf8(title ? title : "Open File");
    wchar_t* wide_ext = host_wide_from_utf8(extension ? extension : "");
    host_build_filter(extension, filter, sizeof(filter) / sizeof(filter[0]));

    OPENFILENAMEW ofn;
    memset(&ofn, 0, sizeof(ofn));
    ofn.hwndOwner = host->owner;
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFilter = filter;
    ofn.lpstrFile = file;
    ofn.nMaxFile = (DWORD)(sizeof(file) / sizeof(file[0]));
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrTitle = wide_title;
    ofn.lpstrDefExt = wide_ext && wide_ext[0] ? wide_ext : NULL;

    BOOL ok = GetOpenFileNameW(&ofn);
    if (ok) host_utf8_from_wide(file, out_path, out_capacity);
    free(wide_title);
    free(wide_ext);
    return ok != FALSE;
}

bool editor_host_save_file(editor_host* host, const char* title, const char* extension,
                           const char* suggested_name, char* out_path, size_t out_capacity) {
    if (!host || !out_path || out_capacity == 0) return false;
    wchar_t file[32768] = {0};
    wchar_t filter[512];
    wchar_t* wide_title = host_wide_from_utf8(title ? title : "Save File");
    wchar_t* wide_ext = host_wide_from_utf8(extension ? extension : "");
    wchar_t* wide_suggested = host_wide_from_utf8(suggested_name ? suggested_name : "");
    host_build_filter(extension, filter, sizeof(filter) / sizeof(filter[0]));

    if (wide_suggested && wide_suggested[0]) {
        wcsncpy(file, wide_suggested, (sizeof(file) / sizeof(file[0])) - 1);
    }

    OPENFILENAMEW ofn;
    memset(&ofn, 0, sizeof(ofn));
    ofn.hwndOwner = host->owner;
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFilter = filter;
    ofn.lpstrFile = file;
    ofn.nMaxFile = (DWORD)(sizeof(file) / sizeof(file[0]));
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrTitle = wide_title;
    ofn.lpstrDefExt = wide_ext && wide_ext[0] ? wide_ext : NULL;

    BOOL ok = GetSaveFileNameW(&ofn);
    if (ok) host_utf8_from_wide(file, out_path, out_capacity);
    free(wide_title);
    free(wide_ext);
    free(wide_suggested);
    return ok != FALSE;
}

editor_host_unsaved_choice editor_host_confirm_unsaved(editor_host* host,
                                                       const char* title,
                                                       const char* message) {
    wchar_t* wide_title = host_wide_from_utf8(title ? title : "ZCSR Editor");
    wchar_t* wide_message = host_wide_from_utf8(message ? message : "Unsaved changes.");
    int choice = MessageBoxW(host ? host->owner : NULL,
                             wide_message ? wide_message : L"Unsaved changes.",
                             wide_title ? wide_title : L"ZCSR Editor",
                             MB_YESNOCANCEL | MB_ICONWARNING);
    free(wide_title);
    free(wide_message);
    if (choice == IDYES) return EDITOR_HOST_UNSAVED_SAVE;
    if (choice == IDNO) return EDITOR_HOST_UNSAVED_DISCARD;
    return EDITOR_HOST_UNSAVED_CANCEL;
}

bool editor_host_executable_path(editor_host* host, char* out_path, size_t out_capacity) {
    (void)host;
    wchar_t file[32768];
    DWORD n = GetModuleFileNameW(NULL, file, (DWORD)(sizeof(file) / sizeof(file[0])));
    if (n == 0 || n >= sizeof(file) / sizeof(file[0])) return false;
    return host_utf8_from_wide(file, out_path, out_capacity);
}

bool editor_host_run_process(editor_host* host, const char* command, const char* working_dir,
                             char* output, size_t output_capacity, int* out_exit_code) {
    (void)host;
    if (output && output_capacity) output[0] = '\0';
    if (out_exit_code) *out_exit_code = 1;

    SECURITY_ATTRIBUTES sa;
    memset(&sa, 0, sizeof(sa));
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;
    HANDLE read_pipe = NULL;
    HANDLE write_pipe = NULL;
    if (!CreatePipe(&read_pipe, &write_pipe, &sa, 0)) return false;
    SetHandleInformation(read_pipe, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOW si;
    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdOutput = write_pipe;
    si.hStdError = write_pipe;
    si.hStdInput = NULL;

    wchar_t* wide_command = host_wide_from_utf8(command);
    wchar_t* wide_dir = host_wide_from_utf8(working_dir);
    if (!wide_command) {
        CloseHandle(write_pipe);
        CloseHandle(read_pipe);
        free(wide_dir);
        return false;
    }

    PROCESS_INFORMATION pi;
    memset(&pi, 0, sizeof(pi));
    BOOL ok = CreateProcessW(NULL, wide_command, NULL, NULL, TRUE,
                             CREATE_NO_WINDOW, NULL,
                             wide_dir && wide_dir[0] ? wide_dir : NULL,
                             &si, &pi);
    free(wide_command);
    free(wide_dir);
    CloseHandle(write_pipe);
    if (!ok) {
        CloseHandle(read_pipe);
        return false;
    }

    CloseHandle(pi.hThread);
    size_t used = 0;
    char buffer[4096];
    DWORD read = 0;
    while (ReadFile(read_pipe, buffer, sizeof(buffer), &read, NULL) && read > 0) {
        if (output && used + 1 < output_capacity) {
            size_t room = output_capacity - used - 1;
            size_t n = read < room ? read : room;
            memcpy(output + used, buffer, n);
            used += n;
            output[used] = '\0';
        }
    }
    CloseHandle(read_pipe);
    WaitForSingleObject(pi.hProcess, INFINITE);
    DWORD exit_code = 1;
    GetExitCodeProcess(pi.hProcess, &exit_code);
    if (out_exit_code) *out_exit_code = (int)exit_code;
    CloseHandle(pi.hProcess);
    return true;
}

bool editor_host_launch_process(editor_host* host, const char* command, const char* working_dir) {
    (void)host;
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    memset(&pi, 0, sizeof(pi));
    wchar_t* wide_command = host_wide_from_utf8(command);
    wchar_t* wide_dir = host_wide_from_utf8(working_dir);
    if (!wide_command) {
        free(wide_dir);
        return false;
    }
    BOOL ok = CreateProcessW(NULL, wide_command, NULL, NULL, FALSE,
                             0, NULL,
                             wide_dir && wide_dir[0] ? wide_dir : NULL,
                             &si, &pi);
    free(wide_command);
    free(wide_dir);
    if (!ok) return false;
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return true;
}