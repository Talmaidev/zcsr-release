#include "ui_editor_workspace.h"
#include <string.h>

static bool ws_rect_valid(uim_Rect r)
{
    return r.width > 0.0f && r.height > 0.0f;
}

static uim_Rect ws_rect(float x, float y, float w, float h)
{
    uim_Rect r = {x, y, w, h};
    if (r.width < 0.0f) r.width = 0.0f;
    if (r.height < 0.0f) r.height = 0.0f;
    return r;
}

static uim_WorkspaceNodeId ws_alloc_node(uim_Workspace *ws, uim_WorkspaceNodeType type)
{
    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i) {
        if (ws->nodes[i].type == uim_WORKSPACE_NODE_UNUSED) {
            memset(&ws->nodes[i], 0, sizeof(ws->nodes[i]));
            ws->nodes[i].type = type;
            return (uim_WorkspaceNodeId)i;
        }
    }
    return uim_WORKSPACE_NODE_INVALID;
}

static uim_WorkspaceNodeId ws_add_tabs(uim_Workspace *ws,
                                       const uim_WorkspacePanelId *ids, size_t count)
{
    uim_WorkspaceNodeId id = ws_alloc_node(ws, uim_WORKSPACE_NODE_TABS);
    uim_WorkspaceNode *n;
    if (id == uim_WORKSPACE_NODE_INVALID) return id;
    n = &ws->nodes[id];
    n->parent = uim_WORKSPACE_NODE_INVALID;
    for (size_t i = 0; i < count && i < uim_WORKSPACE_MAX_TABS_PER_GROUP; ++i) {
        n->panel_ids[n->panel_count++] = ids[i];
    }
    n->active_index = 0;
    return id;
}

static uim_WorkspaceNodeId ws_add_split(uim_Workspace *ws, uim_WorkspaceAxis axis,
                                        float ratio, uim_WorkspaceNodeId a,
                                        uim_WorkspaceNodeId b)
{
    uim_WorkspaceNodeId id = ws_alloc_node(ws, uim_WORKSPACE_NODE_SPLIT);
    uim_WorkspaceNode *n;
    if (id == uim_WORKSPACE_NODE_INVALID) return id;
    n = &ws->nodes[id];
    n->axis = axis;
    n->ratio = ratio;
    n->child_a = a;
    n->child_b = b;
    ws->nodes[a].parent = id;
    ws->nodes[b].parent = id;
    return id;
}

static void ws_factor_panels(uim_Workspace *ws)
{
    for (size_t i = 0; i < ws->panel_count; ++i) {
        ws->panels[i].id = ws->config.panels[i].id;
        ws->panels[i].title = ws->config.panels[i].title;
        ws->panels[i].min_width = ws->config.panels[i].min_width;
        ws->panels[i].min_height = ws->config.panels[i].min_height;
        ws->panels[i].flags = ws->config.panels[i].flags;
    }
}

static uim_WorkspacePanelDesc *ws_panel(uim_Workspace *ws, uim_WorkspacePanelId id)
{
    for (size_t i = 0; i < ws->panel_count; ++i) {
        if (ws->panels[i].id == id) return &ws->panels[i];
    }
    return NULL;
}

static const uim_WorkspacePanelDesc *ws_panel_c(const uim_Workspace *ws, uim_WorkspacePanelId id)
{
    for (size_t i = 0; i < ws->panel_count; ++i) {
        if (ws->panels[i].id == id) return &ws->panels[i];
    }
    return NULL;
}

static uim_WorkspaceNodeId ws_find_group(const uim_Workspace *ws, uim_WorkspacePanelId id)
{
    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i) {
        if (ws->nodes[i].type != uim_WORKSPACE_NODE_TABS) continue;
        for (size_t j = 0; j < ws->nodes[i].panel_count; ++j) {
            if (ws->nodes[i].panel_ids[j] == id) return (uim_WorkspaceNodeId)i;
        }
    }
    return uim_WORKSPACE_NODE_INVALID;
}

static bool ws_remove_from_groups(uim_Workspace *ws, uim_WorkspacePanelId id, bool *removed)
{
    *removed = false;
    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i) {
        uim_WorkspaceNode *n = &ws->nodes[i];
        if (n->type != uim_WORKSPACE_NODE_TABS) continue;
        for (size_t j = 0; j < n->panel_count; ++j) {
            if (n->panel_ids[j] != id) continue;
            memmove(&n->panel_ids[j], &n->panel_ids[j + 1],
                    (n->panel_count - j - 1) * sizeof(n->panel_ids[0]));
            n->panel_count--;
            if (n->active_index >= n->panel_count && n->panel_count)
                n->active_index = (uint8_t)(n->panel_count - 1);
            *removed = true;
            return true;
        }
    }
    return false;
}

static void ws_layout_node(uim_Workspace *ws, uim_WorkspaceNodeId id, uim_Rect rect)
{
    uim_WorkspaceNode *n;
    if (id == uim_WORKSPACE_NODE_INVALID || id >= uim_WORKSPACE_MAX_NODES) return;
    n = &ws->nodes[id];
    if (n->type == uim_WORKSPACE_NODE_UNUSED) return;
    n->rect = rect;
    if (n->type != uim_WORKSPACE_NODE_SPLIT) return;
    float ratio = n->ratio;
    if (ratio < 0.05f) ratio = 0.05f;
    if (ratio > 0.95f) ratio = 0.95f;
    float s = ws->config.splitter_size > 0.0f ? ws->config.splitter_size : 6.0f;
    if (n->axis == uim_WORKSPACE_AXIS_HORIZONTAL) {
        float a_width = (rect.width - s) * ratio;
        uim_Rect a = ws_rect(rect.x, rect.y, a_width, rect.height);
        uim_Rect b = ws_rect(rect.x + a_width + s, rect.y,
                             rect.width - a_width - s, rect.height);
        ws_layout_node(ws, n->child_a, a);
        ws_layout_node(ws, n->child_b, b);
    } else {
        float a_height = (rect.height - s) * ratio;
        uim_Rect a = ws_rect(rect.x, rect.y, rect.width, a_height);
        uim_Rect b = ws_rect(rect.x, rect.y + a_height + s,
                             rect.width, rect.height - a_height - s);
        ws_layout_node(ws, n->child_a, a);
        ws_layout_node(ws, n->child_b, b);
    }
}

static uim_Rect ws_group_content(const uim_Workspace *ws, const uim_WorkspaceNode *n)
{
    float tab_h = ws->config.tab_height > 0.0f ? ws->config.tab_height : 26.0f;
    return ws_rect(n->rect.x, n->rect.y + tab_h, n->rect.width,
                   n->rect.height - tab_h);
}

static void ws_add_splitter_view(uim_Workspace *ws, uim_WorkspaceFrame *frame,
                                 uim_WorkspaceNodeId id)
{
    uim_WorkspaceNode *n = &ws->nodes[id];
    float s = ws->config.splitter_size > 0.0f ? ws->config.splitter_size : 6.0f;
    uim_WorkspaceSplitterView *v;
    if (frame->splitter_count >= uim_WORKSPACE_MAX_SPLITTERS) return;
    v = &frame->splitters[frame->splitter_count++];
    v->node_id = id;
    v->axis = n->axis;
    v->ratio = n->ratio;
    if (n->axis == uim_WORKSPACE_AXIS_HORIZONTAL) {
        float a_width = (n->rect.width - s) * n->ratio;
        v->rect = ws_rect(n->rect.x + a_width, n->rect.y, s, n->rect.height);
    } else {
        float a_height = (n->rect.height - s) * n->ratio;
        v->rect = ws_rect(n->rect.x, n->rect.y + a_height, n->rect.width, s);
    }
}

uim_Result uim_workspace_init_default(uim_Workspace *workspace,
                                      const uim_WorkspaceConfig *config)
{
    uim_WorkspacePanelDesc default_panels[8] = {
        {uim_WORKSPACE_PANEL_PALETTE, "Palette", 160.0f, 120.0f, 0u},
        {uim_WORKSPACE_PANEL_HIERARCHY, "Hierarchy", 180.0f, 120.0f, 0u},
        {uim_WORKSPACE_PANEL_SCENE, "Scene", 320.0f, 240.0f, 0u},
        {uim_WORKSPACE_PANEL_GAME, "Game", 320.0f, 240.0f, 0u},
        {uim_WORKSPACE_PANEL_INSPECTOR, "Inspector", 220.0f, 200.0f, 0u},
        {uim_WORKSPACE_PANEL_PROJECT, "Project", 200.0f, 100.0f, 0u},
        {uim_WORKSPACE_PANEL_ASSETS, "Assets", 200.0f, 100.0f, 0u},
        {uim_WORKSPACE_PANEL_CONSOLE, "Console", 200.0f, 100.0f, 0u},
    };
    if (!workspace) return uim_ERR_ARGUMENT;
    memset(workspace, 0, sizeof(*workspace));
    if (config) workspace->config = *config;
    else {
        workspace->config.width = 1280.0f;
        workspace->config.height = 720.0f;
        workspace->config.menu_bar_height = 24.0f;
        workspace->config.toolbar_height = 40.0f;
        workspace->config.status_bar_height = 22.0f;
        workspace->config.bottom_panel_height = 160.0f;
        workspace->config.left_panel_width = 240.0f;
        workspace->config.right_panel_width = 280.0f;
        workspace->config.splitter_size = 6.0f;
        workspace->config.tab_height = 26.0f;
    }
    if (!workspace->config.panels || !workspace->config.panel_count) {
        workspace->config.panels = default_panels;
        workspace->config.panel_count = 8;
    }
    if (workspace->config.width <= 0.0f) workspace->config.width = 1280.0f;
    if (workspace->config.height <= 0.0f) workspace->config.height = 720.0f;
    if (workspace->config.tab_height <= 0.0f) workspace->config.tab_height = 26.0f;
    if (workspace->config.splitter_size <= 0.0f) workspace->config.splitter_size = 6.0f;
    workspace->panel_count = workspace->config.panel_count;
    if (workspace->panel_count > uim_WORKSPACE_MAX_PANELS)
        workspace->panel_count = uim_WORKSPACE_MAX_PANELS;
    ws_factor_panels(workspace);
    workspace->config.panels = workspace->panels;
    workspace->root = uim_WORKSPACE_NODE_INVALID;
    workspace->active_splitter = uim_WORKSPACE_NODE_INVALID;
    workspace->viewport_mode = uim_WORKSPACE_VIEW_SCENE;

    uim_WorkspacePanelId left_ids[] = {uim_WORKSPACE_PANEL_PALETTE, uim_WORKSPACE_PANEL_HIERARCHY};
    uim_WorkspacePanelId center_ids[] = {uim_WORKSPACE_PANEL_SCENE, uim_WORKSPACE_PANEL_GAME};
    uim_WorkspacePanelId right_ids[] = {uim_WORKSPACE_PANEL_INSPECTOR};
    uim_WorkspacePanelId bottom_ids[] = {uim_WORKSPACE_PANEL_PROJECT, uim_WORKSPACE_PANEL_ASSETS,
                                         uim_WORKSPACE_PANEL_CONSOLE};
    uim_WorkspaceNodeId left = ws_add_tabs(workspace, left_ids, 2);
    uim_WorkspaceNodeId center = ws_add_tabs(workspace, center_ids, 2);
    uim_WorkspaceNodeId right = ws_add_tabs(workspace, right_ids, 1);
    uim_WorkspaceNodeId bottom = ws_add_tabs(workspace, bottom_ids, 3);
    if (left == uim_WORKSPACE_NODE_INVALID || center == uim_WORKSPACE_NODE_INVALID ||
        right == uim_WORKSPACE_NODE_INVALID || bottom == uim_WORKSPACE_NODE_INVALID)
        return uim_ERR_RANGE;
    uim_WorkspaceNodeId center_right = ws_add_split(workspace, uim_WORKSPACE_AXIS_HORIZONTAL,
                                                    0.62f, center, right);
    uim_WorkspaceNodeId main = ws_add_split(workspace, uim_WORKSPACE_AXIS_HORIZONTAL,
                                            0.20f, left, center_right);
    float bottom_ratio = 1.0f - workspace->config.bottom_panel_height / workspace->config.height;
    if (bottom_ratio < 0.1f) bottom_ratio = 0.75f;
    workspace->root = ws_add_split(workspace, uim_WORKSPACE_AXIS_VERTICAL,
                                   bottom_ratio, main, bottom);
    workspace->layout_revision = 1;
    return workspace->root == uim_WORKSPACE_NODE_INVALID ? uim_ERR_RANGE : uim_OK;
}

uim_Result uim_workspace_set_bounds(uim_Workspace *workspace, float width, float height)
{
    if (!workspace || width <= 0.0f || height <= 0.0f) return uim_ERR_ARGUMENT;
    workspace->config.width = width;
    workspace->config.height = height;
    workspace->layout_revision++;
    return uim_OK;
}

uim_Result uim_workspace_build_frame(uim_Workspace *workspace,
                                     uim_WorkspaceFrame *out_frame)
{
    if (!workspace || !out_frame || workspace->root == uim_WORKSPACE_NODE_INVALID)
        return uim_ERR_ARGUMENT;
    memset(out_frame, 0, sizeof(*out_frame));
    float w = workspace->config.width;
    float h = workspace->config.height;
    float menu_h = workspace->config.menu_bar_height;
    float tool_h = workspace->config.toolbar_height;
    float status_h = workspace->config.status_bar_height;
    out_frame->menu_bar = ws_rect(0, 0, w, menu_h);
    out_frame->toolbar = ws_rect(0, menu_h, w, tool_h);
    out_frame->status_bar = ws_rect(0, h - status_h, w, status_h);
    out_frame->dock_area = ws_rect(0, menu_h + tool_h, w, h - menu_h - tool_h - status_h);
    workspace->last_dock_area = out_frame->dock_area;
    ws_layout_node(workspace, workspace->root, out_frame->dock_area);

    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i) {
        uim_WorkspaceNode *n = &workspace->nodes[i];
        if (n->type != uim_WORKSPACE_NODE_TABS || n->panel_count == 0) continue;
        float tab_w = n->rect.width / n->panel_count;
        uim_Rect content = ws_group_content(workspace, n);
        for (size_t j = 0; j < n->panel_count && out_frame->panel_count < uim_WORKSPACE_MAX_PANELS; ++j) {
            uim_WorkspacePanelView *v = &out_frame->panels[out_frame->panel_count++];
            v->panel_id = n->panel_ids[j];
            v->group_node = (uim_WorkspaceNodeId)i;
            v->tab_rect = ws_rect(n->rect.x + tab_w * j, n->rect.y, tab_w, workspace->config.tab_height);
            v->content_rect = content;
            v->active = j == n->active_index;
        }
    }
    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i) {
        if (workspace->nodes[i].type == uim_WORKSPACE_NODE_SPLIT)
            ws_add_splitter_view(workspace, out_frame, (uim_WorkspaceNodeId)i);
    }
    return uim_OK;
}

uim_Result uim_workspace_get_panel_view(const uim_WorkspaceFrame *frame,
                                        uim_WorkspacePanelId panel_id,
                                        uim_WorkspacePanelView *out_view)
{
    if (!frame || !out_view) return uim_ERR_ARGUMENT;
    for (size_t i = 0; i < frame->panel_count; ++i) {
        if (frame->panels[i].panel_id == panel_id) {
            *out_view = frame->panels[i];
            return uim_OK;
        }
    }
    return uim_ERR_NOT_FOUND;
}

uim_Result uim_workspace_activate_panel(uim_Workspace *workspace,
                                        uim_WorkspacePanelId panel_id)
{
    uim_WorkspaceNodeId group;
    if (!workspace) return uim_ERR_ARGUMENT;
    group = ws_find_group(workspace, panel_id);
    if (group == uim_WORKSPACE_NODE_INVALID) return uim_ERR_NOT_FOUND;
    uim_WorkspaceNode *n = &workspace->nodes[group];
    for (size_t i = 0; i < n->panel_count; ++i) {
        if (n->panel_ids[i] == panel_id) n->active_index = (uint8_t)i;
    }
    if (panel_id == uim_WORKSPACE_PANEL_SCENE) workspace->viewport_mode = uim_WORKSPACE_VIEW_SCENE;
    else if (panel_id == uim_WORKSPACE_PANEL_GAME) workspace->viewport_mode = uim_WORKSPACE_VIEW_GAME;
    workspace->layout_revision++;
    return uim_OK;
}

uim_Result uim_workspace_get_panel_title(const uim_Workspace *workspace,
                                         uim_WorkspacePanelId panel_id,
                                         const char **out_title)
{
    const uim_WorkspacePanelDesc *p;
    if (!workspace || !out_title) return uim_ERR_ARGUMENT;
    p = ws_panel_c(workspace, panel_id);
    if (!p) return uim_ERR_NOT_FOUND;
    *out_title = p->title ? p->title : "";
    return uim_OK;
}

uim_Result uim_workspace_get_active_panel(const uim_Workspace *workspace,
                                          uim_WorkspaceNodeId group_node,
                                          uim_WorkspacePanelId *out_panel_id)
{
    if (!workspace || !out_panel_id || group_node >= uim_WORKSPACE_MAX_NODES)
        return uim_ERR_ARGUMENT;
    const uim_WorkspaceNode *n = &workspace->nodes[group_node];
    if (n->type != uim_WORKSPACE_NODE_TABS || n->panel_count == 0)
        return uim_ERR_NOT_FOUND;
    *out_panel_id = n->panel_ids[n->active_index];
    return uim_OK;
}

uim_Result uim_workspace_dock_panel(uim_Workspace *workspace,
                                    uim_WorkspacePanelId panel_id,
                                    uim_WorkspacePanelId target_panel_id,
                                    uim_WorkspaceDockZone zone)
{
    bool removed = false;
    uim_WorkspaceNodeId target;
    if (!workspace || !ws_panel(workspace, panel_id) || !ws_panel(workspace, target_panel_id))
        return uim_ERR_ARGUMENT;
    target = ws_find_group(workspace, target_panel_id);
    if (target == uim_WORKSPACE_NODE_INVALID) return uim_ERR_NOT_FOUND;
    ws_remove_from_groups(workspace, panel_id, &removed);
    if (zone == uim_WORKSPACE_DOCK_CENTER) {
        uim_WorkspaceNode *n = &workspace->nodes[target];
        if (n->panel_count >= uim_WORKSPACE_MAX_TABS_PER_GROUP) return uim_ERR_RANGE;
        n->panel_ids[n->panel_count++] = panel_id;
        n->active_index = (uint8_t)(n->panel_count - 1);
    } else {
        uim_WorkspacePanelId lone[] = {panel_id};
        uim_WorkspaceNodeId group = ws_add_tabs(workspace, lone, 1);
        uim_WorkspaceNodeId target_id = target;
        uim_WorkspaceNodeId parent;
        bool was_a;
        if (group == uim_WORKSPACE_NODE_INVALID) return uim_ERR_RANGE;
        parent = workspace->nodes[target_id].parent;
        was_a = parent != uim_WORKSPACE_NODE_INVALID && workspace->nodes[parent].child_a == target_id;
        if (parent != uim_WORKSPACE_NODE_INVALID) {
            if (was_a) workspace->nodes[parent].child_a = uim_WORKSPACE_NODE_INVALID;
            else workspace->nodes[parent].child_b = uim_WORKSPACE_NODE_INVALID;
        } else {
            workspace->root = uim_WORKSPACE_NODE_INVALID;
        }
        bool before = zone == uim_WORKSPACE_DOCK_LEFT || zone == uim_WORKSPACE_DOCK_TOP;
        uim_WorkspaceNodeId split = ws_add_split(workspace,
            (zone == uim_WORKSPACE_DOCK_LEFT || zone == uim_WORKSPACE_DOCK_RIGHT)
                ? uim_WORKSPACE_AXIS_HORIZONTAL : uim_WORKSPACE_AXIS_VERTICAL,
            before ? 0.30f : 0.70f, before ? group : target_id, before ? target_id : group);
        if (split == uim_WORKSPACE_NODE_INVALID) return uim_ERR_RANGE;
        if (parent != uim_WORKSPACE_NODE_INVALID) {
            if (was_a) workspace->nodes[parent].child_a = split;
            else workspace->nodes[parent].child_b = split;
            workspace->nodes[split].parent = parent;
        } else {
            workspace->root = split;
            workspace->nodes[split].parent = uim_WORKSPACE_NODE_INVALID;
        }
        ws_layout_node(workspace, workspace->root, workspace->last_dock_area);
    }
    workspace->layout_revision++;
    return uim_OK;
}

uim_Result uim_workspace_close_panel(uim_Workspace *workspace,
                                     uim_WorkspacePanelId panel_id)
{
    bool removed = false;
    if (!workspace) return uim_ERR_ARGUMENT;
    if (!ws_remove_from_groups(workspace, panel_id, &removed)) return uim_ERR_NOT_FOUND;
    workspace->layout_revision++;
    return removed ? uim_OK : uim_ERR_NOT_FOUND;
}

uim_Result uim_workspace_get_drop_target(const uim_WorkspaceFrame *frame,
                                         float x, float y,
                                         uim_WorkspacePanelId *out_target_panel,
                                         uim_WorkspaceDockZone *out_zone)
{
    if (!frame || !out_target_panel || !out_zone) return uim_ERR_ARGUMENT;
    for (size_t i = 0; i < frame->panel_count; ++i) {
        uim_Rect r = frame->panels[i].content_rect;
        if (x < r.x || y < r.y || x >= r.x + r.width || y >= r.y + r.height) continue;
        *out_target_panel = frame->panels[i].panel_id;
        float fx = (x - r.x) / (r.width > 0 ? r.width : 1.0f);
        float fy = (y - r.y) / (r.height > 0 ? r.height : 1.0f);
        if (fx < 0.22f) *out_zone = uim_WORKSPACE_DOCK_LEFT;
        else if (fx > 0.78f) *out_zone = uim_WORKSPACE_DOCK_RIGHT;
        else if (fy < 0.22f) *out_zone = uim_WORKSPACE_DOCK_TOP;
        else if (fy > 0.78f) *out_zone = uim_WORKSPACE_DOCK_BOTTOM;
        else *out_zone = uim_WORKSPACE_DOCK_CENTER;
        return uim_OK;
    }
    return uim_ERR_NOT_FOUND;
}

uim_Result uim_workspace_pointer_down(uim_Workspace *workspace,
                                      const uim_WorkspaceFrame *frame,
                                      float x, float y)
{
    if (!workspace || !frame) return uim_ERR_ARGUMENT;
    workspace->active_splitter = uim_WORKSPACE_NODE_INVALID;
    for (size_t i = 0; i < frame->panel_count; ++i) {
        uim_Rect r = frame->panels[i].tab_rect;
        if (x >= r.x && y >= r.y && x < r.x + r.width && y < r.y + r.height) {
            return uim_workspace_activate_panel(workspace, frame->panels[i].panel_id);
        }
    }
    for (size_t i = 0; i < frame->splitter_count; ++i) {
        uim_Rect r = frame->splitters[i].rect;
        if (x >= r.x && y >= r.y && x < r.x + r.width && y < r.y + r.height) {
            workspace->active_splitter = frame->splitters[i].node_id;
            return uim_OK;
        }
    }
    return uim_ERR_NOT_FOUND;
}

uim_Result uim_workspace_pointer_move(uim_Workspace *workspace, float x, float y)
{
    if (!workspace) return uim_ERR_ARGUMENT;
    if (workspace->active_splitter == uim_WORKSPACE_NODE_INVALID) return uim_ERR_NOT_FOUND;
    uim_WorkspaceNodeId id = workspace->active_splitter;
    uim_WorkspaceNode *n = &workspace->nodes[id];
    if (n->type != uim_WORKSPACE_NODE_SPLIT) return uim_ERR_STATE;
    float s = workspace->config.splitter_size > 0 ? workspace->config.splitter_size : 6.0f;
    float ratio;
    if (n->axis == uim_WORKSPACE_AXIS_HORIZONTAL)
        ratio = (x - n->rect.x) / (n->rect.width - s > 0 ? n->rect.width - s : 1.0f);
    else
        ratio = (y - n->rect.y) / (n->rect.height - s > 0 ? n->rect.height - s : 1.0f);
    if (ratio < 0.05f) ratio = 0.05f;
    if (ratio > 0.95f) ratio = 0.95f;
    n->ratio = ratio;
    workspace->layout_revision++;
    return uim_OK;
}

uim_Result uim_workspace_pointer_up(uim_Workspace *workspace)
{
    if (!workspace) return uim_ERR_ARGUMENT;
    workspace->active_splitter = uim_WORKSPACE_NODE_INVALID;
    return uim_OK;
}

uim_Result uim_workspace_viewport_set_mode(uim_Workspace *workspace,
                                            uim_WorkspaceViewportMode mode)
{
    if (!workspace || (mode != uim_WORKSPACE_VIEW_SCENE && mode != uim_WORKSPACE_VIEW_GAME))
        return uim_ERR_ARGUMENT;
    workspace->viewport_mode = mode;
    uim_workspace_activate_panel(workspace,
        mode == uim_WORKSPACE_VIEW_SCENE ? uim_WORKSPACE_PANEL_SCENE : uim_WORKSPACE_PANEL_GAME);
    return uim_OK;
}

uim_Result uim_workspace_viewport_get_mode(const uim_Workspace *workspace,
                                            uim_WorkspaceViewportMode *out_mode)
{
    if (!workspace || !out_mode) return uim_ERR_ARGUMENT;
    *out_mode = workspace->viewport_mode;
    return uim_OK;
}

uim_Result uim_workspace_viewport_get_rect(const uim_WorkspaceFrame *frame,
                                            uim_WorkspaceViewportMode mode,
                                            uim_Rect *out_rect)
{
    uim_WorkspacePanelView v;
    if (!frame || !out_rect) return uim_ERR_ARGUMENT;
    uim_Result rc = uim_workspace_get_panel_view(frame,
        mode == uim_WORKSPACE_VIEW_GAME ? uim_WORKSPACE_PANEL_GAME : uim_WORKSPACE_PANEL_SCENE, &v);
    if (rc != uim_OK) return rc;
    if (!v.active) return uim_ERR_STATE;
    *out_rect = v.content_rect;
    return uim_OK;
}

uim_Result uim_workspace_get_center_host_rect(
    const uim_Workspace *workspace, const uim_WorkspaceFrame *frame,
    uim_Rect *out_rect, uim_WorkspaceViewportMode *out_mode)
{
    if (!workspace || !frame || !out_rect || !out_mode) return uim_ERR_ARGUMENT;
    *out_mode = workspace->viewport_mode;
    return uim_workspace_viewport_get_rect(frame, workspace->viewport_mode, out_rect);
}

uim_Result uim_workspace_viewport_apply_rect(uim_Editor *editor, uim_Rect viewport_rect)
{
    uim_EditorCanvasState state;
    if (!editor || !ws_rect_valid(viewport_rect)) return uim_ERR_ARGUMENT;
    if (uir_editor_get_canvas_state(editor, &state) != uim_OK) return uim_ERR_STATE;
    state.viewport = viewport_rect;
    return uir_editor_set_canvas_state(editor, &state);
}

uim_Result uim_workspace_viewport_zoom_at(uim_Editor *editor,
                                           float zoom, float screen_x, float screen_y)
{
    if (!editor) return uim_ERR_ARGUMENT;
    return uir_editor_zoom_at(editor, zoom, screen_x, screen_y);
}

uim_Result uim_workspace_viewport_pan(uim_Editor *editor, float dx, float dy)
{
    if (!editor) return uim_ERR_ARGUMENT;
    return uir_editor_pan(editor, dx, dy);
}

uim_Result uim_workspace_viewport_fit_page(uim_Editor *editor,
                                            float page_width, float page_height,
                                            float margin)
{
    uim_EditorCanvasState state;
    float zx, zy, z;
    if (!editor || page_width <= 0.0f || page_height <= 0.0f || margin < 0.0f)
        return uim_ERR_ARGUMENT;
    if (uir_editor_get_canvas_state(editor, &state) != uim_OK) return uim_ERR_STATE;
    zx = (state.viewport.width - margin * 2.0f) / page_width;
    zy = (state.viewport.height - margin * 2.0f) / page_height;
    z = zx < zy ? zx : zy;
    if (z < 0.05f) z = 0.05f;
    if (z > 16.0f) z = 16.0f;
    state.zoom = z;
    state.pan_x = (state.viewport.width - page_width * z) * 0.5f;
    state.pan_y = (state.viewport.height - page_height * z) * 0.5f;
    return uir_editor_set_canvas_state(editor, &state);
}
