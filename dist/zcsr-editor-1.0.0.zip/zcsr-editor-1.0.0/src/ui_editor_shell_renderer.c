#include "ui_editor_shell_renderer.h"

static bool render_ops_valid(const uim_EditorShellRenderOps *ops)
{
    return ops && ops->abi_version == uim_EDITOR_SHELL_RENDER_ABI_VERSION &&
           ops->struct_size >= sizeof(*ops) &&
           ops->begin_frame && ops->draw_element &&
           ops->draw_center_overlay && ops->end_frame;
}

uim_Result uir_editor_shell_render_frame(
    const uim_EditorShellFrame *frame,
    const uim_EditorShellTheme *theme,
    uim_ExternalViewManager *external_views,
    void *renderer_context,
    const uim_EditorShellRenderOps *ops,
    void *user)
{
    (void)external_views;
    if (!frame || !theme || !render_ops_valid(ops)) return uim_ERR_ARGUMENT;
    uim_Result rc = ops->begin_frame(user, renderer_context, frame, theme);
    if (rc != uim_OK) return rc;
    size_t order[uim_EDITOR_SHELL_MAX_ELEMENTS];
    size_t count = frame->element_count;
    if (count > uim_EDITOR_SHELL_MAX_ELEMENTS) count = uim_EDITOR_SHELL_MAX_ELEMENTS;
    for (size_t i = 0; i < count; ++i) order[i] = i;
    for (size_t i = 1; i < count; ++i) {
        size_t key = order[i];
        size_t j = i;
        while (j > 0 && frame->elements[order[j - 1]].z_order > frame->elements[key].z_order) {
            order[j] = order[j - 1];
            j--;
        }
        order[j] = key;
    }
    const uim_EditorShellElement *center = NULL;
    for (size_t s = 0; s < count; ++s) {
        const uim_EditorShellElement *e = &frame->elements[order[s]];
        rc = ops->draw_element(user, renderer_context, e, theme);
        if (rc != uim_OK) return rc;
        if (e->kind == uim_SHELL_ELEMENT_CENTER_HOST) center = e;
        if (center && e->kind != uim_SHELL_ELEMENT_CENTER_HOST) {
            rc = ops->draw_center_overlay(user, renderer_context, frame, center);
            if (rc != uim_OK) return rc;
            center = NULL;
        }
    }
    if (center) {
        rc = ops->draw_center_overlay(user, renderer_context, frame, center);
        if (rc != uim_OK) return rc;
    }
    return ops->end_frame(user, renderer_context);
}
