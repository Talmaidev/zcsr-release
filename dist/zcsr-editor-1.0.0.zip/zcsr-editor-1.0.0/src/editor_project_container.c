#include "editor_project_container.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(_WIN32)
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
#endif

#define ZCSR_CONTAINER_MAGIC "ZCSRPROJ 1"
#define ZCSR_CONTAINER_LIMIT (128u * 1024u * 1024u)
#define ZCSR_CONTAINER_HEADER_LIMIT 512u

#if defined(_WIN32)
static FILE *open_utf8(const char *utf8_path, const wchar_t *mode) {
    wchar_t wide_path[1024];
    if (!utf8_path || !*utf8_path || !mode) return NULL;
    if (MultiByteToWideChar(CP_UTF8, 0, utf8_path, -1, wide_path,
                            (int)(sizeof(wide_path) / sizeof(wide_path[0]))) <= 0)
        return NULL;
    return _wfopen(wide_path, mode);
}
#else
static FILE *open_utf8(const char *utf8_path, const char *mode) {
    if (!utf8_path || !*utf8_path || !mode) return NULL;
    return fopen(utf8_path, mode);
}
#endif

#if defined(_WIN32)
static bool write_atomic_bytes(const char *utf8_path, const void *data, size_t size) {
    wchar_t dest_w[1024];
    wchar_t temp_w[1024];
    char temp_utf8[1024];
    FILE *f;
    bool ok;

    if (!utf8_path || !data || size == 0u) return false;
    if (strlen(utf8_path) >= sizeof(temp_utf8) - 5u) return false;
    snprintf(temp_utf8, sizeof(temp_utf8), "%s.tmp", utf8_path);
    if (MultiByteToWideChar(CP_UTF8, 0, utf8_path, -1, dest_w,
                            (int)(sizeof(dest_w) / sizeof(dest_w[0]))) <= 0 ||
        MultiByteToWideChar(CP_UTF8, 0, temp_utf8, -1, temp_w,
                            (int)(sizeof(temp_w) / sizeof(temp_w[0]))) <= 0)
        return false;
    f = _wfopen(temp_w, L"wb");
    if (!f) return false;
    ok = fwrite(data, 1u, size, f) == size;
    if (ok) ok = fflush(f) == 0;
    if (fclose(f) != 0) ok = false;
    if (!ok) {
        _wremove(temp_w);
        return false;
    }
    if (!MoveFileExW(temp_w, dest_w,
                     MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        _wremove(temp_w);
        return false;
    }
    return true;
}
#else
static bool write_atomic_bytes(const char *utf8_path, const void *data, size_t size) {
    char temp_path[1024];
    FILE *f;
    bool ok;
    if (!utf8_path || !data || size == 0u) return false;
    if (strlen(utf8_path) >= sizeof(temp_path) - 5u) return false;
    snprintf(temp_path, sizeof(temp_path), "%s.tmp", utf8_path);
    f = fopen(temp_path, "wb");
    if (!f) return false;
    ok = fwrite(data, 1u, size, f) == size;
    if (ok) ok = fflush(f) == 0;
    if (fclose(f) != 0) ok = false;
    if (!ok) {
        remove(temp_path);
        return false;
    }
    if (rename(temp_path, utf8_path) != 0) {
        remove(temp_path);
        return false;
    }
    return true;
}
#endif

zcsr_editor_container_result zcsr_editor_project_container_save(
    const char *utf8_path,
    const unsigned char *project, size_t project_size,
    const char *scene, size_t scene_size) {
    char header[ZCSR_CONTAINER_HEADER_LIMIT];
    size_t header_size;
    unsigned char *blob;
    size_t total;
    bool ok;

    if (!utf8_path || !*utf8_path || !project || project_size == 0u)
        return ZCSR_EDITOR_CONTAINER_INVALID_ARGUMENT;
    if (project_size > ZCSR_CONTAINER_LIMIT || scene_size > ZCSR_CONTAINER_LIMIT ||
        project_size > ZCSR_CONTAINER_LIMIT - scene_size)
        return ZCSR_EDITOR_CONTAINER_INVALID_ARGUMENT;

    header_size = (size_t)snprintf(header, sizeof(header),
                                   "%s\nproject %zu\nscene %zu\n",
                                   ZCSR_CONTAINER_MAGIC, project_size, scene_size);
    if (header_size == 0u || header_size >= sizeof(header))
        return ZCSR_EDITOR_CONTAINER_IO_ERROR;
    if (header_size > ZCSR_CONTAINER_LIMIT - project_size - scene_size)
        return ZCSR_EDITOR_CONTAINER_INVALID_ARGUMENT;

    total = header_size + project_size + scene_size;
    blob = (unsigned char *)malloc(total);
    if (!blob) return ZCSR_EDITOR_CONTAINER_IO_ERROR;
    memcpy(blob, header, header_size);
    memcpy(blob + header_size, project, project_size);
    if (scene_size) memcpy(blob + header_size + project_size, scene, scene_size);
    ok = write_atomic_bytes(utf8_path, blob, total);
    free(blob);
    return ok ? ZCSR_EDITOR_CONTAINER_OK : ZCSR_EDITOR_CONTAINER_IO_ERROR;
}

static char *read_all(const char *path, size_t *out_size) {
    FILE *f;
    char *data = NULL;
    size_t size = 0u;
    size_t cap = 0u;

    if (!path || !*path || !out_size) return NULL;
#if defined(_WIN32)
    f = open_utf8(path, L"rb");
#else
    f = open_utf8(path, "rb");
#endif
    if (!f) return NULL;
    for (;;) {
        size_t got;
        if (size == cap) {
            size_t next_cap = cap ? cap * 2u : 4096u;
            char *next;
            if (next_cap > ZCSR_CONTAINER_LIMIT) next_cap = ZCSR_CONTAINER_LIMIT;
            if (next_cap <= cap) break;
            next = (char *)realloc(data, next_cap);
            if (!next) break;
            data = next;
            cap = next_cap;
        }
        got = fread(data + size, 1u, cap - size, f);
        size += got;
        if (got == 0u) break;
    }
    if (ferror(f) || size == 0u) {
        free(data);
        data = NULL;
        size = 0u;
    }
    fclose(f);
    *out_size = size;
    return data;
}

zcsr_editor_container_result zcsr_editor_project_container_load(
    const char *utf8_path,
    unsigned char **out_project, size_t *out_project_size,
    char **out_scene, size_t *out_scene_size) {
    char *data;
    size_t size = 0u;
    char *line1, *line2, *line3, *payload;
    size_t project_size = 0u, scene_size = 0u;
    size_t payload_size;
    unsigned char *project = NULL;
    char *scene = NULL;

    if (!utf8_path || !*utf8_path || !out_project || !out_project_size ||
        !out_scene || !out_scene_size)
        return ZCSR_EDITOR_CONTAINER_INVALID_ARGUMENT;
    *out_project = NULL;
    *out_project_size = 0u;
    *out_scene = NULL;
    *out_scene_size = 0u;

    data = read_all(utf8_path, &size);
    if (!data) return ZCSR_EDITOR_CONTAINER_OPEN_FAILED;

    line1 = data;
    line2 = strchr(line1, '\n');
    if (!line2) { free(data); return ZCSR_EDITOR_CONTAINER_BAD_HEADER; }
    *line2++ = '\0';
    line3 = strchr(line2, '\n');
    if (!line3) { free(data); return ZCSR_EDITOR_CONTAINER_BAD_HEADER; }
    *line3++ = '\0';
    payload = strchr(line3, '\n');
    if (!payload) { free(data); return ZCSR_EDITOR_CONTAINER_BAD_HEADER; }
    *payload++ = '\0';

    if (strcmp(line1, ZCSR_CONTAINER_MAGIC) != 0 ||
        sscanf(line2, "project %zu", &project_size) != 1 ||
        sscanf(line3, "scene %zu", &scene_size) != 1) {
        free(data);
        return ZCSR_EDITOR_CONTAINER_BAD_HEADER;
    }
    payload_size = (size_t)((data + size) - payload);
    if (project_size == 0u || project_size > payload_size ||
        scene_size > payload_size - project_size ||
        project_size + scene_size != payload_size) {
        free(data);
        return ZCSR_EDITOR_CONTAINER_BAD_HEADER;
    }

    project = (unsigned char *)malloc(project_size);
    if (!project) { free(data); return ZCSR_EDITOR_CONTAINER_IO_ERROR; }
    memcpy(project, payload, project_size);
    if (scene_size) {
        scene = (char *)malloc(scene_size + 1u);
        if (!scene) {
            free(project);
            free(data);
            return ZCSR_EDITOR_CONTAINER_IO_ERROR;
        }
        memcpy(scene, payload + project_size, scene_size);
        scene[scene_size] = '\0';
    }

    free(data);
    *out_project = project;
    *out_project_size = project_size;
    *out_scene = scene;
    *out_scene_size = scene_size;
    return ZCSR_EDITOR_CONTAINER_OK;
}

bool zcsr_editor_project_container_probe(const char *utf8_path) {
    char data[32];
    FILE *f;
    size_t got;
    if (!utf8_path || !*utf8_path) return false;
#if defined(_WIN32)
    f = open_utf8(utf8_path, L"rb");
#else
    f = open_utf8(utf8_path, "rb");
#endif
    if (!f) return false;
    got = fread(data, 1u, sizeof(data) - 1u, f);
    fclose(f);
    data[got] = '\0';
    return strncmp(data, ZCSR_CONTAINER_MAGIC, strlen(ZCSR_CONTAINER_MAGIC)) == 0;
}

const char *zcsr_editor_container_result_name(zcsr_editor_container_result result) {
    switch (result) {
    case ZCSR_EDITOR_CONTAINER_OK: return "ok";
    case ZCSR_EDITOR_CONTAINER_INVALID_ARGUMENT: return "invalid argument";
    case ZCSR_EDITOR_CONTAINER_OPEN_FAILED: return "open failed";
    case ZCSR_EDITOR_CONTAINER_BAD_HEADER: return "bad header";
    case ZCSR_EDITOR_CONTAINER_IO_ERROR: return "io error";
    default: return "unknown";
    }
}
