#include "editor_scene_authoring.h"

#include <math.h>
#include <string.h>

static zcsr_editor_scene_change no_change(void) {
    zcsr_editor_scene_change change;
    change.changed = false;
    change.id = 0;
    return change;
}

static zcsr_editor_scene_change changed_id(zcsr_entity_id id) {
    zcsr_editor_scene_change change;
    change.changed = id != 0;
    change.id = id;
    return change;
}

static bool finite_box(float x, float z, float w, float h,
                       float r, float g, float b) {
    return isfinite(x) && isfinite(z) && isfinite(w) && isfinite(h) &&
           isfinite(r) && isfinite(g) && isfinite(b);
}

zcsr_editor_scene_change zcsr_editor_scene_add_box(zcsr_scene *scene,
                                                   float x, float z,
                                                   float w, float h,
                                                   float r, float g, float b) {
    zcsr_scene_entity e;
    zcsr_entity_id id;
    if (!scene || !finite_box(x, z, w, h, r, g, b)) return no_change();

    memset(&e, 0, sizeof(e));
    e.x = x;
    e.y = 0.0f;
    e.z = z;
    e.w = w;
    e.h = h;
    e.rotation_deg = 0.0f;
    e.pivot_x = 0.5f;
    e.pivot_y = 0.5f;
    e.layer = 0;
    e.order = (int)scene->count;
    e.tint_r = r;
    e.tint_g = g;
    e.tint_b = b;
    e.tint_a = 1.0f;
    e.visible = true;

    id = zcsr_scene_add(scene, &e);
    return changed_id(id);
}

zcsr_editor_scene_change zcsr_editor_scene_add_asset(zcsr_scene *scene,
                                                     float x, float z,
                                                     float w, float h,
                                                     uint32_t kind,
                                                     uint64_t prefab_id,
                                                     uint64_t asset_id) {
    zcsr_scene_entity e;
    zcsr_entity_id id;
    if (!scene || !isfinite(x) || !isfinite(z) || !isfinite(w) || !isfinite(h) ||
        w < 0.0f || h < 0.0f ||
        (kind != ZCSR_SCENE_KIND_SPRITE && kind != ZCSR_SCENE_KIND_PREFAB))
        return no_change();
    memset(&e, 0, sizeof(e));
    e.x = x;
    e.z = z;
    e.w = w;
    e.h = h;
    e.pivot_x = 0.5f;
    e.pivot_y = 0.5f;
    e.order = (int)scene->count;
    e.tint_r = 1.0f;
    e.tint_g = 1.0f;
    e.tint_b = 1.0f;
    e.tint_a = 1.0f;
    e.visible = true;
    e.kind = kind;
    e.prefab_id = prefab_id;
    e.asset_id = asset_id;
    id = zcsr_scene_add(scene, &e);
    return changed_id(id);
}

bool zcsr_editor_scene_set_rotation(zcsr_scene *scene, zcsr_entity_id id,
                                    float rotation_deg) {
    zcsr_scene_entity *e;
    zcsr_scene_point q[4];
    float delta;
    if (!scene || id == 0 || !isfinite(rotation_deg)) return false;
    e = zcsr_scene_get(scene, id);
    if (!e) return false;
    delta = rotation_deg - e->rotation_deg;
    if (zcsr_scene_has_quad(scene, id) && isfinite(delta) &&
        zcsr_scene_entity_quad(scene, id, q)) {
        float radians = delta * 3.14159265358979323846f / 180.0f;
        float c = cosf(radians), s = sinf(radians);
        for (int i = 0; i < 4; ++i) {
            float dx = q[i].x - e->x;
            float dz = q[i].z - e->z;
            q[i].x = e->x + dx * c - dz * s;
            q[i].z = e->z + dx * s + dz * c;
            if (!isfinite(q[i].x) || !isfinite(q[i].z)) return false;
        }
        if (!zcsr_scene_set_quad(scene, id, q)) return false;
    }
    e->rotation_deg = rotation_deg;
    return true;
}

bool zcsr_editor_scene_set_size(zcsr_scene *scene, zcsr_entity_id id,
                                float w, float h) {
    zcsr_scene_entity *e;
    zcsr_scene_point q[4];
    float old_w, old_h;
    if (!scene || id == 0 || !isfinite(w) || !isfinite(h) || w < 0.0f || h < 0.0f)
        return false;
    e = zcsr_scene_get(scene, id);
    if (!e) return false;
    old_w = e->w;
    old_h = e->h;
    if (zcsr_scene_has_quad(scene, id) && old_w > 0.0f && old_h > 0.0f &&
        zcsr_scene_entity_quad(scene, id, q)) {
        float fx = w / old_w;
        float fz = h / old_h;
        for (int i = 0; i < 4; ++i) {
            q[i].x = e->x + (q[i].x - e->x) * fx;
            q[i].z = e->z + (q[i].z - e->z) * fz;
            if (!isfinite(q[i].x) || !isfinite(q[i].z)) return false;
        }
        if (!zcsr_scene_set_quad(scene, id, q)) return false;
    }
    e->w = w;
    e->h = h;
    return true;
}

bool zcsr_editor_scene_set_asset_ref(zcsr_scene *scene, zcsr_entity_id id,
                                     uint32_t kind, uint64_t prefab_id,
                                     uint64_t asset_id) {
    zcsr_scene_entity *e;
    if (!scene || id == 0 ||
        (kind != ZCSR_SCENE_KIND_RECT && kind != ZCSR_SCENE_KIND_SPRITE &&
         kind != ZCSR_SCENE_KIND_PREFAB && kind != ZCSR_SCENE_KIND_LIGHT))
        return false;
    e = zcsr_scene_get(scene, id);
    if (!e) return false;
    e->kind = kind;
    e->prefab_id = prefab_id;
    e->asset_id = asset_id;
    return true;
}

zcsr_editor_scene_change zcsr_editor_scene_add_quad(zcsr_scene *scene,
                                                    float x, float z,
                                                    float size,
                                                    float r, float g, float b) {
    zcsr_editor_scene_change change;
    zcsr_scene_point corners[4];

    if (!scene || !isfinite(size) || size <= 0.0f ||
        !finite_box(x, z, size, size, r, g, b))
        return no_change();

    change = zcsr_editor_scene_add_box(scene, x, z, size, size, r, g, b);
    if (!change.changed) return change;

    corners[0].x = x - size * 0.5f;
    corners[0].y = 0.0f;
    corners[0].z = z - size * 0.5f;
    corners[1].x = x + size * 0.75f;
    corners[1].y = 0.0f;
    corners[1].z = z - size * 0.40f;
    corners[2].x = x + size * 0.50f;
    corners[2].y = 0.0f;
    corners[2].z = z + size * 0.65f;
    corners[3].x = x - size * 0.80f;
    corners[3].y = 0.0f;
    corners[3].z = z + size * 0.35f;

    if (!zcsr_scene_set_quad(scene, change.id, corners)) {
        (void)zcsr_scene_remove(scene, change.id);
        return no_change();
    }
    return change;
}

zcsr_editor_scene_change zcsr_editor_scene_duplicate(zcsr_scene *scene,
                                                     zcsr_entity_id id,
                                                     float dx, float dz) {
    const zcsr_scene_entity *src;
    zcsr_scene_entity copy;
    zcsr_entity_id made;
    zcsr_scene_point q[4];
    bool has_quad;

    if (!scene || id == 0 || !isfinite(dx) || !isfinite(dz)) return no_change();
    src = zcsr_scene_get_const(scene, id);
    if (!src) return no_change();

    has_quad = zcsr_scene_has_quad(scene, id);
    if (has_quad && !zcsr_scene_entity_quad(scene, id, q)) return no_change();
    if (has_quad) {
        size_t i;
        for (i = 0; i < 4; ++i) {
            q[i].x += dx;
            q[i].z += dz;
            if (!isfinite(q[i].x) || !isfinite(q[i].z)) return no_change();
        }
    }

    copy = *src;
    copy.id = 0;
    copy.x += dx;
    copy.z += dz;
    copy.order = (int)scene->count;
    if (!isfinite(copy.x) || !isfinite(copy.z)) return no_change();

    made = zcsr_scene_add(scene, &copy);
    if (!made) return no_change();

    if (has_quad && !zcsr_scene_set_quad(scene, made, q)) {
        (void)zcsr_scene_remove(scene, made);
        return no_change();
    }
    return changed_id(made);
}

zcsr_editor_scene_change zcsr_editor_scene_delete(zcsr_scene *scene,
                                                  zcsr_entity_id id) {
    if (!scene || id == 0) return no_change();
    if (!zcsr_scene_remove(scene, id)) return no_change();
    {
        zcsr_editor_scene_change change;
        change.changed = true;
        change.id = 0;
        return change;
    }
}

bool zcsr_editor_scene_move(zcsr_scene *scene, zcsr_entity_id id,
                            float dx, float dz) {
    zcsr_scene_entity *e;
    zcsr_scene_point q[4];
    bool has_quad;
    float nx, nz;

    if (!scene || id == 0 || !isfinite(dx) || !isfinite(dz)) return false;
    e = zcsr_scene_get(scene, id);
    if (!e) return false;

    nx = e->x + dx;
    nz = e->z + dz;
    if (!isfinite(nx) || !isfinite(nz)) return false;

    has_quad = zcsr_scene_has_quad(scene, id);
    if (has_quad) {
        size_t i;
        if (!zcsr_scene_entity_quad(scene, id, q)) return false;
        for (i = 0; i < 4; ++i) {
            q[i].x += dx;
            q[i].z += dz;
            if (!isfinite(q[i].x) || !isfinite(q[i].z)) return false;
        }
        if (!zcsr_scene_set_quad(scene, id, q)) return false;
    }

    e->x = nx;
    e->z = nz;
    return true;
}

bool zcsr_editor_scene_set_y(zcsr_scene *scene, zcsr_entity_id id, float y) {
    zcsr_scene_entity *e;
    zcsr_scene_point q[4];
    bool has_quad;
    float dy;

    if (!scene || id == 0 || !isfinite(y)) return false;
    e = zcsr_scene_get(scene, id);
    if (!e) return false;
    dy = y - e->y;

    has_quad = zcsr_scene_has_quad(scene, id);
    if (has_quad) {
        size_t i;
        if (!zcsr_scene_entity_quad(scene, id, q)) return false;
        for (i = 0; i < 4; ++i) {
            q[i].y += dy;
            if (!isfinite(q[i].y)) return false;
        }
        if (!zcsr_scene_set_quad(scene, id, q)) return false;
    }

    e->y = y;
    return true;
}

bool zcsr_editor_scene_set_quad(zcsr_scene *scene, zcsr_entity_id id,
                                const zcsr_scene_point quad[4]) {
    if (!scene || id == 0 || !quad) return false;
    if (!zcsr_scene_get_const(scene, id)) return false;
    return zcsr_scene_set_quad(scene, id, quad);
}

bool zcsr_editor_scene_set_corner(zcsr_scene *scene, zcsr_entity_id id,
                                  int corner, float x, float y, float z) {
    zcsr_scene_point q[4];
    if (!scene || id == 0 || corner < 0 || corner > 3) return false;
    if (!isfinite(x) || !isfinite(y) || !isfinite(z)) return false;
    if (!zcsr_scene_entity_quad(scene, id, q)) return false;
    q[corner].x = x;
    q[corner].y = y;
    q[corner].z = z;
    return zcsr_scene_set_quad(scene, id, q);
}

bool zcsr_editor_scene_clear_quad(zcsr_scene *scene, zcsr_entity_id id) {
    if (!scene || id == 0) return false;
    return zcsr_scene_clear_quad(scene, id);
}
