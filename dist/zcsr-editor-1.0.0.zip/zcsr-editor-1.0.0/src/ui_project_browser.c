#include "ui_project_browser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PB_ROOT_MAX 512u
#define PB_DEPTH_MAX 8

struct uim_ProjectBrowser {
    const uim_FileService *fs;
    char root[PB_ROOT_MAX];
    char expanded[uim_PB_MAX_EXPANDED][uim_PB_MAX_PATH_UTF8];
    size_t expanded_count;
    uim_PBVisibleNode visible[uim_PB_MAX_VISIBLE_NODES];
    size_t visible_count;
    int selected;
    uim_PBError error;
    bool capacity_exceeded;
};

static void pb_set_error(uim_ProjectBrowser *pb, uim_PBError error)
{
    pb->error = error;
}

static void pb_copy(char *dst, size_t cap, const char *src)
{
    if (!cap) return;
    if (!src) { dst[0] = 0; return; }
    size_t n = strlen(src);
    if (n >= cap) n = cap - 1;
    memcpy(dst, src, n);
    dst[n] = 0;
}

static void pb_normalize_root(const char *src, char *dst, size_t cap)
{
    pb_copy(dst, cap, src ? src : "");
    size_t n = strlen(dst);
    while (n > 1 && (dst[n - 1] == '/' || dst[n - 1] == '\\')) {
        /* Keep drive roots such as C:/ intact. */
        if (n == 3 && dst[1] == ':') break;
        dst[--n] = 0;
    }
}

static bool pb_name_is_component(const char *name)
{
    if (!name || !name[0] || strlen(name) >= uim_PB_MAX_NAME_UTF8) return false;
    if (name[0] == '/' || name[0] == '\\') return false;
    if (strchr(name, '/') || strchr(name, '\\')) return false;
    if (strcmp(name, ".") == 0 || strcmp(name, "..") == 0) return false;
    if (strlen(name) >= 2 && name[1] == ':') return false;
    return true;
}

static bool pb_is_expanded(const uim_ProjectBrowser *pb, const char *rel)
{
    size_t i;
    for (i = 0; i < pb->expanded_count; ++i) {
        if (strcmp(pb->expanded[i], rel) == 0) return true;
    }
    return false;
}

static bool pb_join(char *out, size_t cap, const char *a, const char *b)
{
    size_t alen = a ? strlen(a) : 0;
    size_t blen = b ? strlen(b) : 0;
    bool slash = alen > 0 && a[alen - 1] != '/' && a[alen - 1] != '\\';
    if (alen + (slash ? 1u : 0u) + blen >= cap) return false;
    if (alen) memcpy(out, a, alen);
    if (slash) out[alen++] = '/';
    if (blen) memcpy(out + alen, b, blen);
    out[alen + blen] = 0;
    return true;
}

static void pb_push_visible(uim_ProjectBrowser *pb, const char *name,
                            const char *rel, int depth, bool is_dir)
{
    uim_PBVisibleNode *node;
    if (pb->visible_count >= uim_PB_MAX_VISIBLE_NODES) {
        pb->capacity_exceeded = true;
        return;
    }
    node = &pb->visible[pb->visible_count];
    memset(node, 0, sizeof(*node));
    node->index = (uint32_t)pb->visible_count;
    node->depth = depth;
    node->is_dir = is_dir;
    node->expanded = is_dir && pb_is_expanded(pb, rel);
    pb_copy(node->name, sizeof(node->name), name);
    pb_copy(node->rel_path, sizeof(node->rel_path), rel);
    pb->visible_count++;
}

typedef struct PbChild {
    char name[uim_PB_MAX_NAME_UTF8];
    bool is_dir;
} PbChild;

static int pb_child_compare(const void *a, const void *b)
{
    const PbChild *ca = (const PbChild *)a;
    const PbChild *cb = (const PbChild *)b;
    if (ca->is_dir != cb->is_dir) return ca->is_dir ? -1 : 1;
    return strcmp(ca->name, cb->name);
}

static bool pb_walk(uim_ProjectBrowser *pb, const char *native_dir,
                    const char *rel_dir, int depth)
{
    uim_DirectoryHandle dh = uim_DIRECTORY_HANDLE_INVALID;
    PbChild children[256];
    size_t child_count = 0;
    uim_FileResult rc = pb->fs->ops.directory_open(pb->fs->user, native_dir, &dh);
    if (rc != uim_FILE_OK) {
        pb_set_error(pb, rc == uim_FILE_ERR_ACCESS ? uim_PB_ERR_ACCESS_DENIED
                                                    : uim_PB_ERR_READ_FAILED);
        return false;
    }
    for (;;) {
        uim_DirectoryEntry entry;
        char name[uim_PB_MAX_NAME_UTF8];
        memset(&entry, 0, sizeof(entry));
        entry.struct_size = sizeof(entry);
        rc = pb->fs->ops.directory_next(pb->fs->user, dh, &entry, name, sizeof(name));
        if (rc == uim_FILE_END) break;
        if (rc != uim_FILE_OK) {
            (void)pb->fs->ops.directory_close(pb->fs->user, dh);
            pb_set_error(pb, uim_PB_ERR_READ_FAILED);
            return false;
        }
        if (!name[0] || strcmp(name, ".") == 0 || strcmp(name, "..") == 0) continue;
        if (child_count >= 256) { pb->capacity_exceeded = true; break; }
        pb_copy(children[child_count].name, sizeof(children[child_count].name), name);
        children[child_count].is_dir = entry.kind == uim_FILE_KIND_DIRECTORY;
        child_count++;
    }
    (void)pb->fs->ops.directory_close(pb->fs->user, dh);
    qsort(children, child_count, sizeof(children[0]), pb_child_compare);

    for (size_t i = 0; i < child_count; ++i) {
        char rel[uim_PB_MAX_PATH_UTF8];
        char native[uim_PB_MAX_PATH_UTF8 * 2];
        bool dir = children[i].is_dir;
        if (!pb_join(rel, sizeof(rel), rel_dir, children[i].name)) {
            pb->capacity_exceeded = true;
            continue;
        }
        if (!pb_join(native, sizeof(native), native_dir, children[i].name)) {
            pb->capacity_exceeded = true;
            continue;
        }
        pb_push_visible(pb, children[i].name, rel, depth, dir);
        if (dir && pb_is_expanded(pb, rel) && depth < PB_DEPTH_MAX) {
            pb_walk(pb, native, rel, depth + 1);
        }
    }
    return true;
}

static bool pb_rebuild(uim_ProjectBrowser *pb)
{
    uim_FileStat st;
    char root_name[uim_PB_MAX_NAME_UTF8];
    const char *slash;
    if (!pb->fs) { pb_set_error(pb, uim_PB_ERR_NOT_INITIALIZED); return false; }
    if (!pb->root[0]) { pb_set_error(pb, uim_PB_ERR_ROOT_NOT_FOUND); return false; }
    if (uim_file_service_validate(pb->fs) != uim_FILE_OK) {
        pb_set_error(pb, uim_PB_ERR_NOT_INITIALIZED);
        return false;
    }
    memset(&st, 0, sizeof(st));
    st.struct_size = sizeof(st);
    uim_FileResult rc = pb->fs->ops.stat_path(pb->fs->user, pb->root, &st);
    if (rc != uim_FILE_OK) {
        pb_set_error(pb, rc == uim_FILE_ERR_NOT_FOUND ? uim_PB_ERR_ROOT_NOT_FOUND
                                                       : uim_PB_ERR_ACCESS_DENIED);
        return false;
    }
    if (st.kind != uim_FILE_KIND_DIRECTORY) {
        pb_set_error(pb, uim_PB_ERR_ROOT_NOT_FOUND);
        return false;
    }
    pb->visible_count = 0;
    pb->capacity_exceeded = false;
    pb_set_error(pb, uim_PB_OK);
    slash = strrchr(pb->root, '/');
    if (!slash) slash = strrchr(pb->root, '\\');
    pb_copy(root_name, sizeof(root_name), slash ? slash + 1 : pb->root);
    if (!root_name[0]) pb_copy(root_name, sizeof(root_name), pb->root);
    pb_push_visible(pb, root_name, "", 0, true);
    pb_walk(pb, pb->root, "", 1);
    if (pb->capacity_exceeded && pb->error == uim_PB_OK) pb_set_error(pb, uim_PB_ERR_CAPACITY_EXCEEDED);
    return pb->error == uim_PB_OK || pb->error == uim_PB_ERR_CAPACITY_EXCEEDED;
}

uim_ProjectBrowser *uim_project_browser_create(void)
{
    return (uim_ProjectBrowser *)calloc(1, sizeof(uim_ProjectBrowser));
}

void uim_project_browser_destroy(uim_ProjectBrowser *pb)
{
    free(pb);
}

uim_PBError uim_project_browser_set_file_service(uim_ProjectBrowser *pb,
                                                 const uim_FileService *fs)
{
    if (!pb) return uim_PB_ERR_NOT_INITIALIZED;
    if (fs && uim_file_service_validate(fs) != uim_FILE_OK) {
        pb_set_error(pb, uim_PB_ERR_INVALID_PATH);
        return uim_PB_ERR_INVALID_PATH;
    }
    pb->fs = fs;
    pb->visible_count = 0;
    pb->selected = -1;
    pb_set_error(pb, fs ? uim_PB_OK : uim_PB_ERR_NOT_INITIALIZED);
    return pb->error;
}

uim_PBError uim_project_browser_set_root(uim_ProjectBrowser *pb, const char *utf8_root)
{
    if (!pb) return uim_PB_ERR_NOT_INITIALIZED;
    pb_normalize_root(utf8_root, pb->root, sizeof(pb->root));
    pb->visible_count = 0;
    pb->selected = -1;
    if (!pb->root[0]) {
        pb_set_error(pb, uim_PB_OK);
        return uim_PB_OK;
    }
    return uim_project_browser_refresh(pb);
}

uim_PBError uim_project_browser_refresh(uim_ProjectBrowser *pb)
{
    if (!pb) return uim_PB_ERR_NOT_INITIALIZED;
    pb_rebuild(pb);
    if (pb->selected >= (int)pb->visible_count) pb->selected = -1;
    return pb->error;
}

bool uim_project_browser_toggle_node(uim_ProjectBrowser *pb, int visible_index)
{
    const uim_PBVisibleNode *node;
    if (!pb || visible_index < 0 || visible_index >= (int)pb->visible_count) return false;
    node = &pb->visible[visible_index];
    if (!node->is_dir) return false;
    pb->selected = visible_index;
    if (pb_is_expanded(pb, node->rel_path)) {
        size_t i;
        for (i = 0; i < pb->expanded_count; ++i) {
            if (strcmp(pb->expanded[i], node->rel_path) == 0) {
                memmove(&pb->expanded[i], &pb->expanded[i + 1],
                        (pb->expanded_count - i - 1) * sizeof(pb->expanded[0]));
                pb->expanded_count--;
                break;
            }
        }
    } else {
        if (pb->expanded_count >= uim_PB_MAX_EXPANDED) {
            pb_set_error(pb, uim_PB_ERR_CAPACITY_EXCEEDED);
            return false;
        }
        pb_copy(pb->expanded[pb->expanded_count++], uim_PB_MAX_PATH_UTF8, node->rel_path);
    }
    pb_rebuild(pb);
    return true;
}

void uim_project_browser_select(uim_ProjectBrowser *pb, int visible_index)
{
    if (!pb || visible_index < 0 || visible_index >= (int)pb->visible_count) return;
    pb->selected = visible_index;
}

uim_PBError uim_project_browser_create_dir(uim_ProjectBrowser *pb, const char *name)
{
    char native[PB_ROOT_MAX + uim_PB_MAX_NAME_UTF8];
    if (!pb || !pb->fs) return uim_PB_ERR_NOT_INITIALIZED;
    if (!pb->root[0]) return uim_PB_ERR_ROOT_NOT_FOUND;
    if (!pb_name_is_component(name)) { pb_set_error(pb, uim_PB_ERR_INVALID_PATH); return pb->error; }
    if (!pb_join(native, sizeof(native), pb->root, name)) {
        pb_set_error(pb, uim_PB_ERR_INVALID_PATH);
        return pb->error;
    }
    uim_FileResult rc = pb->fs->ops.create_directory(pb->fs->user, native);
    pb_set_error(pb, rc == uim_FILE_OK ? uim_PB_OK : uim_PB_ERR_OPERATION_FAILED);
    if (rc == uim_FILE_OK) uim_project_browser_refresh(pb);
    return pb->error;
}

static void pb_parent_rel(const char *rel, char *out, size_t cap)
{
    const char *slash;
    size_t n;
    if (!out || cap == 0) return;
    out[0] = 0;
    if (!rel || !rel[0]) return;
    slash = strrchr(rel, '/');
    if (!slash) slash = strrchr(rel, '\\');
    if (!slash) return;
    n = (size_t)(slash - rel);
    if (n >= cap) return;
    memcpy(out, rel, n);
    out[n] = 0;
}

uim_PBError uim_project_browser_create_dir_in_selected(uim_ProjectBrowser *pb, const char *name)
{
    char parent[PB_ROOT_MAX + uim_PB_MAX_PATH_UTF8];
    char rel[PB_ROOT_MAX + uim_PB_MAX_PATH_UTF8];
    char native[PB_ROOT_MAX + uim_PB_MAX_PATH_UTF8];
    if (!pb || !pb->fs) return uim_PB_ERR_NOT_INITIALIZED;
    if (!pb->root[0]) return uim_PB_ERR_ROOT_NOT_FOUND;
    if (!pb_name_is_component(name)) { pb_set_error(pb, uim_PB_ERR_INVALID_PATH); return pb->error; }
    if (pb->selected < 0 || pb->selected >= (int)pb->visible_count) {
        return uim_project_browser_create_dir(pb, name);
    }
    const uim_PBVisibleNode *node = &pb->visible[pb->selected];
    if (!node->rel_path[0]) {
        /* The root row is selected: create directly below it. */
        return uim_project_browser_create_dir(pb, name);
    }
    if (node->is_dir) {
        pb_copy(parent, sizeof(parent), node->rel_path);
    } else {
        pb_parent_rel(node->rel_path, parent, sizeof(parent));
    }
    if (!pb_join(rel, sizeof(rel), parent, name) ||
        !pb_join(native, sizeof(native), pb->root, rel)) {
        pb_set_error(pb, uim_PB_ERR_INVALID_PATH);
        return pb->error;
    }
    uim_FileResult rc = pb->fs->ops.create_directory(pb->fs->user, native);
    pb_set_error(pb, rc == uim_FILE_OK ? uim_PB_OK : uim_PB_ERR_OPERATION_FAILED);
    if (rc == uim_FILE_OK) uim_project_browser_refresh(pb);
    return pb->error;
}

uim_PBError uim_project_browser_rename_selected(uim_ProjectBrowser *pb, const char *new_name)
{
    char from[PB_ROOT_MAX + uim_PB_MAX_PATH_UTF8];
    char to[PB_ROOT_MAX + uim_PB_MAX_PATH_UTF8];
    char parent[PB_ROOT_MAX + uim_PB_MAX_PATH_UTF8];
    const char *rel;
    const char *slash;
    if (!pb || !pb->fs) return uim_PB_ERR_NOT_INITIALIZED;
    if (pb->selected < 0 || pb->selected >= (int)pb->visible_count) {
        pb_set_error(pb, uim_PB_ERR_NO_SELECTION);
        return pb->error;
    }
    if (!pb_name_is_component(new_name)) { pb_set_error(pb, uim_PB_ERR_INVALID_PATH); return pb->error; }
    rel = pb->visible[pb->selected].rel_path;
    if (!rel[0]) { pb_set_error(pb, uim_PB_ERR_OPERATION_FAILED); return pb->error; }
    /* Rename in place, not into the root. The old implementation joined the
     * root and the new name directly, so renaming a nested node silently moved
     * it to the top level. */
    slash = strrchr(rel, '/');
    if (!slash) slash = strrchr(rel, '\\');
    pb_copy(parent, sizeof(parent), "");
    if (slash) {
        size_t parent_len = (size_t)(slash - rel);
        if (parent_len >= sizeof(parent)) {
            pb_set_error(pb, uim_PB_ERR_INVALID_PATH);
            return pb->error;
        }
        memcpy(parent, rel, parent_len);
        parent[parent_len] = 0;
    }
    if (!pb_join(from, sizeof(from), pb->root, rel) ||
        !pb_join(to, sizeof(to), pb->root, parent) ||
        !pb_join(to, sizeof(to), to, new_name)) {
        pb_set_error(pb, uim_PB_ERR_INVALID_PATH);
        return pb->error;
    }
    uim_FileResult rc = pb->fs->ops.rename_path(pb->fs->user, from, to);
    pb_set_error(pb, rc == uim_FILE_OK ? uim_PB_OK : uim_PB_ERR_OPERATION_FAILED);
    if (rc != uim_FILE_OK) return pb->error;
    /* Expanded path keys are relative to the old name. Rebuild from a clean
     * expansion set so the tree cannot retain a stale key. */
    pb->expanded_count = 0;
    pb->selected = -1;
    uim_project_browser_refresh(pb);
    return pb->error;
}

uim_PBError uim_project_browser_remove_selected(uim_ProjectBrowser *pb)
{
    char native[PB_ROOT_MAX + uim_PB_MAX_PATH_UTF8];
    const uim_PBVisibleNode *node;
    uim_FileResult rc;
    if (!pb || !pb->fs) return uim_PB_ERR_NOT_INITIALIZED;
    if (pb->selected < 0 || pb->selected >= (int)pb->visible_count) {
        pb_set_error(pb, uim_PB_ERR_NO_SELECTION);
        return pb->error;
    }
    node = &pb->visible[pb->selected];
    if (!node->rel_path[0]) { pb_set_error(pb, uim_PB_ERR_OPERATION_FAILED); return pb->error; }
    if (!pb_join(native, sizeof(native), pb->root, node->rel_path)) {
        pb_set_error(pb, uim_PB_ERR_INVALID_PATH);
        return pb->error;
    }
    rc = node->is_dir ? pb->fs->ops.remove_directory(pb->fs->user, native)
                      : pb->fs->ops.remove_file(pb->fs->user, native);
    pb_set_error(pb, rc == uim_FILE_OK ? uim_PB_OK : uim_PB_ERR_OPERATION_FAILED);
    if (rc == uim_FILE_OK) {
        pb->selected = -1;
        uim_project_browser_refresh(pb);
    }
    return pb->error;
}

int uim_project_browser_visible_count(const uim_ProjectBrowser *pb)
{
    return pb ? (int)pb->visible_count : 0;
}

uim_PBError uim_project_browser_get_node(const uim_ProjectBrowser *pb,
                                          int visible_index,
                                          uim_PBVisibleNode *out_node)
{
    if (!pb || !out_node || visible_index < 0 || visible_index >= (int)pb->visible_count) {
        return uim_PB_ERR_INVALID_INDEX;
    }
    *out_node = pb->visible[visible_index];
    out_node->selected = visible_index == pb->selected;
    return uim_PB_OK;
}

uim_PBError uim_project_browser_get_error(const uim_ProjectBrowser *pb)
{
    return pb ? pb->error : uim_PB_ERR_NOT_INITIALIZED;
}

bool uim_project_browser_capacity_exceeded(const uim_ProjectBrowser *pb)
{
    return pb && pb->capacity_exceeded;
}

const char *uim_project_browser_root_path(const uim_ProjectBrowser *pb)
{
    return pb ? pb->root : "";
}

int uim_project_browser_selected_index(const uim_ProjectBrowser *pb)
{
    return pb ? pb->selected : -1;
}
