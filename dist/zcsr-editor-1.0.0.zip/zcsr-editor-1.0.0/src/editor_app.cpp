﻿/*
 * ZCSR Editor product chrome.
 *
 * Responsibilities kept here are only editor responsibilities:
 *   - Dear ImGui chrome and docking
 *   - canvas viewport, picking, gestures and overlay presentation
 *   - Inspector presentation over UIM ComponentRegistry descriptors
 *   - project file dialogs and .uireproj / build / play commands
 *
 * Document storage, component types, component runtime and page semantics stay
 * in UIM; rendering, input, files and textures stay in ZCSR. This file must not
 * create a second OS window, main loop, document model or component runtime.
 */
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_opengl3.h"

#include "ui_editor.h"
#include "uim_component_registry.h"
#include "uim_project.h"
#include "uim_asset_registry.h"

extern "C" {
#include "uim_component_runtime.h"
#include "uim_zcsr_runtime_bridge.h"
#include "zcsr_runtime_shell.h"
#include "zcsr/platform.h"
#include "zcsr/gl_render.h"
#include "zcsr/input.h"
#include "zcsr/camera3d.h"
}

#if !defined(_WIN32)
#error "zcsr_editor is Windows-only: Win32 file dialogs (commdlg.h) and GL/gl.h are part of its current host contract."
#endif

#define NOMINMAX
#include <windows.h>
#include <commdlg.h>
#include <GL/gl.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <map>
#include <string>
#include <vector>

extern "C" bool zcsr_page_render(zcsr_gl_renderer *renderer,
                                 const UIM_ComponentManager *manager,
                                 uim_PageId page,
                                 int view_x, int view_y,
                                 int view_w, int view_h,
                                 const char *project_root);

namespace {

namespace fs = std::filesystem;

static bool project_3d_node(void *user, const UIM_ComponentManager *manager,
                            const uim_NodeInfo *info, uim_Rect *out_rect) {
    (void)user;
    return uim_zcsr_runtime_bridge_project_node_rect(manager, info, out_rect);
}

struct EditorApp {
    UIM_ComponentManager *manager = nullptr;
    uim_Editor *editor = nullptr;
    uim_ComponentRegistry *registry = nullptr;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = uim_NODE_INVALID;
    std::string project_path;
    bool dirty = false;
    bool playing = false;
    bool play_first_logged = false;
    double play_start_ms = 0.0;
    bool first_layout = true;
    bool show_console = true;
    bool show_hierarchy = true;
    bool show_inspector = true;
    bool show_viewport = true;

    zcsr_gl_renderer *renderer = nullptr;
    int window_w = 0, window_h = 0;
    zcsr_gl_texture page_texture = 0;
    int texture_w = 0, texture_h = 0;
    UIM_ComponentManager *texture_manager = nullptr;
    uim_PageId texture_page = uim_PAGE_INVALID;

    float zoom = 1.0f;
    float pan_x = 0.0f, pan_y = 0.0f;
    bool viewport_initialized = false;
    bool auto_fit = true;
    float last_view_w = 0.0f, last_view_h = 0.0f;
    char component_filter[64] = {0};
    bool component_picker_open = false;
    bool confirm_delete_page = false;

    bool dragging = false;
    bool panning = false;
    bool gizmo_dragging = false;
    int gizmo_axis = -1;
    ImVec2 gizmo_start{0, 0};
    uim_NodeId gizmo_nodes[16]{};
    uim_Transform3 gizmo_orig[16]{};
    size_t gizmo_count = 0;
    size_t drag_undo_before = 0;
    ImVec2 drag_prev{0, 0};
    uint32_t drag_mods = 0;

    uim_ComponentInstanceId selected_instance = 0;
    uim_NodeId rename_node = 0;
    bool rename_open = false;
    bool rename_focus = false;
    char rename_buf[128]{};
    std::vector<std::string> log;
    std::map<uint64_t, std::array<char, 512>> text_buffers;

    // Input collected by shell callbacks.
    float mouse_x = 0.0f, mouse_y = 0.0f;
    uint32_t mouse_buttons = 0;
    uint32_t mouse_pressed = 0, mouse_released = 0;

    int wheel_delta = 0;
    std::string text_input;
    std::vector<int> keys;
    // Keys sent down to ImGui this frame; released at the start of the next
    // frame so ImGui observes a real down edge instead of down+up in one queue.
    std::vector<ImGuiKey> imgui_keys_down;
};

EditorApp g;
uint64_t g_node_serial = 1;
double g_last_time = 0.0;

void log_line(const std::string &s) {
    g.log.push_back(s);
    if (g.log.size() > 64) g.log.erase(g.log.begin());
}

std::string narrow(const wchar_t *w) {
    if (!w) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr);
    if (n <= 0) return {};
    std::string s((size_t)n - 1, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w, -1, s.data(), n, nullptr, nullptr);
    return s;
}

std::string narrow(const std::wstring &w) { return narrow(w.c_str()); }

std::wstring widen(const std::string &s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
    if (n <= 0) return {};
    std::wstring w((size_t)n - 1, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, w.data(), n);
    return w;
}

std::string exe_path() {
    wchar_t buf[MAX_PATH]{};
    DWORD n = GetModuleFileNameW(nullptr, buf, MAX_PATH);
    if (!n) return {};
    return narrow(std::wstring(buf, buf + n));
}

std::string open_dialog(HWND owner) {
    wchar_t file[MAX_PATH]{};
    OPENFILENAMEW ofn{};
    ofn.hwndOwner = owner;
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFilter = L"ZCSR UI Project (*.uireproj)\0*.uireproj\0All Files\0*.*\0";
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrDefExt = L"uireproj";
    if (!GetOpenFileNameW(&ofn)) return {};
    return narrow(file);
}

std::string save_dialog(HWND owner, const std::string &suggested) {
    wchar_t file[MAX_PATH]{};
    std::wstring init = widen(suggested);
    if (!init.empty()) wcsncpy(file, init.c_str(), MAX_PATH - 1);
    OPENFILENAMEW ofn{};
    ofn.hwndOwner = owner;
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFilter = L"ZCSR UI Project (*.uireproj)\0*.uireproj\0All Files\0*.*\0";
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrDefExt = L"uireproj";
    if (!GetSaveFileNameW(&ofn)) return {};
    return narrow(file);
}

uim_NodeId page_root(UIM_ComponentManager *m, uim_PageId page) {
    if (!m || page == uim_PAGE_INVALID) return uim_NODE_INVALID;
    size_t count = 0;
    if (uim_page_get_node_count(m, page, &count) != uim_OK) return uim_NODE_INVALID;
    for (size_t i = 0; i < count; ++i) {
        uim_NodeInfo n{};
        if (uim_page_get_node_at(m, page, i, &n) == uim_OK && n.parent_id == 0) return n.id;
    }
    return uim_NODE_INVALID;
}

bool node_key_exists(const std::string &key) {
    if (!g.manager || g.page == uim_PAGE_INVALID) return false;
    uim_NodeId id = 0;
    return uim_node_find_stable_key(g.manager, g.page, key.c_str(), &id) == uim_OK;
}

std::string make_node_key() {
    for (;;) {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "node_%llu", (unsigned long long)g_node_serial++);
        if (!node_key_exists(buf)) return buf;
    }
}

void destroy_document() {
    if (g.playing) {
        uim_runtime_end();
        g.playing = false;
    }
    if (g.page_texture && g.renderer) {
        zcsr_gl_texture_destroy(g.renderer, g.page_texture);
    }
    g.page_texture = 0;
    g.texture_w = g.texture_h = 0;
    g.texture_manager = nullptr;
    g.texture_page = uim_PAGE_INVALID;
    if (g.editor) uir_editor_destroy(g.editor);
    g.editor = nullptr;
    if (g.manager) uim_component_manager_destroy(g.manager);
    g.manager = nullptr;
    if (g.registry) uim_component_registry_destroy(g.registry);
    g.registry = nullptr;
    g.page = uim_PAGE_INVALID;
    g.root = uim_NODE_INVALID;
    g.selected_instance = 0;
    g.text_buffers.clear();
    g.viewport_initialized = false;
    g.auto_fit = true;
}

bool create_editor_shell() {
    if (!g.manager) return false;
    uim_ComponentRegistryConfig cfg{};
    cfg.initial_type_capacity = 32;
    if (uim_component_registry_create(&cfg, &g.registry) != uim_OK) return false;
    if (uim_component_registry_register_builtins(g.registry) != uim_OK) return false;
    if (uir_editor_create(g.manager, 256, &g.editor) != uim_OK) return false;
    if (g.page != uim_PAGE_INVALID) {
        uir_editor_set_active_page(g.editor, g.page);
        g.root = page_root(g.manager, g.page);
    }
    return true;
}

bool attach_component(uim_NodeId node, uim_ComponentTypeId type, uim_ComponentInstanceId *out = nullptr) {
    if (!g.manager || !g.registry || !g.editor) return false;
    uim_ComponentInstanceId instance = 0;
    uim_Result rc = uir_editor_component_attach_registered(g.editor, g.registry, node, type, &instance);
    if (rc == uim_ERR_EXISTS) {
        log_line("component already exists on this node");
        if (out) *out = 0;
        return false;
    }
    if (rc != uim_OK) {
        log_line("component attach failed: " + std::to_string((int)rc));
        return false;
    }
    if (out) *out = instance;
    g.selected_instance = instance;
    g.dirty = true;
    return true;
}

/* A singleton component is already present on this node. Used by the picker
 * to explain the no-op instead of presenting a failed attach. */
bool node_has_singleton_type(uim_NodeId node, uim_ComponentTypeId type) {
    if (!g.manager || !node || !type) return false;
    size_t count = 0;
    if (uim_node_component_count(g.manager, node, &count) != uim_OK) return false;
    for (size_t i = 0; i < count; ++i) {
        uim_ComponentInstanceInfo info{};
        if (uim_node_component_get_at(g.manager, node, i, &info) != uim_OK) continue;
        if (info.type_id == type) return true;
    }
    return false;
}

uim_NodeId create_node(const std::string &key, uim_NodeId parent, uim_Rect rect,
                       uim_ComponentTypeId component = 0) {
    if (!g.editor || g.page == uim_PAGE_INVALID) return uim_NODE_INVALID;
    std::string stable = key.empty() ? make_node_key() : key;
    if (node_key_exists(stable)) stable = make_node_key();
    uim_NodeDesc desc{};
    desc.page_id = g.page;
    desc.parent_id = parent;
    desc.stable_key = stable.c_str();
    desc.local_rect = rect;
    desc.visible = true;
    desc.enabled = true;
    desc.space = uim_SPACE_2D;
    desc.transform.scale[0] = desc.transform.scale[1] = desc.transform.scale[2] = 1.0f;
    uim_NodeId id = 0;
    uim_Result rc = uir_editor_create_node(g.editor, &desc, &id);
    if (rc != uim_OK) {
        log_line("create node failed: " + std::to_string((int)rc));
        return uim_NODE_INVALID;
    }
    if (component) attach_component(id, component);
    g.dirty = true;
    return id;
}

uim_NodeId create_3d_node(uim_NodeId parent) {
    if (!g.editor || g.page == uim_PAGE_INVALID) return uim_NODE_INVALID;
    std::string stable = make_node_key();
    uim_NodeDesc desc{};
    desc.page_id = g.page;
    desc.parent_id = parent;
    desc.stable_key = stable.c_str();
    desc.local_rect = {0, 0, 160, 80};
    desc.visible = true;
    desc.enabled = true;
    desc.space = uim_SPACE_3D;
    desc.transform.position[2] = 60.0f;
    desc.transform.scale[0] = desc.transform.scale[1] = desc.transform.scale[2] = 1.0f;
    uim_NodeId id = 0;
    uim_Result rc = uir_editor_create_node(g.editor, &desc, &id);
    if (rc != uim_OK) {
        log_line("create 3D node failed: " + std::to_string((int)rc));
        return uim_NODE_INVALID;
    }
    (void)attach_component(id, uim_COMPONENT_PANEL);
    std::vector<uim_NodeId> sel{id};
    uir_editor_select(g.editor, sel.data(), 1);
    g.dirty = true;
    return id;
}

bool new_document() {
    destroy_document();
    UIM_ComponentManagerConfig cfg{};
    cfg.initial_page_capacity = 4;
    cfg.initial_node_capacity = 64;
    if (uim_component_manager_create(&cfg, &g.manager) != uim_OK) return false;
    if (uim_page_create(g.manager, "screen", &g.page) != uim_OK) return false;
    if (!create_editor_shell()) return false;
    g.root = create_node("screen", 0, {0, 0, 960, 600}, uim_COMPONENT_PANEL);
    if (!g.root) return false;
    std::vector<uim_NodeId> sel{g.root};
    uir_editor_select(g.editor, sel.data(), 1);
    g.project_path.clear();
    g.dirty = true;
    g.viewport_initialized = false;
    g.auto_fit = true;
    log_line("new project");
    return true;
}

bool load_project(const std::string &path) {
    UIM_ComponentManager *manager = nullptr;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = 0;
    char root_path[UIR_PROJECT_PATH_CAP]{};
    char name[UIR_PROJECT_NAME_CAP]{};
    if (uir_project_load(path.c_str(), &manager, &page, &root, root_path, sizeof(root_path),
                         name, sizeof(name)) != uim_OK) {
        log_line("open failed: " + path);
        return false;
    }
    destroy_document();
    g.manager = manager;
    g.page = page;
    if (!create_editor_shell()) {
        destroy_document();
        return false;
    }
    g.root = root ? root : page_root(g.manager, g.page);
    g.project_path = path;
    g.dirty = false;
    g.viewport_initialized = false;
    g.auto_fit = true;
    std::vector<uim_NodeId> sel{g.root};
    if (g.root) uir_editor_select(g.editor, sel.data(), 1);
    log_line("opened " + path);
    return true;
}

bool save_project(bool save_as) {
    if (!g.manager || g.page == uim_PAGE_INVALID) return false;
    std::string path = g.project_path;
    if (save_as || path.empty()) {
        HWND owner = (HWND)zcsr_surface_native_handle(zcsr_runtime_shell_surface());
        path = save_dialog(owner, path.empty() ? "project.uireproj" : fs::path(path).filename().string());
    }
    if (path.empty()) return false;
    if (uir_project_save(g.manager, &g.page, 1, path.c_str()) != uim_OK) {
        log_line("save failed: " + path);
        return false;
    }
    g.project_path = path;
    g.dirty = false;
    log_line("saved " + path);
    return true;
}

bool build_package() {
    if (g.project_path.empty() && !save_project(false)) return false;
    if (g.dirty && !save_project(false)) return false;
    char package[UIR_PROJECT_PATH_CAP]{};
    char project[UIR_PROJECT_PATH_CAP]{};
    char player[UIR_PROJECT_PATH_CAP]{};
    std::string output_root = fs::path(g.project_path).parent_path().string();
    fs::path player_exe = fs::path(exe_path()).replace_filename("zcsr_player.exe");
    if (!fs::exists(player_exe)) {
        log_line("build failed: missing " + player_exe.string());
        return false;
    }
    std::string player_source = player_exe.string();
    uim_Result rc = uir_project_build_package(g.project_path.c_str(), player_source.c_str(),
                                              output_root.c_str(), output_root.c_str(),
                                              nullptr, package, sizeof(package),
                                              project, sizeof(project), player, sizeof(player));
    if (rc != uim_OK) {
        log_line("build failed: " + std::to_string((int)rc));
        return false;
    }
    log_line(std::string("built ") + package);
    return true;
}

void start_play() {
    if (!g.manager || g.page == uim_PAGE_INVALID || g.playing) return;
    g.play_start_ms = (double)GetTickCount64();
    g.play_first_logged = false;
    if (!uim_runtime_begin(g.manager, g.page)) {
        log_line("play failed");
        return;
    }
    g.playing = true;
    log_line("play");
}

void stop_play() {
    if (!g.playing) return;
    uim_runtime_end();
    g.playing = false;
    log_line("stop");
}

void ensure_texture(int w, int h) {
    if (!g.renderer || !g.manager || g.page == uim_PAGE_INVALID || !g.root) return;
    if (g.page_texture && g.texture_w == w && g.texture_h == h &&
        g.texture_manager == g.manager && g.texture_page == g.page) return;
    if (g.page_texture) zcsr_gl_texture_destroy(g.renderer, g.page_texture);
    g.page_texture = 0;
    std::vector<unsigned char> pixels((size_t)w * (size_t)h * 4u, 0);
    g.page_texture = zcsr_gl_texture_create(g.renderer, pixels.data(), w, h);
    g.texture_w = w;
    g.texture_h = h;
    g.texture_manager = g.manager;
    g.texture_page = g.page;
    if (g.page_texture) zcsr_gl_texture_filter(g.renderer, g.page_texture, false);
}

void render_page_to_texture() {
    if (!g.renderer || !g.manager || !g.root || g.page == uim_PAGE_INVALID) return;
    uim_NodeInfo root_info{};
    if (uim_node_get(g.manager, g.root, &root_info) != uim_OK) return;
    int w = (int)std::lround(root_info.local_rect.width);
    int h = (int)std::lround(root_info.local_rect.height);
    if (w < 16) w = 960;
    if (h < 16) h = 600;
    w = std::clamp(w, 64, 3840);
    h = std::clamp(h, 64, 2160);
    ensure_texture(w, h);
    if (!g.page_texture) return;
    zcsr_gl_set_target(g.renderer, g.page_texture);
    glViewport(0, 0, w, h);
    glClearColor(0.07f, 0.08f, 0.10f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    zcsr_page_render(g.renderer, g.manager, g.page, 0, 0, w, h,
                     g.project_path.empty()
                         ? nullptr
                         : fs::path(g.project_path).parent_path().string().c_str());
    // The page commands are queued in the renderer. Flush them while the FBO is
    // still bound; otherwise the shell flushes them to the default framebuffer
    // after ImGui and the page texture paint covers the editor chrome.
    zcsr_gl_flush(g.renderer);
    zcsr_gl_set_target(g.renderer, 0);
    glViewport(0, 0, g.window_w, g.window_h);
}

void draw_overlay(ImDrawList *draw, const ImVec2 &clip_min, const ImVec2 &clip_max) {
    if (!g.editor || g.page == uim_PAGE_INVALID) return;
    size_t count = 0;
    if (uir_editor_build_overlay(g.editor, g.page, nullptr, 0, &count) != uim_OK || !count) return;
    std::vector<uim_EditorOverlayCommand> cmds(count);
    if (uir_editor_build_overlay(g.editor, g.page, cmds.data(), cmds.size(), &count) != uim_OK) return;
    for (size_t i = 0; i < count; ++i) {
        const auto &c = cmds[i];
        ImU32 col = IM_COL32(120, 160, 220, 120);
        if (c.type == uim_EDITOR_OVERLAY_SELECTED_BOUNDS) col = IM_COL32(255, 190, 70, 255);
        if (c.type == uim_EDITOR_OVERLAY_FOCUS_BOUNDS) col = IM_COL32(100, 220, 255, 180);
        if (c.type == uim_EDITOR_OVERLAY_RESIZE_HANDLE) col = IM_COL32(255, 170, 60, 255);
        if (c.type == uim_EDITOR_OVERLAY_GRID_LINE) col = IM_COL32(90, 95, 105, 80);
        if (c.type == uim_EDITOR_OVERLAY_GUIDE_LINE) col = IM_COL32(90, 210, 255, 120);
        if (c.type == uim_EDITOR_OVERLAY_SAFE_AREA) col = IM_COL32(80, 200, 120, 120);
        if (c.type == uim_EDITOR_OVERLAY_SELECTION_MARQUEE) col = IM_COL32(90, 180, 255, 160);

        if (c.type == uim_EDITOR_OVERLAY_GRID_LINE || c.type == uim_EDITOR_OVERLAY_GUIDE_LINE) {
            ImVec2 a(c.x1, c.y1);
            ImVec2 b(c.x2, c.y2);
            a.x = std::clamp(a.x, clip_min.x, clip_max.x);
            a.y = std::clamp(a.y, clip_min.y, clip_max.y);
            b.x = std::clamp(b.x, clip_min.x, clip_max.x);
            b.y = std::clamp(b.y, clip_min.y, clip_max.y);
            draw->AddLine(a, b, col, 1.0f);
        } else if (c.type == uim_EDITOR_OVERLAY_RESIZE_HANDLE) {
            draw->AddRectFilled(ImVec2(c.rect.x, c.rect.y),
                                ImVec2(c.rect.x + c.rect.width, c.rect.y + c.rect.height), col);
        } else if (c.type == uim_EDITOR_OVERLAY_SELECTION_MARQUEE) {
            draw->AddRectFilled(ImVec2(std::min(c.x1, c.x2), std::min(c.y1, c.y2)),
                                ImVec2(std::max(c.x1, c.x2), std::max(c.y1, c.y2)),
                                IM_COL32(70, 140, 220, 40));
            draw->AddRect(ImVec2(std::min(c.x1, c.x2), std::min(c.y1, c.y2)),
                          ImVec2(std::max(c.x1, c.x2), std::max(c.y1, c.y2)), col,
                          0.0f, 1.0f, ImDrawFlags_None);
        } else {
            draw->AddRect(ImVec2(c.rect.x, c.rect.y),
                          ImVec2(c.rect.x + c.rect.width, c.rect.y + c.rect.height), col,
                          0.0f, 1.5f, ImDrawFlags_None);
        }
    }
}

/* Returns the first selected 3D node and its screen-space origin. The gizmo
 * uses the same camera as the preview, so it cannot drift from the billboard. */
static bool gizmo_origin(const ImVec2 &child_min, ImVec2 *out_origin,
                         float *out_px_per_unit, uim_NodeId *out_node) {
    if (!g.editor || !g.manager || g.texture_w <= 0 || g.texture_h <= 0) return false;
    uim_EditorSelection sel{};
    if (uir_editor_get_selection(g.editor, &sel) != uim_OK) return false;
    for (size_t i = 0; i < sel.count; ++i) {
        uim_NodeInfo n;
        if (uim_node_get(g.manager, sel.ids[i], &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        zcsr_camera3d camera;
        zcsr_camera3d_init(&camera, g.texture_w, g.texture_h,
                           0.0f, 0.0f, 600.0f, 0.0f, 0.0f, 60.0f);
        float px = 0.0f, py = 0.0f, depth = 0.0f;
        if (!zcsr_camera3d_project(&camera, n.transform.position[0],
                                   n.transform.position[1], n.transform.position[2],
                                   &px, &py, &depth))
            continue;
        if (out_origin)
            *out_origin = ImVec2(child_min.x + g.pan_x + px * g.zoom,
                                 child_min.y + g.pan_y + py * g.zoom);
        if (out_px_per_unit) {
            float ppu = zcsr_camera3d_px_per_unit(&camera, depth);
            *out_px_per_unit = ppu > 0.0f ? ppu : 1.0f;
        }
        if (out_node) *out_node = n.id;
        return true;
    }
    return false;
}

static float gizmo_axis_screen_len() { return 58.0f; }

void draw_3d_gizmo(ImDrawList *draw, const ImVec2 &child_min) {
    ImVec2 origin;
    float ppu = 1.0f;
    uim_NodeId node = uim_NODE_INVALID;
    if (!gizmo_origin(child_min, &origin, &ppu, &node)) return;
    (void)ppu;
    float len = gizmo_axis_screen_len();
    ImU32 x_col = g.gizmo_axis == 0 ? IM_COL32(255, 220, 80, 255) : IM_COL32(230, 70, 70, 255);
    ImU32 y_col = g.gizmo_axis == 1 ? IM_COL32(255, 220, 80, 255) : IM_COL32(80, 220, 110, 255);
    ImU32 z_col = g.gizmo_axis == 2 ? IM_COL32(255, 220, 80, 255) : IM_COL32(80, 160, 255, 255);
    ImVec2 x_end(origin.x + len, origin.y);
    ImVec2 y_end(origin.x, origin.y - len);
    ImVec2 z_end(origin.x - len * 0.55f, origin.y - len * 0.55f);
    draw->AddCircleFilled(origin, 4.0f, IM_COL32(255, 255, 255, 255));
    draw->AddLine(origin, x_end, x_col, 2.5f);
    draw->AddLine(origin, y_end, y_col, 2.5f);
    draw->AddLine(origin, z_end, z_col, 2.5f);
    draw->AddTriangleFilled(x_end, ImVec2(x_end.x - 8.0f, x_end.y - 4.0f),
                            ImVec2(x_end.x - 8.0f, x_end.y + 4.0f), x_col);
    draw->AddTriangleFilled(y_end, ImVec2(y_end.x - 4.0f, y_end.y + 8.0f),
                            ImVec2(y_end.x + 4.0f, y_end.y + 8.0f), y_col);
    draw->AddTriangleFilled(z_end, ImVec2(z_end.x + 8.0f, z_end.y + 2.0f),
                            ImVec2(z_end.x + 2.0f, z_end.y + 8.0f), z_col);
    draw->AddText(ImVec2(x_end.x + 4.0f, x_end.y - 6.0f), x_col, "X");
    draw->AddText(ImVec2(y_end.x + 5.0f, y_end.y - 14.0f), y_col, "Y");
    draw->AddText(ImVec2(z_end.x - 12.0f, z_end.y - 4.0f), z_col, "Z");
}

static int gizmo_hit_test(const ImVec2 &mouse, const ImVec2 &child_min) {
    ImVec2 origin;
    if (!gizmo_origin(child_min, &origin, nullptr, nullptr)) return -1;
    float len = gizmo_axis_screen_len();
    ImVec2 ends[3] = {
        ImVec2(origin.x + len, origin.y),
        ImVec2(origin.x, origin.y - len),
        ImVec2(origin.x - len * 0.55f, origin.y - len * 0.55f)
    };
    for (int axis = 0; axis < 3; ++axis) {
        float dx = mouse.x - ends[axis].x;
        float dy = mouse.y - ends[axis].y;
        if (dx * dx + dy * dy <= 12.0f * 12.0f) return axis;
    }
    return -1;
}

static void gizmo_begin(const ImVec2 &mouse, const ImVec2 &child_min) {
    if (!g.editor || !g.manager) return;
    uim_EditorSelection sel{};
    if (uir_editor_get_selection(g.editor, &sel) != uim_OK) return;
    g.gizmo_count = 0;
    for (size_t i = 0; i < sel.count && g.gizmo_count < 16; ++i) {
        uim_NodeInfo n;
        uim_Transform3 tr;
        if (uim_node_get(g.manager, sel.ids[i], &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        if (uim_node_get_transform3(g.manager, n.id, &tr) != uim_OK) continue;
        g.gizmo_nodes[g.gizmo_count] = n.id;
        g.gizmo_orig[g.gizmo_count] = tr;
        g.gizmo_count++;
    }
    if (g.gizmo_count == 0) return;
    g.gizmo_axis = gizmo_hit_test(mouse, child_min);
    if (g.gizmo_axis < 0) return;
    g.gizmo_dragging = true;
    g.gizmo_start = mouse;
    g.dragging = false; /* never route this gesture to the 2D kernel */
}

static void gizmo_drag(const ImVec2 &mouse, const ImVec2 &child_min) {
    if (!g.gizmo_dragging || g.gizmo_axis < 0 || !g.manager) return;
    ImVec2 origin;
    float ppu = 1.0f;
    if (!gizmo_origin(child_min, &origin, &ppu, nullptr)) return;
    float dx = (mouse.x - g.gizmo_start.x) / std::max(g.zoom, 0.01f);
    float dy = (mouse.y - g.gizmo_start.y) / std::max(g.zoom, 0.01f);
    float wx = dx / std::max(ppu, 0.001f);
    float wy = -dy / std::max(ppu, 0.001f);
    for (size_t i = 0; i < g.gizmo_count; ++i) {
        uim_Transform3 tr = g.gizmo_orig[i];
        if (g.gizmo_axis == 0) tr.position[0] += wx;
        else if (g.gizmo_axis == 1) tr.position[1] += wy;
        else tr.position[2] += wy;
        (void)uim_node_set_transform3(g.manager, g.gizmo_nodes[i], &tr);
    }
}

static void gizmo_end() {
    if (!g.gizmo_dragging) return;
    if (g.editor && g.manager) {
        for (size_t i = 0; i < g.gizmo_count; ++i) {
            uim_Transform3 final;
            if (uim_node_get_transform3(g.manager, g.gizmo_nodes[i], &final) != uim_OK)
                continue;
            /* Restore the pre-drag state, then let the editor kernel record one
             * undo entry for the completed gesture. */
            (void)uim_node_set_transform3(g.manager, g.gizmo_nodes[i], &g.gizmo_orig[i]);
            (void)uir_editor_set_transform3(g.editor, g.gizmo_nodes[i], &final);
        }
        g.dirty = true;
    }
    g.gizmo_dragging = false;
    g.gizmo_axis = -1;
    g.gizmo_count = 0;
}

/* 3D nodes are not part of the 2D page texture. The editor presents them
 * through the engine's software perspective camera (zcsr_camera3d); no second
 * renderer or document model is introduced. Billboard size uses the node
 * transform scale so Inspector edits are visible next frame. */
void draw_3d_overlay(ImDrawList *draw, const ImVec2 &child_min) {
    if (!g.manager || g.page == uim_PAGE_INVALID || g.texture_w <= 0 || g.texture_h <= 0)
        return;
    zcsr_camera3d camera;
    zcsr_camera3d_init(&camera, g.texture_w, g.texture_h,
                       0.0f, 0.0f, 600.0f,
                       0.0f, 0.0f, 60.0f);
    size_t count = 0u;
    if (uim_page_get_node_count(g.manager, g.page, &count) != uim_OK || count == 0u) return;
    bool any = false;
    for (size_t i = 0; i < count; ++i) {
        uim_NodeInfo n;
        if (uim_page_get_node_at(g.manager, g.page, i, &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        float world_w = std::max(std::abs(n.transform.scale[0]), 0.05f) * 120.0f;
        float world_h = std::max(std::abs(n.transform.scale[1]), 0.05f) * 60.0f;
        float bx = 0.0f, by = 0.0f, bw = 0.0f, bh = 0.0f;
        if (!zcsr_camera3d_billboard(&camera, n.transform.position[0],
                                     n.transform.position[1], n.transform.position[2],
                                     world_w, world_h, &bx, &by, &bw, &bh)) continue;
        ImVec2 a(child_min.x + g.pan_x + bx * g.zoom,
                 child_min.y + g.pan_y + by * g.zoom);
        ImVec2 b(child_min.x + g.pan_x + (bx + bw) * g.zoom,
                 child_min.y + g.pan_y + (by + bh) * g.zoom);
        draw->AddRect(a, b, IM_COL32(120, 200, 255, 220), 2.0f, 1.5f, ImDrawFlags_None);
        draw->AddText(ImVec2(a.x + 4.0f, a.y + 3.0f), IM_COL32(210, 240, 255, 255),
                      n.stable_key ? n.stable_key : "3D node");
        any = true;
    }
    if (any) {
        ImVec2 badge(child_min.x + 8.0f, child_min.y + 34.0f);
        draw->AddRectFilled(badge, ImVec2(badge.x + 156.0f, badge.y + 22.0f),
                            IM_COL32(35, 65, 100, 210), 4.0f);
        draw->AddText(ImVec2(badge.x + 8.0f, badge.y + 4.0f),
                      IM_COL32(190, 225, 255, 255), "3D preview: camera3d");
    }
}

void select_node(uim_NodeId node, bool additive);

/* Viewport selection must see the same 3D billboard the user sees. The 2D
 * canvas picker only knows local_rect, so a full-screen 2D panel would always
 * win over a 3D node drawn on top. This pick runs first and returns the
 * top-most 3D node under the cursor, then the 2D kernel handles the rest. */
uim_NodeId pick_3d_at(const ImVec2 &mouse, const ImVec2 &child_min) {
    if (!g.manager || g.page == uim_PAGE_INVALID || g.texture_w <= 0 || g.texture_h <= 0)
        return uim_NODE_INVALID;
    float page_x = (mouse.x - child_min.x - g.pan_x) / g.zoom;
    float page_y = (mouse.y - child_min.y - g.pan_y) / g.zoom;
    zcsr_camera3d camera;
    zcsr_camera3d_init(&camera, g.texture_w, g.texture_h,
                       0.0f, 0.0f, 600.0f,
                       0.0f, 0.0f, 60.0f);
    size_t count = 0u;
    if (uim_page_get_node_count(g.manager, g.page, &count) != uim_OK) return uim_NODE_INVALID;
    uim_NodeId best = uim_NODE_INVALID;
    float best_z = -3.0e38f;
    for (size_t i = 0; i < count; ++i) {
        uim_NodeInfo n;
        if (uim_page_get_node_at(g.manager, g.page, i, &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        float world_w = std::max(std::abs(n.transform.scale[0]), 0.05f) * 120.0f;
        float world_h = std::max(std::abs(n.transform.scale[1]), 0.05f) * 60.0f;
        float bx = 0.0f, by = 0.0f, bw = 0.0f, bh = 0.0f;
        if (!zcsr_camera3d_billboard(&camera, n.transform.position[0],
                                     n.transform.position[1], n.transform.position[2],
                                     world_w, world_h, &bx, &by, &bw, &bh)) continue;
        if (page_x < bx || page_x > bx + bw || page_y < by || page_y > by + bh) continue;
        if (n.transform.position[2] > best_z) {
            best_z = n.transform.position[2];
            best = n.id;
        }
    }
    return best;
}

void apply_canvas(const ImVec2 &content_min, const ImVec2 &content_size) {
    uim_EditorCanvasState state{};
    if (g.editor) uir_editor_get_canvas_state(g.editor, &state);
    state.viewport = {content_min.x, content_min.y, content_size.x, content_size.y};
    state.zoom = g.zoom;
    state.pan_x = g.pan_x;
    state.pan_y = g.pan_y;
    if (g.editor) uir_editor_set_canvas_state(g.editor, &state);
}

int modifier_mask() {
    int m = 0;
    if (ImGui::GetIO().KeyShift) m |= uim_EDITOR_MOD_SHIFT;
    if (ImGui::GetIO().KeyCtrl) m |= uim_EDITOR_MOD_CTRL;
    if (ImGui::GetIO().KeyAlt) m |= uim_EDITOR_MOD_ALT;
    return m;
}

void select_node(uim_NodeId node, bool additive) {
    if (!g.editor) return;
    g.selected_instance = 0;
    if (!additive) {
        uir_editor_select(g.editor, &node, 1);
        return;
    }
    uim_EditorSelection sel{};
    uir_editor_get_selection(g.editor, &sel);
    std::vector<uim_NodeId> ids;
    bool found = false;
    for (size_t i = 0; i < sel.count; ++i) {
        ids.push_back(sel.ids[i]);
        if (sel.ids[i] == node) found = true;
    }
    if (found) ids.erase(std::remove(ids.begin(), ids.end(), node), ids.end());
    else ids.push_back(node);
    uir_editor_select(g.editor, ids.data(), ids.size());
}

void select_node_duplicate() {
    uim_EditorSelection sel{};
    if (!g.editor || uir_editor_get_selection(g.editor, &sel) != uim_OK || sel.count != 1) return;
    uim_NodeId made = uim_NODE_INVALID;
    if (uir_editor_duplicate_node(g.editor, sel.ids[0], 16.0f, 16.0f, &made) == uim_OK) {
        g.dirty = true;
        select_node(made, false);
    }
}

void delete_selected_node() {
    uim_EditorSelection sel{};
    if (!g.editor || uir_editor_get_selection(g.editor, &sel) != uim_OK || sel.count == 0) return;
    for (size_t i = 0; i < sel.count; ++i) {
        if (sel.ids[i] != g.root) uir_editor_delete_node(g.editor, sel.ids[i]);
    }
    g.dirty = true;
}

void begin_rename(uim_NodeId node) {
    if (!g.manager || !node) return;
    uim_NodeInfo info{};
    if (uim_node_get(g.manager, node, &info) != uim_OK) return;
    g.rename_node = node;
    std::snprintf(g.rename_buf, sizeof(g.rename_buf), "%s", info.stable_key ? info.stable_key : "");
    g.rename_open = true;
    g.rename_focus = true;
}

void draw_rename_popup() {
    if (!g.rename_open) return;
    ImGui::OpenPopup("Rename Node");
    ImGui::SetNextWindowSize(ImVec2(300, 0));
    if (ImGui::BeginPopupModal("Rename Node", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::SetWindowFocus();
        ImGui::Text("Node name");
        ImGui::SetNextItemWidth(260);
        if (g.rename_focus) {
            ImGui::SetKeyboardFocusHere();
            g.rename_focus = false;
        }
        bool enter = ImGui::InputText("##rename", g.rename_buf, sizeof(g.rename_buf),
                                      ImGuiInputTextFlags_EnterReturnsTrue);
        bool ok = ImGui::Button("Rename", ImVec2(90, 0));
        ImGui::SameLine();
        bool cancel = ImGui::Button("Cancel", ImVec2(90, 0));
        if ((enter || ok) && g.rename_node && g.rename_buf[0]) {
            if (uir_editor_hierarchy_set_name(g.editor, g.rename_node, g.rename_buf) == uim_OK &&
                uim_node_set_stable_key(g.manager, g.rename_node, g.rename_buf) == uim_OK) {
                g.dirty = true;
            } else {
                log_line("rename failed");
            }
            g.rename_open = false;
            ImGui::CloseCurrentPopup();
        }
        if (cancel) {
            g.rename_open = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
    if (!ImGui::IsPopupOpen("Rename Node")) g.rename_open = false;
}


void draw_hierarchy() {
    ImGui::Begin("Hierarchy", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("HIERARCHY");
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(4.0f, 3.0f));
    if (ImGui::SmallButton("+Empty")) {
        uim_NodeId parent = g.root;
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
        create_node({}, parent, {0, 0, 160, 80}, 0);
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("+Panel")) {
        uim_NodeId parent = g.root;
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
        create_node({}, parent, {0, 0, 160, 80}, uim_COMPONENT_PANEL);
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("Dup")) {
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) {
            uim_NodeId made = 0;
            if (uir_editor_duplicate_node(g.editor, sel.ids[0], 16.0f, 16.0f, &made) == uim_OK) {
                g.dirty = true;
                select_node(made, false);
            }
        }
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("Del")) {
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count) {
            for (size_t i = 0; i < sel.count; ++i) {
                if (sel.ids[i] != g.root) uir_editor_delete_node(g.editor, sel.ids[i]);
            }
            g.dirty = true;
        }
    }
    ImGui::PopStyleVar();
    ImGui::Separator();


    size_t count = 0;
    if (g.editor) uir_editor_hierarchy_get_visible_count(g.editor, &count);
    for (size_t i = 0; i < count; ++i) {
        uim_EditorHierarchyItem item{};
        if (uir_editor_hierarchy_get_visible_at(g.editor, i, &item) != uim_OK) continue;
        ImGui::PushID((int)(uintptr_t)item.node.id);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + item.depth * 16.0f);
        bool selected = false;
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK) {
            for (size_t k = 0; k < sel.count; ++k) if (sel.ids[k] == item.node.id) selected = true;
        }
        std::string label = item.display_name ? item.display_name : "(node)";
        if (!item.node.visible) label += "  (hidden)";
        std::string row_label = (item.has_children ? (item.expanded ? "v  " : ">  ") : "    ") + label;
        float row_w = ImGui::GetContentRegionAvail().x;
        ImVec4 row_bg = selected ? ImGui::GetStyleColorVec4(ImGuiCol_Header)
                                 : ImVec4(0, 0, 0, 0);
        ImGui::PushStyleColor(ImGuiCol_Button, row_bg);
        bool clicked = ImGui::Button(row_label.c_str(), ImVec2(row_w, 0.0f));
        ImGui::PopStyleColor();
        if (clicked) {
            if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
                if (item.has_children) {
                    uir_editor_hierarchy_set_expanded(g.editor, item.node.id, !item.expanded);
                } else {
                    begin_rename(item.node.id);
                }
            } else {
                select_node(item.node.id, ImGui::GetIO().KeyCtrl);
            }
        }
        if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
            uim_NodeId dragged = item.node.id;
            ImGui::SetDragDropPayload("zcsr_hierarchy_node", &dragged, sizeof(dragged));
            ImGui::TextUnformatted(label.c_str());
            ImGui::EndDragDropSource();
        }
        if (ImGui::BeginDragDropTarget()) {
            const ImGuiPayload *payload = ImGui::AcceptDragDropPayload("zcsr_hierarchy_node");
            if (payload && payload->DataSize == sizeof(uim_NodeId)) {
                uim_NodeId dragged = *(const uim_NodeId *)payload->Data;
                if (dragged != item.node.id && dragged != g.root &&
                    uir_editor_set_parent(g.editor, dragged, item.node.id) == uim_OK) {
                    g.dirty = true;
                    log_line("reparented node");
                }
            }
            ImGui::EndDragDropTarget();
        }
        if (ImGui::BeginPopupContextItem()) {
            if (ImGui::MenuItem("Rename")) begin_rename(item.node.id);
            if (ImGui::MenuItem("Create Empty Child")) {
                create_node({}, item.node.id, {0, 0, 160, 80}, 0);
            }
            if (ImGui::MenuItem("Create Panel Child")) {
                create_node({}, item.node.id, {0, 0, 160, 80}, uim_COMPONENT_PANEL);
            }
            if (ImGui::MenuItem("Duplicate")) {
                uim_NodeId made = 0;
                if (uir_editor_duplicate_node(g.editor, item.node.id, 16.0f, 16.0f, &made) == uim_OK) {
                    g.dirty = true;
                    select_node(made, false);
                }
            }
            if (ImGui::MenuItem("Delete", nullptr, false, item.node.id != g.root)) {
                uir_editor_delete_node(g.editor, item.node.id);
                g.dirty = true;
            }
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    ImGui::End();
}

std::string value_string(uim_Value v) {
    if (v.type != uim_VALUE_STRING || !v.as.string.data) return {};
    return std::string(v.as.string.data, v.as.string.size);
}

bool set_value(uim_ComponentInstanceId instance, uim_PropertyId prop, uim_Value value) {
    if (!g.manager || !g.registry || !g.editor) return false;
    uim_Result rc = uir_editor_component_set_property(g.editor, g.registry, instance, prop, value);
    if (rc != uim_OK) {
        log_line("property set failed: " + std::to_string((int)rc));
        return false;
    }
    g.dirty = true;
    return true;
}

void draw_property(uim_ComponentInstanceId instance, const uim_ComponentPropertyDesc &p) {
    if (p.flags & uim_PROPERTY_FLAG_HIDDEN_IN_INSPECTOR) return;
    if (p.flags & uim_PROPERTY_FLAG_READ_ONLY) ImGui::BeginDisabled();
    uim_Value value{};
    if (uim_component_instance_get_property(g.manager, instance, p.property_id, &value) != uim_OK) {
        if (p.flags & uim_PROPERTY_FLAG_READ_ONLY) ImGui::EndDisabled();
        return;
    }
    ImGui::PushID((int)p.property_id);
    const char *label = p.display_name_key ? p.display_name_key : (p.stable_key ? p.stable_key : "?");
    bool changed = false;

    if (p.inspector_control == uim_INSPECTOR_COLOR) {
        ImGui::PushItemWidth(-96.0f);
        int64_t packed = value.type == uim_VALUE_INT64 ? value.as.integer : 0;
        float rgba[4] = {
            ((packed >> 24) & 0xff) / 255.0f,
            ((packed >> 16) & 0xff) / 255.0f,
            ((packed >> 8) & 0xff) / 255.0f,
            (packed & 0xff) / 255.0f,
        };
        if (ImGui::ColorEdit4(label, rgba, ImGuiColorEditFlags_AlphaBar)) {
            int64_t v = ((int64_t)std::lround(rgba[0] * 255.0f) << 24) |
                        ((int64_t)std::lround(rgba[1] * 255.0f) << 16) |
                        ((int64_t)std::lround(rgba[2] * 255.0f) << 8) |
                        (int64_t)std::lround(rgba[3] * 255.0f);
            changed = set_value(instance, p.property_id, uim_value_int(v));
        }
        ImGui::PopItemWidth();
    } else if (p.inspector_control == uim_INSPECTOR_CHECKBOX || value.type == uim_VALUE_BOOL) {
        bool v = value.as.boolean;
        if (ImGui::Checkbox(label, &v)) changed = set_value(instance, p.property_id, uim_value_bool(v));
    } else if (p.inspector_control == uim_INSPECTOR_SLIDER && value.type == uim_VALUE_FLOAT64) {
        float v = (float)value.as.real;
        float lo = (float)p.numeric_min, hi = (float)p.numeric_max;
        if (ImGui::SliderFloat(label, &v, lo, hi)) changed = set_value(instance, p.property_id, uim_value_float(v));
    } else if (p.property_id == uim_PROPERTY_TRIGGER || p.property_id == uim_PROPERTY_SELECTOR ||
               p.property_id == uim_PROPERTY_EFFECT) {
        int v = (int)(value.type == uim_VALUE_INT64 ? value.as.integer : 0);
        const char *items[] = {"Trigger: Click", "Trigger: Tick", "Selector: Same Row",
                               "Selector: Same Col", "Selector: Radius", "Selector: Nearest",
                               "Selector: Tag", "Effect: Damage", "Effect: Move",
                               "Effect: Destroy", "Effect: Goto"};
        int base = 0, count = 0;
        if (p.property_id == uim_PROPERTY_TRIGGER) { base = 0; count = 2; }
        else if (p.property_id == uim_PROPERTY_SELECTOR) { base = 2; count = 5; }
        else { base = 7; count = 4; }
        if (ImGui::Combo(label, &v, items + base, count)) {
            changed = set_value(instance, p.property_id, uim_value_int(v));
        }
    } else if (value.type == uim_VALUE_INT64) {
        int v = (int)value.as.integer;
        if (ImGui::DragInt(label, &v, (float)(p.numeric_step > 0 ? p.numeric_step : 1.0),
                           (int)p.numeric_min, (int)p.numeric_max)) {
            changed = set_value(instance, p.property_id, uim_value_int(v));
        }
    } else if (value.type == uim_VALUE_FLOAT64) {
        float v = (float)value.as.real;
        if (ImGui::DragFloat(label, &v, (float)(p.numeric_step > 0 ? p.numeric_step : 0.1f),
                             (float)p.numeric_min, (float)p.numeric_max, "%.3f")) {
            changed = set_value(instance, p.property_id, uim_value_float(v));
        }
    } else if (value.type == uim_VALUE_STRING) {
        uint64_t key = ((uint64_t)instance << 32) | p.property_id;
        auto &buf = g.text_buffers[key];
        bool active = ImGui::IsAnyItemActive();
        if (!active || buf[0] == '\0') {
            std::snprintf(buf.data(), buf.size(), "%s", value_string(value).c_str());
        }
        if (ImGui::InputText(label, buf.data(), buf.size())) {
            changed = set_value(instance, p.property_id,
                                uim_value_string(buf.data(), std::strlen(buf.data())));
        }
    } else {
        ImGui::TextDisabled("%s: unsupported value", label);
    }
    if (changed) g.selected_instance = instance;
    ImGui::PopID();
    if (p.flags & uim_PROPERTY_FLAG_READ_ONLY) ImGui::EndDisabled();
}

void draw_components(uim_NodeId node) {
    size_t count = 0;
    if (uim_node_component_count(g.manager, node, &count) != uim_OK) count = 0;
    ImGui::Text("Components %zu", count);
    for (size_t i = 0; i < count; ++i) {
        uim_ComponentInstanceInfo info{};
        if (uim_node_component_get_at(g.manager, node, i, &info) != uim_OK) continue;
        uim_ComponentTypeDesc desc{};
        if (uim_component_registry_get(g.registry, info.type_id, &desc) != uim_OK) continue;
        ImGui::PushID((int)info.instance_id);
        bool open = ImGui::TreeNodeEx(desc.display_name_key ? desc.display_name_key : "Component",
                                      ImGuiTreeNodeFlags_DefaultOpen |
                                      (g.selected_instance == info.instance_id ? ImGuiTreeNodeFlags_Selected : 0));
        if (ImGui::IsItemClicked()) g.selected_instance = info.instance_id;
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.45f, 0.16f, 0.16f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.62f, 0.22f, 0.22f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.75f, 0.28f, 0.28f, 1.0f));
        bool remove = ImGui::Button("X##remove_component", ImVec2(26, 0));
        ImGui::PopStyleColor(3);
        if (remove) {
            if (g.editor && uir_editor_component_detach(g.editor, info.instance_id) == uim_OK) {
                g.dirty = true;
                g.selected_instance = 0;
            }
            if (open) ImGui::TreePop();
            ImGui::PopID();
            break;
        }
        if (open) {
            for (size_t k = 0; k < desc.property_count; ++k) draw_property(info.instance_id, desc.properties[k]);
            ImGui::TreePop();
        }
        ImGui::PopID();
    }

    if (ImGui::Button(g.component_picker_open ? "Cancel Add Component" : "+ Add Component",
                       ImVec2(-1.0f, 30.0f))) {
        g.component_filter[0] = '\0';
        g.component_picker_open = !g.component_picker_open;
    }
    if (g.component_picker_open) {
        if (ImGui::IsKeyPressed(ImGuiKey_Escape)) g.component_picker_open = false;
        ImGui::SetNextItemWidth(-1.0f);
        ImGui::InputTextWithHint("##component_filter", "Search components", g.component_filter,
                                 sizeof(g.component_filter));
        std::string filter = g.component_filter;
        for (auto &ch : filter) ch = (char)std::tolower((unsigned char)ch);
        std::string last_category;
        uim_ComponentTypeId attach_type = 0;
        size_t types = uim_component_registry_count(g.registry);
        ImGui::BeginChild("##component_list", ImVec2(0.0f, 240.0f), true);
        for (size_t i = 0; i < types; ++i) {
            uim_ComponentTypeDesc desc{};
            if (uim_component_registry_get_at(g.registry, i, &desc) != uim_OK) continue;
            std::string label = desc.display_name_key ? desc.display_name_key : desc.stable_key;
            std::string category = desc.category_key ? desc.category_key : "Components";
            std::string haystack = label + " " + category;
            for (auto &ch : haystack) ch = (char)std::tolower((unsigned char)ch);
            if (!filter.empty() && haystack.find(filter) == std::string::npos) continue;
            if (last_category.empty() || category != last_category) {
                ImGui::Separator();
                ImGui::TextDisabled("%s", category.c_str());
                last_category = category;
            }
            if (ImGui::Selectable(label.c_str(), false, ImGuiSelectableFlags_None, ImVec2(0.0f, 22.0f))) {
                if ((desc.flags & uim_COMPONENT_FLAG_SINGLETON_PER_NODE) != 0u &&
                    node_has_singleton_type(node, desc.type_id)) {
                    log_line("component already exists on this node");
                } else {
                    attach_type = desc.type_id;
                }
                g.component_picker_open = false;
            }
            if ((desc.flags & uim_COMPONENT_FLAG_SINGLETON_PER_NODE) != 0u &&
                node_has_singleton_type(node, desc.type_id)) {
                ImGui::SameLine();
                ImGui::TextDisabled("already attached");
            }
        }
        ImGui::EndChild();
        if (attach_type) attach_component(node, attach_type);
    }
}

void draw_inspector() {
    ImGui::Begin("Inspector", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("INSPECTOR");
    uim_EditorSelection sel{};
    if (!g.editor || uir_editor_get_selection(g.editor, &sel) != uim_OK || sel.count == 0) {
        ImGui::TextDisabled("Nothing selected");
        ImGui::End();
        return;
    }
    uim_NodeId node = sel.ids[0];
    uim_NodeInfo n{};
    if (uir_editor_inspect_node(g.editor, node, &n) != uim_OK) {
        ImGui::TextDisabled("Selection is stale");
        ImGui::End();
        return;
    }
    char name[128]{};
    std::snprintf(name, sizeof(name), "%s", n.stable_key ? n.stable_key : "");
    ImGui::InputText("Name", name, sizeof(name), ImGuiInputTextFlags_EnterReturnsTrue);
    bool commit_name = ImGui::IsItemDeactivatedAfterEdit();
    if (commit_name && name[0] &&
        std::strcmp(name, n.stable_key ? n.stable_key : "") != 0) {
        if (uir_editor_hierarchy_set_name(g.editor, node, name) == uim_OK &&
            uim_node_set_stable_key(g.manager, node, name) == uim_OK) {
            g.dirty = true;
        } else {
            log_line("rename failed");
        }
    }
    ImGui::SameLine();
    ImGui::TextDisabled("%s #%llu", n.space == uim_SPACE_3D ? "3D" : "2D",
                        (unsigned long long)node);

    if (n.space == uim_SPACE_2D) {
        float x = n.local_rect.x, y = n.local_rect.y, w = n.local_rect.width, h = n.local_rect.height;
        bool edit = false;
        if (ImGui::InputFloat("x", &x, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (ImGui::InputFloat("y", &y, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (ImGui::InputFloat("width", &w, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (ImGui::InputFloat("height", &h, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (edit) {
            w = std::max(w, 0.0f);
            h = std::max(h, 0.0f);
            if (uir_editor_set_rect(g.editor, node, {x, y, w, h}) == uim_OK) g.dirty = true;
        }
    } else {
        uim_Transform3 t = n.transform;
        bool edit = false;
        edit |= ImGui::DragFloat3("position", t.position, 0.1f);
        edit |= ImGui::DragFloat3("rotation", t.rotation, 0.5f);
        edit |= ImGui::DragFloat3("scale", t.scale, 0.01f);
        if (edit && uir_editor_set_transform3(g.editor, node, &t) == uim_OK) g.dirty = true;
    }

    int z = n.z_order;
    if (ImGui::DragInt("z-order", &z)) {
        uir_editor_set_z_order(g.editor, node, z);
        g.dirty = true;
    }
    bool vis = n.visible, en = n.enabled;
    if (ImGui::Checkbox("visible", &vis)) { uir_editor_set_visible(g.editor, node, vis); g.dirty = true; }
    ImGui::SameLine();
    if (ImGui::Checkbox("enabled", &en)) { uir_editor_set_enabled(g.editor, node, en); g.dirty = true; }
    bool is3d = n.space == uim_SPACE_3D;
    if (ImGui::Checkbox("3D space", &is3d)) {
        if (uir_editor_set_space(g.editor, node, is3d ? uim_SPACE_3D : uim_SPACE_2D) == uim_OK)
            g.dirty = true;
    }
    ImGui::Separator();
    draw_components(node);
    ImGui::End();
}

void draw_console() {
    if (!g.show_console) return;
    ImGui::Begin("Console", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("CONSOLE");
    for (const auto &line : g.log) ImGui::TextUnformatted(line.c_str());
    ImGui::End();
}

void draw_pages_bar();
bool close_request_cb(void *user);

void draw_menu(HWND owner) {
    if (!ImGui::BeginMainMenuBar()) return;
    if (ImGui::BeginMenu("File")) {
        if (ImGui::MenuItem("New", "Ctrl+N")) new_document();
        if (ImGui::MenuItem("Open", "Ctrl+O")) {
            std::string path = open_dialog(owner);
            if (!path.empty()) load_project(path);
        }
        if (ImGui::MenuItem("Save", "Ctrl+S")) save_project(false);
        if (ImGui::MenuItem("Save As")) save_project(true);
        ImGui::Separator();
        if (ImGui::MenuItem("Build", "F6")) build_package();
        if (ImGui::MenuItem(g.playing ? "Stop" : "Play", "F5")) {
            if (g.playing) stop_play(); else start_play();
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Exit")) {
            if (close_request_cb(&g)) zcsr_runtime_shell_request_exit();
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Edit")) {
        uim_EditorHistoryState hs{};
        if (g.editor) uir_editor_get_history_state(g.editor, &hs);
        if (ImGui::MenuItem("Undo", "Ctrl+Z", false, hs.undo_count > 0)) {
            if (uir_editor_undo(g.editor) == uim_OK) g.dirty = true;
        }
        if (ImGui::MenuItem("Redo", "Ctrl+Y", false, hs.redo_count > 0)) {
            if (uir_editor_redo(g.editor) == uim_OK) g.dirty = true;
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("GameObject")) {
        if (ImGui::MenuItem("Create Empty")) {
            uim_NodeId parent = g.root;
            uim_EditorSelection sel{};
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
            create_node({}, parent, {0, 0, 160, 80}, 0);
        }
        if (ImGui::MenuItem("UI Panel")) {
            uim_NodeId parent = g.root;
            uim_EditorSelection sel{};
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
            create_node({}, parent, {0, 0, 160, 80}, uim_COMPONENT_PANEL);
        }
        if (ImGui::MenuItem("3D UI Node")) {
            uim_NodeId parent = g.root;
            uim_EditorSelection sel{};
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
            create_3d_node(parent);
        }
        if (ImGui::MenuItem("Resolve Anchors")) {
            if (g.editor && g.page != uim_PAGE_INVALID && g.texture_w > 0 && g.texture_h > 0) {
                if (uir_editor_resolve_page_layout(g.editor, g.page,
                                                   (float)g.texture_w,
                                                   (float)g.texture_h) == uim_OK) {
                    g.dirty = true;
                    log_line("anchors resolved");
                }
            }
        }
        if (ImGui::BeginMenu("Add Component")) {
            uim_EditorSelection sel{};
            uim_NodeId target = uim_NODE_INVALID;
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) target = sel.ids[0];
            size_t types = g.registry ? uim_component_registry_count(g.registry) : 0;
            for (size_t i = 0; i < types; ++i) {
                uim_ComponentTypeDesc desc{};
                if (uim_component_registry_get_at(g.registry, i, &desc) != uim_OK) continue;
                std::string label = desc.display_name_key ? desc.display_name_key : desc.stable_key;
                if (ImGui::MenuItem(label.c_str(), nullptr, false, target != uim_NODE_INVALID))
                    attach_component(target, desc.type_id);
            }
            ImGui::EndMenu();
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Duplicate")) select_node_duplicate();
        if (ImGui::MenuItem("Delete")) delete_selected_node();
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Window")) {
        ImGui::MenuItem("Hierarchy", nullptr, &g.show_hierarchy);
        ImGui::MenuItem("Viewport", nullptr, &g.show_viewport);
        ImGui::MenuItem("Inspector", nullptr, &g.show_inspector);
        ImGui::MenuItem("Console", nullptr, &g.show_console);
        ImGui::EndMenu();
    }
    ImGui::SameLine();
    ImGui::TextUnformatted("|");
    ImGui::SameLine();
    draw_pages_bar();
    ImGui::EndMainMenuBar();
}

void handle_shortcuts(HWND owner) {
    ImGuiIO &io = ImGui::GetIO();
    if (g.component_picker_open) return;
    if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_N, false)) new_document();
    if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_O, false)) {
        std::string path = open_dialog(owner);
        if (!path.empty()) load_project(path);
    }
    if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_S, false)) save_project(io.KeyShift);
    if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Z, false) && g.editor) {
        if (uir_editor_undo(g.editor) == uim_OK) g.dirty = true;
    }
    if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Y, false) && g.editor) {
        if (uir_editor_redo(g.editor) == uim_OK) g.dirty = true;
    }
    if (ImGui::IsKeyPressed(ImGuiKey_F5, false)) { if (g.playing) stop_play(); else start_play(); }
    if (ImGui::IsKeyPressed(ImGuiKey_F6, false)) build_package();
    if (ImGui::IsKeyPressed(ImGuiKey_Delete, false) && g.editor) {
        uim_EditorSelection sel{};
        if (uir_editor_get_selection(g.editor, &sel) == uim_OK) {
            for (size_t i = 0; i < sel.count; ++i) if (sel.ids[i] != g.root) uir_editor_delete_node(g.editor, sel.ids[i]);
            g.dirty = true;
        }
    }
    if (ImGui::IsKeyPressed(ImGuiKey_Escape, false) && g.playing) stop_play();
}

void draw_viewport() {
    ImGui::Begin("Viewport", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar |
                                      ImGuiWindowFlags_NoScrollWithMouse);
    ImVec2 avail = ImGui::GetContentRegionAvail();
    if (avail.x < 32 || avail.y < 32) { ImGui::End(); return; }
    ImVec2 origin = ImGui::GetCursorScreenPos();
    ImGui::BeginChild("##canvas", avail, false,
                      ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                      ImGuiWindowFlags_NoMove);
    ImVec2 child_min = ImGui::GetWindowPos();
    ImVec2 child_size = ImGui::GetWindowSize();

    if ((!g.viewport_initialized || (g.auto_fit &&
         (std::abs(child_size.x - g.last_view_w) > 1.0f ||
          std::abs(child_size.y - g.last_view_h) > 1.0f))) && g.page_texture) {
        float fit = std::min(child_size.x / (float)g.texture_w, child_size.y / (float)g.texture_h);
        g.zoom = std::max(fit, 0.05f);
        g.pan_x = (child_size.x - g.texture_w * g.zoom) * 0.5f;
        g.pan_y = (child_size.y - g.texture_h * g.zoom) * 0.5f;
        g.viewport_initialized = true;
        g.last_view_w = child_size.x;
        g.last_view_h = child_size.y;
    }
    apply_canvas(child_min, child_size);

    if (g.page_texture) {
        ImVec2 image_min(child_min.x + g.pan_x, child_min.y + g.pan_y);
        ImVec2 image_size(g.texture_w * g.zoom, g.texture_h * g.zoom);
        ImGui::SetCursorScreenPos(image_min);
        ImTextureRef tex((ImTextureID)(uintptr_t)g.page_texture);
        ImGui::Image(tex, image_size, ImVec2(0, 1), ImVec2(1, 0));
        bool hovered = ImGui::IsItemHovered();

        ImDrawList *draw = ImGui::GetWindowDrawList();
        if (g.playing) {
            draw->AddRect(ImVec2(image_min.x - 1.0f, image_min.y - 1.0f),
                          ImVec2(image_min.x + image_size.x + 1.0f,
                                 image_min.y + image_size.y + 1.0f),
                          IM_COL32(255, 90, 80, 255), 0.0f, ImDrawFlags_None, 2.0f);
            draw->AddRectFilled(ImVec2(child_min.x + 8.0f, child_min.y + 8.0f),
                                ImVec2(child_min.x + 126.0f, child_min.y + 28.0f),
                                IM_COL32(150, 35, 30, 220), 4.0f);
            draw->AddText(ImVec2(child_min.x + 16.0f, child_min.y + 12.0f),
                          IM_COL32(255, 255, 255, 255), "PLAYING  F5/ESC");
        }
        draw->PushClipRect(ImVec2(child_min.x, child_min.y),
                           ImVec2(child_min.x + child_size.x, child_min.y + child_size.y), true);
        draw_overlay(draw, ImVec2(child_min.x, child_min.y),
                     ImVec2(child_min.x + child_size.x, child_min.y + child_size.y));
        draw_3d_overlay(draw, child_min);
        if (!g.playing) draw_3d_gizmo(draw, child_min);
        draw->PopClipRect();

        ImGuiIO &io = ImGui::GetIO();
        if (hovered && io.MouseWheel != 0.0f && !g.playing) {
            float old_zoom = g.zoom;
            float page_x = (io.MousePos.x - child_min.x - g.pan_x) / old_zoom;
            float page_y = (io.MousePos.y - child_min.y - g.pan_y) / old_zoom;
            g.zoom = std::clamp(old_zoom * (io.MouseWheel > 0 ? 1.1f : 0.9f), 0.05f, 8.0f);
            g.pan_x = io.MousePos.x - child_min.x - page_x * g.zoom;
            g.pan_y = io.MousePos.y - child_min.y - page_y * g.zoom;
            g.auto_fit = false;
        }

        if (g.editor && g.page != uim_PAGE_INVALID) {
            if (!g.playing && hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
                gizmo_begin(io.MousePos, child_min);
                if (!g.gizmo_dragging) {
                    uim_NodeId hit3d = pick_3d_at(io.MousePos, child_min);
                    if (hit3d != uim_NODE_INVALID) {
                        select_node(hit3d, io.KeyCtrl || io.KeyShift);
                        g.dragging = false;
                    } else {
                        g.dragging = true;
                        g.drag_prev = io.MousePos;
                        g.drag_mods = (uint32_t)modifier_mask();
                        uim_EditorHistoryState hs{};
                        if (g.editor) uir_editor_get_history_state(g.editor, &hs);
                        g.drag_undo_before = hs.undo_count;
                        uir_editor_canvas_pointer_down(g.editor, g.page, io.MousePos.x,
                                                       io.MousePos.y, g.drag_mods);
                    }
                }
            }
            if (g.gizmo_dragging) {
                if (ImGui::IsMouseDown(ImGuiMouseButton_Left))
                    gizmo_drag(io.MousePos, child_min);
                else
                    gizmo_end();
            } else if (g.dragging) {
                if (ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
                    uir_editor_canvas_pointer_move(g.editor, io.MousePos.x, io.MousePos.y);
                } else {
                    uir_editor_canvas_pointer_up(g.editor, io.MousePos.x, io.MousePos.y);
                    g.dragging = false;
                    uim_EditorHistoryState hs{};
                    if (g.editor) uir_editor_get_history_state(g.editor, &hs);
                    if (hs.undo_count != g.drag_undo_before) g.dirty = true;
                }
            }
            if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Middle)) {
                g.panning = true;
                g.drag_prev = io.MousePos;
            }
            if (g.panning) {
                if (ImGui::IsMouseDown(ImGuiMouseButton_Middle)) {
                    g.pan_x += io.MousePos.x - g.drag_prev.x;
                    g.pan_y += io.MousePos.y - g.drag_prev.y;
                    g.drag_prev = io.MousePos;
                } else {
                    g.panning = false;
                }
            }
            if (g.playing && hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
                float px, py;
                if (uir_editor_canvas_to_page(g.editor, io.MousePos.x, io.MousePos.y, &px, &py) == uim_OK) {
                    uim_runtime_click_ex(g.manager, g.page, px, py, project_3d_node, nullptr);
                }
            }
        }
    } else {
        ImGui::TextDisabled("No page texture");
    }
    ImGui::EndChild();
    ImGui::End();
}

void draw_pages_bar() {
    if (!g.manager) return;
    size_t pages = 0;
    uim_page_count(g.manager, &pages);
    if (pages == 0) return;
    ImGui::SetNextItemWidth(220);
    const char *current = "";
    uim_page_get_key(g.manager, g.page, &current);
    if (ImGui::BeginCombo("##page", current ? current : "page")) {
        for (size_t i = 0; i < pages; ++i) {
            uim_PageId p = uim_PAGE_INVALID;
            const char *key = "";
            uim_page_get_at(g.manager, i, &p);
            uim_page_get_key(g.manager, p, &key);
            bool selected = p == g.page;
            if (ImGui::Selectable(key, selected)) {
                g.page = p;
                g.root = page_root(g.manager, p);
                g.selected_instance = 0;
                g.viewport_initialized = false;
    g.auto_fit = true;
                if (g.editor) uir_editor_set_active_page(g.editor, p);
            }
        }
        ImGui::EndCombo();
    }
    ImGui::SameLine();
    if (ImGui::Button("+ Page")) {
        char key[32];
        for (int i = 1; i < 1000; ++i) {
            std::snprintf(key, sizeof(key), "page_%d", i);
            uim_PageId existing = uim_PAGE_INVALID;
            if (uim_page_find(g.manager, key, &existing) != uim_OK) break;
        }
        uim_PageId p = uim_PAGE_INVALID;
        if (uim_page_create(g.manager, key, &p) == uim_OK) {
            g.page = p;
            g.root = create_node("screen", 0, {0, 0, 960, 600}, uim_COMPONENT_PANEL);
            g.viewport_initialized = false;
    g.auto_fit = true;
            g.dirty = true;
            if (g.editor) uir_editor_set_active_page(g.editor, p);
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("- Page") && pages > 1u) g.confirm_delete_page = true;
    if (g.confirm_delete_page) ImGui::OpenPopup("delete_page");
    if (ImGui::BeginPopupModal("delete_page", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Delete page \"%s\" and all of its nodes?",
                    current ? current : "");
        if (ImGui::Button("Delete", ImVec2(100, 0))) {
            uim_page_destroy(g.manager, g.page);
            uim_PageId first = uim_PAGE_INVALID;
            (void)uim_page_get_at(g.manager, 0u, &first);
            g.page = first;
            g.root = page_root(g.manager, first);
            g.selected_instance = 0;
            g.viewport_initialized = false;
            g.auto_fit = true;
            g.dirty = true;
            if (g.editor) uir_editor_set_active_page(g.editor, first);
            g.confirm_delete_page = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(100, 0))) {
            g.confirm_delete_page = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
    ImGui::SameLine();
    if (ImGui::Button(g.playing ? "Stop (F5)" : "Play (F5)")) {
        if (g.playing) stop_play(); else start_play();
    }
    ImGui::SameLine();
    if (ImGui::Button("Build (F6)")) build_package();
    ImGui::SameLine();
    ImGui::Text("%s%s", g.project_path.empty() ? "(unsaved)"
                                                : fs::path(g.project_path).filename().string().c_str(),
                g.dirty ? "  *" : "");
    if (ImGui::IsItemHovered() && !g.project_path.empty())
        ImGui::SetTooltip("%s", g.project_path.c_str());
}

void build_default_dock_layout(ImGuiID dock_id, const ImGuiViewport *vp) {
    ImGuiID center = dock_id;
    ImGuiID left = 0, right = 0, bottom = 0;
    ImGui::DockBuilderRemoveNode(dock_id);
    ImGui::DockBuilderAddNode(dock_id, ImGuiDockNodeFlags_DockSpace);
    ImGui::DockBuilderSetNodeSize(dock_id, vp->WorkSize);

    left = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 0.22f, &left, &center);
    right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 0.32f, &right, &center);
    bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, 0.24f, &bottom, &center);

    ImGui::DockBuilderDockWindow("Hierarchy", left);
    ImGui::DockBuilderDockWindow("Inspector", right);
    ImGui::DockBuilderDockWindow("Console", bottom);
    ImGui::DockBuilderDockWindow("Viewport", center);
    ImGui::DockBuilderFinish(dock_id);
    /* A single-window dock node otherwise keeps a tab bar that covers the first
     * row of every panel and desynchronises drawing from item hit rectangles.
     * Unity-like fixed panels do not need per-window tabs. */
    for (ImGuiID node_id : {dock_id, left, right, bottom, center}) {
        if (ImGuiDockNode *node = ImGui::DockBuilderGetNode(node_id))
            node->LocalFlags |= ImGuiDockNodeFlags_NoTabBar;
    }
}

void draw_ui() {
    HWND owner = (HWND)zcsr_surface_native_handle(zcsr_runtime_shell_surface());
    draw_menu(owner);
    handle_shortcuts(owner);

    ImGuiViewport *vp = ImGui::GetMainViewport();
    ImGuiID dock_id = ImGui::GetID("ZcsrEditorDock");
    if (g.first_layout) {
        build_default_dock_layout(dock_id, vp);
        g.first_layout = false;
    }
    ImGui::DockSpaceOverViewport(dock_id, vp, ImGuiDockNodeFlags_PassthruCentralNode);

    if (g.show_hierarchy) draw_hierarchy();
    if (g.show_viewport) draw_viewport();
    if (g.show_inspector) draw_inspector();
    if (g.show_console) draw_console();
    draw_rename_popup();
}

void apply_editor_input(EditorApp *app, int cw, int ch) {
    ImGuiIO &io = ImGui::GetIO();
    double now = (double)GetTickCount64() / 1000.0;
    io.DeltaTime = g_last_time > 0.0 ? (float)std::clamp(now - g_last_time, 1.0 / 1000.0, 0.25) : 1.0f / 60.0f;
    g_last_time = now;
    io.DisplaySize = ImVec2((float)cw, (float)ch);
    io.MousePos = ImVec2(app->mouse_x, app->mouse_y);
    io.AddMousePosEvent(app->mouse_x, app->mouse_y);
    static uint32_t prev_buttons = 0;
    for (int b = 0; b < 3; ++b) {
        uint32_t bit = 1u << b;
        bool down = (app->mouse_buttons & bit) != 0;
        bool was = (prev_buttons & bit) != 0;
        bool pressed = (app->mouse_pressed & bit) != 0;
        bool released = (app->mouse_released & bit) != 0;
        if (pressed) io.AddMouseButtonEvent(b, true);
        if (released) io.AddMouseButtonEvent(b, false);
        if (!pressed && !released && down != was) io.AddMouseButtonEvent(b, down);
    }
    prev_buttons = app->mouse_buttons;
    app->mouse_pressed = 0;
    app->mouse_released = 0;
    if (app->wheel_delta) io.AddMouseWheelEvent(0.0f, (float)app->wheel_delta);
    app->wheel_delta = 0;
    bool ctrl = zcsr_runtime_shell_key_down(ZCSR_KEY_CTRL);
    bool shift = zcsr_runtime_shell_key_down(ZCSR_KEY_SHIFT);
    bool alt = zcsr_runtime_shell_key_down(ZCSR_KEY_ALT);
    io.AddKeyEvent(ImGuiMod_Ctrl, ctrl);
    io.AddKeyEvent(ImGuiMod_Shift, shift);
    io.AddKeyEvent(ImGuiMod_Alt, alt);
    for (ImGuiKey held : app->imgui_keys_down) {
        io.AddKeyEvent(held, false);
    }
    app->imgui_keys_down.clear();
    for (int code : app->keys) {
        ImGuiKey key = ImGuiKey_None;
        if (code >= ZCSR_KEY_A && code <= ZCSR_KEY_Z) {
            key = (ImGuiKey)(ImGuiKey_A + (code - ZCSR_KEY_A));
        } else if (code >= ZCSR_KEY_0 && code <= ZCSR_KEY_9) {
            key = (ImGuiKey)(ImGuiKey_0 + (code - ZCSR_KEY_0));
        } else if (code >= ZCSR_KEY_F1 && code <= ZCSR_KEY_F12) {
            key = (ImGuiKey)(ImGuiKey_F1 + (code - ZCSR_KEY_F1));
        } else {
            switch (code) {
                case ZCSR_KEY_ESCAPE: key = ImGuiKey_Escape; break;
                case ZCSR_KEY_TAB: key = ImGuiKey_Tab; break;
                case ZCSR_KEY_ENTER: key = ImGuiKey_Enter; break;
                case ZCSR_KEY_SPACE: key = ImGuiKey_Space; break;
                case ZCSR_KEY_BACKSPACE: key = ImGuiKey_Backspace; break;
                case ZCSR_KEY_DELETE: key = ImGuiKey_Delete; break;
                case ZCSR_KEY_INSERT: key = ImGuiKey_Insert; break;
                case ZCSR_KEY_HOME: key = ImGuiKey_Home; break;
                case ZCSR_KEY_END: key = ImGuiKey_End; break;
                case ZCSR_KEY_PAGE_UP: key = ImGuiKey_PageUp; break;
                case ZCSR_KEY_PAGE_DOWN: key = ImGuiKey_PageDown; break;
                case ZCSR_KEY_ARROW_LEFT: key = ImGuiKey_LeftArrow; break;
                case ZCSR_KEY_ARROW_RIGHT: key = ImGuiKey_RightArrow; break;
                case ZCSR_KEY_ARROW_UP: key = ImGuiKey_UpArrow; break;
                case ZCSR_KEY_ARROW_DOWN: key = ImGuiKey_DownArrow; break;
                case ZCSR_KEY_CTRL: key = ImGuiKey_LeftCtrl; break;
                case ZCSR_KEY_SHIFT: key = ImGuiKey_LeftShift; break;
                case ZCSR_KEY_ALT: key = ImGuiKey_LeftAlt; break;
                case ZCSR_KEY_GUI: key = ImGuiKey_LeftSuper; break;
                default: break;
            }
        }
        if (key != ImGuiKey_None) {
            io.AddKeyEvent(key, true);
            app->imgui_keys_down.push_back(key);
        }
    }
    app->keys.clear();
    if (!app->text_input.empty()) {
        io.AddInputCharactersUTF8(app->text_input.c_str());
        app->text_input.clear();
    }
}

void frame(zcsr_gl_renderer *renderer, int cw, int ch, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app || !renderer) return;
    app->renderer = renderer;
    app->window_w = cw;
    app->window_h = ch;

    if (app->playing && app->manager && app->page != uim_PAGE_INVALID) {
        uim_runtime_tick(app->manager, app->page, ImGui::GetIO().DeltaTime > 0 ? ImGui::GetIO().DeltaTime : 1.0 / 60.0);
        int goto_page = uim_runtime_take_goto_request();
        if (goto_page > 0) {
            uim_PageId next = uim_PAGE_INVALID;
            size_t pages = 0;
            uim_page_count(app->manager, &pages);
            if ((size_t)goto_page <= pages && uim_page_get_at(app->manager, (size_t)goto_page - 1, &next) == uim_OK) {
                app->page = next;
                app->root = page_root(app->manager, next);
                app->viewport_initialized = false;
                if (app->editor) uir_editor_set_active_page(app->editor, next);
                uim_runtime_begin(app->manager, next);
            }
        }
    }

    render_page_to_texture();
    if (g.playing && !g.play_first_logged) {
        char buf[64];
        snprintf(buf, sizeof(buf), "play first frame %.1f ms",
                 (double)GetTickCount64() - g.play_start_ms);
        log_line(buf);
        g.play_first_logged = true;
    }

    apply_editor_input(app, cw, ch);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    draw_ui();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

void pointer_cb(int x, int y, uint32_t buttons, uint32_t pressed, uint32_t released, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return;
    app->mouse_x = (float)x;
    app->mouse_y = (float)y;
    app->mouse_buttons = buttons;
    app->mouse_pressed |= pressed;
    app->mouse_released |= released;


}

void text_cb(const char *utf8, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (app && utf8) app->text_input += utf8;
}

bool key_cb(int key, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return false;
    app->keys.push_back(key);
    // Editor owns Escape/S while active; otherwise the shell would leave the module
    // or open its runtime settings page behind the editor.
    return key == ZCSR_KEY_ESCAPE || key == ZCSR_KEY_S;
}

bool init_cb(zcsr_gl_renderer *renderer, int cw, int ch, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return false;
    app->renderer = renderer;
    app->window_w = cw;
    app->window_h = ch;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImFontConfig fc{};
    fc.OversampleH = 2;
    fc.OversampleV = 2;
    const char *font_path = "C:\\Windows\\Fonts\\Deng.ttf";
    ImFont *font = nullptr;
    if (fs::exists(font_path)) {
        font = io.Fonts->AddFontFromFileTTF(font_path, 16.0f, &fc, io.Fonts->GetGlyphRangesChineseFull());
    }
    if (!font) io.Fonts->AddFontDefault();
    ImGui::StyleColorsDark();
    ImGuiStyle &style = ImGui::GetStyle();
    style.WindowRounding = 4.0f;
    style.FrameRounding = 3.0f;
    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize = 0.0f;
    style.ItemSpacing.y = 4.0f;
    ImGui_ImplOpenGL3_Init("#version 130");
    g_last_time = (double)GetTickCount64() / 1000.0;

    if (!new_document()) log_line("initial document creation failed");
    // Start with the bundled rule demo when it exists, otherwise keep a clean page.
    // The exe lives in build_main/Release; the demo project is in build_main/demo.
    fs::path exe_dir = fs::path(exe_path()).parent_path();
    std::string demo = (exe_dir.parent_path() / "demo" / "rule_demo.uireproj").string();
    if (fs::exists(demo)) load_project(demo);
    return true;
}

void shutdown_cb(zcsr_gl_renderer *renderer, void *user) {
    (void)renderer;
    (void)user;
    stop_play();
    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    destroy_document();
}

bool close_request_cb(void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return true;
    if (!app->dirty) return true;
    zcsr_surface *surface = zcsr_runtime_shell_surface();
    HWND owner = surface ? (HWND)zcsr_surface_native_handle(surface) : nullptr;
    int choice = MessageBoxW(owner,
                             L"Unsaved changes.\n\nYes: save and exit\nNo: discard and exit\nCancel: stay",
                             L"ZCSR Editor", MB_YESNOCANCEL | MB_ICONWARNING);
    if (choice == IDYES) return save_project(false);
    if (choice == IDNO) return true;
    return false;
}

} // namespace

extern "C" void runtime(void) {
    zcsr_runtime_shell_module mod{};
    mod.title = "ZCSR Editor";
    mod.user = &g;
    mod.init = init_cb;
    mod.shutdown = shutdown_cb;
    mod.frame = frame;
    mod.pointer = pointer_cb;
    mod.text = text_cb;
    mod.key = key_cb;
    mod.close_request = close_request_cb;
    (void)zcsr_window_game_run(&mod, 1, 1, nullptr);
}

#ifdef ZCSR_EDITOR_KEY_TEST
// Test-only hooks: drive the same apply_editor_input + handle_shortcuts path
// used by the real window loop, without an OpenGL renderer.
static uim_NodeId g_test_child = uim_NODE_INVALID;

extern "C" bool zcsr_editor_test_init(void) {
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.DisplaySize = ImVec2(960, 600);
    io.DeltaTime = 1.0f / 60.0f;
    // The real editor builds its font atlas through ImGui_ImplOpenGL3_Init.
    // The headless test must build the default atlas explicitly before NewFrame.
    unsigned char *pixels = nullptr;
    int atlas_w = 0, atlas_h = 0;
    io.Fonts->GetTexDataAsRGBA32(&pixels, &atlas_w, &atlas_h);
    return new_document();
}

extern "C" void zcsr_editor_test_shutdown(void) {
    destroy_document();
    ImGui::DestroyContext();
}

extern "C" void zcsr_editor_test_set_save_path(const char *path) {
    g.project_path = path ? path : "";
    g.dirty = true;
}

extern "C" int zcsr_editor_test_make_child(void) {
    g_test_child = create_node("child", g.root, {10, 10, 100, 40}, uim_COMPONENT_PANEL);
    if (g_test_child != uim_NODE_INVALID) select_node(g_test_child, false);
    return (int)g_test_child;
}

extern "C" int zcsr_editor_test_child_alive(void) {
    uim_NodeInfo info{};
    return (g_test_child != uim_NODE_INVALID &&
            uim_node_get(g.manager, g_test_child, &info) == uim_OK) ? 1 : 0;
}

extern "C" int zcsr_editor_test_node_count(void) {
    size_t count = 0;
    if (!g.manager || g.page == uim_PAGE_INVALID) return -1;
    return uim_page_get_node_count(g.manager, g.page, &count) == uim_OK ? (int)count : -1;
}

extern "C" int zcsr_editor_test_playing(void) { return g.playing ? 1 : 0; }
extern "C" int zcsr_editor_test_dirty(void) { return g.dirty ? 1 : 0; }

extern "C" void zcsr_editor_test_open_rename(void) {
    if (g_test_child != uim_NODE_INVALID) begin_rename(g_test_child);
}

extern "C" void zcsr_editor_test_set_rename_name(const char *name) {
    if (name) std::snprintf(g.rename_buf, sizeof(g.rename_buf), "%s", name);
}

extern "C" int zcsr_editor_test_rename_enter(void) {
    // Frame 1 opens the modal and requests focus on the input.
    g.keys.clear();
    apply_editor_input(&g, 960, 600);
    ImGui::NewFrame();
    draw_rename_popup();
    ImGui::EndFrame();
    // Frame 2 lets ImGui process the nav focus request.
    apply_editor_input(&g, 960, 600);
    ImGui::NewFrame();
    draw_rename_popup();
    ImGui::EndFrame();
    // Frames 3-5: press, release, press so the active InputText sees a real edge.
    for (int i = 0; i < 3; ++i) {
        g.keys.clear();
        if (i != 1) g.keys.push_back(ZCSR_KEY_ENTER);
        apply_editor_input(&g, 960, 600);
        ImGui::NewFrame();
        draw_rename_popup();
        ImGui::EndFrame();
        if (!g.rename_open) break;
    }
    return g.rename_open ? 0 : 1;
}

extern "C" void zcsr_editor_test_child_key(char *out, int cap) {
    uim_NodeInfo info{};
    if (!out || cap <= 0) return;
    out[0] = 0;
    if (g_test_child == uim_NODE_INVALID ||
        uim_node_get(g.manager, g_test_child, &info) != uim_OK ||
        !info.stable_key) return;
    std::snprintf(out, (size_t)cap, "%s", info.stable_key);
}

extern "C" int zcsr_editor_test_owns_key(int key) {
    return key_cb(key, &g) ? 1 : 0;
}

extern "C" void zcsr_editor_test_begin_key(int key, int ctrl, int shift) {
    g.keys.clear();
    // Drive the same module key callback used by zcsr_window_game_run(); do not
    // inject directly into EditorApp::keys or this test stops covering the
    // runtime-shell -> module key_cb boundary.
    (void)key_cb(key, &g);
    apply_editor_input(&g, 960, 600);
    ImGuiIO &io = ImGui::GetIO();
    io.AddKeyEvent(ImGuiMod_Ctrl, ctrl != 0);
    io.AddKeyEvent(ImGuiMod_Shift, shift != 0);
    ImGui::NewFrame();
}

extern "C" void zcsr_editor_test_dispatch(void) {
    handle_shortcuts(nullptr);
    ImGui::EndFrame();
}

extern "C" void zcsr_editor_test_idle(void) {
    g.keys.clear();
    apply_editor_input(&g, 960, 600);
    ImGui::NewFrame();
    handle_shortcuts(nullptr);
    ImGui::EndFrame();
}
#endif
