﻿/*
 * ZCSR Editor workspace module.
 *
 * This module is hosted by zcsr_runtime_shell. The runtime host owns the one
 * OS window, surface, input pump and main loop. This file owns authoring UI:
 *   - Dear ImGui chrome and docking
 *   - canvas viewport, picking, gestures and overlay presentation
 *   - Inspector presentation over UIM component instance values
 *   - UI document editing, asset browsing, editor commands and Run
 *
 * UIM owns the smallest UI component registry, component instances and
 * property values. It does not own the UI document; the editor/project owns
 * the document. The setting page manager owns setting page composition.
 * Engine owns rendering, input, assets, textures and the 2.5D scene primitives.
 * This file must not create a second OS window, surface, main loop, document
 * model, component runtime or renderer.
 */
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_opengl3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <array>
#include <cctype>
#include <cmath>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "ui_editor.h"
#include "editor_scene_io.h"
#include "editor_scene_authoring.h"
#include "editor_scene_prefab.h"
#include "editor_scene_history.h"
#include "zcsr/ui_text_edit.h"
#include "editor_project_container.h"
#include "ui_project_browser.h"
#include "ui_editor_file_service_host.h"
#include "uim_component_registry.h"
#include "uim_project.h"
#include "uim_asset_registry.h"

extern "C" {
#include "editor_host.h"
#include "uim_component_runtime.h"
#include "uim_zcsr_runtime_bridge.h"
#include "uim_text_input.h"
#include "zcsr_runtime_shell.h"
#include "zcsr/platform.h"
#include "zcsr/gl_render.h"
#include "zcsr/input.h"
#include "zcsr/clock.h"
#include "zcsr/camera3d.h"
#include "zcsr/scene.h"
#include "zcsr/scene_camera.h"
#include "zcsr/scene_render.h"
}

#ifndef ZCSR_EDITOR_BINARY_DIR
#define ZCSR_EDITOR_BINARY_DIR "."
#endif
#ifndef ZCSR_CMAKE_COMMAND
#define ZCSR_CMAKE_COMMAND "cmake"
#endif
#ifndef ZCSR_RUN_TARGET
#define ZCSR_RUN_TARGET "zcsr_player"
#endif
#ifndef ZCSR_RUN_EXE
#define ZCSR_RUN_EXE "zcsr_player.exe"
#endif
#ifndef ZCSR_RUN_CONFIG_DIR
#define ZCSR_RUN_CONFIG_DIR "Debug"
#endif

/* The editor's "primary" shortcut modifier follows the host platform:
 * Cmd on macOS, Ctrl on Windows/Linux.  Keep it in one place so shortcuts,
 * multi-select and menu labels cannot drift again. */
#if defined(__APPLE__)
#  define ZCSR_EDITOR_PRIMARY_LABEL "Cmd+"
#else
#  define ZCSR_EDITOR_PRIMARY_LABEL "Ctrl+"
#endif

#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <map>
#include <memory>
#include <string>
#include <vector>

extern "C" bool zcsr_page_render(zcsr_gl_renderer *renderer,
                                 const UIM_ComponentManager *manager,
                                 uim_PageId page,
                                 int view_x, int view_y,
                                 int view_w, int view_h,
                                 const char *project_root);

namespace {

namespace fs = std::filesystem;

/* Headless key-contract tests need to exercise both primary modifiers on
 * Windows. -1 = platform default; 0 = Ctrl; 1 = Cmd/Super. */
static int g_test_primary_gui = -1;
constexpr size_t kAssetCapacity = 128u;

struct TextSnapshot {
    std::string text;
    size_t cursor = 0u;
    size_t anchor = 0u;
};

struct TextHistory {
    std::vector<TextSnapshot> undo;
    std::vector<TextSnapshot> redo;
};

bool utf8_word_byte(const char *text, size_t pos) {
    unsigned char c = (unsigned char)text[pos];
    if (c >= 0x80u) return true;   /* treat a CJK run as one word */
    return std::isalnum(c) || c == '_';
}

static bool project_3d_node(void *user, const UIM_ComponentManager *manager,
                            const uim_NodeInfo *info, uim_Rect *out_rect) {
    (void)user;
    return uim_zcsr_runtime_bridge_project_node_rect(manager, info, out_rect);
}

struct EditorApp {
    UIM_ComponentManager *manager = nullptr;
    uim_Editor *editor = nullptr;
    uim_ComponentRegistry *registry = nullptr;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = uim_NODE_INVALID;
    std::string project_path;
    bool dirty = false;
    bool playing = false;
    bool play_first_logged = false;
    double play_start_ms = 0.0;
    bool first_layout = true;
    bool show_console = true;
    bool show_hierarchy = true;
    bool show_inspector = true;
    bool show_viewport = true;
    bool show_project = true;
    bool show_game = false;
    int game_resolution = 1;          /* 0 fit, 1 1280x720, 2 1920x1080, 3 960x540 */
    bool game_stats = true;
    bool show_preferences = false;
    float canvas_grid_size = 8.0f;
    bool canvas_show_grid = true;
    bool canvas_snap = true;
    float zoom_step = 1.1f;
    float auto_save_seconds = 120.0f;
    double last_autosave_ms = 0.0;

    /* Project/Assets panel. The tree, selection and file operations live in the
     * C11 ui_project_browser domain; this C++ object only presents them. */
    uim_ProjectBrowser *project_browser = nullptr;
    uim_FileService project_file_service{};
    zcsr_file_service_t *project_file_backend = nullptr;
    std::string project_browser_root;
    uim_TextInput project_name_text{};
    int project_name_mode = 0;       /* 0 none, 1 new folder, 2 rename */
    bool project_delete_confirm = false;
    uim_TextInput project_filter_text{};
    uim_TextInput console_filter_text{};
    uim_TextInput hierarchy_filter_text{};

    /* Project assets are owned by UIM's C11 asset registry. This object only
     * presents the fixed record table and copies files into assets/. */
    uir_AssetRecord asset_records[kAssetCapacity]{};
    uir_AssetRegistry assets{};
    std::string asset_root;
    int selected_asset = -1;

    zcsr_gl_renderer *renderer = nullptr;
    editor_host *host = nullptr;
    int window_w = 0, window_h = 0;
    zcsr_gl_texture page_texture = 0;
    int texture_w = 0, texture_h = 0;
    UIM_ComponentManager *texture_manager = nullptr;
    uim_PageId texture_page = uim_PAGE_INVALID;

    float zoom = 1.0f;
    float pan_x = 0.0f, pan_y = 0.0f;
    bool viewport_initialized = false;
    bool auto_fit = true;
    float last_view_w = 0.0f, last_view_h = 0.0f;
    bool component_picker_open = false;    bool confirm_delete_page = false;

    bool dragging = false;
    bool panning = false;
    bool gizmo_dragging = false;
    int gizmo_axis = -1;
    int gizmo_mode = 0;              /* 0 move, 1 rotate, 2 scale */
    int gizmo_space = 0;             /* 0 world, 1 local */
    bool gizmo_snap = false;
    float gizmo_snap_step = 0.5f;
    float gizmo_rotate_step = 15.0f;
    float gizmo_scale_step = 0.1f;
    float multi_move_dx = 0.0f, multi_move_dy = 0.0f;
    ImVec2 gizmo_start{0, 0};
    uim_NodeId gizmo_nodes[16]{};
    uim_Transform3 gizmo_orig[16]{};
    size_t gizmo_count = 0;
    size_t drag_undo_before = 0;
    ImVec2 drag_prev{0, 0};
    uint32_t drag_mods = 0;

    /* Scene mode is a second authoring view over the same runtime host, not a
     * second editor, window or document model. */
    bool scene_mode = false;
    zcsr_scene scene{};
    std::string scene_path;
    bool scene_dirty = false;
    zcsr_editor_scene_history *scene_history = nullptr;
    uint64_t scene_saved_hash = 0;
    bool scene_gesture_active = false;
    zcsr_entity_id scene_selected = 0;
    bool scene_dragging = false;
    ImVec2 scene_drag_prev{0, 0};
    float scene_drag_x = 0.0f, scene_drag_z = 0.0f;
    int scene_resize_handle = -1;
    zcsr_scene_point scene_resize_quad[4]{};
    bool scene_panning = false;
    ImVec2 scene_pan_prev{0, 0};
    bool scene_gizmo_dragging = false;
    int scene_gizmo_axis = -1;
    ImVec2 scene_gizmo_start{0, 0};
    float scene_gizmo_x = 0.0f, scene_gizmo_y = 0.0f, scene_gizmo_z = 0.0f;
    float scene_gizmo_rot = 0.0f, scene_gizmo_w = 0.0f, scene_gizmo_h = 0.0f;

    uim_ComponentInstanceId selected_instance = 0;
    uim_NodeId rename_node = 0;
    uim_NodeId clipboard_node = 0;
    bool rename_open = false;
    bool rename_focus = false;
    /* Every editable text in the editor is one uim_TextInput: caret,
     * selection, UTF-8 boundaries and maxLength come from UIM/engine's shared
     * state machine, never from ImGui's InputText. */
    uim_TextInput rename_text{};
    uim_TextInput component_filter_text{};
    uim_TextInput node_name_text{};
    uim_NodeId node_name_node = 0;
    std::string focused_field;            /* widget id of the active field */
    bool field_hovered_this_frame = false; /* blur when a click misses every field */
    std::vector<std::string> log;
    std::map<uint64_t, std::unique_ptr<uim_TextInput>> text_fields;
    std::map<std::string, TextHistory> text_history;

    // Input collected by shell callbacks.
    float mouse_x = 0.0f, mouse_y = 0.0f;
    uint32_t mouse_buttons = 0;
    uint32_t mouse_pressed = 0, mouse_released = 0;

    int wheel_delta = 0;
    std::string text_input;
    std::vector<int> keys;
    // Keys sent down to ImGui this frame; released at the start of the next
    // frame so ImGui observes a real down edge instead of down+up in one queue.
    std::vector<ImGuiKey> imgui_keys_down;
};

EditorApp g;
uint64_t g_node_serial = 1;
double g_last_time = 0.0;
int g_smoke_frames = 0;
int g_frame_count = 0;

void log_line(const std::string &s) {
    g.log.push_back(s);
    if (g.log.size() > 64) g.log.erase(g.log.begin());
}

std::string exe_path() {
    char buf[32768];
    if (!g.host || !editor_host_executable_path(g.host, buf, sizeof(buf))) return {};
    return std::string(buf);
}

double now_ms() {
    return (double)zcsr_clock_now_ns() / 1000000.0;
}

/* ---- the one editable text widget ----------------------------------------
 * ImGui is only the layout/hit-test/glyph layer here: the edit state is a
 * uim_TextInput, fed through the same zcsr/ui_text_edit.h state machine the
 * engine widget and UIM use. That is why there is no ImGui::InputText left in
 * this file — the editor cannot grow a fourth copy of caret/selection rules. */
struct UimFieldResult {
    bool changed = false;    /* text bytes changed */
    bool submitted = false;  /* Enter */
    bool cancelled = false;  /* Escape */
};

static std::string field_value(const uim_TextInput &input) {
    const char *s = nullptr;
    size_t n = 0;
    if (uim_text_input_get_text(&input, &s, &n) != uim_OK || !s) return {};
    return std::string(s, n);
}

static void field_set_external(uim_TextInput *input, const std::string &value) {
    if (field_value(*input) == value) return;   /* keep the caret where it is */
    (void)uim_text_input_set_text(input, value.c_str(), value.size());
}

/* Programmatic set that trims an over-long value at a code point boundary
 * instead of failing, for values the document already owns. */
static void field_set_clamped(uim_TextInput *input, const std::string &value) {
    size_t n = value.size();
    if (n > input->max_bytes) {
        n = input->max_bytes;
        while (n > 0 && ((unsigned char)value[n] & 0xC0u) == 0x80u) n--;
    }
    if (field_value(*input).size() == n &&
        memcmp(field_value(*input).data(), value.data(), n) == 0) return;
    (void)uim_text_input_set_text(input, value.data(), n);
}

static bool field_is_focused(const char *id) {
    return !g.focused_field.empty() && g.focused_field == id;
}

/* Headless test init builds the document without init_cb, so a field may still
 * be zeroed. Give it its policy once, before any edit or programmatic set. */
static void ensure_field(uim_TextInput *input, size_t max_bytes) {
    if (!input) return;
    if (input->max_bytes == 0u || input->max_bytes > (size_t)uim_TEXT_INPUT_MAX_BYTES)
        (void)uim_text_input_init(input, max_bytes);
}

static void commit_node_name_field();   /* defined below, needs the inspector state */
void sync_project_browser();            /* defined with the Project panel */
void reset_assets();
void load_assets();
bool save_assets();
bool ensure_project_browser();
static std::string open_asset_dialog();

static void blur_text_field() {
    if (g.focused_field.empty()) return;
    std::string was = g.focused_field;
    g.focused_field.clear();
    if (was == "node_name") commit_node_name_field();
}

static size_t text_offset_at_x(const char *txt, size_t len, float x) {
    size_t pos = 0;
    float prev = 0.0f;
    if (!txt || x <= 0.0f) return 0;
    while (pos < len) {
        size_t next = pos + 1u;
        while (next < len && ((unsigned char)txt[next] & 0xC0u) == 0x80u) next++;
        float w = ImGui::CalcTextSize(txt + pos, txt + next).x;
        if (x < prev + w * 0.5f) break;
        prev += w;
        pos = next;
    }
    return pos;
}

static TextSnapshot text_snapshot(const uim_TextInput *input, const char *text, size_t len) {
    TextSnapshot s;
    s.text.assign(text ? text : "", len);
    s.cursor = input->cursor;
    s.anchor = input->anchor;
    return s;
}

static void text_restore(uim_TextInput *input, const TextSnapshot &s) {
    (void)uim_text_input_set_text(input, s.text.c_str(), s.text.size());
    size_t cursor = std::min(s.cursor, s.text.size());
    size_t anchor = std::min(s.anchor, s.text.size());
    (void)uim_text_input_set_selection(input, anchor, cursor);
}

static void text_push_undo(TextHistory &history, const TextSnapshot &before) {
    history.undo.push_back(before);
    if (history.undo.size() > 64u) history.undo.erase(history.undo.begin());
    history.redo.clear();
}

/* width <= 0 means "fill the remaining row". */
static UimFieldResult draw_uim_text_field(const char *id, uim_TextInput *input,
                                          float width, const char *hint,
                                          bool take_focus) {
    UimFieldResult r{};
    ImGuiIO &io = ImGui::GetIO();
    ImGui::PushID(id);
    if (width <= 0.0f) width = ImGui::GetContentRegionAvail().x;
    if (width < 40.0f) width = 40.0f;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float h = ImGui::GetFrameHeight();
    ImGui::InvisibleButton("##uimfield", ImVec2(width, h));
    bool hovered = ImGui::IsItemHovered();
    if (hovered) g.field_hovered_this_frame = true;
    if (ImGui::IsItemClicked() || take_focus) g.focused_field = id;
    bool focused = field_is_focused(id);

    const char *txt = nullptr;
    size_t len = 0;
    (void)uim_text_input_get_text(input, &txt, &len);
    if (!txt) txt = "";
    TextHistory &history = g.text_history[id];
    TextSnapshot before = focused ? text_snapshot(input, txt, len) : TextSnapshot{};
    bool history_handled = false;
    float caret_x = ImGui::CalcTextSize(txt, txt + input->cursor).x;
    float scroll = 0.0f;
    if (caret_x > width - 12.0f) scroll = caret_x - (width - 12.0f);
    if (scroll < 0.0f) scroll = 0.0f;
    ImVec2 tp(pos.x + 6.0f - scroll, pos.y + (h - ImGui::GetTextLineHeight()) * 0.5f);

    if (ImGui::IsItemClicked()) {
        size_t at = text_offset_at_x(txt, len, io.MousePos.x - pos.x - 6.0f + scroll);
        if (io.KeyShift) (void)uim_text_input_set_selection(input, input->anchor, at);
        else (void)uim_text_input_set_cursor(input, at);
    }
    if (hovered && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
        size_t at = text_offset_at_x(txt, len, io.MousePos.x - pos.x - 6.0f + scroll);
        size_t start = at, end = at;
        while (start > 0u) {
            size_t prev = zcsr_text_utf8_prev(txt, start);
            if (!utf8_word_byte(txt, prev)) break;
            start = prev;
        }
        while (end < len) {
            if (!utf8_word_byte(txt, end)) break;
            end = zcsr_text_utf8_next(txt, len, end);
        }
        (void)uim_text_input_set_selection(input, start, end);
        g.focused_field = id;
    }
    if (focused && ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
        size_t at = text_offset_at_x(txt, len, io.MousePos.x - pos.x - 6.0f + scroll);
        (void)uim_text_input_set_selection(input, input->anchor, at);
    }

    if (focused && ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows)) {
        if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Z)) {
            if (!history.undo.empty()) {
                TextSnapshot cur = text_snapshot(input, txt, len);
                TextSnapshot prev = history.undo.back();
                history.undo.pop_back();
                history.redo.push_back(cur);
                text_restore(input, prev);
                history_handled = true;
                r.changed = true;
            }
            io.InputQueueCharacters.resize(0);
        } else if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Y)) {
            if (!history.redo.empty()) {
                TextSnapshot cur = text_snapshot(input, txt, len);
                TextSnapshot next = history.redo.back();
                history.redo.pop_back();
                history.undo.push_back(cur);
                text_restore(input, next);
                history_handled = true;
                r.changed = true;
            }
            io.InputQueueCharacters.resize(0);
        } else if (ImGui::IsKeyPressed(ImGuiKey_Enter)) {
            r.submitted = true;
            g.focused_field.clear();
            focused = false;
        } else if (ImGui::IsKeyPressed(ImGuiKey_Escape)) {
            r.cancelled = true;
            g.focused_field.clear();
            focused = false;
        } else {
            if (ImGui::IsKeyPressed(ImGuiKey_Backspace) &&
                uim_text_input_backspace(input) == uim_OK) r.changed = true;
            if (ImGui::IsKeyPressed(ImGuiKey_Delete) &&
                uim_text_input_delete_forward(input) == uim_OK) r.changed = true;
            if (ImGui::IsKeyPressed(ImGuiKey_LeftArrow)) {
                if (io.KeyShift) (void)uim_text_input_move_cursor_extend(input, -1);
                else (void)uim_text_input_move_cursor(input, -1);
            }
            if (ImGui::IsKeyPressed(ImGuiKey_RightArrow)) {
                if (io.KeyShift) (void)uim_text_input_move_cursor_extend(input, 1);
                else (void)uim_text_input_move_cursor(input, 1);
            }
            if (ImGui::IsKeyPressed(ImGuiKey_Home)) {
                if (io.KeyShift) (void)uim_text_input_set_selection(input, input->anchor, 0u);
                else (void)uim_text_input_cursor_home(input);
            }
            if (ImGui::IsKeyPressed(ImGuiKey_End)) {
                if (io.KeyShift) (void)uim_text_input_set_selection(input, input->anchor, input->length);
                else (void)uim_text_input_cursor_end(input);
            }
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_A)) (void)uim_text_input_select_all(input);
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_C)) {
                size_t start = 0, len_sel = 0;
                if (uim_text_input_selection(input, &start, &len_sel) == uim_OK && len_sel > 0) {
                    std::string all = field_value(*input);
                    ImGui::SetClipboardText(all.substr(start, len_sel).c_str());
                }
            }
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_V)) {
                const char *clip = ImGui::GetClipboardText();
                /* Clipboard is a host concern; this is the host handing text in. */
                if (clip && *clip &&
                    uim_text_input_insert(input, clip, std::strlen(clip)) == uim_OK) r.changed = true;
            }
            for (ImWchar ch : io.InputQueueCharacters) {
                char utf8[5] = {0, 0, 0, 0, 0};
                int n;
                if (ch < 0x20) continue;   /* Enter/Escape/Tab travel the key path */
                n = ImTextCharToUtf8(utf8, (unsigned int)ch);
                if (n > 0 && uim_text_input_insert(input, utf8, (size_t)n) == uim_OK) r.changed = true;
            }
            io.InputQueueCharacters.resize(0);
        }
    }

    if (focused && r.changed && !history_handled)
        text_push_undo(history, before);

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 br(pos.x + width, pos.y + h);
    dl->AddRectFilled(pos, br,
                      ImGui::GetColorU32(focused ? ImGuiCol_FrameBgActive
                                                 : hovered ? ImGuiCol_FrameBgHovered
                                                           : ImGuiCol_FrameBg),
                      3.0f);
    dl->AddRect(pos, br,
                ImGui::GetColorU32(focused ? ImGuiCol_ButtonActive : ImGuiCol_Border), 3.0f);

    dl->PushClipRect(pos, br, true);
    if (len == 0 && hint && !focused)
        dl->AddText(tp, ImGui::GetColorU32(ImGuiCol_TextDisabled), hint);
    size_t sel_start = 0, sel_len = 0;
    if (uim_text_input_selection(input, &sel_start, &sel_len) == uim_OK && sel_len > 0) {
        float x0 = tp.x + ImGui::CalcTextSize(txt, txt + sel_start).x;
        float x1 = tp.x + ImGui::CalcTextSize(txt, txt + sel_start + sel_len).x;
        dl->AddRectFilled(ImVec2(x0, pos.y + 3.0f), ImVec2(x1, pos.y + h - 3.0f),
                          ImGui::GetColorU32(ImGuiCol_TextSelectedBg));
    }
    if (len > 0) dl->AddText(tp, ImGui::GetColorU32(ImGuiCol_Text), txt, txt + len);
    if (focused) {
        float cx = tp.x + ImGui::CalcTextSize(txt, txt + input->cursor).x;
        dl->AddLine(ImVec2(cx, pos.y + 3.0f), ImVec2(cx, pos.y + h - 3.0f),
                    ImGui::GetColorU32(ImGuiCol_Text), 1.0f);
        /* Custom fields do not call ImGui::InputText, so ImGui would never
         * publish an IME anchor. Publish the same platform data at the caret;
         * the platform IME owns the candidate window, the editor owns the
         * committed UTF-8 text. */
        ImGuiContext &ctx = *ImGui::GetCurrentContext();
        ctx.PlatformImeData.WantVisible = true;
        ctx.PlatformImeData.WantTextInput = true;
        ctx.PlatformImeData.InputPos = ImVec2(cx, pos.y);
        ctx.PlatformImeData.InputLineHeight = h;
    }
    dl->PopClipRect();
    ImGui::PopID();
    return r;
}

static size_t text_sub_offset_at_x(const char *txt, size_t start, size_t end, float x) {
    size_t pos = start;
    float prev = 0.0f;
    if (!txt || x <= 0.0f) return start;
    while (pos < end) {
        size_t next = pos + 1u;
        while (next < end && ((unsigned char)txt[next] & 0xC0u) == 0x80u) next++;
        float w = ImGui::CalcTextSize(txt + pos, txt + next).x;
        if (x < prev + w * 0.5f) break;
        prev += w;
        pos = next;
    }
    return pos;
}

/* Multiline variant of the one UIM text field. It keeps the same edit state;
 * Enter inserts a newline, Ctrl+Enter submits. The viewport shows the caret
 * line and clips long lines; there is no second text-edit implementation. */
static UimFieldResult draw_uim_text_area(const char *id, uim_TextInput *input,
                                         float width, float height, bool take_focus) {
    UimFieldResult r{};
    ImGuiIO &io = ImGui::GetIO();
    ImGui::PushID(id);
    if (width <= 0.0f) width = ImGui::GetContentRegionAvail().x;
    if (width < 80.0f) width = 80.0f;
    if (height < 50.0f) height = 50.0f;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##uimarea", ImVec2(width, height));
    bool hovered = ImGui::IsItemHovered();
    if (hovered) g.field_hovered_this_frame = true;
    if (ImGui::IsItemClicked() || take_focus) g.focused_field = id;
    bool focused = field_is_focused(id);

    const char *txt = nullptr;
    size_t len = 0;
    (void)uim_text_input_get_text(input, &txt, &len);
    if (!txt) txt = "";
    TextHistory &history = g.text_history[id];
    TextSnapshot before = focused ? text_snapshot(input, txt, len) : TextSnapshot{};
    bool history_handled = false;

    std::vector<std::pair<size_t, size_t>> lines;
    size_t line_start = 0;
    for (size_t i = 0; i <= len; ++i) {
        if (i == len || txt[i] == '\n') {
            lines.emplace_back(line_start, i);
            line_start = i + 1u;
            if (i == len) break;
        }
    }
    if (lines.empty()) lines.emplace_back(0u, 0u);

    float line_h = ImGui::GetTextLineHeight() + 2.0f;
    int visible_lines = std::max(1, (int)((height - 8.0f) / line_h));
    size_t caret_line = 0;
    for (size_t i = 0; i < lines.size(); ++i) {
        if (input->cursor >= lines[i].first && input->cursor <= lines[i].second) {
            caret_line = i;
            break;
        }
    }
    int first_line = std::max(0, (int)caret_line - visible_lines + 1);

    if (ImGui::IsItemClicked()) {
        int line = (int)((io.MousePos.y - pos.y - 4.0f) / line_h) + first_line;
        line = std::clamp(line, 0, (int)lines.size() - 1);
        size_t at = text_sub_offset_at_x(txt, lines[line].first, lines[line].second,
                                         io.MousePos.x - pos.x - 6.0f);
        if (io.KeyShift) (void)uim_text_input_set_selection(input, input->anchor, at);
        else (void)uim_text_input_set_cursor(input, at);
    }
    if (focused && ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
        int line = (int)((io.MousePos.y - pos.y - 4.0f) / line_h) + first_line;
        line = std::clamp(line, 0, (int)lines.size() - 1);
        size_t at = text_sub_offset_at_x(txt, lines[line].first, lines[line].second,
                                         io.MousePos.x - pos.x - 6.0f);
        (void)uim_text_input_set_selection(input, input->anchor, at);
    }

    if (hovered && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
        int line = (int)((io.MousePos.y - pos.y - 4.0f) / line_h) + first_line;
        line = std::clamp(line, 0, (int)lines.size() - 1);
        size_t at = text_sub_offset_at_x(txt, lines[line].first, lines[line].second,
                                         io.MousePos.x - pos.x - 6.0f);
        size_t start = at, end = at;
        while (start > 0u) {
            size_t prev = zcsr_text_utf8_prev(txt, start);
            if (!utf8_word_byte(txt, prev)) break;
            start = prev;
        }
        while (end < len) {
            if (!utf8_word_byte(txt, end)) break;
            end = zcsr_text_utf8_next(txt, len, end);
        }
        (void)uim_text_input_set_selection(input, start, end);
    }

    if (focused && ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows)) {
        if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Z)) {
            if (!history.undo.empty()) {
                TextSnapshot cur = text_snapshot(input, txt, len);
                TextSnapshot prev = history.undo.back();
                history.undo.pop_back();
                history.redo.push_back(cur);
                text_restore(input, prev);
                history_handled = true;
                r.changed = true;
            }
            io.InputQueueCharacters.resize(0);
        } else if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Y)) {
            if (!history.redo.empty()) {
                TextSnapshot cur = text_snapshot(input, txt, len);
                TextSnapshot next = history.redo.back();
                history.redo.pop_back();
                history.undo.push_back(cur);
                text_restore(input, next);
                history_handled = true;
                r.changed = true;
            }
            io.InputQueueCharacters.resize(0);
        } else if (ImGui::IsKeyPressed(ImGuiKey_Enter)) {
            if (io.KeyCtrl) {
                r.submitted = true;
                g.focused_field.clear();
                focused = false;
            } else if (uim_text_input_insert(input, "\n", 1u) == uim_OK) {
                r.changed = true;
            }
        } else if (ImGui::IsKeyPressed(ImGuiKey_Escape)) {
            r.cancelled = true;
            g.focused_field.clear();
            focused = false;
        } else {
            if (ImGui::IsKeyPressed(ImGuiKey_Backspace) &&
                uim_text_input_backspace(input) == uim_OK) r.changed = true;
            if (ImGui::IsKeyPressed(ImGuiKey_Delete) &&
                uim_text_input_delete_forward(input) == uim_OK) r.changed = true;
            if (ImGui::IsKeyPressed(ImGuiKey_LeftArrow)) {
                if (io.KeyShift) (void)uim_text_input_move_cursor_extend(input, -1);
                else (void)uim_text_input_move_cursor(input, -1);
            }
            if (ImGui::IsKeyPressed(ImGuiKey_RightArrow)) {
                if (io.KeyShift) (void)uim_text_input_move_cursor_extend(input, 1);
                else (void)uim_text_input_move_cursor(input, 1);
            }
            if (ImGui::IsKeyPressed(ImGuiKey_UpArrow) || ImGui::IsKeyPressed(ImGuiKey_DownArrow)) {
                size_t line = 0;
                for (size_t i = 0; i < lines.size(); ++i) {
                    if (input->cursor >= lines[i].first && input->cursor <= lines[i].second) {
                        line = i;
                        break;
                    }
                }
                int target = (int)line + (ImGui::IsKeyPressed(ImGuiKey_UpArrow) ? -1 : 1);
                target = std::clamp(target, 0, (int)lines.size() - 1);
                float x = ImGui::CalcTextSize(txt + lines[line].first, txt + input->cursor).x;
                size_t at = text_sub_offset_at_x(txt, lines[target].first,
                                                 lines[target].second, x);
                if (io.KeyShift) (void)uim_text_input_set_selection(input, input->anchor, at);
                else (void)uim_text_input_set_cursor(input, at);
            }
            if (ImGui::IsKeyPressed(ImGuiKey_Home) || ImGui::IsKeyPressed(ImGuiKey_End)) {
                size_t line = 0;
                for (size_t i = 0; i < lines.size(); ++i) {
                    if (input->cursor >= lines[i].first && input->cursor <= lines[i].second) {
                        line = i;
                        break;
                    }
                }
                size_t at = ImGui::IsKeyPressed(ImGuiKey_Home) ? lines[line].first : lines[line].second;
                if (io.KeyShift) (void)uim_text_input_set_selection(input, input->anchor, at);
                else (void)uim_text_input_set_cursor(input, at);
            }
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_A)) (void)uim_text_input_select_all(input);
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_C)) {
                size_t start = 0, len_sel = 0;
                if (uim_text_input_selection(input, &start, &len_sel) == uim_OK && len_sel > 0) {
                    std::string all = field_value(*input);
                    ImGui::SetClipboardText(all.substr(start, len_sel).c_str());
                }
            }
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_V)) {
                const char *clip = ImGui::GetClipboardText();
                if (clip && *clip &&
                    uim_text_input_insert(input, clip, std::strlen(clip)) == uim_OK) r.changed = true;
            }
            for (ImWchar ch : io.InputQueueCharacters) {
                char utf8[5] = {0, 0, 0, 0, 0};
                int n;
                if (ch < 0x20) continue;
                n = ImTextCharToUtf8(utf8, (unsigned int)ch);
                if (n > 0 && uim_text_input_insert(input, utf8, (size_t)n) == uim_OK) r.changed = true;
            }
            io.InputQueueCharacters.resize(0);
        }
    }

    if (r.changed && !history_handled) {
        std::string now_text = field_value(*input);
        TextSnapshot now{now_text, input->cursor, input->anchor};
        bool same = !history.undo.empty() &&
                    history.undo.back().text == before.text &&
                    history.undo.back().cursor == before.cursor &&
                    history.undo.back().anchor == before.anchor;
        if (!same && before.text != now.text) {
            history.undo.push_back(before);
            if (history.undo.size() > 64u) history.undo.erase(history.undo.begin());
            history.redo.clear();
        }
        r.changed = before.text != now.text;
    }

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 br(pos.x + width, pos.y + height);
    dl->AddRectFilled(pos, br,
                      ImGui::GetColorU32(focused ? ImGuiCol_FrameBgActive
                                                 : hovered ? ImGuiCol_FrameBgHovered
                                                           : ImGuiCol_FrameBg),
                      3.0f);
    dl->AddRect(pos, br,
                ImGui::GetColorU32(focused ? ImGuiCol_ButtonActive : ImGuiCol_Border), 3.0f);
    dl->PushClipRect(pos, br, true);
    size_t sel_start = 0, sel_len = 0;
    (void)uim_text_input_selection(input, &sel_start, &sel_len);
    size_t sel_end = sel_start + sel_len;
    for (int row = 0; row < visible_lines; ++row) {
        int line_index = first_line + row;
        if (line_index >= (int)lines.size()) break;
        size_t ls = lines[line_index].first, le = lines[line_index].second;
        float y = pos.y + 4.0f + (float)row * line_h;
        float x0 = pos.x + 6.0f;
        if (sel_len > 0) {
            size_t s = std::max(ls, sel_start), e = std::min(le, sel_end);
            if (s < e) {
                float sx0 = x0 + ImGui::CalcTextSize(txt + ls, txt + s).x;
                float sx1 = x0 + ImGui::CalcTextSize(txt + ls, txt + e).x;
                dl->AddRectFilled(ImVec2(sx0, y), ImVec2(sx1, y + line_h - 1.0f),
                                  ImGui::GetColorU32(ImGuiCol_TextSelectedBg));
            }
        }
        if (le > ls)
            dl->AddText(ImVec2(x0, y), ImGui::GetColorU32(ImGuiCol_Text),
                        txt + ls, txt + le);
    }
    if (focused) {
        float cx = pos.x + 6.0f;
        float cy = pos.y + 4.0f + (float)((int)caret_line - first_line) * line_h;
        if (input->cursor >= lines[caret_line].first && input->cursor <= lines[caret_line].second) {
            size_t ls = lines[caret_line].first;
            cx += ImGui::CalcTextSize(txt + ls, txt + input->cursor).x;
        }
        dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + line_h - 1.0f),
                    ImGui::GetColorU32(ImGuiCol_Text), 1.0f);
        ImGuiContext &ctx = *ImGui::GetCurrentContext();
        ctx.PlatformImeData.WantVisible = true;
        ctx.PlatformImeData.WantTextInput = true;
        ctx.PlatformImeData.InputPos = ImVec2(cx, cy);
        ctx.PlatformImeData.InputLineHeight = line_h;
    }
    dl->PopClipRect();
    ImGui::PopID();
    return r;
}


struct ProcessResult {
    bool started = false;
    int exit_code = 1;
    std::string output;
};

ProcessResult run_process(const std::string &command, const std::string &working_dir) {
    ProcessResult result;
    char output[8192] = {0};
    int exit_code = 1;
    result.started = g.host &&
        editor_host_run_process(g.host, command.c_str(), working_dir.c_str(),
                                output, sizeof(output), &exit_code);
    result.exit_code = exit_code;
    result.output.assign(output);
    return result;
}

bool launch_process(const std::string &command, const std::string &working_dir) {
    return g.host &&
        editor_host_launch_process(g.host, command.c_str(), working_dir.c_str());
}

void log_process_output(const std::string &output) {
    size_t start = 0;
    size_t lines = 0;
    while (start < output.size() && lines < 12) {
        size_t end = output.find('\n', start);
        std::string line = output.substr(start, end == std::string::npos ? std::string::npos : end - start);
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ' || line.back() == '\t'))
            line.pop_back();
        if (!line.empty()) {
            log_line("cmake: " + line);
            ++lines;
        }
        if (end == std::string::npos) break;
        start = end + 1;
    }
}

std::string open_dialog() {
    char path[32768] = {0};
    if (!g.host || !editor_host_open_file(g.host, "Open ZCSR Project", "uiproj",
                                          path, sizeof(path))) return {};
    return path;
}

std::string save_dialog(const std::string &suggested) {
    char path[32768] = {0};
    if (!g.host || !editor_host_save_file(g.host, "Save ZCSR Project", "uiproj",
                                          suggested.c_str(), path, sizeof(path))) return {};
    return path;
}

std::string open_scene_dialog() {
    char path[32768] = {0};
    if (!g.host || !editor_host_open_file(g.host, "Open ZCSR Scene", "uiscene",
                                          path, sizeof(path))) return {};
    return path;
}

std::string save_scene_dialog(const std::string &suggested) {
    char path[32768] = {0};
    if (!g.host || !editor_host_save_file(g.host, "Save ZCSR Scene", "uiscene",
                                          suggested.c_str(), path, sizeof(path))) return {};
    return path;
}

uim_NodeId page_root(UIM_ComponentManager *m, uim_PageId page) {
    if (!m || page == uim_PAGE_INVALID) return uim_NODE_INVALID;
    size_t count = 0;
    if (uim_page_get_node_count(m, page, &count) != uim_OK) return uim_NODE_INVALID;
    for (size_t i = 0; i < count; ++i) {
        uim_NodeInfo n{};
        if (uim_page_get_node_at(m, page, i, &n) == uim_OK && n.parent_id == 0) return n.id;
    }
    return uim_NODE_INVALID;
}

void refresh_scene_dirty() {
    if (!g.scene_history) return;
    g.scene_dirty =
        zcsr_editor_scene_content_hash(&g.scene) != g.scene_saved_hash;
}

bool scene_history_begin() {
    if (!g.scene_history) return false;
    return zcsr_editor_scene_history_begin(g.scene_history, &g.scene);
}

bool scene_history_commit() {
    if (!g.scene_history) return false;
    bool changed = zcsr_editor_scene_history_commit(g.scene_history, &g.scene);
    if (changed) refresh_scene_dirty();
    return changed;
}

bool scene_history_cancel() {
    if (!g.scene_history) return false;
    bool changed = zcsr_editor_scene_history_cancel(g.scene_history, &g.scene);
    if (changed) {
        if (g.scene_selected && !zcsr_scene_get_const(&g.scene, g.scene_selected))
            g.scene_selected = 0;
        refresh_scene_dirty();
    }
    return changed;
}

bool scene_history_undo() {
    if (!g.scene_history) return false;
    bool changed = zcsr_editor_scene_history_undo(g.scene_history, &g.scene);
    if (changed) {
        if (g.scene_selected && !zcsr_scene_get_const(&g.scene, g.scene_selected))
            g.scene_selected = 0;
        refresh_scene_dirty();
    }
    return changed;
}

bool scene_history_redo() {
    if (!g.scene_history) return false;
    bool changed = zcsr_editor_scene_history_redo(g.scene_history, &g.scene);
    if (changed) {
        if (g.scene_selected && !zcsr_scene_get_const(&g.scene, g.scene_selected))
            g.scene_selected = 0;
        refresh_scene_dirty();
    }
    return changed;
}

void scene_gesture_end();

void scene_gesture_begin() {
    if (g.scene_gesture_active) scene_gesture_end();
    g.scene_gesture_active = scene_history_begin();
}

void scene_gesture_end() {
    if (!g.scene_gesture_active) return;
    (void)scene_history_commit();
    g.scene_gesture_active = false;
}

void scene_gesture_cancel() {
    if (!g.scene_gesture_active) return;
    (void)scene_history_cancel();
    g.scene_gesture_active = false;
    g.scene_dragging = false;
    g.scene_resize_handle = -1;
}

void apply_scene_change(zcsr_editor_scene_change change) {
    if (!change.changed) return;
    g.scene_selected = change.id;
    g.scene_dirty = true;
}

zcsr_entity_id scene_add_box(float x, float z, float w, float h,
                             float r, float g0, float b) {
    (void)scene_history_begin();
    zcsr_editor_scene_change change =
        zcsr_editor_scene_add_box(&g.scene, x, z, w, h, r, g0, b);
    apply_scene_change(change);
    (void)scene_history_commit();
    return change.id;
}

zcsr_entity_id scene_add_quad(float x, float z, float size, float r, float g0, float b) {
    (void)scene_history_begin();
    zcsr_editor_scene_change change =
        zcsr_editor_scene_add_quad(&g.scene, x, z, size, r, g0, b);
    apply_scene_change(change);
    (void)scene_history_commit();
    if (!change.changed) log_line("scene quad set failed");
    return change.id;
}

bool scene_duplicate(zcsr_entity_id id, float dx, float dz) {
    (void)scene_history_begin();
    zcsr_editor_scene_change change =
        zcsr_editor_scene_duplicate(&g.scene, id, dx, dz);
    apply_scene_change(change);
    (void)scene_history_commit();
    return change.changed;
}

bool scene_delete(zcsr_entity_id id) {
    (void)scene_history_begin();
    zcsr_editor_scene_change change = zcsr_editor_scene_delete(&g.scene, id);
    if (change.changed) g.scene_selected = 0;
    g.scene_dirty = g.scene_dirty || change.changed;
    (void)scene_history_commit();
    return change.changed;
}

void scene_ensure_demo() {
    if (g.scene.count > 0) return;
    (void)scene_add_box(-3.0f, 0.0f, 2.0f, 2.0f, 0.90f, 0.55f, 0.40f);
    (void)scene_add_box(0.0f, 1.0f, 2.0f, 2.0f, 0.40f, 0.75f, 0.55f);
    (void)scene_add_quad(3.0f, 0.0f, 2.0f, 0.45f, 0.60f, 0.90f);
    /* The bundled demo is a starting document, not three user edits. Without
     * this reset the first Ctrl+Z would erase the demo one entity at a time
     * instead of undoing the user's first real gesture. */
    if (g.scene_history) zcsr_editor_scene_history_reset(g.scene_history, &g.scene);
}

bool scene_save(bool save_as) {
    if (g.scene_gesture_active) scene_gesture_end();
    std::string path = g.scene_path;
    if (save_as || path.empty()) {
        path = save_scene_dialog(path.empty() ? "scene.uiscene" : fs::path(path).filename().string());
    }
    if (path.empty()) return false;
    zcsr_editor_scene_io_result rc = zcsr_editor_scene_save(&g.scene, path.c_str());
    if (rc != ZCSR_EDITOR_SCENE_IO_OK) {
        log_line("scene save failed: " + path + " (" +
                 zcsr_editor_scene_io_result_name(rc) + ")");
        return false;
    }
    g.scene_path = path;
    g.scene_dirty = false;
    g.scene_saved_hash = zcsr_editor_scene_content_hash(&g.scene);
    log_line("scene saved " + path);
    return true;
}

bool scene_load(const std::string &path) {
    zcsr_editor_scene_io_result rc = zcsr_editor_scene_load(&g.scene, path.c_str());
    if (rc != ZCSR_EDITOR_SCENE_IO_OK) {
        log_line("scene open failed: " + path + " (" +
                 zcsr_editor_scene_io_result_name(rc) + ")");
        return false;
    }
    g.scene_path = path;
    g.scene_dirty = false;
    g.scene_saved_hash = zcsr_editor_scene_content_hash(&g.scene);
    if (g.scene_history) zcsr_editor_scene_history_reset(g.scene_history, &g.scene);
    g.scene_gesture_active = false;
    g.scene_dragging = false;
    g.scene_resize_handle = -1;
    g.scene_selected = 0;
    g.scene_mode = true;
    log_line("scene opened " + path);
    return true;
}

bool node_key_exists(const std::string &key) {
    if (!g.manager || g.page == uim_PAGE_INVALID) return false;
    uim_NodeId id = 0;
    return uim_node_find_stable_key(g.manager, g.page, key.c_str(), &id) == uim_OK;
}

std::string make_node_key() {
    for (;;) {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "node_%llu", (unsigned long long)g_node_serial++);
        if (!node_key_exists(buf)) return buf;
    }
}

void destroy_document() {
    if (g.playing) {
        uim_runtime_end();
        g.playing = false;
    }
    if (g.page_texture && g.renderer) {
        zcsr_gl_texture_destroy(g.renderer, g.page_texture);
    }
    g.page_texture = 0;
    g.texture_w = g.texture_h = 0;
    g.texture_manager = nullptr;
    g.texture_page = uim_PAGE_INVALID;
    if (g.editor) uir_editor_destroy(g.editor);
    g.editor = nullptr;
    if (g.manager) uim_component_manager_destroy(g.manager);
    g.manager = nullptr;
    if (g.registry) uim_component_registry_destroy(g.registry);
    g.registry = nullptr;
    g.page = uim_PAGE_INVALID;
    g.root = uim_NODE_INVALID;
    g.selected_instance = 0;
    g.text_fields.clear();
    g.viewport_initialized = false;
    g.auto_fit = true;
}

bool create_editor_shell() {
    if (!g.manager) return false;
    uim_ComponentRegistryConfig cfg{};
    cfg.initial_type_capacity = 32;
    if (uim_component_registry_create(&cfg, &g.registry) != uim_OK) return false;
    if (uim_component_registry_register_builtins(g.registry) != uim_OK) return false;
    if (uir_editor_create(g.manager, 256, &g.editor) != uim_OK) return false;
    if (g.page != uim_PAGE_INVALID) {
        uir_editor_set_active_page(g.editor, g.page);
        g.root = page_root(g.manager, g.page);
    }
    return true;
}

bool attach_component(uim_NodeId node, uim_ComponentTypeId type, uim_ComponentInstanceId *out = nullptr) {
    if (!g.manager || !g.registry || !g.editor) return false;
    uim_ComponentInstanceId instance = 0;
    uim_Result rc = uir_editor_component_attach_registered(g.editor, g.registry, node, type, &instance);
    if (rc == uim_ERR_EXISTS) {
        log_line("component already exists on this node");
        if (out) *out = 0;
        return false;
    }
    if (rc != uim_OK) {
        log_line("component attach failed: " + std::to_string((int)rc));
        return false;
    }
    if (out) *out = instance;
    g.selected_instance = instance;
    g.dirty = true;
    return true;
}

/* A singleton component is already present on this node. Used by the picker
 * to explain the no-op instead of presenting a failed attach. */
bool node_has_singleton_type(uim_NodeId node, uim_ComponentTypeId type) {
    if (!g.manager || !node || !type) return false;
    size_t count = 0;
    if (uim_node_component_count(g.manager, node, &count) != uim_OK) return false;
    for (size_t i = 0; i < count; ++i) {
        uim_ComponentInstanceInfo info{};
        if (uim_node_component_get_at(g.manager, node, i, &info) != uim_OK) continue;
        if (info.type_id == type) return true;
    }
    return false;
}

uim_NodeId create_node(const std::string &key, uim_NodeId parent, uim_Rect rect,
                       uim_ComponentTypeId component = 0) {
    if (!g.editor || g.page == uim_PAGE_INVALID) return uim_NODE_INVALID;
    std::string stable = key.empty() ? make_node_key() : key;
    if (node_key_exists(stable)) stable = make_node_key();
    uim_NodeDesc desc{};
    desc.page_id = g.page;
    desc.parent_id = parent;
    desc.stable_key = stable.c_str();
    desc.local_rect = rect;
    desc.visible = true;
    desc.enabled = true;
    desc.space = uim_SPACE_2D;
    desc.transform.scale[0] = desc.transform.scale[1] = desc.transform.scale[2] = 1.0f;
    uim_NodeId id = 0;
    uim_Result rc = uir_editor_create_node(g.editor, &desc, &id);
    if (rc != uim_OK) {
        log_line("create node failed: " + std::to_string((int)rc));
        return uim_NODE_INVALID;
    }
    if (component) attach_component(id, component);
    g.dirty = true;
    return id;
}

/* A UI panel placed on the 2.5D canvas. It is not a scene entity, not a 3D
 * model and not a ground object; it is a document node whose editor placement
 * happens to use a projected 2.5D transform. */
uim_NodeId create_projected_panel_node(uim_NodeId parent) {
    if (!g.editor || g.page == uim_PAGE_INVALID) return uim_NODE_INVALID;
    std::string stable = make_node_key();
    uim_NodeDesc desc{};
    desc.page_id = g.page;
    desc.parent_id = parent;
    desc.stable_key = stable.c_str();
    desc.local_rect = {0, 0, 160, 80};
    desc.visible = true;
    desc.enabled = true;
    desc.space = uim_SPACE_3D;
    desc.transform.position[2] = 60.0f;
    desc.transform.scale[0] = desc.transform.scale[1] = desc.transform.scale[2] = 1.0f;
    uim_NodeId id = 0;
    uim_Result rc = uir_editor_create_node(g.editor, &desc, &id);
    if (rc != uim_OK) {
        log_line("create 3D node failed: " + std::to_string((int)rc));
        return uim_NODE_INVALID;
    }
    (void)attach_component(id, uim_COMPONENT_PANEL);
    std::vector<uim_NodeId> sel{id};
    uir_editor_select(g.editor, sel.data(), 1);
    g.dirty = true;
    return id;
}

bool new_document() {
    destroy_document();
    UIM_ComponentManagerConfig cfg{};
    cfg.initial_page_capacity = 4;
    cfg.initial_node_capacity = 64;
    if (uim_component_manager_create(&cfg, &g.manager) != uim_OK) return false;
    if (uim_page_create(g.manager, "screen", &g.page) != uim_OK) return false;
    if (!create_editor_shell()) return false;
    g.root = create_node("screen", 0, {0, 0, 960, 600}, uim_COMPONENT_PANEL);
    if (!g.root) return false;
    std::vector<uim_NodeId> sel{g.root};
    uir_editor_select(g.editor, sel.data(), 1);
    g.project_path.clear();
    g.scene_path.clear();
    reset_assets();
    sync_project_browser();
    zcsr_scene_init(&g.scene);
    g.scene_selected = 0;
    g.scene_gesture_active = false;
    g.scene_dragging = false;
    g.scene_resize_handle = -1;
    g.scene_dirty = false;
    if (g.scene_history) zcsr_editor_scene_history_reset(g.scene_history, &g.scene);
    g.scene_saved_hash = zcsr_editor_scene_content_hash(&g.scene);
    g.dirty = true;
    g.viewport_initialized = false;
    g.auto_fit = true;
    log_line("new project");
    return true;
}

bool load_project(const std::string &path) {
    UIM_ComponentManager *manager = nullptr;
    uim_PageId page = uim_PAGE_INVALID;
    uim_NodeId root = 0;
    char root_path[UIR_PROJECT_PATH_CAP]{};
    char name[UIR_PROJECT_NAME_CAP]{};
    std::unique_ptr<zcsr_scene> loaded_scene;
    bool container = zcsr_editor_project_container_probe(path.c_str());

    if (container) {
        unsigned char *project_bytes = nullptr;
        size_t project_size = 0;
        char *scene_text = nullptr;
        size_t scene_size = 0;
        zcsr_editor_container_result crc = zcsr_editor_project_container_load(
            path.c_str(), &project_bytes, &project_size, &scene_text, &scene_size);
        if (crc != ZCSR_EDITOR_CONTAINER_OK) {
            log_line("open failed: " + path + " (" +
                     zcsr_editor_container_result_name(crc) + ")");
            return false;
        }
        uim_Result rc = uir_project_deserialize(project_bytes, project_size, &manager,
                                                &page, &root, name, sizeof(name));
        free(project_bytes);
        if (rc != uim_OK) {
            free(scene_text);
            log_line("open failed: " + path + " (project " + std::to_string((int)rc) + ")");
            return false;
        }
        loaded_scene.reset(new zcsr_scene());
        zcsr_scene_init(loaded_scene.get());
        if (scene_size > 0) {
            zcsr_editor_scene_io_result src = zcsr_editor_scene_deserialize(
                scene_text, scene_size, loaded_scene.get());
            if (src != ZCSR_EDITOR_SCENE_IO_OK) {
                free(scene_text);
                if (manager) uim_component_manager_destroy(manager);
                log_line("open failed: " + path + " (scene " +
                         zcsr_editor_scene_io_result_name(src) + ")");
                return false;
            }
        }
        free(scene_text);
    } else {
        if (uir_project_load(path.c_str(), &manager, &page, &root, root_path,
                             sizeof(root_path), name, sizeof(name)) != uim_OK) {
            log_line("open failed: " + path);
            return false;
        }
    }

    destroy_document();
    g.manager = manager;
    g.page = page;
    if (!create_editor_shell()) {
        destroy_document();
        return false;
    }
    g.root = root ? root : page_root(g.manager, g.page);
    g.project_path = path;
    sync_project_browser();
    load_assets();
    if (loaded_scene) {
        g.scene = *loaded_scene;
        g.scene_path.clear();
        g.scene_selected = 0;
        g.scene_gesture_active = false;
        g.scene_dragging = false;
        g.scene_resize_handle = -1;
        if (g.scene_history) zcsr_editor_scene_history_reset(g.scene_history, &g.scene);
    }
    g.scene_saved_hash = zcsr_editor_scene_content_hash(&g.scene);
    g.scene_dirty = false;
    g.dirty = false;
    g.viewport_initialized = false;
    g.auto_fit = true;
    std::vector<uim_NodeId> sel{g.root};
    if (g.root) uir_editor_select(g.editor, sel.data(), 1);
    log_line((container ? "opened container " : "opened legacy project ") + path);
    return true;
}

bool save_project(bool save_as) {
    if (!g.manager || g.page == uim_PAGE_INVALID) return false;
    if (g.scene_gesture_active) scene_gesture_end();
    std::string path = g.project_path;
    if (save_as || path.empty()) {
        path = save_dialog(path.empty() ? "project.uiproj" : fs::path(path).filename().string());
    }
    if (path.empty()) return false;

    unsigned char *project = nullptr;
    size_t project_size = 0;
    std::string project_name = fs::path(path).stem().string();
    uim_Result prc = uir_project_serialize(g.manager, &g.page, 1,
                                           project_name.c_str(),
                                           &project, &project_size);
    if (prc != uim_OK || !project) {
        log_line("save failed: " + path + " (project " + std::to_string((int)prc) + ")");
        free(project);
        return false;
    }

    char *scene_text = nullptr;
    size_t scene_size = 0;
    zcsr_editor_scene_io_result src = zcsr_editor_scene_serialize(
        &g.scene, &scene_text, &scene_size);
    if (src != ZCSR_EDITOR_SCENE_IO_OK) {
        free(project);
        log_line("save failed: " + path + " (scene " +
                 zcsr_editor_scene_io_result_name(src) + ")");
        return false;
    }

    zcsr_editor_container_result crc = zcsr_editor_project_container_save(
        path.c_str(), project, project_size, scene_text, scene_size);
    free(project);
    free(scene_text);
    if (crc != ZCSR_EDITOR_CONTAINER_OK) {
        log_line("save failed: " + path + " (" +
                 zcsr_editor_container_result_name(crc) + ")");
        return false;
    }
    g.project_path = path;
    g.dirty = false;
    g.scene_dirty = false;
    sync_project_browser();
    (void)save_assets();
    g.scene_saved_hash = zcsr_editor_scene_content_hash(&g.scene);
    log_line("saved container " + path);
    return true;
}

bool run_cmake_debug() {
    if (g.project_path.empty() && !save_project(false)) return false;
    if (g.dirty && !save_project(false)) return false;
    std::string build_dir = ZCSR_EDITOR_BINARY_DIR;
    std::string command = std::string("\"") + ZCSR_CMAKE_COMMAND + "\" --build \""
                        + build_dir + "\"";
    if (ZCSR_RUN_CONFIG_DIR[0]) command += std::string(" --config ") + ZCSR_RUN_CONFIG_DIR;
    command += std::string(" --target ") + ZCSR_RUN_TARGET;
    log_line(std::string("run: cmake --build ") + (ZCSR_RUN_CONFIG_DIR[0] ? ZCSR_RUN_CONFIG_DIR : "default"));
    ProcessResult build = run_process(command, build_dir);
    if (!build.started) {
        log_line("run failed: could not start cmake");
        return false;
    }
    log_process_output(build.output);
    if (build.exit_code != 0) {
        log_line("run failed: cmake exit " + std::to_string((unsigned long)build.exit_code));
        return false;
    }
    fs::path player_exe = fs::path(build_dir);
    if (ZCSR_RUN_CONFIG_DIR[0]) player_exe /= ZCSR_RUN_CONFIG_DIR;
    player_exe /= ZCSR_RUN_EXE;
    if (!fs::exists(player_exe)) {
        player_exe = fs::path(exe_path()).replace_filename(ZCSR_RUN_EXE);
    }
    if (!fs::exists(player_exe)) {
        log_line("run failed: missing " + player_exe.string());
        return false;
    }
    std::string launch = std::string("\"") + player_exe.string() + "\" --play \""
                       + g.project_path + "\"";
    if (!launch_process(launch, fs::path(player_exe).parent_path().string())) {
        log_line("run failed: could not launch player");
        return false;
    }
    log_line("run: launched " + player_exe.filename().string());
    return true;
}

void start_play() {
    if (!g.manager || g.page == uim_PAGE_INVALID || g.playing) return;
    g.play_start_ms = now_ms();
    g.play_first_logged = false;
    uim_runtime_set_paused(false);
    if (!uim_runtime_begin(g.manager, g.page)) {
        log_line("play failed");
        return;
    }
    g.playing = true;
    g.show_game = true;
    log_line("play");
}

void stop_play() {
    if (!g.playing) return;
    uim_runtime_set_paused(false);
    uim_runtime_end();
    g.playing = false;
    log_line("stop");
}

void ensure_texture(int w, int h) {
    if (!g.renderer || !g.manager || g.page == uim_PAGE_INVALID || !g.root) return;
    if (g.page_texture && g.texture_w == w && g.texture_h == h &&
        g.texture_manager == g.manager && g.texture_page == g.page) return;
    if (g.page_texture) zcsr_gl_texture_destroy(g.renderer, g.page_texture);
    g.page_texture = 0;
    std::vector<unsigned char> pixels((size_t)w * (size_t)h * 4u, 0);
    g.page_texture = zcsr_gl_texture_create(g.renderer, pixels.data(), w, h);
    g.texture_w = w;
    g.texture_h = h;
    g.texture_manager = g.manager;
    g.texture_page = g.page;
    if (g.page_texture) zcsr_gl_texture_filter(g.renderer, g.page_texture, false);
}

void render_page_to_texture() {
    if (!g.renderer || !g.manager || !g.root || g.page == uim_PAGE_INVALID) return;
    uim_NodeInfo root_info{};
    if (uim_node_get(g.manager, g.root, &root_info) != uim_OK) return;
    int w = (int)std::lround(root_info.local_rect.width);
    int h = (int)std::lround(root_info.local_rect.height);
    if (w < 16) w = 960;
    if (h < 16) h = 600;
    w = std::clamp(w, 64, 3840);
    h = std::clamp(h, 64, 2160);
    ensure_texture(w, h);
    if (!g.page_texture) return;
    zcsr_gl_set_target(g.renderer, g.page_texture);
    zcsr_gl_clear_target(g.renderer, 0.07f, 0.08f, 0.10f, 1.0f);
    zcsr_page_render(g.renderer, g.manager, g.page, 0, 0, w, h,
                     g.project_path.empty()
                         ? nullptr
                         : fs::path(g.project_path).parent_path().string().c_str());
    // The page commands are queued in the renderer. Flush them while the FBO is
    // still bound; otherwise the shell flushes them to the default framebuffer
    // after ImGui and the page texture paint covers the editor chrome.
    zcsr_gl_flush(g.renderer);
    zcsr_gl_set_target(g.renderer, 0);
}

void draw_overlay(ImDrawList *draw, const ImVec2 &clip_min, const ImVec2 &clip_max) {
    if (!g.editor || g.page == uim_PAGE_INVALID) return;
    size_t count = 0;
    if (uir_editor_build_overlay(g.editor, g.page, nullptr, 0, &count) != uim_OK || !count) return;
    std::vector<uim_EditorOverlayCommand> cmds(count);
    if (uir_editor_build_overlay(g.editor, g.page, cmds.data(), cmds.size(), &count) != uim_OK) return;
    for (size_t i = 0; i < count; ++i) {
        const auto &c = cmds[i];
        ImU32 col = IM_COL32(120, 160, 220, 120);
        if (c.type == uim_EDITOR_OVERLAY_SELECTED_BOUNDS) col = IM_COL32(255, 190, 70, 255);
        if (c.type == uim_EDITOR_OVERLAY_FOCUS_BOUNDS) col = IM_COL32(100, 220, 255, 180);
        if (c.type == uim_EDITOR_OVERLAY_RESIZE_HANDLE) col = IM_COL32(255, 170, 60, 255);
        if (c.type == uim_EDITOR_OVERLAY_GRID_LINE) col = IM_COL32(90, 95, 105, 80);
        if (c.type == uim_EDITOR_OVERLAY_GUIDE_LINE) col = IM_COL32(90, 210, 255, 120);
        if (c.type == uim_EDITOR_OVERLAY_SAFE_AREA) col = IM_COL32(80, 200, 120, 120);
        if (c.type == uim_EDITOR_OVERLAY_SELECTION_MARQUEE) col = IM_COL32(90, 180, 255, 160);

        if (c.type == uim_EDITOR_OVERLAY_GRID_LINE || c.type == uim_EDITOR_OVERLAY_GUIDE_LINE) {
            ImVec2 a(c.x1, c.y1);
            ImVec2 b(c.x2, c.y2);
            a.x = std::clamp(a.x, clip_min.x, clip_max.x);
            a.y = std::clamp(a.y, clip_min.y, clip_max.y);
            b.x = std::clamp(b.x, clip_min.x, clip_max.x);
            b.y = std::clamp(b.y, clip_min.y, clip_max.y);
            draw->AddLine(a, b, col, 1.0f);
        } else if (c.type == uim_EDITOR_OVERLAY_RESIZE_HANDLE) {
            draw->AddRectFilled(ImVec2(c.rect.x, c.rect.y),
                                ImVec2(c.rect.x + c.rect.width, c.rect.y + c.rect.height), col);
        } else if (c.type == uim_EDITOR_OVERLAY_SELECTION_MARQUEE) {
            draw->AddRectFilled(ImVec2(std::min(c.x1, c.x2), std::min(c.y1, c.y2)),
                                ImVec2(std::max(c.x1, c.x2), std::max(c.y1, c.y2)),
                                IM_COL32(70, 140, 220, 40));
            draw->AddRect(ImVec2(std::min(c.x1, c.x2), std::min(c.y1, c.y2)),
                          ImVec2(std::max(c.x1, c.x2), std::max(c.y1, c.y2)), col,
                          0.0f, 1.0f, ImDrawFlags_None);
        } else {
            draw->AddRect(ImVec2(c.rect.x, c.rect.y),
                          ImVec2(c.rect.x + c.rect.width, c.rect.y + c.rect.height), col,
                          0.0f, 1.5f, ImDrawFlags_None);
        }
    }
}

/* Returns the first selected 3D node and its screen-space origin. The gizmo
 * uses the same camera as the preview, so it cannot drift from the billboard. */
static bool gizmo_origin(const ImVec2 &child_min, ImVec2 *out_origin,
                         float *out_px_per_unit, uim_NodeId *out_node) {
    if (!g.editor || !g.manager || g.texture_w <= 0 || g.texture_h <= 0) return false;
    uim_EditorSelection sel{};
    if (uir_editor_get_selection(g.editor, &sel) != uim_OK) return false;
    for (size_t i = 0; i < sel.count; ++i) {
        uim_NodeInfo n;
        if (uim_node_get(g.manager, sel.ids[i], &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        zcsr_camera3d camera;
        zcsr_camera3d_init(&camera, g.texture_w, g.texture_h,
                           0.0f, 0.0f, 600.0f, 0.0f, 0.0f, 60.0f);
        float px = 0.0f, py = 0.0f, depth = 0.0f;
        if (!zcsr_camera3d_project(&camera, n.transform.position[0],
                                   n.transform.position[1], n.transform.position[2],
                                   &px, &py, &depth))
            continue;
        if (out_origin)
            *out_origin = ImVec2(child_min.x + g.pan_x + px * g.zoom,
                                 child_min.y + g.pan_y + py * g.zoom);
        if (out_px_per_unit) {
            float ppu = zcsr_camera3d_px_per_unit(&camera, depth);
            *out_px_per_unit = ppu > 0.0f ? ppu : 1.0f;
        }
        if (out_node) *out_node = n.id;
        return true;
    }
    return false;
}

static float gizmo_axis_screen_len() { return 58.0f; }

void draw_3d_gizmo(ImDrawList *draw, const ImVec2 &child_min) {
    ImVec2 origin;
    float ppu = 1.0f;
    uim_NodeId node = uim_NODE_INVALID;
    if (!gizmo_origin(child_min, &origin, &ppu, &node)) return;
    (void)ppu;
    float len = gizmo_axis_screen_len();
    ImU32 x_col = g.gizmo_axis == 0 ? IM_COL32(255, 220, 80, 255) : IM_COL32(230, 70, 70, 255);
    ImU32 y_col = g.gizmo_axis == 1 ? IM_COL32(255, 220, 80, 255) : IM_COL32(80, 220, 110, 255);
    ImU32 z_col = g.gizmo_axis == 2 ? IM_COL32(255, 220, 80, 255) : IM_COL32(80, 160, 255, 255);
    ImVec2 x_end(origin.x + len, origin.y);
    ImVec2 y_end(origin.x, origin.y - len);
    ImVec2 z_end(origin.x - len * 0.55f, origin.y - len * 0.55f);
    draw->AddCircleFilled(origin, 4.0f, IM_COL32(255, 255, 255, 255));
    draw->AddLine(origin, x_end, x_col, 2.5f);
    draw->AddLine(origin, y_end, y_col, 2.5f);
    draw->AddLine(origin, z_end, z_col, 2.5f);
    draw->AddTriangleFilled(x_end, ImVec2(x_end.x - 8.0f, x_end.y - 4.0f),
                            ImVec2(x_end.x - 8.0f, x_end.y + 4.0f), x_col);
    draw->AddTriangleFilled(y_end, ImVec2(y_end.x - 4.0f, y_end.y + 8.0f),
                            ImVec2(y_end.x + 4.0f, y_end.y + 8.0f), y_col);
    draw->AddTriangleFilled(z_end, ImVec2(z_end.x + 8.0f, z_end.y + 2.0f),
                            ImVec2(z_end.x + 2.0f, z_end.y + 8.0f), z_col);
    draw->AddText(ImVec2(x_end.x + 4.0f, x_end.y - 6.0f), x_col, "X");
    draw->AddText(ImVec2(y_end.x + 5.0f, y_end.y - 14.0f), y_col, "Y");
    draw->AddText(ImVec2(z_end.x - 12.0f, z_end.y - 4.0f), z_col, "Z");
}

static int gizmo_hit_test(const ImVec2 &mouse, const ImVec2 &child_min) {
    ImVec2 origin;
    if (!gizmo_origin(child_min, &origin, nullptr, nullptr)) return -1;
    float len = gizmo_axis_screen_len();
    ImVec2 ends[3] = {
        ImVec2(origin.x + len, origin.y),
        ImVec2(origin.x, origin.y - len),
        ImVec2(origin.x - len * 0.55f, origin.y - len * 0.55f)
    };
    for (int axis = 0; axis < 3; ++axis) {
        float dx = mouse.x - ends[axis].x;
        float dy = mouse.y - ends[axis].y;
        if (dx * dx + dy * dy <= 12.0f * 12.0f) return axis;
    }
    return -1;
}

static void gizmo_begin(const ImVec2 &mouse, const ImVec2 &child_min) {
    if (!g.editor || !g.manager) return;
    uim_EditorSelection sel{};
    if (uir_editor_get_selection(g.editor, &sel) != uim_OK) return;
    g.gizmo_count = 0;
    for (size_t i = 0; i < sel.count && g.gizmo_count < 16; ++i) {
        uim_NodeInfo n;
        uim_Transform3 tr;
        if (uim_node_get(g.manager, sel.ids[i], &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        if (uim_node_get_transform3(g.manager, n.id, &tr) != uim_OK) continue;
        g.gizmo_nodes[g.gizmo_count] = n.id;
        g.gizmo_orig[g.gizmo_count] = tr;
        g.gizmo_count++;
    }
    if (g.gizmo_count == 0) return;
    g.gizmo_axis = gizmo_hit_test(mouse, child_min);
    if (g.gizmo_axis < 0) return;
    g.gizmo_dragging = true;
    g.gizmo_start = mouse;
    g.dragging = false; /* never route this gesture to the 2D kernel */
}

static void gizmo_drag(const ImVec2 &mouse, const ImVec2 &child_min) {
    if (!g.gizmo_dragging || g.gizmo_axis < 0 || !g.manager) return;
    ImVec2 origin;
    float ppu = 1.0f;
    if (!gizmo_origin(child_min, &origin, &ppu, nullptr)) return;
    float dx = (mouse.x - g.gizmo_start.x) / std::max(g.zoom, 0.01f);
    float dy = (mouse.y - g.gizmo_start.y) / std::max(g.zoom, 0.01f);
    float wx = dx / std::max(ppu, 0.001f);
    float wy = -dy / std::max(ppu, 0.001f);
    for (size_t i = 0; i < g.gizmo_count; ++i) {
        uim_Transform3 tr = g.gizmo_orig[i];
        if (g.gizmo_mode == 1) {
            float delta = (dx - dy) * 1.0f;
            if (g.gizmo_snap && g.gizmo_rotate_step > 0.0f)
                delta = std::round(delta / g.gizmo_rotate_step) * g.gizmo_rotate_step;
            tr.rotation[g.gizmo_axis] += delta;
        } else if (g.gizmo_mode == 2) {
            float delta = (dx - dy) * 0.02f;
            tr.scale[g.gizmo_axis] = std::max(0.01f, tr.scale[g.gizmo_axis] + delta);
            if (g.gizmo_snap && g.gizmo_scale_step > 0.0f)
                tr.scale[g.gizmo_axis] = std::max(
                    g.gizmo_scale_step,
                    std::round(tr.scale[g.gizmo_axis] / g.gizmo_scale_step) * g.gizmo_scale_step);
        } else {
            float local_x = wx, local_z = wy;
            if (g.gizmo_space == 1) {
                float radians = tr.rotation[1] * 3.14159265358979323846f / 180.0f;
                float c = std::cos(radians), s = std::sin(radians);
                local_x = wx * c + wy * s;
                local_z = -wx * s + wy * c;
            }
            if (g.gizmo_axis == 0) tr.position[0] += local_x;
            else if (g.gizmo_axis == 1) tr.position[1] += wy;
            else tr.position[2] += local_z;
            if (g.gizmo_snap && g.gizmo_snap_step > 0.0f) {
                tr.position[g.gizmo_axis] = std::round(
                    tr.position[g.gizmo_axis] / g.gizmo_snap_step) * g.gizmo_snap_step;
            }
        }
        (void)uim_node_set_transform3(g.manager, g.gizmo_nodes[i], &tr);
    }
}

static void gizmo_end() {
    if (!g.gizmo_dragging) return;
    if (g.editor && g.manager) {
        for (size_t i = 0; i < g.gizmo_count; ++i) {
            uim_Transform3 final;
            if (uim_node_get_transform3(g.manager, g.gizmo_nodes[i], &final) != uim_OK)
                continue;
            /* Restore the pre-drag state, then let the editor kernel record one
             * undo entry for the completed gesture. */
            (void)uim_node_set_transform3(g.manager, g.gizmo_nodes[i], &g.gizmo_orig[i]);
            (void)uir_editor_set_transform3(g.editor, g.gizmo_nodes[i], &final);
        }
        g.dirty = true;
    }
    g.gizmo_dragging = false;
    g.gizmo_axis = -1;
    g.gizmo_count = 0;
}

/* 3D nodes are not part of the 2D page texture. The editor presents them
 * through the engine's software perspective camera (zcsr_camera3d); no second
 * renderer or document model is introduced. Billboard size uses the node
 * transform scale so Inspector edits are visible next frame. */
void draw_3d_overlay(ImDrawList *draw, const ImVec2 &child_min) {
    if (!g.manager || g.page == uim_PAGE_INVALID || g.texture_w <= 0 || g.texture_h <= 0)
        return;
    zcsr_camera3d camera;
    zcsr_camera3d_init(&camera, g.texture_w, g.texture_h,
                       0.0f, 0.0f, 600.0f,
                       0.0f, 0.0f, 60.0f);
    size_t count = 0u;
    if (uim_page_get_node_count(g.manager, g.page, &count) != uim_OK || count == 0u) return;
    bool any = false;
    for (size_t i = 0; i < count; ++i) {
        uim_NodeInfo n;
        if (uim_page_get_node_at(g.manager, g.page, i, &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        float world_w = std::max(std::abs(n.transform.scale[0]), 0.05f) * 120.0f;
        float world_h = std::max(std::abs(n.transform.scale[1]), 0.05f) * 60.0f;
        float bx = 0.0f, by = 0.0f, bw = 0.0f, bh = 0.0f;
        if (!zcsr_camera3d_billboard(&camera, n.transform.position[0],
                                     n.transform.position[1], n.transform.position[2],
                                     world_w, world_h, &bx, &by, &bw, &bh)) continue;
        ImVec2 a(child_min.x + g.pan_x + bx * g.zoom,
                 child_min.y + g.pan_y + by * g.zoom);
        ImVec2 b(child_min.x + g.pan_x + (bx + bw) * g.zoom,
                 child_min.y + g.pan_y + (by + bh) * g.zoom);
        draw->AddRect(a, b, IM_COL32(120, 200, 255, 220), 2.0f, 1.5f, ImDrawFlags_None);
        draw->AddText(ImVec2(a.x + 4.0f, a.y + 3.0f), IM_COL32(210, 240, 255, 255),
                      n.stable_key ? n.stable_key : "3D node");
        any = true;
    }
    if (any) {
        ImVec2 badge(child_min.x + 8.0f, child_min.y + 34.0f);
        draw->AddRectFilled(badge, ImVec2(badge.x + 156.0f, badge.y + 22.0f),
                            IM_COL32(35, 65, 100, 210), 4.0f);
        draw->AddText(ImVec2(badge.x + 8.0f, badge.y + 4.0f),
                      IM_COL32(190, 225, 255, 255), "3D preview: camera3d");
    }
}

void select_node(uim_NodeId node, bool additive);

/* Viewport selection must see the same 3D billboard the user sees. The 2D
 * canvas picker only knows local_rect, so a full-screen 2D panel would always
 * win over a 3D node drawn on top. This pick runs first and returns the
 * top-most 3D node under the cursor, then the 2D kernel handles the rest. */
uim_NodeId pick_3d_at(const ImVec2 &mouse, const ImVec2 &child_min) {
    if (!g.manager || g.page == uim_PAGE_INVALID || g.texture_w <= 0 || g.texture_h <= 0)
        return uim_NODE_INVALID;
    float page_x = (mouse.x - child_min.x - g.pan_x) / g.zoom;
    float page_y = (mouse.y - child_min.y - g.pan_y) / g.zoom;
    zcsr_camera3d camera;
    zcsr_camera3d_init(&camera, g.texture_w, g.texture_h,
                       0.0f, 0.0f, 600.0f,
                       0.0f, 0.0f, 60.0f);
    size_t count = 0u;
    if (uim_page_get_node_count(g.manager, g.page, &count) != uim_OK) return uim_NODE_INVALID;
    uim_NodeId best = uim_NODE_INVALID;
    float best_z = -3.0e38f;
    for (size_t i = 0; i < count; ++i) {
        uim_NodeInfo n;
        if (uim_page_get_node_at(g.manager, g.page, i, &n) != uim_OK) continue;
        if (n.space != uim_SPACE_3D) continue;
        float world_w = std::max(std::abs(n.transform.scale[0]), 0.05f) * 120.0f;
        float world_h = std::max(std::abs(n.transform.scale[1]), 0.05f) * 60.0f;
        float bx = 0.0f, by = 0.0f, bw = 0.0f, bh = 0.0f;
        if (!zcsr_camera3d_billboard(&camera, n.transform.position[0],
                                     n.transform.position[1], n.transform.position[2],
                                     world_w, world_h, &bx, &by, &bw, &bh)) continue;
        if (page_x < bx || page_x > bx + bw || page_y < by || page_y > by + bh) continue;
        if (n.transform.position[2] > best_z) {
            best_z = n.transform.position[2];
            best = n.id;
        }
    }
    return best;
}

void apply_canvas(const ImVec2 &content_min, const ImVec2 &content_size) {
    uim_EditorCanvasState state{};
    if (g.editor) uir_editor_get_canvas_state(g.editor, &state);
    state.viewport = {content_min.x, content_min.y, content_size.x, content_size.y};
    state.zoom = g.zoom;
    state.pan_x = g.pan_x;
    state.pan_y = g.pan_y;
    state.grid_size = g.canvas_grid_size;
    state.show_grid = g.canvas_show_grid;
    state.snap_to_grid = g.canvas_snap;
    if (g.editor) uir_editor_set_canvas_state(g.editor, &state);
}

bool primary_mod_down() {
    ImGuiIO &io = ImGui::GetIO();
#if defined(__APPLE__)
    if (g_test_primary_gui == 1) return io.KeySuper;
    if (g_test_primary_gui == 0) return io.KeyCtrl;
    return io.KeySuper || io.KeyCtrl;
#else
    if (g_test_primary_gui == 1) return io.KeySuper;
    return io.KeyCtrl;
#endif
}

int modifier_mask() {
    int m = 0;
    if (ImGui::GetIO().KeyShift) m |= uim_EDITOR_MOD_SHIFT;
    if (primary_mod_down()) m |= uim_EDITOR_MOD_CTRL;
    if (ImGui::GetIO().KeyAlt) m |= uim_EDITOR_MOD_ALT;
    return m;
}

void select_node(uim_NodeId node, bool additive) {
    if (!g.editor) return;
    g.selected_instance = 0;
    if (!additive) {
        uir_editor_select(g.editor, &node, 1);
        return;
    }
    uim_EditorSelection sel{};
    uir_editor_get_selection(g.editor, &sel);
    std::vector<uim_NodeId> ids;
    bool found = false;
    for (size_t i = 0; i < sel.count; ++i) {
        ids.push_back(sel.ids[i]);
        if (sel.ids[i] == node) found = true;
    }
    if (found) ids.erase(std::remove(ids.begin(), ids.end(), node), ids.end());
    else ids.push_back(node);
    uir_editor_select(g.editor, ids.data(), ids.size());
}

void select_node_duplicate() {
    uim_EditorSelection sel{};
    if (!g.editor || uir_editor_get_selection(g.editor, &sel) != uim_OK || sel.count != 1) return;
    uim_NodeId made = uim_NODE_INVALID;
    if (uir_editor_duplicate_node(g.editor, sel.ids[0], 16.0f, 16.0f, &made) == uim_OK) {
        g.dirty = true;
        select_node(made, false);
    }
}

uim_NodeId primary_selected_node() {
    uim_EditorSelection sel{};
    if (!g.editor || uir_editor_get_selection(g.editor, &sel) != uim_OK || sel.count == 0)
        return uim_NODE_INVALID;
    return sel.ids[sel.count - 1];
}

void copy_selected_node() {
    uim_NodeId node = primary_selected_node();
    if (node == uim_NODE_INVALID || node == g.root) return;
    g.clipboard_node = node;
    log_line("node copied");
}

void paste_copied_node() {
    if (!g.editor || g.clipboard_node == uim_NODE_INVALID) return;
    uim_NodeId made = uim_NODE_INVALID;
    if (uir_editor_duplicate_node(g.editor, g.clipboard_node, 16.0f, 16.0f, &made) == uim_OK) {
        g.dirty = true;
        select_node(made, false);
        log_line("node pasted");
    }
}

void move_selected_sibling(int delta) {
    uim_NodeId node = primary_selected_node();
    if (!g.editor || node == uim_NODE_INVALID || node == g.root) return;
    uim_NodeInfo info{};
    if (uim_node_get(g.manager, node, &info) != uim_OK || !info.parent_id) return;
    size_t count = 0;
    if (uir_editor_get_child_count(g.editor, info.parent_id, &count) != uim_OK) return;
    size_t index = count;
    for (size_t i = 0; i < count; ++i) {
        uim_NodeInfo child{};
        if (uir_editor_get_child_at(g.editor, info.parent_id, i, &child) == uim_OK &&
            child.id == node) { index = i; break; }
    }
    if (index == count) return;
    int next = (int)index + delta;
    if (next < 0 || next >= (int)count) return;
    if (uir_editor_reorder_node(g.editor, node, (size_t)next) == uim_OK) {
        g.dirty = true;
        log_line("node order changed");
    }
}

void delete_selected_node() {
    uim_EditorSelection sel{};
    if (!g.editor || uir_editor_get_selection(g.editor, &sel) != uim_OK || sel.count == 0) return;
    for (size_t i = 0; i < sel.count; ++i) {
        if (sel.ids[i] != g.root) uir_editor_delete_node(g.editor, sel.ids[i]);
    }
    g.dirty = true;
}

void begin_rename(uim_NodeId node) {
    if (!g.manager || !node) return;
    uim_NodeInfo info{};
    if (uim_node_get(g.manager, node, &info) != uim_OK) return;
    g.rename_node = node;
    ensure_field(&g.rename_text, 127u);
    (void)uim_text_input_set_text(&g.rename_text,
                                  info.stable_key ? info.stable_key : "",
                                  info.stable_key ? std::strlen(info.stable_key) : 0u);
    g.rename_open = true;
    g.rename_focus = true;
}

void draw_rename_popup() {
    if (!g.rename_open) return;
    ImGui::OpenPopup("Rename Node");
    ImGui::SetNextWindowSize(ImVec2(300, 0));
    if (ImGui::BeginPopupModal("Rename Node", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::SetWindowFocus();
        ImGui::Text("Node name");
        bool take_focus = g.rename_focus;
        g.rename_focus = false;
        UimFieldResult field = draw_uim_text_field("##rename", &g.rename_text, 260.0f, nullptr,
                                                   take_focus);
        std::string renamed = field_value(g.rename_text);
        bool enter = field.submitted;
        bool ok = ImGui::Button("Rename", ImVec2(90, 0));
        ImGui::SameLine();
        bool cancel = ImGui::Button("Cancel", ImVec2(90, 0));
        if ((enter || ok) && g.rename_node && !renamed.empty()) {
            if (uir_editor_hierarchy_set_name(g.editor, g.rename_node, renamed.c_str()) == uim_OK &&
                uim_node_set_stable_key(g.manager, g.rename_node, renamed.c_str()) == uim_OK) {
                g.dirty = true;
            } else {
                log_line("rename failed");
            }
            g.rename_open = false;
            ImGui::CloseCurrentPopup();
        }
        if (cancel) {
            g.rename_open = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
    if (!ImGui::IsPopupOpen("Rename Node")) g.rename_open = false;
}


std::string project_root_path() {
    if (!g.project_path.empty()) {
        std::error_code ec;
        fs::path parent = fs::path(g.project_path).parent_path();
        if (!parent.empty()) return parent.string();
    }
    std::error_code ec;
    fs::path cwd = fs::current_path(ec);
    return ec ? std::string(".") : cwd.string();
}

void reset_assets() {
    (void)uir_asset_registry_init(&g.assets, g.asset_records, kAssetCapacity);
    g.selected_asset = -1;
    g.asset_root.clear();
}

void load_assets() {
    reset_assets();
    if (g.project_path.empty()) return;
    if (!ensure_project_browser()) return;
    std::string root = project_root_path();
    std::string file = (fs::path(root) / ".uirassets").string();
    g.asset_root = root;
    if (!fs::exists(file)) return;
    uim_Result rc = uir_asset_registry_load(&g.assets, &g.project_file_service,
                                            file.c_str());
    if (rc != uim_OK) {
        reset_assets();
        log_line("asset registry load failed: " + file + " (" +
                 std::to_string((int)rc) + ")");
    } else {
        log_line("assets loaded: " + std::to_string(g.assets.count));
    }
}

bool save_assets() {
    if (g.project_path.empty()) return false;
    if (!ensure_project_browser()) return false;
    std::string root = project_root_path();
    std::string file = (fs::path(root) / ".uirassets").string();
    uim_Result rc = uir_asset_registry_save(&g.assets, &g.project_file_service,
                                            file.c_str());
    if (rc != uim_OK) {
        log_line("asset registry save failed: " + std::to_string((int)rc));
        return false;
    }
    return true;
}

uint32_t asset_kind_for_path(const fs::path &path) {
    std::string ext = path.extension().string();
    for (auto &c : ext) c = (char)std::tolower((unsigned char)c);
    if (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp" ||
        ext == ".tga" || ext == ".webp") return UIR_ASSET_IMAGE;
    if (ext == ".ttf" || ext == ".otf" || ext == ".ttc") return UIR_ASSET_FONT;
    if (ext == ".wav" || ext == ".mp3" || ext == ".ogg" || ext == ".flac")
        return UIR_ASSET_AUDIO;
    if (ext == ".uiscene" || ext == ".uiproj" || ext == ".uireproj")
        return UIR_ASSET_SCENE;
    return UIR_ASSET_OTHER;
}

std::string unique_asset_destination(const fs::path &root, const fs::path &src) {
    fs::path dir = root / "assets";
    std::error_code ec;
    fs::create_directories(dir, ec);
    if (ec) return {};
    fs::path dst = dir / src.filename();
    if (!fs::exists(dst)) return dst.string();
    std::string stem = dst.stem().string();
    std::string ext = dst.extension().string();
    for (int i = 1; i < 1000; ++i) {
        fs::path candidate = dir / (stem + "_" + std::to_string(i) + ext);
        if (!fs::exists(candidate)) return candidate.string();
    }
    return {};
}

bool import_asset_from_path(const std::string &source_path) {
    if (g.project_path.empty()) {
        log_line("import asset needs a saved project");
        return false;
    }
    fs::path src(source_path);
    if (!fs::exists(src) || !fs::is_regular_file(src)) {
        log_line("import asset missing: " + source_path);
        return false;
    }
    fs::path root(project_root_path());
    std::string dest = unique_asset_destination(root, src);
    if (dest.empty()) {
        log_line("import asset destination failed");
        return false;
    }
    std::error_code ec;
    fs::copy_file(src, dest, fs::copy_options::none, ec);
    if (ec) {
        log_line("import asset copy failed: " + ec.message());
        return false;
    }
    std::string rel = fs::relative(fs::path(dest), root, ec).generic_string();
    if (ec || rel.empty()) {
        log_line("import asset relative path failed");
        return false;
    }
    uint64_t id = 0;
    uim_Result rc = uir_asset_registry_register(&g.assets, rel.c_str(),
                                                asset_kind_for_path(src), &id);
    if (rc != uim_OK) {
        log_line("asset registration failed: " + std::to_string((int)rc));
        return false;
    }
    if (!save_assets()) return false;
    g.selected_asset = (int)g.assets.count - 1;
    if (g.project_browser) (void)uim_project_browser_refresh(g.project_browser);
    log_line("asset imported: " + rel);
    return true;
}

bool import_asset_dialog() {
    std::string path = open_asset_dialog();
    if (path.empty()) return false;
    return import_asset_from_path(path);
}

const uir_AssetRecord *asset_by_id(uint64_t id) {
    for (uint32_t i = 0; i < g.assets.count; ++i) {
        if (g.assets.records[i].id == id) return &g.assets.records[i];
    }
    return nullptr;
}

bool create_prefab_from_selected() {
    if (!g.scene_mode || !g.scene_selected) {
        log_line("create prefab: select a scene entity first");
        return false;
    }
    std::string path = save_scene_dialog("prefab.uiscene");
    if (path.empty()) return false;
    uint64_t prefab_id = 0;
    if (!zcsr_editor_prefab_save_entity(&g.scene, g.scene_selected, path.c_str(),
                                        &prefab_id)) {
        log_line("create prefab failed: " + path);
        return false;
    }
    std::error_code ec;
    fs::path root(project_root_path());
    std::string rel = fs::relative(fs::path(path), root, ec).generic_string();
    if (!ec && !rel.empty() && rel.rfind("..", 0) != 0) {
        uint64_t id = 0;
        (void)uir_asset_registry_register(&g.assets, rel.c_str(),
                                          UIR_ASSET_SCENE, &id);
        (void)save_assets();
        g.selected_asset = (int)g.assets.count - 1;
        if (g.project_browser) (void)uim_project_browser_refresh(g.project_browser);
    }
    log_line("prefab saved: " + path);
    return true;
}

bool instantiate_prefab_asset(uint64_t asset_id, float x, float z) {
    const uir_AssetRecord *asset = asset_by_id(asset_id);
    if (!asset) return false;
    std::string absolute = asset->relative_path;
    if (!fs::path(absolute).is_absolute())
        absolute = (fs::path(project_root_path()) / absolute).string();
    zcsr_entity_id ids[ZCSR_SCENE_MAX_ENTITIES]{};
    size_t count = zcsr_editor_prefab_instantiate(&g.scene, absolute.c_str(),
                                                  x, z, ids, 8u, nullptr);
    if (count == 0u) {
        log_line("instantiate prefab failed: " + absolute);
        return false;
    }
    g.scene_selected = ids[0];
    g.scene_dirty = true;
    log_line("prefab instantiated: " + std::to_string(count));
    return true;
}

bool instantiate_prefab_dialog() {
    std::string path = open_scene_dialog();
    if (path.empty()) return false;
    std::error_code ec;
    fs::path root(project_root_path());
    std::string rel = fs::relative(fs::path(path), root, ec).generic_string();
    uint64_t id = 0;
    if (!ec && !rel.empty() && rel.rfind("..", 0) != 0 &&
        uir_asset_registry_find_path(&g.assets, rel.c_str(), &id) == uim_OK) {
        return instantiate_prefab_asset(id, 0.0f, 0.0f);
    }
    /* A prefab outside the asset registry can still be instantiated directly;
     * the scene keeps only its stable path hash. */
    uint64_t prefab_id = 0;
    size_t count = zcsr_editor_prefab_instantiate(&g.scene, path.c_str(),
                                                  0.0f, 0.0f, nullptr, 0u,
                                                  &prefab_id);
    if (count == 0u) return false;
    g.scene_dirty = true;
    log_line("prefab instantiated: " + std::to_string(count));
    return true;
}

void destroy_project_browser() {
    if (g.project_browser) {
        uim_project_browser_destroy(g.project_browser);
        g.project_browser = nullptr;
    }
    if (g.project_file_service.user) uim_file_service_destroy(&g.project_file_service);
    memset(&g.project_file_service, 0, sizeof(g.project_file_service));
    if (g.project_file_backend) {
        zcsr_file_service_destroy(g.project_file_backend);
        g.project_file_backend = nullptr;
    }
    g.project_browser_root.clear();
}

bool ensure_project_browser() {
    if (!g.project_browser) {
        g.project_browser = uim_project_browser_create();
        if (!g.project_browser) return false;
        (void)uim_text_input_init(&g.project_name_text, 127u);
    }
    if (!g.project_file_backend) {
        g.project_file_backend = zcsr_file_service_create();
        if (!g.project_file_backend) return false;
    }
    if (!g.project_file_service.user) {
        if (uim_file_service_create_from_zcsr(g.project_file_backend,
                                              &g.project_file_service) != uim_FILE_OK) {
            return false;
        }
        (void)uim_project_browser_set_file_service(g.project_browser, &g.project_file_service);
    }
    return true;
}

void sync_project_browser() {
    if (!ensure_project_browser()) return;
    std::string root = project_root_path();
    if (root.empty()) root = ".";
    if (root == g.project_browser_root) return;
    (void)uim_file_service_set_base_path(&g.project_file_service, root.c_str());
    uim_PBError rc = uim_project_browser_set_root(g.project_browser, root.c_str());
    if (rc == uim_PB_OK || rc == uim_PB_ERR_CAPACITY_EXCEEDED) {
        g.project_browser_root = root;
    } else {
        log_line("project browser root failed: " + root + " (" + std::to_string((int)rc) + ")");
    }
}

void draw_project_panel() {
    if (!g.show_project) return;
    ImGui::Begin("Project", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("PROJECT / ASSETS");
    sync_project_browser();
    if (!g.project_browser) {
        ImGui::TextDisabled("Project browser unavailable");
        ImGui::End();
        return;
    }

    const char *root = uim_project_browser_root_path(g.project_browser);
    std::string root_label = root && root[0] ? fs::path(root).filename().string() : "(no folder)";
    if (root_label.empty()) root_label = root;
    ImGui::TextDisabled("%s", root_label.c_str());
    if (ImGui::IsItemHovered() && root && root[0]) ImGui::SetTooltip("%s", root);
    if (ImGui::SmallButton("Refresh")) (void)uim_project_browser_refresh(g.project_browser);
    ImGui::SameLine();
    ImGui::BeginDisabled(g.project_path.empty());
    if (ImGui::SmallButton("Import")) (void)import_asset_dialog();
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::SmallButton("+Folder")) {
        g.project_name_mode = 1;
        ensure_field(&g.project_name_text, 127u);
        (void)uim_text_input_set_text(&g.project_name_text, "", 0u);
        ImGui::OpenPopup("project_name");
    }

    int selected = uim_project_browser_selected_index(g.project_browser);
    uim_PBVisibleNode selected_node{};
    bool has_selected = selected >= 0 &&
        uim_project_browser_get_node(g.project_browser, selected, &selected_node) == uim_PB_OK &&
        selected_node.rel_path[0] != '\0';
    ImGui::SameLine();
    ImGui::BeginDisabled(!has_selected);
    if (ImGui::SmallButton("Rename")) {
        g.project_name_mode = 2;
        ensure_field(&g.project_name_text, 127u);
        field_set_clamped(&g.project_name_text, selected_node.name);
        ImGui::OpenPopup("project_name");
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("Delete")) {
        g.project_delete_confirm = true;
        ImGui::OpenPopup("project_delete");
    }
    ImGui::EndDisabled();

    ensure_field(&g.project_filter_text, 63u);
    if (!field_is_focused("##project_filter"))
        field_set_clamped(&g.project_filter_text, field_value(g.project_filter_text));
    (void)draw_uim_text_field("##project_filter", &g.project_filter_text, 0.0f,
                              "Search project", false);
    std::string project_filter = field_value(g.project_filter_text);
    for (auto &c : project_filter) c = (char)std::tolower((unsigned char)c);

    ImGui::Separator();
    ImGui::BeginChild("##project_tree", ImVec2(0.0f, -118.0f), true);
    int count = uim_project_browser_visible_count(g.project_browser);
    for (int i = 0; i < count; ++i) {
        uim_PBVisibleNode node{};
        if (uim_project_browser_get_node(g.project_browser, i, &node) != uim_PB_OK) continue;
        std::string haystack = std::string(node.name) + " " + node.rel_path;
        for (auto &c : haystack) c = (char)std::tolower((unsigned char)c);
        if (!project_filter.empty() && node.depth > 0 &&
            haystack.find(project_filter) == std::string::npos)
            continue;
        ImGui::PushID(i);
        float indent = 14.0f * (float)node.depth;
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + indent);
        if (node.is_dir) {
            if (ImGui::SmallButton(node.expanded ? "v" : ">"))
                (void)uim_project_browser_toggle_node(g.project_browser, i);
            ImGui::SameLine();
        } else {
            ImGui::TextDisabled("-");
            ImGui::SameLine();
        }
        std::string label = (node.is_dir ? "[D] " : "") + std::string(node.name);
        if (ImGui::Selectable(label.c_str(), node.selected,
                              ImGuiSelectableFlags_AllowDoubleClick,
                              ImVec2(0.0f, 20.0f))) {
            uim_project_browser_select(g.project_browser, i);
        }
        if (node.is_dir && ImGui::IsItemHovered() &&
            ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
            (void)uim_project_browser_toggle_node(g.project_browser, i);
        }
        ImGui::PopID();
    }
    ImGui::EndChild();

    ImGui::Separator();
    ImGui::TextDisabled("ASSETS %u", (unsigned int)g.assets.count);
    ImGui::SameLine();
    ImGui::BeginDisabled(g.selected_asset < 0 ||
                         g.selected_asset >= (int)g.assets.count);
    if (ImGui::SmallButton("Remove")) {
        uint64_t id = g.assets.records[g.selected_asset].id;
        if (uir_asset_registry_remove(&g.assets, id) == uim_OK) {
            (void)save_assets();
            g.selected_asset = -1;
            log_line("asset removed from registry");
        }
    }
    ImGui::EndDisabled();
    ImGui::BeginChild("##project_assets", ImVec2(0.0f, 96.0f), true);
    if (g.assets.count == 0u) {
        ImGui::TextDisabled("Import an image/font/audio or .uiscene.");
    } else {
        for (uint32_t i = 0; i < g.assets.count; ++i) {
            const uir_AssetRecord &a = g.assets.records[i];
            ImGui::PushID((int)a.id);
            std::string label = std::string("[A] ") + a.display_name;
            bool selected = g.selected_asset == (int)i;
            if (ImGui::Selectable(label.c_str(), selected, 0, ImVec2(0.0f, 18.0f)))
                g.selected_asset = (int)i;
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", a.relative_path);
            if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
                ImGui::SetDragDropPayload("zcsr_asset", &a.id, sizeof(a.id));
                ImGui::TextUnformatted(a.display_name);
                ImGui::EndDragDropSource();
            }
            ImGui::PopID();
        }
    }
    ImGui::EndChild();

    uim_PBError error = uim_project_browser_get_error(g.project_browser);
    if (error != uim_PB_OK) {
        ImGui::TextColored(ImVec4(0.95f, 0.55f, 0.35f, 1.0f),
                           "Project browser error %d", (int)error);
    }
    if (uim_project_browser_capacity_exceeded(g.project_browser))
        ImGui::TextDisabled("Tree truncated at capacity");

    if (g.project_name_mode != 0 && ImGui::BeginPopupModal(
            "project_name", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted(g.project_name_mode == 1 ? "New folder" : "Rename");
        ensure_field(&g.project_name_text, 127u);
        UimFieldResult f = draw_uim_text_field("##project_name", &g.project_name_text,
                                               240.0f, nullptr, true);
        bool submit = f.submitted || ImGui::Button("OK", ImVec2(90, 0));
        ImGui::SameLine();
        bool cancel = f.cancelled || ImGui::Button("Cancel", ImVec2(90, 0));
        if (submit) {
            std::string name = field_value(g.project_name_text);
            uim_PBError rc = g.project_name_mode == 1
                ? uim_project_browser_create_dir_in_selected(g.project_browser, name.c_str())
                : uim_project_browser_rename_selected(g.project_browser, name.c_str());
            if (rc == uim_PB_OK) {
                log_line(g.project_name_mode == 1 ? "project folder created" : "project renamed");
            } else {
                log_line("project operation failed: " + std::to_string((int)rc));
            }
            g.project_name_mode = 0;
            ImGui::CloseCurrentPopup();
        }
        if (cancel) {
            g.project_name_mode = 0;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }

    if (g.project_delete_confirm && ImGui::BeginPopupModal(
            "project_delete", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Delete \"%s\"?", has_selected ? selected_node.name : "selected item");
        ImGui::TextDisabled("This removes the file or directory from disk.");
        if (ImGui::Button("Delete", ImVec2(90, 0))) {
            uim_PBError rc = uim_project_browser_remove_selected(g.project_browser);
            if (rc == uim_PB_OK) log_line("project item deleted");
            else log_line("project delete failed: " + std::to_string((int)rc));
            g.project_delete_confirm = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(90, 0))) {
            g.project_delete_confirm = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
    ImGui::End();
}


void draw_scene_hierarchy() {
    ImGui::Begin("Hierarchy", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("SCENE ENTITIES");
    ensure_field(&g.hierarchy_filter_text, 63u);
    (void)draw_uim_text_field("##scene_filter", &g.hierarchy_filter_text, 0.0f,
                              "Search entities", false);
    std::string scene_filter = field_value(g.hierarchy_filter_text);
    for (auto &c : scene_filter) c = (char)std::tolower((unsigned char)c);
    if (ImGui::SmallButton("+Box")) {
        scene_add_box(0.0f, 0.0f, 2.0f, 2.0f, 0.80f, 0.60f, 0.40f);
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("+Quad")) {
        scene_add_quad(0.0f, 0.0f, 2.0f, 0.45f, 0.65f, 0.90f);
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("Dup") && g.scene_selected) {
        (void)scene_duplicate(g.scene_selected, 0.5f, 0.0f);
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("Del") && g.scene_selected) {
        (void)scene_delete(g.scene_selected);
    }
    ImGui::Separator();
    for (size_t i = 0; i < g.scene.count; ++i) {
        const zcsr_scene_entity &e = g.scene.entities[i];
        ImGui::PushID((int)(uintptr_t)e.id);
        char label[160];
        std::snprintf(label, sizeof(label), "Entity #%llu  L%d/O%d  K%u",
                      (unsigned long long)e.id, e.layer, e.order,
                      (unsigned int)e.kind);
        std::string haystack = label;
        for (auto &c : haystack) c = (char)std::tolower((unsigned char)c);
        if (!scene_filter.empty() && haystack.find(scene_filter) == std::string::npos)
            continue;
        bool selected = e.id == g.scene_selected;
        if (ImGui::Selectable(label, selected)) g.scene_selected = e.id;
        if (ImGui::BeginPopupContextItem()) {
            if (ImGui::MenuItem("Delete")) {
                (void)scene_delete(e.id);
            }
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    ImGui::End();
}

/* Call immediately after an editable Inspector widget.  IsItemActivated on
 * the first click captures the pre-edit content; IsItemDeactivatedAfterEdit
 * commits exactly one undo entry for a drag/keyboard edit. */
void scene_inspector_item_history() {
    if (ImGui::IsItemActivated()) scene_gesture_begin();
    if (ImGui::IsItemDeactivatedAfterEdit()) scene_gesture_end();
}

void draw_scene_camera_panel() {
    zcsr_scene_camera &c = g.scene.camera;
    if (ImGui::CollapsingHeader("Scene Camera", ImGuiTreeNodeFlags_DefaultOpen)) {
        float target[3] = {c.target_x, c.target_y, c.target_z};
        if (ImGui::DragFloat3("target", target, 0.10f)) {
            c.target_x = target[0];
            c.target_y = target[1];
            c.target_z = target[2];
            g.scene_dirty = true;
        }
        if (ImGui::DragFloat("yaw", &c.yaw_deg, 0.5f, -180.0f, 180.0f)) g.scene_dirty = true;
        if (ImGui::DragFloat("pitch", &c.pitch_deg, 0.5f, 1.0f, 89.0f)) g.scene_dirty = true;
        if (ImGui::DragFloat("roll", &c.roll_deg, 0.5f, -180.0f, 180.0f)) g.scene_dirty = true;
        if (ImGui::DragFloat("distance", &c.distance, 0.1f, 0.1f, 200.0f)) g.scene_dirty = true;
        if (ImGui::DragFloat("ortho", &c.ortho_size, 0.05f, 0.5f, 80.0f)) g.scene_dirty = true;
        if (ImGui::Button("Reset camera")) {
            zcsr_scene_camera_init(&c, c.view_w, c.view_h,
                                   35.0f, 45.0f, 0.0f, 20.0f, 8.0f);
            g.scene_dirty = true;
        }
    }
}

void draw_scene_inspector() {
    ImGui::Begin("Inspector", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("SCENE INSPECTOR");
    zcsr_scene_entity *e = g.scene_selected ? zcsr_scene_get(&g.scene, g.scene_selected) : nullptr;
    if (!e) {
        ImGui::TextDisabled("Nothing selected");
        draw_scene_camera_panel();
        ImGui::Separator();
        if (ImGui::Button("Save scene")) (void)scene_save(false);
        ImGui::SameLine();
        if (ImGui::Button("Save scene as")) (void)scene_save(true);
        ImGui::SameLine();
        if (ImGui::Button("Open scene")) {
            std::string path = open_scene_dialog();
            if (!path.empty()) (void)scene_load(path);
        }
        ImGui::End();
        return;
    }

    ImGui::Text("Entity #%llu", (unsigned long long)e->id);
    float pos[3] = {e->x, e->y, e->z};
    if (ImGui::DragFloat3("position", pos, 0.05f)) {
        e->x = pos[0]; e->y = pos[1]; e->z = pos[2];
        g.scene_dirty = true;
    }
    scene_inspector_item_history();
    float size[2] = {e->w, e->h};
    if (ImGui::DragFloat2("size", size, 0.05f, 0.0f, 1000.0f)) {
        e->w = std::max(size[0], 0.0f);
        e->h = std::max(size[1], 0.0f);
        g.scene_dirty = true;
    }
    scene_inspector_item_history();
    if (ImGui::DragFloat("rotation", &e->rotation_deg, 0.5f, -180.0f, 180.0f))
        g.scene_dirty = true;
    scene_inspector_item_history();
    if (ImGui::DragFloat2("pivot", &e->pivot_x, 0.01f, 0.0f, 1.0f))
        g.scene_dirty = true;
    scene_inspector_item_history();
    if (ImGui::DragInt("layer", &e->layer, 1, 0, ZCSR_SCENE_MAX_LAYERS - 1))
        g.scene_dirty = true;
    scene_inspector_item_history();
    if (ImGui::DragInt("order", &e->order, 1, -10000, 10000))
        g.scene_dirty = true;
    scene_inspector_item_history();
    float tint[4] = {e->tint_r, e->tint_g, e->tint_b, e->tint_a};
    if (ImGui::ColorEdit4("tint", tint, ImGuiColorEditFlags_AlphaBar)) {
        e->tint_r = tint[0]; e->tint_g = tint[1];
        e->tint_b = tint[2]; e->tint_a = tint[3];
        g.scene_dirty = true;
    }
    scene_inspector_item_history();
    int texture = (int)e->texture;
    if (ImGui::DragInt("texture", &texture, 1, 0, 0x7fffffff)) {
        e->texture = (uint32_t)texture;
        g.scene_dirty = true;
    }
    scene_inspector_item_history();

    int kind = (int)e->kind;
    const char *kind_items[] = {"Rect", "Sprite", "Prefab", "Light"};
    if (ImGui::Combo("kind", &kind, kind_items, 4)) {
        if (zcsr_editor_scene_set_asset_ref(&g.scene, e->id, (uint32_t)kind,
                                            e->prefab_id, e->asset_id))
            g.scene_dirty = true;
    }
    scene_inspector_item_history();
    uint64_t prefab_id = e->prefab_id;
    if (ImGui::InputScalar("prefab id", ImGuiDataType_U64, &prefab_id)) {
        if (zcsr_editor_scene_set_asset_ref(&g.scene, e->id, e->kind,
                                            prefab_id, e->asset_id))
            g.scene_dirty = true;
    }
    scene_inspector_item_history();
    int asset_index = 0;
    for (uint32_t i = 0; i < g.assets.count; ++i) {
        if (g.assets.records[i].id == e->asset_id) { asset_index = (int)i + 1; break; }
    }
    std::vector<const char *> asset_items;
    asset_items.push_back("None");
    for (uint32_t i = 0; i < g.assets.count; ++i)
        asset_items.push_back(g.assets.records[i].display_name);
    if (!asset_items.empty() && ImGui::Combo("asset", &asset_index,
                                             asset_items.data(),
                                             (int)asset_items.size())) {
        uint64_t next_asset = asset_index > 0
            ? g.assets.records[asset_index - 1].id : 0u;
        if (zcsr_editor_scene_set_asset_ref(&g.scene, e->id, e->kind,
                                            e->prefab_id, next_asset))
            g.scene_dirty = true;
    }
    scene_inspector_item_history();
    if (ImGui::Button("Create prefab")) (void)create_prefab_from_selected();
    ImGui::SameLine();
    if (ImGui::Button("Instantiate prefab")) (void)instantiate_prefab_dialog();
    if (ImGui::Checkbox("visible", &e->visible)) g.scene_dirty = true;
    scene_inspector_item_history();

    bool has_quad = zcsr_scene_has_quad(&g.scene, e->id);
    if (ImGui::Checkbox("explicit quad", &has_quad)) {
        scene_gesture_begin();
        if (has_quad) {
            zcsr_scene_point q[4];
            if (zcsr_scene_entity_quad(&g.scene, e->id, q))
                (void)zcsr_editor_scene_set_quad(&g.scene, e->id, q);
        } else {
            (void)zcsr_editor_scene_clear_quad(&g.scene, e->id);
        }
        g.scene_dirty = true;
        scene_gesture_end();
    }
    if (zcsr_scene_has_quad(&g.scene, e->id)) {
        zcsr_scene_point q[4];
        if (zcsr_scene_entity_quad(&g.scene, e->id, q)) {
            bool qedit = false;
            for (int i = 0; i < 4; ++i) {
                float p[3] = {q[i].x, q[i].y, q[i].z};
                ImGui::PushID(i);
                if (ImGui::DragFloat3("corner", p, 0.05f)) {
                    q[i].x = p[0]; q[i].y = p[1]; q[i].z = p[2];
                    qedit = true;
                }
                scene_inspector_item_history();
                ImGui::PopID();
            }
            if (qedit) {
                (void)zcsr_editor_scene_set_quad(&g.scene, e->id, q);
                g.scene_dirty = true;
            }
        }
        if (ImGui::Button("Reset quad from rectangle")) {
            scene_gesture_begin();
            zcsr_scene_point q[4];
            (void)zcsr_editor_scene_clear_quad(&g.scene, e->id);
            if (zcsr_scene_entity_quad(&g.scene, e->id, q))
                (void)zcsr_editor_scene_set_quad(&g.scene, e->id, q);
            g.scene_dirty = true;
            scene_gesture_end();
        }
    }
    if (ImGui::Button("Delete entity")) {
        (void)scene_delete(e->id);
    }
    if (g.scene_gesture_active && !ImGui::IsAnyItemActive() &&
        ImGui::IsMouseReleased(ImGuiMouseButton_Left)) scene_gesture_end();
    ImGui::Separator();
    draw_scene_camera_panel();
    if (g.scene_gesture_active && !ImGui::IsAnyItemActive() &&
        ImGui::IsMouseReleased(ImGuiMouseButton_Left)) scene_gesture_end();
    ImGui::Separator();
    ImGui::TextDisabled("scene: %s%s", g.scene_path.empty() ? "(untitled)" : g.scene_path.c_str(),
                        g.scene_dirty ? " *" : "");
    if (ImGui::Button("Save scene")) (void)scene_save(false);
    ImGui::SameLine();
    if (ImGui::Button("Save as")) (void)scene_save(true);
    ImGui::SameLine();
    if (ImGui::Button("Open scene")) {
        std::string path = open_scene_dialog();
        if (!path.empty()) (void)scene_load(path);
    }
    ImGui::End();
}

void scene_gizmo_basis(const zcsr_scene_entity *e,
                       float &xx, float &xz, float &zx, float &zz) {
    float radians = (e ? e->rotation_deg : 0.0f) * 3.14159265358979323846f / 180.0f;
    float c = std::cos(radians), s = std::sin(radians);
    if (g.gizmo_space == 1) {
        xx = c; xz = s;
        zx = -s; zz = c;
    } else {
        xx = 1.0f; xz = 0.0f;
        zx = 0.0f; zz = 1.0f;
    }
}

bool scene_gizmo_endpoint(const zcsr_scene_entity *e, int axis,
                          const ImVec2 &child_min, ImVec2 *out) {
    if (!e || !out) return false;
    float xx, xz, zx, zz;
    scene_gizmo_basis(e, xx, xz, zx, zz);
    const float len = 1.6f;
    float wx = e->x, wy = e->y, wz = e->z;
    if (axis == 0) { wx += xx * len; wz += xz * len; }
    else if (axis == 1) { wy += len; }
    else { wx += zx * len; wz += zz * len; }
    float sx = 0.0f, sy = 0.0f;
    if (!zcsr_scene_camera_project(&g.scene.camera, wx, wy, wz, &sx, &sy, nullptr))
        return false;
    *out = ImVec2(child_min.x + sx, child_min.y + sy);
    return true;
}

void draw_scene_gizmo(ImDrawList *draw, const ImVec2 &child_min) {
    const zcsr_scene_entity *e = zcsr_scene_get_const(&g.scene, g.scene_selected);
    if (!e) return;
    ImVec2 origin;
    if (!zcsr_scene_camera_project(&g.scene.camera, e->x, e->y, e->z,
                                   &origin.x, &origin.y, nullptr))
        return;
    origin.x += child_min.x;
    origin.y += child_min.y;
    ImU32 cols[3] = {
        g.scene_gizmo_axis == 0 ? IM_COL32(255, 230, 90, 255) : IM_COL32(230, 75, 75, 255),
        g.scene_gizmo_axis == 1 ? IM_COL32(255, 230, 90, 255) : IM_COL32(80, 225, 115, 255),
        g.scene_gizmo_axis == 2 ? IM_COL32(255, 230, 90, 255) : IM_COL32(80, 155, 255, 255)
    };
    const char *labels[3] = {"X", "Y", "Z"};
    draw->AddCircleFilled(origin, 4.0f, IM_COL32(250, 250, 250, 255));
    for (int axis = 0; axis < 3; ++axis) {
        ImVec2 end;
        if (!scene_gizmo_endpoint(e, axis, child_min, &end)) continue;
        draw->AddLine(origin, end, cols[axis], 2.2f);
        draw->AddText(ImVec2(end.x + 3.0f, end.y - 5.0f), cols[axis], labels[axis]);
    }
}

int scene_gizmo_hit(const ImVec2 &mouse, const ImVec2 &child_min) {
    const zcsr_scene_entity *e = zcsr_scene_get_const(&g.scene, g.scene_selected);
    if (!e) return -1;
    for (int axis = 0; axis < 3; ++axis) {
        ImVec2 end;
        if (!scene_gizmo_endpoint(e, axis, child_min, &end)) continue;
        float dx = mouse.x - end.x, dy = mouse.y - end.y;
        if (dx * dx + dy * dy <= 12.0f * 12.0f) return axis;
    }
    return -1;
}

void scene_gizmo_begin(const ImVec2 &mouse, const ImVec2 &child_min) {
    const zcsr_scene_entity *e = zcsr_scene_get_const(&g.scene, g.scene_selected);
    if (!e) return;
    g.scene_gizmo_axis = scene_gizmo_hit(mouse, child_min);
    if (g.scene_gizmo_axis < 0) return;
    g.scene_gizmo_dragging = true;
    g.scene_gizmo_start = mouse;
    g.scene_gizmo_x = e->x;
    g.scene_gizmo_y = e->y;
    g.scene_gizmo_z = e->z;
    g.scene_gizmo_rot = e->rotation_deg;
    g.scene_gizmo_w = e->w;
    g.scene_gizmo_h = e->h;
    g.scene_dragging = false;
    scene_gesture_begin();
}

void scene_gizmo_drag(const ImVec2 &mouse, const ImVec2 &child_min) {
    zcsr_scene_entity *e = zcsr_scene_get(&g.scene, g.scene_selected);
    if (!e || !g.scene_gizmo_dragging) return;
    float dx = mouse.x - g.scene_gizmo_start.x;
    float dy = mouse.y - g.scene_gizmo_start.y;
    if (g.gizmo_mode == 1) {
        float next = g.scene_gizmo_rot + dx * 0.5f;
        if (g.gizmo_snap && g.gizmo_rotate_step > 0.0f)
            next = std::round(next / g.gizmo_rotate_step) * g.gizmo_rotate_step;
        if (zcsr_editor_scene_set_rotation(&g.scene, e->id, next)) g.scene_dirty = true;
    } else if (g.gizmo_mode == 2) {
        float delta = (dx - dy) * 0.02f;
        float next_w = g.scene_gizmo_w + (g.scene_gizmo_axis == 1 ? 0.0f : delta);
        float next_h = g.scene_gizmo_h + (g.scene_gizmo_axis == 0 ? 0.0f : delta);
        next_w = std::max(0.01f, next_w);
        next_h = std::max(0.01f, next_h);
        if (g.gizmo_snap && g.gizmo_scale_step > 0.0f) {
            next_w = std::max(g.gizmo_scale_step,
                              std::round(next_w / g.gizmo_scale_step) * g.gizmo_scale_step);
            next_h = std::max(g.gizmo_scale_step,
                              std::round(next_h / g.gizmo_scale_step) * g.gizmo_scale_step);
        }
        if (zcsr_editor_scene_set_size(&g.scene, e->id, next_w, next_h))
            g.scene_dirty = true;
    } else {
        if (g.scene_gizmo_axis == 1) {
            float sx0 = 0.0f, sy0 = 0.0f, sx1 = 0.0f, sy1 = 0.0f;
            float next_y;
            (void)zcsr_scene_camera_project(&g.scene.camera, e->x, g.scene_gizmo_y, e->z,
                                            &sx0, &sy0, nullptr);
            (void)zcsr_scene_camera_project(&g.scene.camera, e->x, g.scene_gizmo_y + 1.0f, e->z,
                                            &sx1, &sy1, nullptr);
            float pixels_per_unit = sy0 - sy1;
            if (pixels_per_unit < 1.0f) pixels_per_unit = 1.0f;
            next_y = g.scene_gizmo_y + (g.scene_gizmo_start.y - mouse.y) / pixels_per_unit;
            if (g.gizmo_snap && g.gizmo_snap_step > 0.0f)
                next_y = std::round(next_y / g.gizmo_snap_step) * g.gizmo_snap_step;
            if (zcsr_editor_scene_set_y(&g.scene, e->id, next_y))
                g.scene_dirty = true;
            return;
        }
        float x0 = 0.0f, z0 = 0.0f, x1 = 0.0f, z1 = 0.0f;
        if (zcsr_scene_camera_screen_to_plane(&g.scene.camera,
                                               g.scene_gizmo_start.x - child_min.x,
                                               g.scene_gizmo_start.y - child_min.y,
                                               e->y, &x0, &z0) &&
            zcsr_scene_camera_screen_to_plane(&g.scene.camera,
                                               mouse.x - child_min.x,
                                               mouse.y - child_min.y,
                                               e->y, &x1, &z1)) {
            float xx, xz, zx, zz;
            scene_gizmo_basis(e, xx, xz, zx, zz);
            float wx, wz;
            if (g.scene_gizmo_axis == 0) {
                float d = (x1 - x0) * xx + (z1 - z0) * xz;
                wx = g.scene_gizmo_x + d * xx;
                wz = g.scene_gizmo_z + d * xz;
            } else {
                float d = (x1 - x0) * zx + (z1 - z0) * zz;
                wx = g.scene_gizmo_x + d * zx;
                wz = g.scene_gizmo_z + d * zz;
            }
            if (g.gizmo_snap && g.gizmo_snap_step > 0.0f) {
                wx = std::round(wx / g.gizmo_snap_step) * g.gizmo_snap_step;
                wz = std::round(wz / g.gizmo_snap_step) * g.gizmo_snap_step;
            }
            if (zcsr_editor_scene_move(&g.scene, e->id, wx - e->x, wz - e->z))
                g.scene_dirty = true;
        }
    }
}

void draw_scene_viewport(ImVec2 child_min, ImVec2 child_size) {
    zcsr_scene_camera_set_viewport(&g.scene.camera, (int)child_size.x, (int)child_size.y);
    ImGui::Dummy(child_size);
    if (ImGui::BeginDragDropTarget()) {
        const ImGuiPayload *payload = ImGui::AcceptDragDropPayload("zcsr_asset");
        if (payload && payload->DataSize == sizeof(uint64_t)) {
            uint64_t asset_id = *(const uint64_t *)payload->Data;
            const uir_AssetRecord *asset = asset_by_id(asset_id);
            if (asset) {
                float lx = ImGui::GetIO().MousePos.x - child_min.x;
                float ly = ImGui::GetIO().MousePos.y - child_min.y;
                float wx = 0.0f, wz = 0.0f;
                (void)zcsr_scene_camera_screen_to_ground(&g.scene.camera, lx, ly, &wx, &wz);
                if (asset->kind == UIR_ASSET_SCENE) {
                    (void)instantiate_prefab_asset(asset_id, wx, wz);
                } else {
                    zcsr_editor_scene_change change = zcsr_editor_scene_add_asset(
                        &g.scene, wx, wz, 2.0f, 2.0f, ZCSR_SCENE_KIND_SPRITE,
                        0u, asset_id);
                    if (change.changed) {
                        g.scene_selected = change.id;
                        g.scene_dirty = true;
                        log_line("asset dropped into scene: " + std::string(asset->relative_path));
                    }
                }
            }
        }
        ImGui::EndDragDropTarget();
    }
    ImDrawList *draw = ImGui::GetWindowDrawList();
    ImGuiIO &io = ImGui::GetIO();
    draw->AddRectFilled(child_min, ImVec2(child_min.x + child_size.x, child_min.y + child_size.y),
                        IM_COL32(18, 24, 31, 255));

    /* Ground grid in world units. This is authoring reference geometry, not a
     * scene entity and not part of the saved document. */
    for (int i = -12; i <= 12; ++i) {
        float ax = 0.0f, ay = 0.0f, bx = 0.0f, by = 0.0f;
        if (zcsr_scene_camera_project(&g.scene.camera, (float)i, 0.0f, -12.0f, &ax, &ay, NULL) &&
            zcsr_scene_camera_project(&g.scene.camera, (float)i, 0.0f, 12.0f, &bx, &by, NULL)) {
            draw->AddLine(ImVec2(child_min.x + ax, child_min.y + ay),
                          ImVec2(child_min.x + bx, child_min.y + by),
                          i == 0 ? IM_COL32(90, 130, 160, 220) : IM_COL32(55, 75, 95, 150), 1.0f);
        }
        if (zcsr_scene_camera_project(&g.scene.camera, -12.0f, 0.0f, (float)i, &ax, &ay, NULL) &&
            zcsr_scene_camera_project(&g.scene.camera, 12.0f, 0.0f, (float)i, &bx, &by, NULL)) {
            draw->AddLine(ImVec2(child_min.x + ax, child_min.y + ay),
                          ImVec2(child_min.x + bx, child_min.y + by),
                          i == 0 ? IM_COL32(90, 130, 160, 220) : IM_COL32(55, 75, 95, 150), 1.0f);
        }
    }

    size_t order[ZCSR_SCENE_MAX_ENTITIES];
    size_t count = zcsr_scene_build_order(&g.scene, order, ZCSR_SCENE_MAX_ENTITIES);
    for (size_t k = 0; k < count; ++k) {
        const zcsr_scene_entity &e = g.scene.entities[order[k]];
        zcsr_scene_point q[4];
        ImVec2 p[4];
        bool ok = true;
        if (!zcsr_scene_entity_quad(&g.scene, e.id, q)) continue;
        for (int i = 0; i < 4; ++i) {
            float sx = 0.0f, sy = 0.0f;
            if (!zcsr_scene_camera_project(&g.scene.camera, q[i].x, q[i].y, q[i].z, &sx, &sy, NULL)) {
                ok = false;
                break;
            }
            p[i] = ImVec2(child_min.x + sx, child_min.y + sy);
        }
        if (!ok) continue;
        ImU32 fill = ImGui::ColorConvertFloat4ToU32(
            ImVec4(e.tint_r, e.tint_g, e.tint_b, e.tint_a));
        draw->AddConvexPolyFilled(p, 4, fill);
        ImU32 outline = (e.id == g.scene_selected) ? IM_COL32(255, 205, 90, 255)
                                                   : IM_COL32(210, 220, 235, 180);
        draw->AddPolyline(p, 4, outline, ImDrawFlags_Closed,
                          (e.id == g.scene_selected) ? 2.5f : 1.0f);
        if (e.texture != 0) {
            draw->AddText(ImVec2(p[0].x + 4.0f, p[0].y + 2.0f),
                          IM_COL32(255, 255, 255, 220), "tex");
        }
    }

    if (g.scene_selected) {
        draw_scene_gizmo(draw, child_min);
        zcsr_scene_point q[4];
        ImVec2 handles[4];
        bool handles_ok = zcsr_scene_entity_quad(&g.scene, g.scene_selected, q);
        for (int i = 0; i < 4 && handles_ok; ++i) {
            float sx = 0.0f, sy = 0.0f;
            if (!zcsr_scene_camera_project(&g.scene.camera, q[i].x, q[i].y, q[i].z, &sx, &sy, NULL)) {
                handles_ok = false;
                break;
            }
            handles[i] = ImVec2(child_min.x + sx, child_min.y + sy);
        }
        if (handles_ok) {
            for (int i = 0; i < 4; ++i) {
                draw->AddCircleFilled(handles[i], 5.0f,
                                      (i == g.scene_resize_handle) ? IM_COL32(255, 230, 120, 255)
                                                                   : IM_COL32(230, 235, 245, 230));
            }
            if (ImGui::IsMouseReleased(ImGuiMouseButton_Left)) g.scene_resize_handle = -1;
        }
    }

    bool hovered = ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
    if (hovered && !g.scene_panning && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
        float lx = io.MousePos.x - child_min.x;
        float ly = io.MousePos.y - child_min.y;
        int gizmo_axis = g.scene_selected ? scene_gizmo_hit(io.MousePos, child_min) : -1;
        int handle = -1;
        if (gizmo_axis >= 0) {
            scene_gizmo_begin(io.MousePos, child_min);
        } else if (g.scene_selected) {
            zcsr_scene_point q[4];
            if (zcsr_scene_entity_quad(&g.scene, g.scene_selected, q)) {
                for (int i = 0; i < 4; ++i) {
                    float sx = 0.0f, sy = 0.0f;
                    if (zcsr_scene_camera_project(&g.scene.camera, q[i].x, q[i].y, q[i].z, &sx, &sy, NULL) &&
                        std::abs(lx - sx) < 8.0f && std::abs(ly - sy) < 8.0f) {
                        handle = i;
                        break;
                    }
                }
            }
        }
        if (gizmo_axis >= 0) {
            /* scene_gizmo_begin already recorded the gesture. */
        } else if (handle >= 0) {
            scene_gesture_begin();
            g.scene_resize_handle = handle;
            if (zcsr_scene_entity_quad(&g.scene, g.scene_selected, g.scene_resize_quad))
                g.scene_dragging = false;
        } else {
            zcsr_entity_id hit = zcsr_scene_pick(&g.scene, lx, ly);
            g.scene_selected = hit;
            g.scene_dragging = hit != 0;
            g.scene_drag_prev = io.MousePos;
            if (hit) {
                scene_gesture_begin();
                zcsr_scene_entity *e = zcsr_scene_get(&g.scene, hit);
                if (e) {
                    g.scene_drag_x = e->x;
                    g.scene_drag_z = e->z;
                }
            }
        }
    }

    if (g.scene_gizmo_dragging && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
        scene_gizmo_drag(io.MousePos, child_min);
    } else if (g.scene_resize_handle >= 0 && g.scene_selected &&
        ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
        zcsr_scene_entity *e = zcsr_scene_get(&g.scene, g.scene_selected);
        if (e) {
            float lx = io.MousePos.x - child_min.x;
            float ly = io.MousePos.y - child_min.y;
            float wx = 0.0f, wz = 0.0f;
            zcsr_scene_point q[4];
            if (zcsr_scene_entity_quad(&g.scene, e->id, q)) {
                if (zcsr_scene_camera_screen_to_plane(&g.scene.camera, lx, ly,
                                                       q[g.scene_resize_handle].y, &wx, &wz)) {
                    q[g.scene_resize_handle].x = wx;
                    q[g.scene_resize_handle].z = wz;
                    (void)zcsr_editor_scene_set_quad(&g.scene, e->id, q);
                    g.scene_dirty = true;
                }
            }
        }
    } else if (g.scene_dragging && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
        zcsr_scene_entity *e = zcsr_scene_get(&g.scene, g.scene_selected);
        if (e) {
            float lx0 = g.scene_drag_prev.x - child_min.x;
            float ly0 = g.scene_drag_prev.y - child_min.y;
            float lx1 = io.MousePos.x - child_min.x;
            float ly1 = io.MousePos.y - child_min.y;
            float x0 = 0.0f, z0 = 0.0f, x1 = 0.0f, z1 = 0.0f;
            if (zcsr_scene_camera_screen_to_plane(&g.scene.camera, lx0, ly0, e->y, &x0, &z0) &&
                zcsr_scene_camera_screen_to_plane(&g.scene.camera, lx1, ly1, e->y, &x1, &z1)) {
                if (zcsr_editor_scene_move(&g.scene, e->id, x1 - x0, z1 - z0))
                    g.scene_dirty = true;
            }
            g.scene_drag_prev = io.MousePos;
        }
    }
    /* End only on an actual release. Using !IsMouseDown here ends the gesture
     * on the mousedown frame before the drag delta exists, which commits an
     * unchanged snapshot and leaves the move outside undo history. */
    if (ImGui::IsMouseReleased(ImGuiMouseButton_Left)) {
        g.scene_dragging = false;
        g.scene_gizmo_dragging = false;
        g.scene_gizmo_axis = -1;
        scene_gesture_end();
    }

    if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Middle)) {
        g.scene_panning = true;
        g.scene_pan_prev = io.MousePos;
    }
    if (g.scene_panning) {
        if (ImGui::IsMouseDown(ImGuiMouseButton_Middle)) {
            float lx0 = g.scene_pan_prev.x - child_min.x;
            float ly0 = g.scene_pan_prev.y - child_min.y;
            float lx1 = io.MousePos.x - child_min.x;
            float ly1 = io.MousePos.y - child_min.y;
            float x0 = 0.0f, z0 = 0.0f, x1 = 0.0f, z1 = 0.0f;
            if (zcsr_scene_camera_screen_to_ground(&g.scene.camera, lx0, ly0, &x0, &z0) &&
                zcsr_scene_camera_screen_to_ground(&g.scene.camera, lx1, ly1, &x1, &z1)) {
                g.scene.camera.target_x -= x1 - x0;
                g.scene.camera.target_z -= z1 - z0;
            } else {
                g.scene.camera.target_x -= (lx1 - lx0) * g.scene.camera.ortho_size / child_size.y * 2.0f;
                g.scene.camera.target_z += (ly1 - ly0) * g.scene.camera.ortho_size / child_size.y * 2.0f;
            }
            g.scene_dirty = true;
            g.scene_pan_prev = io.MousePos;
        } else {
            g.scene_panning = false;
        }
    }

    if (hovered && io.MouseWheel != 0.0f) {
        g.scene.camera.ortho_size = std::clamp(
            g.scene.camera.ortho_size * (io.MouseWheel > 0 ? 0.9f : 1.1f), 0.5f, 80.0f);
        g.scene_dirty = true;
    }

    draw->AddText(ImVec2(child_min.x + 10.0f, child_min.y + 8.0f),
                  IM_COL32(190, 210, 230, 255),
                  g.scene_selected ? "SCENE  |  LMB select/move  |  corner handle resize  |  MMB pan  |  wheel zoom"
                                   : "SCENE  |  LMB select  |  MMB pan  |  wheel zoom");
}

void draw_hierarchy() {
    if (g.scene_mode) {
        draw_scene_hierarchy();
        return;
    }
    ImGui::Begin("Hierarchy", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("HIERARCHY");
    ensure_field(&g.hierarchy_filter_text, 63u);
    (void)draw_uim_text_field("##hierarchy_filter", &g.hierarchy_filter_text, 0.0f,
                              "Search nodes", false);
    std::string hierarchy_filter = field_value(g.hierarchy_filter_text);
    for (auto &c : hierarchy_filter) c = (char)std::tolower((unsigned char)c);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(4.0f, 3.0f));
    if (ImGui::SmallButton("+Empty")) {
        uim_NodeId parent = g.root;
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
        create_node({}, parent, {0, 0, 160, 80}, 0);
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("+Panel")) {
        uim_NodeId parent = g.root;
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
        create_node({}, parent, {0, 0, 160, 80}, uim_COMPONENT_PANEL);
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("Dup")) {
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) {
            uim_NodeId made = 0;
            if (uir_editor_duplicate_node(g.editor, sel.ids[0], 16.0f, 16.0f, &made) == uim_OK) {
                g.dirty = true;
                select_node(made, false);
            }
        }
    }
    ImGui::SameLine();
    if (ImGui::SmallButton("Del")) {
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count) {
            for (size_t i = 0; i < sel.count; ++i) {
                if (sel.ids[i] != g.root) uir_editor_delete_node(g.editor, sel.ids[i]);
            }
            g.dirty = true;
        }
    }
    ImGui::PopStyleVar();
    ImGui::Separator();


    size_t count = 0;
    if (g.editor) uir_editor_hierarchy_get_visible_count(g.editor, &count);
    for (size_t i = 0; i < count; ++i) {
        uim_EditorHierarchyItem item{};
        if (uir_editor_hierarchy_get_visible_at(g.editor, i, &item) != uim_OK) continue;
        ImGui::PushID((int)(uintptr_t)item.node.id);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + item.depth * 16.0f);
        bool selected = false;
        uim_EditorSelection sel{};
        if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK) {
            for (size_t k = 0; k < sel.count; ++k) if (sel.ids[k] == item.node.id) selected = true;
        }
        std::string label = item.display_name ? item.display_name : "(node)";
        std::string haystack = label;
        for (auto &c : haystack) c = (char)std::tolower((unsigned char)c);
        if (!hierarchy_filter.empty() && haystack.find(hierarchy_filter) == std::string::npos)
            continue;
        if (!item.node.visible) label += "  (hidden)";
        std::string row_label = (item.has_children ? (item.expanded ? "v  " : ">  ") : "    ") + label;
        float row_w = ImGui::GetContentRegionAvail().x;
        ImVec4 row_bg = selected ? ImGui::GetStyleColorVec4(ImGuiCol_Header)
                                 : ImVec4(0, 0, 0, 0);
        ImGui::PushStyleColor(ImGuiCol_Button, row_bg);
        bool clicked = ImGui::Button(row_label.c_str(), ImVec2(row_w, 0.0f));
        ImGui::PopStyleColor();
        if (clicked) {
            if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
                if (item.has_children) {
                    uir_editor_hierarchy_set_expanded(g.editor, item.node.id, !item.expanded);
                } else {
                    begin_rename(item.node.id);
                }
            } else {
                select_node(item.node.id, primary_mod_down());
            }
        }
        if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
            uim_NodeId dragged = item.node.id;
            ImGui::SetDragDropPayload("zcsr_hierarchy_node", &dragged, sizeof(dragged));
            ImGui::TextUnformatted(label.c_str());
            ImGui::EndDragDropSource();
        }
        if (ImGui::BeginDragDropTarget()) {
            const ImGuiPayload *payload = ImGui::AcceptDragDropPayload("zcsr_hierarchy_node");
            if (payload && payload->DataSize == sizeof(uim_NodeId)) {
                uim_NodeId dragged = *(const uim_NodeId *)payload->Data;
                if (dragged != item.node.id && dragged != g.root &&
                    uir_editor_set_parent(g.editor, dragged, item.node.id) == uim_OK) {
                    g.dirty = true;
                    log_line("reparented node");
                }
            }
            ImGui::EndDragDropTarget();
        }
        if (ImGui::BeginPopupContextItem()) {
            if (ImGui::MenuItem("Rename")) begin_rename(item.node.id);
            if (ImGui::MenuItem("Copy")) {
                select_node(item.node.id, false);
                copy_selected_node();
            }
            if (ImGui::MenuItem("Paste", nullptr, false,
                                g.clipboard_node != uim_NODE_INVALID)) {
                select_node(item.node.id, false);
                paste_copied_node();
            }
            if (ImGui::MenuItem("Move Up")) {
                select_node(item.node.id, false);
                move_selected_sibling(-1);
            }
            if (ImGui::MenuItem("Move Down")) {
                select_node(item.node.id, false);
                move_selected_sibling(1);
            }
            if (ImGui::MenuItem("Create Empty Child")) {
                create_node({}, item.node.id, {0, 0, 160, 80}, 0);
            }
            if (ImGui::MenuItem("Create Panel Child")) {
                create_node({}, item.node.id, {0, 0, 160, 80}, uim_COMPONENT_PANEL);
            }
            if (ImGui::MenuItem("Duplicate")) {
                uim_NodeId made = 0;
                if (uir_editor_duplicate_node(g.editor, item.node.id, 16.0f, 16.0f, &made) == uim_OK) {
                    g.dirty = true;
                    select_node(made, false);
                }
            }
            if (ImGui::MenuItem("Delete", nullptr, false, item.node.id != g.root)) {
                uir_editor_delete_node(g.editor, item.node.id);
                g.dirty = true;
            }
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    ImGui::End();
}

std::string value_string(uim_Value v) {
    if (v.type != uim_VALUE_STRING || !v.as.string.data) return {};
    return std::string(v.as.string.data, v.as.string.size);
}

bool set_value(uim_ComponentInstanceId instance, uim_PropertyId prop, uim_Value value) {
    if (!g.manager || !g.registry || !g.editor) return false;
    uim_Result rc = uir_editor_component_set_property(g.editor, g.registry, instance, prop, value);
    if (rc != uim_OK) {
        log_line("property set failed: " + std::to_string((int)rc));
        return false;
    }
    g.dirty = true;
    return true;
}

static int parse_float_list(const std::string &text, float *out, int max_count) {
    int count = 0;
    const char *p = text.c_str();
    while (count < max_count && p && *p) {
        while (*p && (std::isspace((unsigned char)*p) || *p == ',' || *p == ';')) p++;
        if (!*p) break;
        char *end = nullptr;
        float v = std::strtof(p, &end);
        if (end == p) break;
        out[count++] = v;
        p = end;
    }
    return count;
}

static std::string format_float_list(const float *values, int count) {
    char buf[160];
    if (count == 2) std::snprintf(buf, sizeof(buf), "%.3f, %.3f", values[0], values[1]);
    else if (count == 3) std::snprintf(buf, sizeof(buf), "%.3f, %.3f, %.3f",
                                      values[0], values[1], values[2]);
    else std::snprintf(buf, sizeof(buf), "%.3f", values[0]);
    return std::string(buf);
}

static std::string open_asset_dialog() {
    char path[32768] = {0};
    if (!g.host || !editor_host_open_file(g.host, "Select asset", "",
                                          path, sizeof(path))) return {};
    return path;
}

static std::string project_relative_asset(const std::string &path) {
    if (g.project_path.empty()) return path;
    std::error_code ec;
    fs::path root = fs::path(g.project_path).parent_path();
    fs::path rel = fs::relative(fs::path(path), root, ec);
    if (ec || rel.empty()) return path;
    std::string s = rel.generic_string();
    if (s.rfind("..", 0) == 0) return path;
    return s;
}

void draw_property(uim_ComponentInstanceId instance, const uim_ComponentPropertyDesc &p) {
    if (p.flags & uim_PROPERTY_FLAG_HIDDEN_IN_INSPECTOR) return;
    if (p.flags & uim_PROPERTY_FLAG_READ_ONLY) ImGui::BeginDisabled();
    uim_Value value{};
    if (uim_component_instance_get_property(g.manager, instance, p.property_id, &value) != uim_OK) {
        if (p.flags & uim_PROPERTY_FLAG_READ_ONLY) ImGui::EndDisabled();
        return;
    }
    ImGui::PushID((int)p.property_id);
    const char *label = p.display_name_key ? p.display_name_key : (p.stable_key ? p.stable_key : "?");
    bool changed = false;

    if (p.inspector_control == uim_INSPECTOR_COLOR) {
        ImGui::PushItemWidth(-96.0f);
        int64_t packed = value.type == uim_VALUE_INT64 ? value.as.integer : 0;
        float rgba[4] = {
            ((packed >> 24) & 0xff) / 255.0f,
            ((packed >> 16) & 0xff) / 255.0f,
            ((packed >> 8) & 0xff) / 255.0f,
            (packed & 0xff) / 255.0f,
        };
        if (ImGui::ColorEdit4(label, rgba, ImGuiColorEditFlags_AlphaBar)) {
            int64_t v = ((int64_t)std::lround(rgba[0] * 255.0f) << 24) |
                        ((int64_t)std::lround(rgba[1] * 255.0f) << 16) |
                        ((int64_t)std::lround(rgba[2] * 255.0f) << 8) |
                        (int64_t)std::lround(rgba[3] * 255.0f);
            changed = set_value(instance, p.property_id, uim_value_int(v));
        }
        ImGui::PopItemWidth();
    } else if (p.inspector_control == uim_INSPECTOR_ASSET_PICKER &&
               value.type == uim_VALUE_STRING) {
        uint64_t key = ((uint64_t)instance << 32) | p.property_id;
        auto &slot = g.text_fields[key];
        if (!slot) {
            slot = std::make_unique<uim_TextInput>();
            (void)uim_text_input_init(slot.get(), 2047u);
        }
        char field_id[96];
        std::snprintf(field_id, sizeof(field_id), "asset:%llu", (unsigned long long)key);
        if (!field_is_focused(field_id)) field_set_clamped(slot.get(), value_string(value));
        float field_w = std::max(80.0f, ImGui::GetContentRegionAvail().x - 42.0f);
        UimFieldResult field = draw_uim_text_field(field_id, slot.get(), field_w, "asset path", false);
        ImGui::SameLine();
        if (ImGui::Button("...", ImVec2(30.0f, 0.0f))) {
            std::string picked = open_asset_dialog();
            if (!picked.empty()) {
                std::string rel = project_relative_asset(picked);
                field_set_clamped(slot.get(), rel);
                changed = set_value(instance, p.property_id,
                                    uim_value_string(rel.c_str(), rel.size()));
            }
        }
        ImGui::SameLine();
        ImGui::TextUnformatted(label);
        if (field.changed) {
            std::string text = field_value(*slot);
            changed = set_value(instance, p.property_id,
                                uim_value_string(text.c_str(), text.size()));
        }
    } else if ((p.inspector_control == uim_INSPECTOR_VECTOR2 ||
                p.inspector_control == uim_INSPECTOR_VECTOR3) &&
               value.type == uim_VALUE_STRING) {
        int dim = p.inspector_control == uim_INSPECTOR_VECTOR2 ? 2 : 3;
        float components[3] = {0.0f, 0.0f, 0.0f};
        int parsed = parse_float_list(value_string(value), components, dim);
        (void)parsed;
        bool vec_changed = dim == 2
            ? ImGui::DragFloat2(label, components, 0.1f)
            : ImGui::DragFloat3(label, components, 0.1f);
        if (vec_changed) {
            std::string text = format_float_list(components, dim);
            changed = set_value(instance, p.property_id,
                                uim_value_string(text.c_str(), text.size()));
        }
    } else if (p.inspector_control == uim_INSPECTOR_MULTILINE_TEXT &&
               value.type == uim_VALUE_STRING) {
        uint64_t key = ((uint64_t)instance << 32) | p.property_id;
        auto &slot = g.text_fields[key];
        if (!slot) {
            slot = std::make_unique<uim_TextInput>();
            (void)uim_text_input_init(slot.get(), 1023u);
        }
        char field_id[96];
        std::snprintf(field_id, sizeof(field_id), "multi:%llu", (unsigned long long)key);
        if (!field_is_focused(field_id)) field_set_clamped(slot.get(), value_string(value));
        ImGui::TextUnformatted(label);
        UimFieldResult field = draw_uim_text_area(field_id, slot.get(),
                                                  ImGui::GetContentRegionAvail().x,
                                                  92.0f, false);
        if (field.changed) {
            std::string text = field_value(*slot);
            changed = set_value(instance, p.property_id,
                                uim_value_string(text.c_str(), text.size()));
        }
    } else if (p.inspector_control == uim_INSPECTOR_DROPDOWN && value.type == uim_VALUE_INT64) {
        int v = (int)value.as.integer;
        int lo = (int)p.numeric_min, hi = (int)p.numeric_max;
        int count = hi - lo + 1;
        if (count > 0 && count <= 64) {
            char labels[64][24];
            const char *items[64];
            for (int i = 0; i < count; ++i) {
                std::snprintf(labels[i], sizeof(labels[i]), "%d", lo + i);
                items[i] = labels[i];
            }
            if (ImGui::Combo(label, &v, items, count)) {
                changed = set_value(instance, p.property_id, uim_value_int(v));
            }
        } else {
            ImGui::TextDisabled("%s: dropdown needs a 1..64 integer range", label);
        }
    } else if (p.inspector_control == uim_INSPECTOR_CHECKBOX || value.type == uim_VALUE_BOOL) {
        bool v = value.as.boolean;
        if (ImGui::Checkbox(label, &v)) changed = set_value(instance, p.property_id, uim_value_bool(v));
    } else if (p.inspector_control == uim_INSPECTOR_SLIDER && value.type == uim_VALUE_FLOAT64) {
        float v = (float)value.as.real;
        float lo = (float)p.numeric_min, hi = (float)p.numeric_max;
        if (ImGui::SliderFloat(label, &v, lo, hi)) changed = set_value(instance, p.property_id, uim_value_float(v));
    } else if (p.property_id == uim_PROPERTY_TRIGGER || p.property_id == uim_PROPERTY_SELECTOR ||
               p.property_id == uim_PROPERTY_EFFECT) {
        int v = (int)(value.type == uim_VALUE_INT64 ? value.as.integer : 0);
        const char *items[] = {"Trigger: Click", "Trigger: Tick", "Selector: Same Row",
                               "Selector: Same Col", "Selector: Radius", "Selector: Nearest",
                               "Selector: Tag", "Effect: Damage", "Effect: Move",
                               "Effect: Destroy", "Effect: Goto"};
        int base = 0, count = 0;
        if (p.property_id == uim_PROPERTY_TRIGGER) { base = 0; count = 2; }
        else if (p.property_id == uim_PROPERTY_SELECTOR) { base = 2; count = 5; }
        else { base = 7; count = 4; }
        if (ImGui::Combo(label, &v, items + base, count)) {
            changed = set_value(instance, p.property_id, uim_value_int(v));
        }
    } else if (value.type == uim_VALUE_INT64) {
        int v = (int)value.as.integer;
        if (ImGui::DragInt(label, &v, (float)(p.numeric_step > 0 ? p.numeric_step : 1.0),
                           (int)p.numeric_min, (int)p.numeric_max)) {
            changed = set_value(instance, p.property_id, uim_value_int(v));
        }
    } else if (value.type == uim_VALUE_FLOAT64) {
        float v = (float)value.as.real;
        if (ImGui::DragFloat(label, &v, (float)(p.numeric_step > 0 ? p.numeric_step : 0.1f),
                             (float)p.numeric_min, (float)p.numeric_max, "%.3f")) {
            changed = set_value(instance, p.property_id, uim_value_float(v));
        }
    } else if (value.type == uim_VALUE_STRING &&
               (p.inspector_control == uim_INSPECTOR_MULTILINE_TEXT ||
                p.max_string_bytes >= 1024u ||
                (p.stable_key && (std::strstr(p.stable_key, "list") ||
                                  std::strstr(p.stable_key, "array"))))) {
        /* A list in the current value model is a newline-delimited string. No
         * second array storage type is invented; the UIM property slot stays a
         * string, and this is the standard line-list editor. */
        uint64_t key = ((uint64_t)instance << 32) | p.property_id;
        auto &slot = g.text_fields[key];
        if (!slot) {
            slot = std::make_unique<uim_TextInput>();
            (void)uim_text_input_init(slot.get(), 2047u);
        }
        char field_id[96];
        std::snprintf(field_id, sizeof(field_id), "list:%llu", (unsigned long long)key);
        if (!field_is_focused(field_id)) field_set_clamped(slot.get(), value_string(value));
        ImGui::TextUnformatted(label);
        UimFieldResult field = draw_uim_text_area(field_id, slot.get(),
                                                  ImGui::GetContentRegionAvail().x,
                                                  120.0f, false);
        if (field.changed) {
            std::string text = field_value(*slot);
            changed = set_value(instance, p.property_id,
                                uim_value_string(text.c_str(), text.size()));
        }
    } else if (value.type == uim_VALUE_STRING) {
        uint64_t key = ((uint64_t)instance << 32) | p.property_id;
        auto &slot = g.text_fields[key];
        if (!slot) {
            slot = std::make_unique<uim_TextInput>();
            (void)uim_text_input_init(slot.get(), 511u);
        }
        char field_id[96];
        std::snprintf(field_id, sizeof(field_id), "prop:%llu", (unsigned long long)key);
        /* While the field owns the caret, the property's value must not stomp
         * on it; otherwise the UIM text state mirrors the property. */
        if (!field_is_focused(field_id))
            field_set_clamped(slot.get(), value_string(value));
        UimFieldResult field = draw_uim_text_field(field_id, slot.get(), 0.0f, nullptr, false);
        ImGui::SameLine();
        ImGui::TextUnformatted(label);
        if (field.changed) {
            std::string text = field_value(*slot);
            changed = set_value(instance, p.property_id,
                                uim_value_string(text.c_str(), text.size()));
        }
    } else {
        ImGui::TextDisabled("%s: unsupported value", label);
    }
    if (changed) g.selected_instance = instance;
    ImGui::PopID();
    if (p.flags & uim_PROPERTY_FLAG_READ_ONLY) ImGui::EndDisabled();
}

void draw_components(uim_NodeId node) {
    size_t count = 0;
    if (uim_node_component_count(g.manager, node, &count) != uim_OK) count = 0;
    ImGui::Text("Components %zu", count);
    for (size_t i = 0; i < count; ++i) {
        uim_ComponentInstanceInfo info{};
        if (uim_node_component_get_at(g.manager, node, i, &info) != uim_OK) continue;
        uim_ComponentTypeDesc desc{};
        if (uim_component_registry_get(g.registry, info.type_id, &desc) != uim_OK) continue;
        ImGui::PushID((int)info.instance_id);
        bool open = ImGui::TreeNodeEx(desc.display_name_key ? desc.display_name_key : "Component",
                                      ImGuiTreeNodeFlags_DefaultOpen |
                                      (g.selected_instance == info.instance_id ? ImGuiTreeNodeFlags_Selected : 0));
        if (ImGui::IsItemClicked()) g.selected_instance = info.instance_id;
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.45f, 0.16f, 0.16f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.62f, 0.22f, 0.22f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.75f, 0.28f, 0.28f, 1.0f));
        bool remove = ImGui::Button("X##remove_component", ImVec2(26, 0));
        ImGui::PopStyleColor(3);
        if (remove) {
            if (g.editor && uir_editor_component_detach(g.editor, info.instance_id) == uim_OK) {
                g.dirty = true;
                g.selected_instance = 0;
            }
            if (open) ImGui::TreePop();
            ImGui::PopID();
            break;
        }
        if (open) {
            for (size_t k = 0; k < desc.property_count; ++k) draw_property(info.instance_id, desc.properties[k]);
            ImGui::TreePop();
        }
        ImGui::PopID();
    }

    if (ImGui::Button(g.component_picker_open ? "Cancel Add Component" : "+ Add Component",
                       ImVec2(-1.0f, 30.0f))) {
        (void)uim_text_input_set_text(&g.component_filter_text, "", 0u);
        g.component_picker_open = !g.component_picker_open;
        if (!g.component_picker_open) g.focused_field.clear();
    }
    if (g.component_picker_open) {
        ensure_field(&g.component_filter_text, 63u);
        if (ImGui::IsKeyPressed(ImGuiKey_Escape)) {
            g.component_picker_open = false;
            if (g.focused_field == "##component_filter") g.focused_field.clear();
        }
        (void)draw_uim_text_field("##component_filter", &g.component_filter_text, 0.0f,
                                  "Search components", false);
        std::string filter = field_value(g.component_filter_text);
        for (auto &ch : filter) ch = (char)std::tolower((unsigned char)ch);
        std::string last_category;
        uim_ComponentTypeId attach_type = 0;
        size_t types = uim_component_registry_count(g.registry);
        ImGui::BeginChild("##component_list", ImVec2(0.0f, 240.0f), true);
        for (size_t i = 0; i < types; ++i) {
            uim_ComponentTypeDesc desc{};
            if (uim_component_registry_get_at(g.registry, i, &desc) != uim_OK) continue;
            std::string label = desc.display_name_key ? desc.display_name_key : desc.stable_key;
            std::string category = desc.category_key ? desc.category_key : "Components";
            std::string haystack = label + " " + category;
            for (auto &ch : haystack) ch = (char)std::tolower((unsigned char)ch);
            if (!filter.empty() && haystack.find(filter) == std::string::npos) continue;
            if (last_category.empty() || category != last_category) {
                ImGui::Separator();
                ImGui::TextDisabled("%s", category.c_str());
                last_category = category;
            }
            if (ImGui::Selectable(label.c_str(), false, ImGuiSelectableFlags_None, ImVec2(0.0f, 22.0f))) {
                if ((desc.flags & uim_COMPONENT_FLAG_SINGLETON_PER_NODE) != 0u &&
                    node_has_singleton_type(node, desc.type_id)) {
                    log_line("component already exists on this node");
                } else {
                    attach_type = desc.type_id;
                }
                g.component_picker_open = false;
            }
            if ((desc.flags & uim_COMPONENT_FLAG_SINGLETON_PER_NODE) != 0u &&
                node_has_singleton_type(node, desc.type_id)) {
                ImGui::SameLine();
                ImGui::TextDisabled("already attached");
            }
        }
        ImGui::EndChild();
        if (attach_type) attach_component(node, attach_type);
    }
}

/* Commit the inspector's UIM text state back to the node key. Called on Enter
 * and on blur, so clicking away keeps the edit like the old ImGui field did. */
void commit_node_name_field() {
    if (!g.manager || !g.editor || !g.node_name_node) return;
    std::string name = field_value(g.node_name_text);
    uim_NodeInfo info{};
    if (uim_node_get(g.manager, g.node_name_node, &info) != uim_OK) return;
    std::string old = info.stable_key ? info.stable_key : "";
    if (name.empty() || name == old) return;
    if (uir_editor_hierarchy_set_name(g.editor, g.node_name_node, name.c_str()) == uim_OK &&
        uim_node_set_stable_key(g.manager, g.node_name_node, name.c_str()) == uim_OK) {
        g.dirty = true;
    } else {
        log_line("rename failed");
    }
}

void draw_inspector() {
    if (g.scene_mode) {
        draw_scene_inspector();
        return;
    }
    ImGui::Begin("Inspector", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("INSPECTOR");
    uim_EditorSelection sel{};
    if (!g.editor || uir_editor_get_selection(g.editor, &sel) != uim_OK || sel.count == 0) {
        ImGui::TextDisabled("Nothing selected");
        ImGui::End();
        return;
    }
    if (sel.count > 1) {
        ImGui::Text("%zu nodes selected", sel.count);
        ImGui::BeginChild("##multi_sel", ImVec2(0.0f, 130.0f), true);
        for (size_t i = 0; i < sel.count; ++i) {
            uim_NodeInfo mi{};
            if (uim_node_get(g.manager, sel.ids[i], &mi) == uim_OK)
                ImGui::TextUnformatted(mi.stable_key ? mi.stable_key : "(node)");
        }
        ImGui::EndChild();
        ImGui::DragFloat2("group move", &g.multi_move_dx, 0.5f);
        if (ImGui::Button("Apply to all") &&
            uir_editor_move_selection(g.editor, g.multi_move_dx, g.multi_move_dy) == uim_OK) {
            g.dirty = true;
            g.multi_move_dx = g.multi_move_dy = 0.0f;
        }
        ImGui::SameLine();
        if (ImGui::Button("Delete selected")) delete_selected_node();
        ImGui::Separator();
    }
    uim_NodeId node = sel.ids[0];
    uim_NodeInfo n{};
    if (uir_editor_inspect_node(g.editor, node, &n) != uim_OK) {
        ImGui::TextDisabled("Selection is stale");
        ImGui::End();
        return;
    }
    if (g.node_name_node != node) {
        g.node_name_node = node;
        ensure_field(&g.node_name_text, 127u);
        field_set_clamped(&g.node_name_text, n.stable_key ? n.stable_key : "");
    } else if (!field_is_focused("node_name")) {
        field_set_external(&g.node_name_text, n.stable_key ? n.stable_key : "");
    }
    UimFieldResult name_field = draw_uim_text_field("node_name", &g.node_name_text, 200.0f,
                                                    nullptr, false);
    ImGui::SameLine();
    ImGui::TextUnformatted("Name");
    if (name_field.submitted) commit_node_name_field();
    ImGui::SameLine();
    ImGui::TextDisabled("%s #%llu", n.space == uim_SPACE_3D ? "3D" : "2D",
                        (unsigned long long)node);

    if (n.space == uim_SPACE_2D) {
        float x = n.local_rect.x, y = n.local_rect.y, w = n.local_rect.width, h = n.local_rect.height;
        bool edit = false;
        if (ImGui::InputFloat("x", &x, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (ImGui::InputFloat("y", &y, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (ImGui::InputFloat("width", &w, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (ImGui::InputFloat("height", &h, 0.0f, 0.0f, "%.2f")) edit = true;
        if (ImGui::IsItemDeactivatedAfterEdit()) edit = true;
        if (edit) {
            w = std::max(w, 0.0f);
            h = std::max(h, 0.0f);
            if (uir_editor_set_rect(g.editor, node, {x, y, w, h}) == uim_OK) g.dirty = true;
        }
    } else {
        uim_Transform3 t = n.transform;
        bool edit = false;
        edit |= ImGui::DragFloat3("position", t.position, 0.1f);
        edit |= ImGui::DragFloat3("rotation", t.rotation, 0.5f);
        edit |= ImGui::DragFloat3("scale", t.scale, 0.01f);
        if (edit && uir_editor_set_transform3(g.editor, node, &t) == uim_OK) g.dirty = true;
    }

    /* Responsive anchors were already in the node model and resolved by C11
     * uim_page_resolve_layout; the Inspector simply never exposed them. */
    uim_LayoutConstraints lc = n.layout;
    bool lc_changed = false;
    if (ImGui::Checkbox("anchors", &lc.enabled)) lc_changed = true;
    if (lc.enabled) {
        lc_changed |= ImGui::DragFloat2("anchor min", &lc.anchor_min_x, 0.01f, 0.0f, 1.0f, "%.3f");
        lc_changed |= ImGui::DragFloat2("anchor max", &lc.anchor_max_x, 0.01f, 0.0f, 1.0f, "%.3f");
        lc_changed |= ImGui::DragFloat4("offset LTRB", &lc.offset_left, 0.5f);
        lc.anchor_min_x = std::clamp(lc.anchor_min_x, 0.0f, 1.0f);
        lc.anchor_min_y = std::clamp(lc.anchor_min_y, 0.0f, 1.0f);
        lc.anchor_max_x = std::clamp(lc.anchor_max_x, 0.0f, 1.0f);
        lc.anchor_max_y = std::clamp(lc.anchor_max_y, 0.0f, 1.0f);
    }
    if (lc_changed) {
        if (uir_editor_set_layout_constraints(g.editor, node, lc) == uim_OK) g.dirty = true;
    }

    int z = n.z_order;
    if (ImGui::DragInt("z-order", &z)) {
        uir_editor_set_z_order(g.editor, node, z);
        g.dirty = true;
    }
    bool vis = n.visible, en = n.enabled;
    if (ImGui::Checkbox("visible", &vis)) { uir_editor_set_visible(g.editor, node, vis); g.dirty = true; }
    ImGui::SameLine();
    if (ImGui::Checkbox("enabled", &en)) { uir_editor_set_enabled(g.editor, node, en); g.dirty = true; }
    bool is3d = n.space == uim_SPACE_3D;
    if (ImGui::Checkbox("3D space", &is3d)) {
        if (uir_editor_set_space(g.editor, node, is3d ? uim_SPACE_3D : uim_SPACE_2D) == uim_OK)
            g.dirty = true;
    }
    ImGui::Separator();
    draw_components(node);
    ImGui::End();
}

void draw_preferences() {
    if (!g.show_preferences) return;
    ImGui::Begin("Preferences", &g.show_preferences, ImGuiWindowFlags_AlwaysAutoResize);
    ImGui::TextDisabled("CANVAS");
    ImGui::Checkbox("show grid", &g.canvas_show_grid);
    ImGui::DragFloat("grid size", &g.canvas_grid_size, 0.5f, 1.0f, 128.0f, "%.1f");
    ImGui::Checkbox("snap to grid", &g.canvas_snap);
    ImGui::DragFloat("zoom step", &g.zoom_step, 0.01f, 1.05f, 2.0f, "%.2f");
    ImGui::Separator();
    ImGui::TextDisabled("GIZMO");
    ImGui::Checkbox("snap", &g.gizmo_snap);
    ImGui::DragFloat("move step", &g.gizmo_snap_step, 0.05f, 0.05f, 10.0f, "%.2f");
    ImGui::DragFloat("rotate step", &g.gizmo_rotate_step, 1.0f, 1.0f, 90.0f, "%.1f");
    ImGui::DragFloat("scale step", &g.gizmo_scale_step, 0.01f, 0.01f, 1.0f, "%.2f");
    if (ImGui::RadioButton("World", g.gizmo_space == 0)) g.gizmo_space = 0;
    ImGui::SameLine();
    if (ImGui::RadioButton("Local", g.gizmo_space == 1)) g.gizmo_space = 1;
    ImGui::Separator();
    ImGui::TextDisabled("AUTOSAVE");
    ImGui::DragFloat("seconds", &g.auto_save_seconds, 5.0f, 0.0f, 3600.0f, "%.0f");
    ImGui::TextDisabled("0 disables autosave. Untitled documents are skipped.");
    ImGui::End();
}

void draw_console() {
    if (!g.show_console) return;
    ImGui::Begin("Console", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
    ImGui::TextDisabled("CONSOLE");
    ensure_field(&g.console_filter_text, 63u);
    (void)draw_uim_text_field("##console_filter", &g.console_filter_text, 0.0f,
                              "Filter log", false);
    std::string filter = field_value(g.console_filter_text);
    for (auto &c : filter) c = (char)std::tolower((unsigned char)c);
    ImGui::SameLine();
    if (ImGui::SmallButton("Clear")) g.log.clear();
    ImGui::SameLine();
    ImGui::TextDisabled("%zu lines", g.log.size());
    ImGui::Separator();
    ImGui::BeginChild("##console_log", ImVec2(0.0f, 0.0f), false);
    size_t shown = 0;
    for (const auto &line : g.log) {
        std::string haystack = line;
        for (auto &c : haystack) c = (char)std::tolower((unsigned char)c);
        if (!filter.empty() && haystack.find(filter) == std::string::npos) continue;
        ImGui::TextUnformatted(line.c_str());
        ++shown;
    }
    if (g.log.empty()) ImGui::TextDisabled("(empty)");
    else if (shown == 0) ImGui::TextDisabled("(no match)");
    ImGui::EndChild();
    ImGui::End();
}

void draw_pages_bar();
bool close_request_cb(void *user);

void draw_menu() {
    if (!ImGui::BeginMainMenuBar()) return;
    if (ImGui::BeginMenu("File")) {
        if (ImGui::MenuItem("New", ZCSR_EDITOR_PRIMARY_LABEL "N")) new_document();
        if (ImGui::MenuItem("Open", ZCSR_EDITOR_PRIMARY_LABEL "O")) {
            std::string path = open_dialog();
            if (!path.empty()) load_project(path);
        }
        if (ImGui::MenuItem("Save", ZCSR_EDITOR_PRIMARY_LABEL "S")) save_project(false);
        if (ImGui::MenuItem("Save As")) save_project(true);
        ImGui::Separator();
        if (ImGui::MenuItem("Open scene", nullptr, false, g.scene_mode)) {
            std::string path = open_scene_dialog();
            if (!path.empty()) (void)scene_load(path);
        }
        if (ImGui::MenuItem("Save scene", nullptr, false, g.scene_mode)) (void)scene_save(false);
        if (ImGui::MenuItem("Save scene as", nullptr, false, g.scene_mode)) (void)scene_save(true);
        ImGui::Separator();
        if (ImGui::MenuItem("Run (CMake Debug)", "F6 / Ctrl+F5")) run_cmake_debug();
        if (ImGui::MenuItem(g.playing ? "Stop" : "Play", "F5")) {
            if (g.playing) stop_play(); else start_play();
        }
        if (g.playing) {
            bool paused = uim_runtime_paused();
            if (ImGui::MenuItem(paused ? "Resume" : "Pause"))
                uim_runtime_set_paused(!paused);
            if (ImGui::MenuItem("Step", nullptr, false, paused))
                uim_runtime_step(g.manager, g.page);
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Exit")) {
            if (close_request_cb(&g)) zcsr_runtime_shell_request_exit();
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Edit")) {
        if (g.scene_mode) {
            bool can_undo = g.scene_history &&
                zcsr_editor_scene_history_undo_count(g.scene_history) > 0;
            bool can_redo = g.scene_history &&
                zcsr_editor_scene_history_redo_count(g.scene_history) > 0;
            if (ImGui::MenuItem("Undo", ZCSR_EDITOR_PRIMARY_LABEL "Z", false, can_undo))
                (void)scene_history_undo();
            if (ImGui::MenuItem("Redo", ZCSR_EDITOR_PRIMARY_LABEL "Y", false, can_redo))
                (void)scene_history_redo();
        } else {
            uim_EditorHistoryState hs{};
            if (g.editor) uir_editor_get_history_state(g.editor, &hs);
            if (ImGui::MenuItem("Undo", ZCSR_EDITOR_PRIMARY_LABEL "Z", false, hs.undo_count > 0)) {
                if (uir_editor_undo(g.editor) == uim_OK) g.dirty = true;
            }
            if (ImGui::MenuItem("Redo", ZCSR_EDITOR_PRIMARY_LABEL "Y", false, hs.redo_count > 0)) {
                if (uir_editor_redo(g.editor) == uim_OK) g.dirty = true;
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Copy Node", ZCSR_EDITOR_PRIMARY_LABEL "C"))
                copy_selected_node();
            if (ImGui::MenuItem("Paste Node", ZCSR_EDITOR_PRIMARY_LABEL "V",
                                false, g.clipboard_node != uim_NODE_INVALID))
                paste_copied_node();
            if (ImGui::MenuItem("Move Up")) move_selected_sibling(-1);
            if (ImGui::MenuItem("Move Down")) move_selected_sibling(1);
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Preferences...")) g.show_preferences = true;
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("GameObject")) {
        if (ImGui::MenuItem("Create Empty")) {
            uim_NodeId parent = g.root;
            uim_EditorSelection sel{};
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
            create_node({}, parent, {0, 0, 160, 80}, 0);
        }
        if (ImGui::MenuItem("UI Panel")) {
            uim_NodeId parent = g.root;
            uim_EditorSelection sel{};
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
            create_node({}, parent, {0, 0, 160, 80}, uim_COMPONENT_PANEL);
        }
        if (ImGui::MenuItem("3D UI Node")) {
            uim_NodeId parent = g.root;
            uim_EditorSelection sel{};
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) parent = sel.ids[0];
            create_projected_panel_node(parent);
        }
        if (ImGui::MenuItem("Resolve Anchors")) {
            if (g.editor && g.page != uim_PAGE_INVALID && g.texture_w > 0 && g.texture_h > 0) {
                if (uir_editor_resolve_page_layout(g.editor, g.page,
                                                   (float)g.texture_w,
                                                   (float)g.texture_h) == uim_OK) {
                    g.dirty = true;
                    log_line("anchors resolved");
                }
            }
        }
        if (ImGui::BeginMenu("Add Component")) {
            uim_EditorSelection sel{};
            uim_NodeId target = uim_NODE_INVALID;
            if (g.editor && uir_editor_get_selection(g.editor, &sel) == uim_OK && sel.count == 1) target = sel.ids[0];
            size_t types = g.registry ? uim_component_registry_count(g.registry) : 0;
            for (size_t i = 0; i < types; ++i) {
                uim_ComponentTypeDesc desc{};
                if (uim_component_registry_get_at(g.registry, i, &desc) != uim_OK) continue;
                std::string label = desc.display_name_key ? desc.display_name_key : desc.stable_key;
                if (ImGui::MenuItem(label.c_str(), nullptr, false, target != uim_NODE_INVALID))
                    attach_component(target, desc.type_id);
            }
            ImGui::EndMenu();
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Duplicate")) select_node_duplicate();
        if (ImGui::MenuItem("Delete")) delete_selected_node();
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Scene")) {
        ImGui::MenuItem("Scene mode", nullptr, &g.scene_mode);
        if (ImGui::MenuItem("Add box")) {
            g.scene_mode = true;
            scene_add_box(0.0f, 0.0f, 2.0f, 2.0f, 0.80f, 0.60f, 0.40f);
        }
        if (ImGui::MenuItem("Add quad")) {
            g.scene_mode = true;
            scene_add_quad(0.0f, 0.0f, 2.0f, 0.45f, 0.65f, 0.90f);
        }
        if (ImGui::MenuItem("Delete selected", nullptr, false, g.scene_selected != 0)) {
            (void)scene_delete(g.scene_selected);
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Get demo")) scene_ensure_demo();
        if (ImGui::MenuItem("Create prefab from selected", nullptr, false,
                            g.scene_selected != 0))
            (void)create_prefab_from_selected();
        if (ImGui::MenuItem("Instantiate prefab"))
            (void)instantiate_prefab_dialog();
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Window")) {
        ImGui::MenuItem("Hierarchy", nullptr, &g.show_hierarchy);
        ImGui::MenuItem("Project", nullptr, &g.show_project);
        ImGui::MenuItem("Viewport", nullptr, &g.show_viewport);
        ImGui::MenuItem("Game", nullptr, &g.show_game);
        ImGui::MenuItem("Inspector", nullptr, &g.show_inspector);
        ImGui::MenuItem("Console", nullptr, &g.show_console);
        if (ImGui::BeginMenu("Game resolution")) {
            ImGui::MenuItem("Fit window", nullptr, g.game_resolution == 0);
            if (ImGui::MenuItem("1280x720")) g.game_resolution = 1;
            if (ImGui::MenuItem("1920x1080")) g.game_resolution = 2;
            if (ImGui::MenuItem("960x540")) g.game_resolution = 3;
            ImGui::MenuItem("Stats", nullptr, &g.game_stats);
            ImGui::EndMenu();
        }
        ImGui::EndMenu();
    }
    ImGui::SameLine();
    ImGui::TextUnformatted("|");
    ImGui::SameLine();
    draw_pages_bar();
    ImGui::EndMainMenuBar();
}

void handle_shortcuts() {
    ImGuiIO &io = ImGui::GetIO();
    if (g.component_picker_open) return;
    /* A focused text field owns the keyboard: Delete edits a character, Ctrl+S
     * must not save, and shortcuts must not fire while typing. */
    if (!g.focused_field.empty()) return;
    bool primary = primary_mod_down();
    if (primary && ImGui::IsKeyPressed(ImGuiKey_N, false) && !g.scene_mode) new_document();
    if (primary && ImGui::IsKeyPressed(ImGuiKey_O, false)) {
        std::string path = g.scene_mode ? open_scene_dialog() : open_dialog();
        if (!path.empty()) {
            if (g.scene_mode) (void)scene_load(path); else load_project(path);
        }
    }
    if (primary && ImGui::IsKeyPressed(ImGuiKey_S, false)) {
        if (g.scene_mode) (void)scene_save(io.KeyShift); else save_project(io.KeyShift);
    }
    if (primary && ImGui::IsKeyPressed(ImGuiKey_Z, false)) {
        if (g.scene_mode) {
            (void)scene_history_undo();
        } else if (g.editor && uir_editor_undo(g.editor) == uim_OK) {
            g.dirty = true;
        }
    }
    if (primary && ImGui::IsKeyPressed(ImGuiKey_Y, false)) {
        if (g.scene_mode) {
            (void)scene_history_redo();
        } else if (g.editor && uir_editor_redo(g.editor) == uim_OK) {
            g.dirty = true;
        }
    }
    if (!g.scene_mode && primary && ImGui::IsKeyPressed(ImGuiKey_C, false))
        copy_selected_node();
    if (!g.scene_mode && primary && ImGui::IsKeyPressed(ImGuiKey_V, false))
        paste_copied_node();
    if (!g.scene_mode && primary && ImGui::IsKeyPressed(ImGuiKey_D, false))
        select_node_duplicate();
    if (ImGui::IsKeyPressed(ImGuiKey_F5, false)) {
        if (primary_mod_down()) {
            /* VS-style start-without-debugging shortcut; still CMake build +
             * launch, never a package step. */
            run_cmake_debug();
        } else if (!g.scene_mode) {
            if (g.playing) stop_play(); else start_play();
        }
    }
    if (ImGui::IsKeyPressed(ImGuiKey_F6, false)) run_cmake_debug();
    if (!io.WantTextInput) {
        if (ImGui::IsKeyPressed(ImGuiKey_W, false)) g.gizmo_mode = 0;
        if (ImGui::IsKeyPressed(ImGuiKey_E, false)) g.gizmo_mode = 1;
        if (ImGui::IsKeyPressed(ImGuiKey_R, false)) g.gizmo_mode = 2;
    }
    if (ImGui::IsKeyPressed(ImGuiKey_Delete, false)) {
        if (g.scene_mode) {
            if (g.scene_selected) (void)scene_delete(g.scene_selected);
        } else if (g.editor) {
            uim_EditorSelection sel{};
            if (uir_editor_get_selection(g.editor, &sel) == uim_OK) {
                for (size_t i = 0; i < sel.count; ++i) if (sel.ids[i] != g.root) uir_editor_delete_node(g.editor, sel.ids[i]);
                g.dirty = true;
            }
        }
    }
    if (ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
        if (g.playing) stop_play();
        else if (g.scene_mode) {
            if (g.scene_gesture_active || g.scene_dragging || g.scene_resize_handle >= 0)
                scene_gesture_cancel();
            else
                g.scene_selected = 0;
        }
    }
}

void draw_viewport() {
    ImGui::Begin("Viewport", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar |
                                      ImGuiWindowFlags_NoScrollWithMouse);
    ImVec2 avail = ImGui::GetContentRegionAvail();
    if (avail.x < 32 || avail.y < 32) { ImGui::End(); return; }
    ImVec2 origin = ImGui::GetCursorScreenPos();
    ImGui::BeginChild("##canvas", avail, false,
                      ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                      ImGuiWindowFlags_NoMove);
    ImVec2 child_min = ImGui::GetWindowPos();
    ImVec2 child_size = ImGui::GetWindowSize();

    if (g.scene_mode) {
        draw_scene_viewport(child_min, child_size);
        ImGui::EndChild();
        ImGui::End();
        return;
    }

    if ((!g.viewport_initialized || (g.auto_fit &&
         (std::abs(child_size.x - g.last_view_w) > 1.0f ||
          std::abs(child_size.y - g.last_view_h) > 1.0f))) && g.page_texture) {
        float fit = std::min(child_size.x / (float)g.texture_w, child_size.y / (float)g.texture_h);
        g.zoom = std::max(fit, 0.05f);
        g.pan_x = (child_size.x - g.texture_w * g.zoom) * 0.5f;
        g.pan_y = (child_size.y - g.texture_h * g.zoom) * 0.5f;
        g.viewport_initialized = true;
        g.last_view_w = child_size.x;
        g.last_view_h = child_size.y;
    }
    apply_canvas(child_min, child_size);

    if (g.page_texture) {
        ImVec2 image_min(child_min.x + g.pan_x, child_min.y + g.pan_y);
        ImVec2 image_size(g.texture_w * g.zoom, g.texture_h * g.zoom);
        ImGui::SetCursorScreenPos(image_min);
        ImTextureRef tex((ImTextureID)(uintptr_t)g.page_texture);
        ImGui::Image(tex, image_size, ImVec2(0, 1), ImVec2(1, 0));
        bool hovered = ImGui::IsItemHovered();

        ImDrawList *draw = ImGui::GetWindowDrawList();
        if (g.playing) {
            draw->AddRect(ImVec2(image_min.x - 1.0f, image_min.y - 1.0f),
                          ImVec2(image_min.x + image_size.x + 1.0f,
                                 image_min.y + image_size.y + 1.0f),
                          IM_COL32(255, 90, 80, 255), 0.0f, ImDrawFlags_None, 2.0f);
            draw->AddRectFilled(ImVec2(child_min.x + 8.0f, child_min.y + 8.0f),
                                ImVec2(child_min.x + 126.0f, child_min.y + 28.0f),
                                IM_COL32(150, 35, 30, 220), 4.0f);
            draw->AddText(ImVec2(child_min.x + 16.0f, child_min.y + 12.0f),
                          IM_COL32(255, 255, 255, 255),
                          uim_runtime_paused() ? "PAUSED  Step / Resume" : "PLAYING  F5/ESC");
        }
        draw->PushClipRect(ImVec2(child_min.x, child_min.y),
                           ImVec2(child_min.x + child_size.x, child_min.y + child_size.y), true);
        draw_overlay(draw, ImVec2(child_min.x, child_min.y),
                     ImVec2(child_min.x + child_size.x, child_min.y + child_size.y));
        draw_3d_overlay(draw, child_min);
        if (!g.playing) draw_3d_gizmo(draw, child_min);
        draw->PopClipRect();

        ImGuiIO &io = ImGui::GetIO();
        if (hovered && io.MouseWheel != 0.0f && !g.playing) {
            float old_zoom = g.zoom;
            float page_x = (io.MousePos.x - child_min.x - g.pan_x) / old_zoom;
            float page_y = (io.MousePos.y - child_min.y - g.pan_y) / old_zoom;
            g.zoom = std::clamp(old_zoom * (io.MouseWheel > 0 ? g.zoom_step : 1.0f / g.zoom_step), 0.05f, 8.0f);
            g.pan_x = io.MousePos.x - child_min.x - page_x * g.zoom;
            g.pan_y = io.MousePos.y - child_min.y - page_y * g.zoom;
            g.auto_fit = false;
        }

        if (g.editor && g.page != uim_PAGE_INVALID) {
            if (!g.playing && hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
                gizmo_begin(io.MousePos, child_min);
                if (!g.gizmo_dragging) {
                    uim_NodeId hit3d = pick_3d_at(io.MousePos, child_min);
                    if (hit3d != uim_NODE_INVALID) {
                        select_node(hit3d, primary_mod_down() || io.KeyShift);
                        g.dragging = false;
                    } else {
                        g.dragging = true;
                        g.drag_prev = io.MousePos;
                        g.drag_mods = (uint32_t)modifier_mask();
                        uim_EditorHistoryState hs{};
                        if (g.editor) uir_editor_get_history_state(g.editor, &hs);
                        g.drag_undo_before = hs.undo_count;
                        uir_editor_canvas_pointer_down(g.editor, g.page, io.MousePos.x,
                                                       io.MousePos.y, g.drag_mods);
                    }
                }
            }
            if (g.gizmo_dragging) {
                if (ImGui::IsMouseDown(ImGuiMouseButton_Left))
                    gizmo_drag(io.MousePos, child_min);
                else
                    gizmo_end();
            } else if (g.dragging) {
                if (ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
                    uir_editor_canvas_pointer_move(g.editor, io.MousePos.x, io.MousePos.y);
                } else {
                    uir_editor_canvas_pointer_up(g.editor, io.MousePos.x, io.MousePos.y);
                    g.dragging = false;
                    uim_EditorHistoryState hs{};
                    if (g.editor) uir_editor_get_history_state(g.editor, &hs);
                    if (hs.undo_count != g.drag_undo_before) g.dirty = true;
                }
            }
            if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Middle)) {
                g.panning = true;
                g.drag_prev = io.MousePos;
            }
            if (g.panning) {
                if (ImGui::IsMouseDown(ImGuiMouseButton_Middle)) {
                    g.pan_x += io.MousePos.x - g.drag_prev.x;
                    g.pan_y += io.MousePos.y - g.drag_prev.y;
                    g.drag_prev = io.MousePos;
                } else {
                    g.panning = false;
                }
            }
            if (g.playing && hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
                float px, py;
                if (uir_editor_canvas_to_page(g.editor, io.MousePos.x, io.MousePos.y, &px, &py) == uim_OK) {
                    uim_runtime_click_ex(g.manager, g.page, px, py, project_3d_node, nullptr);
                }
            }
        }
    } else {
        ImGui::TextDisabled("No page texture");
    }
    ImGui::EndChild();
    ImGui::End();
}

void draw_game_view() {
    if (!g.show_game) return;
    ImGuiViewport *vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowSize(ImVec2(800.0f, 450.0f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x * 0.40f,
                                   vp->WorkPos.y + vp->WorkSize.y * 0.08f),
                            ImGuiCond_FirstUseEver);
    ImGui::Begin("Game", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                                      ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                                      ImGuiWindowFlags_NoDocking);
    ImVec2 avail = ImGui::GetContentRegionAvail();
    if (avail.x < 32.0f || avail.y < 32.0f) { ImGui::End(); return; }
    ImVec2 origin = ImGui::GetCursorScreenPos();

    int target_w = (int)avail.x;
    int target_h = (int)avail.y;
    switch (g.game_resolution) {
    case 1: target_w = 1280; target_h = 720; break;
    case 2: target_w = 1920; target_h = 1080; break;
    case 3: target_w = 960; target_h = 540; break;
    default: break;
    }
    float sx = avail.x / (float)target_w;
    float sy = avail.y / (float)target_h;
    float fit = std::min(sx, sy);
    float draw_w = target_w * fit;
    float draw_h = target_h * fit;
    ImVec2 game_min(origin.x + (avail.x - draw_w) * 0.5f,
                    origin.y + (avail.y - draw_h) * 0.5f);
    ImVec2 game_max(game_min.x + draw_w, game_min.y + draw_h);
    ImDrawList *draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(origin, ImVec2(origin.x + avail.x, origin.y + avail.y),
                        IM_COL32(12, 13, 16, 255));
    draw->AddRectFilled(game_min, game_max, IM_COL32(20, 22, 27, 255));

    if (g.scene_mode) {
        zcsr_scene_camera cam = g.scene.camera;
        zcsr_scene_camera_set_viewport(&cam, target_w, target_h);
        for (size_t i = 0; i < g.scene.count; ++i) {
            const zcsr_scene_entity &e = g.scene.entities[i];
            zcsr_scene_point q[4];
            if (!e.visible || !zcsr_scene_entity_quad(&g.scene, e.id, q)) continue;
            ImVec2 pts[4];
            bool ok = true;
            for (int k = 0; k < 4; ++k) {
                float px = 0, py = 0, depth = 0;
                if (!zcsr_scene_camera_project(&cam, q[k].x, q[k].y, q[k].z,
                                               &px, &py, &depth)) { ok = false; break; }
                pts[k] = ImVec2(game_min.x + px * fit, game_min.y + py * fit);
            }
            if (!ok) continue;
            ImU32 color = IM_COL32((int)(e.tint_r * 255.0f),
                                   (int)(e.tint_g * 255.0f),
                                   (int)(e.tint_b * 255.0f),
                                   (int)(e.tint_a * 255.0f));
            draw->AddConvexPolyFilled(pts, 4, color);
            draw->AddPolyline(pts, 4, IM_COL32(10, 10, 10, 180),
                              ImDrawFlags_Closed, 1.0f);
        }
    } else if (g.page_texture) {
        float image_fit = std::min(draw_w / (float)g.texture_w, draw_h / (float)g.texture_h);
        ImVec2 image_size(g.texture_w * image_fit, g.texture_h * image_fit);
        ImVec2 image_min(game_min.x + (draw_w - image_size.x) * 0.5f,
                         game_min.y + (draw_h - image_size.y) * 0.5f);
        ImGui::SetCursorScreenPos(image_min);
        ImTextureRef tex((ImTextureID)(uintptr_t)g.page_texture);
        ImGui::Image(tex, image_size, ImVec2(0, 1), ImVec2(1, 0));
        if (g.playing && ImGui::IsItemHovered() &&
            ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            float px = (ImGui::GetIO().MousePos.x - image_min.x) / image_fit;
            float py = (ImGui::GetIO().MousePos.y - image_min.y) / image_fit;
            if (px >= 0 && py >= 0 && px < (float)g.texture_w && py < (float)g.texture_h)
                uim_runtime_click_ex(g.manager, g.page, px, py, project_3d_node, nullptr);
        }
    } else {
        draw->AddText(ImVec2(game_min.x + 12, game_min.y + 12),
                      IM_COL32(160, 166, 176, 255), "No scene / page");
    }

    if (g.game_stats) {
        char stats[160];
        std::snprintf(stats, sizeof(stats), "%dx%d  %.1f FPS  %.2f ms  %s",
                      target_w, target_h, ImGui::GetIO().Framerate,
                      ImGui::GetIO().DeltaTime * 1000.0f,
                      g.scene_mode ? "SCENE" : "UI");
        draw->AddRectFilled(ImVec2(game_min.x + 8, game_min.y + 8),
                            ImVec2(game_min.x + 300, game_min.y + 30),
                            IM_COL32(0, 0, 0, 150), 3.0f);
        draw->AddText(ImVec2(game_min.x + 14, game_min.y + 12),
                      IM_COL32(230, 232, 238, 255), stats);
        if (g.playing) {
            char play[64];
            std::snprintf(play, sizeof(play), "%s",
                          uim_runtime_paused() ? "PAUSED" : "PLAYING");
            draw->AddText(ImVec2(game_max.x - 80, game_min.y + 12),
                          uim_runtime_paused() ? IM_COL32(255, 210, 90, 255)
                                               : IM_COL32(110, 235, 140, 255), play);
        }
    }
    draw->AddRect(game_min, game_max, IM_COL32(90, 95, 105, 255), 0.0f,
                  ImDrawFlags_None, 1.0f);
    ImGui::End();
}

void draw_pages_bar() {
    if (!g.manager) return;
    if (g.scene_mode) {
        if (ImGui::Button("UI Mode")) g.scene_mode = false;
        ImGui::SameLine();
        if (ImGui::Button("Save scene")) (void)scene_save(false);
        ImGui::SameLine();
        if (ImGui::Button("Save scene as")) (void)scene_save(true);
        ImGui::SameLine();
        if (ImGui::Button("Open scene")) {
            std::string path = open_scene_dialog();
            if (!path.empty()) (void)scene_load(path);
        }
        ImGui::SameLine();
        ImGui::Text("%s%s", g.scene_path.empty() ? "(untitled scene)"
                                                 : fs::path(g.scene_path).filename().string().c_str(),
                    g.scene_dirty ? "  *" : "");
        return;
    }
    size_t pages = 0;
    uim_page_count(g.manager, &pages);
    if (pages == 0) return;
    ImGui::SetNextItemWidth(220);
    const char *current = "";
    uim_page_get_key(g.manager, g.page, &current);
    if (ImGui::BeginCombo("##page", current ? current : "page")) {
        for (size_t i = 0; i < pages; ++i) {
            uim_PageId p = uim_PAGE_INVALID;
            const char *key = "";
            uim_page_get_at(g.manager, i, &p);
            uim_page_get_key(g.manager, p, &key);
            bool selected = p == g.page;
            if (ImGui::Selectable(key, selected)) {
                g.page = p;
                g.root = page_root(g.manager, p);
                g.selected_instance = 0;
                g.viewport_initialized = false;
    g.auto_fit = true;
                if (g.editor) uir_editor_set_active_page(g.editor, p);
            }
        }
        ImGui::EndCombo();
    }
    ImGui::SameLine();
    if (ImGui::Button("+ Page")) {
        char key[32];
        for (int i = 1; i < 1000; ++i) {
            std::snprintf(key, sizeof(key), "page_%d", i);
            uim_PageId existing = uim_PAGE_INVALID;
            if (uim_page_find(g.manager, key, &existing) != uim_OK) break;
        }
        uim_PageId p = uim_PAGE_INVALID;
        if (uim_page_create(g.manager, key, &p) == uim_OK) {
            g.page = p;
            g.root = create_node("screen", 0, {0, 0, 960, 600}, uim_COMPONENT_PANEL);
            g.viewport_initialized = false;
    g.auto_fit = true;
            g.dirty = true;
            if (g.editor) uir_editor_set_active_page(g.editor, p);
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("- Page") && pages > 1u) g.confirm_delete_page = true;
    if (g.confirm_delete_page) ImGui::OpenPopup("delete_page");
    if (ImGui::BeginPopupModal("delete_page", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Delete page \"%s\" and all of its nodes?",
                    current ? current : "");
        if (ImGui::Button("Delete", ImVec2(100, 0))) {
            uim_page_destroy(g.manager, g.page);
            uim_PageId first = uim_PAGE_INVALID;
            (void)uim_page_get_at(g.manager, 0u, &first);
            g.page = first;
            g.root = page_root(g.manager, first);
            g.selected_instance = 0;
            g.viewport_initialized = false;
            g.auto_fit = true;
            g.dirty = true;
            if (g.editor) uir_editor_set_active_page(g.editor, first);
            g.confirm_delete_page = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(100, 0))) {
            g.confirm_delete_page = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
    ImGui::SameLine();
    if (!g.playing) {
        if (ImGui::Button("Play (F5)")) start_play();
    } else {
        bool paused = uim_runtime_paused();
        if (ImGui::Button(paused ? "Resume" : "Pause"))
            uim_runtime_set_paused(!paused);
        ImGui::SameLine();
        if (ImGui::Button("Step")) {
            uim_runtime_set_paused(true);
            uim_runtime_step(g.manager, g.page);
        }
        ImGui::SameLine();
        if (ImGui::Button("Stop (F5)")) stop_play();
    }
    ImGui::SameLine();
    if (ImGui::Button("Run (CMake) (F6 / Ctrl+F5)")) run_cmake_debug();
    ImGui::SameLine();
    if (ImGui::Button("Scene Mode")) {
        scene_ensure_demo();
        g.scene_mode = true;
    }
    if (g.scene_mode) {
        ImGui::SameLine();
        if (ImGui::Button(g.gizmo_mode == 0 ? "[W] Move" : "W Move")) g.gizmo_mode = 0;
        ImGui::SameLine();
        if (ImGui::Button(g.gizmo_mode == 1 ? "[E] Rotate" : "E Rotate")) g.gizmo_mode = 1;
        ImGui::SameLine();
        if (ImGui::Button(g.gizmo_mode == 2 ? "[R] Scale" : "R Scale")) g.gizmo_mode = 2;
    }
    ImGui::SameLine();
    if (ImGui::Button(g.gizmo_space ? "Local" : "World"))
        g.gizmo_space = g.gizmo_space ? 0 : 1;
    ImGui::SameLine();
    ImGui::Checkbox("Snap", &g.gizmo_snap);
    ImGui::SameLine();
    if (ImGui::Button(g.show_game ? "Game [on]" : "Game"))
        g.show_game = !g.show_game;
    ImGui::SameLine();
    ImGui::Text("%s%s", g.project_path.empty() ? "(unsaved)"
                                                : fs::path(g.project_path).filename().string().c_str(),
                g.dirty ? "  *" : "");
    if (ImGui::IsItemHovered() && !g.project_path.empty())
        ImGui::SetTooltip("%s", g.project_path.c_str());
}

void build_default_dock_layout(ImGuiID dock_id, const ImGuiViewport *vp) {
    ImGuiID center = dock_id;
    ImGuiID left = 0, right = 0, bottom = 0;
    ImGui::DockBuilderRemoveNode(dock_id);
    ImGui::DockBuilderAddNode(dock_id, ImGuiDockNodeFlags_DockSpace);
    ImGui::DockBuilderSetNodeSize(dock_id, vp->WorkSize);

    left = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 0.22f, &left, &center);
    right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 0.32f, &right, &center);
    bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, 0.24f, &bottom, &center);
    ImGuiID project = 0;
    project = ImGui::DockBuilderSplitNode(left, ImGuiDir_Down, 0.45f, &project, &left);

    ImGui::DockBuilderDockWindow("Hierarchy", left);
    ImGui::DockBuilderDockWindow("Project", project);
    ImGui::DockBuilderDockWindow("Inspector", right);
    ImGui::DockBuilderDockWindow("Console", bottom);
    ImGui::DockBuilderDockWindow("Viewport", center);
    ImGui::DockBuilderFinish(dock_id);
    /* A single-window dock node otherwise keeps a tab bar that covers the first
     * row of every panel and desynchronises drawing from item hit rectangles.
     * Unity-like fixed panels do not need per-window tabs. */
    for (ImGuiID node_id : {dock_id, left, right, bottom, center, project}) {
        if (ImGuiDockNode *node = ImGui::DockBuilderGetNode(node_id))
            node->LocalFlags |= ImGuiDockNodeFlags_NoTabBar;
    }
}

void draw_ui() {
    draw_menu();
    handle_shortcuts();

    ImGuiViewport *vp = ImGui::GetMainViewport();
    ImGuiID dock_id = ImGui::GetID("ZcsrEditorDock");
    if (g.first_layout) {
        build_default_dock_layout(dock_id, vp);
        g.first_layout = false;
    }
    ImGui::DockSpaceOverViewport(dock_id, vp, ImGuiDockNodeFlags_PassthruCentralNode);

    if (g.show_hierarchy) draw_hierarchy();
    if (g.show_project) draw_project_panel();
    if (g.show_viewport) draw_viewport();
    if (g.show_game) draw_game_view();
    if (g.show_inspector) draw_inspector();
    if (g.show_console) draw_console();
    draw_preferences();
    draw_rename_popup();

    /* Blur the active field when the click landed on no field at all. Done at
     * the end of the frame so the field that was clicked had its chance to
     * claim focus first. */
    if (ImGui::IsMouseClicked(0) && !g.field_hovered_this_frame) blur_text_field();
    g.field_hovered_this_frame = false;

    if (g.auto_save_seconds > 0.0f && !g.playing && g.focused_field.empty() &&
        (g.dirty || g.scene_dirty) &&
        now_ms() - g.last_autosave_ms >= (double)g.auto_save_seconds * 1000.0) {
        if (g.scene_mode) {
            if (!g.scene_path.empty()) (void)scene_save(false);
        } else {
            if (!g.project_path.empty()) (void)save_project(false);
        }
        g.last_autosave_ms = now_ms();
    }
}

void apply_editor_input(EditorApp *app, int cw, int ch) {
    ImGuiIO &io = ImGui::GetIO();
    double now = now_ms() / 1000.0;
    io.DeltaTime = g_last_time > 0.0 ? (float)std::clamp(now - g_last_time, 1.0 / 1000.0, 0.25) : 1.0f / 60.0f;
    g_last_time = now;
    io.DisplaySize = ImVec2((float)cw, (float)ch);
    io.MousePos = ImVec2(app->mouse_x, app->mouse_y);
    io.AddMousePosEvent(app->mouse_x, app->mouse_y);
    static uint32_t prev_buttons = 0;
    for (int b = 0; b < 3; ++b) {
        uint32_t bit = 1u << b;
        bool down = (app->mouse_buttons & bit) != 0;
        bool was = (prev_buttons & bit) != 0;
        bool pressed = (app->mouse_pressed & bit) != 0;
        bool released = (app->mouse_released & bit) != 0;
        if (pressed) io.AddMouseButtonEvent(b, true);
        if (released) io.AddMouseButtonEvent(b, false);
        if (!pressed && !released && down != was) io.AddMouseButtonEvent(b, down);
    }
    prev_buttons = app->mouse_buttons;
    app->mouse_pressed = 0;
    app->mouse_released = 0;
    if (app->wheel_delta) io.AddMouseWheelEvent(0.0f, (float)app->wheel_delta);
    app->wheel_delta = 0;
    bool ctrl = zcsr_runtime_shell_key_down(ZCSR_KEY_CTRL);
    bool shift = zcsr_runtime_shell_key_down(ZCSR_KEY_SHIFT);
    bool alt = zcsr_runtime_shell_key_down(ZCSR_KEY_ALT);
    bool gui = zcsr_runtime_shell_key_down(ZCSR_KEY_GUI);
    io.AddKeyEvent(ImGuiMod_Ctrl, ctrl);
    io.AddKeyEvent(ImGuiMod_Shift, shift);
    io.AddKeyEvent(ImGuiMod_Alt, alt);
    io.AddKeyEvent(ImGuiMod_Super, gui);
    io.AddKeyEvent(ImGuiKey_LeftSuper, gui);
    for (ImGuiKey held : app->imgui_keys_down) {
        io.AddKeyEvent(held, false);
    }
    app->imgui_keys_down.clear();
    for (int code : app->keys) {
        ImGuiKey key = ImGuiKey_None;
        if (code >= ZCSR_KEY_A && code <= ZCSR_KEY_Z) {
            key = (ImGuiKey)(ImGuiKey_A + (code - ZCSR_KEY_A));
        } else if (code >= ZCSR_KEY_0 && code <= ZCSR_KEY_9) {
            key = (ImGuiKey)(ImGuiKey_0 + (code - ZCSR_KEY_0));
        } else if (code >= ZCSR_KEY_F1 && code <= ZCSR_KEY_F12) {
            key = (ImGuiKey)(ImGuiKey_F1 + (code - ZCSR_KEY_F1));
        } else {
            switch (code) {
                case ZCSR_KEY_ESCAPE: key = ImGuiKey_Escape; break;
                case ZCSR_KEY_TAB: key = ImGuiKey_Tab; break;
                case ZCSR_KEY_ENTER: key = ImGuiKey_Enter; break;
                case ZCSR_KEY_SPACE: key = ImGuiKey_Space; break;
                case ZCSR_KEY_BACKSPACE: key = ImGuiKey_Backspace; break;
                case ZCSR_KEY_DELETE: key = ImGuiKey_Delete; break;
                case ZCSR_KEY_INSERT: key = ImGuiKey_Insert; break;
                case ZCSR_KEY_HOME: key = ImGuiKey_Home; break;
                case ZCSR_KEY_END: key = ImGuiKey_End; break;
                case ZCSR_KEY_PAGE_UP: key = ImGuiKey_PageUp; break;
                case ZCSR_KEY_PAGE_DOWN: key = ImGuiKey_PageDown; break;
                case ZCSR_KEY_ARROW_LEFT: key = ImGuiKey_LeftArrow; break;
                case ZCSR_KEY_ARROW_RIGHT: key = ImGuiKey_RightArrow; break;
                case ZCSR_KEY_ARROW_UP: key = ImGuiKey_UpArrow; break;
                case ZCSR_KEY_ARROW_DOWN: key = ImGuiKey_DownArrow; break;
                case ZCSR_KEY_CTRL: key = ImGuiKey_LeftCtrl; break;
                case ZCSR_KEY_SHIFT: key = ImGuiKey_LeftShift; break;
                case ZCSR_KEY_ALT: key = ImGuiKey_LeftAlt; break;
                case ZCSR_KEY_GUI: key = ImGuiKey_LeftSuper; break;
                default: break;
            }
        }
        if (key != ImGuiKey_None) {
            io.AddKeyEvent(key, true);
            app->imgui_keys_down.push_back(key);
        }
    }
    app->keys.clear();
    if (!app->text_input.empty()) {
        io.AddInputCharactersUTF8(app->text_input.c_str());
        app->text_input.clear();
    }
}

void frame(zcsr_gl_renderer *renderer, int cw, int ch, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app || !renderer) return;
    app->renderer = renderer;
    app->window_w = cw;
    app->window_h = ch;

    if (app->playing && app->manager && app->page != uim_PAGE_INVALID) {
        uim_runtime_tick(app->manager, app->page, ImGui::GetIO().DeltaTime > 0 ? ImGui::GetIO().DeltaTime : 1.0 / 60.0);
        int goto_page = uim_runtime_take_goto_request();
        if (goto_page > 0) {
            uim_PageId next = uim_PAGE_INVALID;
            size_t pages = 0;
            uim_page_count(app->manager, &pages);
            if ((size_t)goto_page <= pages && uim_page_get_at(app->manager, (size_t)goto_page - 1, &next) == uim_OK) {
                app->page = next;
                app->root = page_root(app->manager, next);
                app->viewport_initialized = false;
                if (app->editor) uir_editor_set_active_page(app->editor, next);
                uim_runtime_begin(app->manager, next);
            }
        }
    }

    render_page_to_texture();
    if (g.playing && !g.play_first_logged) {
        char buf[64];
        snprintf(buf, sizeof(buf), "play first frame %.1f ms",
                 now_ms() - g.play_start_ms);
        log_line(buf);
        g.play_first_logged = true;
    }

    apply_editor_input(app, cw, ch);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    draw_ui();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    if (g_smoke_frames > 0 && ++g_frame_count >= g_smoke_frames) {
        g_smoke_frames = 0;
        zcsr_runtime_shell_request_exit();
        printf("editor smoke: requested exit after %d frames\n", g_frame_count);
        fflush(stdout);
    }
}

void pointer_cb(int x, int y, uint32_t buttons, uint32_t pressed, uint32_t released, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return;
    app->mouse_x = (float)x;
    app->mouse_y = (float)y;
    app->mouse_buttons = buttons;
    app->mouse_pressed |= pressed;
    app->mouse_released |= released;


}

void text_cb(const char *utf8, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (app && utf8) app->text_input += utf8;
}

bool key_cb(int key, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return false;
    app->keys.push_back(key);
    // Editor owns Escape/S while active; otherwise the shell would leave the module
    // or open its runtime settings page behind the editor.
    return key == ZCSR_KEY_ESCAPE || key == ZCSR_KEY_S;
}

bool init_cb(zcsr_gl_renderer *renderer, int cw, int ch, void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return false;
    app->renderer = renderer;
    app->window_w = cw;
    app->window_h = ch;
    app->host = editor_host_create(zcsr_runtime_shell_surface());
    if (!app->host) return false;

    /* The three editor text fields are UIM text state from their first use. */
    (void)uim_text_input_init(&app->rename_text, 127u);
    (void)uim_text_input_init(&app->component_filter_text, 63u);
    (void)uim_text_input_init(&app->node_name_text, 127u);
    (void)uim_text_input_init(&app->project_filter_text, 63u);
    (void)uim_text_input_init(&app->console_filter_text, 63u);
    (void)uim_text_input_init(&app->hierarchy_filter_text, 63u);
    reset_assets();

    /* DPI has exactly one source: the engine platform surface (WM_DPICHANGED
     * on Win32). The glyph height and every ImGui style metric derive from it,
     * so the editor is neither a fixed 16 px island nor a hand-tuned constant. */
    float dpi_scale = 1.0f;
    if (zcsr_surface *dpi_surface = zcsr_runtime_shell_surface()) {
        float d = zcsr_surface_get_dpi_scale(dpi_surface);
        /* Windows can report 5.0 at 500%. Never fall back to 1.0 for a value
         * that is merely above the supported range: that would shrink the
         * whole editor. Clamp to the same 0.5..4.0 policy as uim_theme. */
        if (std::isfinite(d) && d >= 0.5f) dpi_scale = std::min(d, 4.0f);
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImFontConfig fc{};
    fc.OversampleH = 2;
    fc.OversampleV = 2;
    const char *font_candidates[] = {
        "C:\\Windows\\Fonts\\msyh.ttc",
        "C:\\Windows\\Fonts\\Deng.ttf",
        "C:\\Windows\\Fonts\\simhei.ttf",
        "/System/Library/Fonts/PingFang.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    };
    const char *font_path = nullptr;
    for (const char *candidate : font_candidates) {
        if (fs::exists(candidate)) { font_path = candidate; break; }
    }
    ImFont *font = nullptr;
    if (font_path) {
        font = io.Fonts->AddFontFromFileTTF(font_path, 16.0f * dpi_scale, &fc,
                                            io.Fonts->GetGlyphRangesChineseFull());
    }
    if (!font) io.Fonts->AddFontDefault();
    ImGui::StyleColorsDark();
    ImGuiStyle &style = ImGui::GetStyle();
    style.WindowRounding = 4.0f;
    style.FrameRounding = 3.0f;
    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize = 0.0f;
    style.ItemSpacing.y = 4.0f;
    if (dpi_scale != 1.0f) style.ScaleAllSizes(dpi_scale);
    ImGui_ImplOpenGL3_Init("#version 130");
    g_last_time = now_ms() / 1000.0;

    if (!new_document()) log_line("initial document creation failed");
    zcsr_scene_init(&g.scene);
    g.scene_history = zcsr_editor_scene_history_create();
    if (!g.scene_history) log_line("scene history allocation failed");
    g.scene_saved_hash = zcsr_editor_scene_content_hash(&g.scene);
    // Start with the bundled rule demo when it exists, otherwise keep a clean page.
    // The exe lives in build_main/Release; the demo project is in build_main/demo.
    fs::path exe_dir = fs::path(exe_path()).parent_path();
    std::string demo = (exe_dir.parent_path() / "demo" / "rule_demo.uireproj").string();
    if (fs::exists(demo)) load_project(demo);
    return true;
}

void shutdown_cb(zcsr_gl_renderer *renderer, void *user) {
    (void)renderer;
    (void)user;
    stop_play();
    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    destroy_document();
    destroy_project_browser();
    zcsr_editor_scene_history_destroy(g.scene_history);
    g.scene_history = nullptr;
    editor_host_destroy(g.host);
    g.host = nullptr;
}

bool close_request_cb(void *user) {
    EditorApp *app = (EditorApp *)user;
    if (!app) return true;
    if (!app->dirty && !app->scene_dirty) return true;
    editor_host_unsaved_choice choice = app->host
        ? editor_host_confirm_unsaved(app->host, "ZCSR Editor",
              "Unsaved changes.\n\nSave: save and exit\nDiscard: discard and exit\nCancel: stay")
        : EDITOR_HOST_UNSAVED_CANCEL;
    if (choice == EDITOR_HOST_UNSAVED_SAVE) {
        if (app->dirty && !save_project(false)) return false;
        if (app->scene_dirty && !scene_save(false)) return false;
        return true;
    }
    if (choice == EDITOR_HOST_UNSAVED_DISCARD) return true;
    return false;
}

} // namespace

static void configure_smoke_exit(int argc, char **argv) {
    g_smoke_frames = 0;
    g_frame_count = 0;
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--smoke-frames") == 0 && i + 1 < argc) {
            char *end = nullptr;
            long n = strtol(argv[++i], &end, 10);
            if (end && *end == '\0' && n > 0 && n <= 100000) {
                g_smoke_frames = (int)n;
            }
        } else if (strcmp(argv[i], "--autoquit") == 0 || strcmp(argv[i], "autoquit") == 0) {
            /* --autoquit is a fallback exit, not an override of an explicit
             * --smoke-frames. Keep the caller's deterministic frame budget. */
            if (g_smoke_frames == 0) g_smoke_frames = 150;
        }
    }
}

extern "C" void runtime(int argc, char **argv) {
    configure_smoke_exit(argc, argv);
    zcsr_runtime_shell_module mod{};
    mod.title = "ZCSR Editor";
    mod.user = &g;
    mod.init = init_cb;
    mod.shutdown = shutdown_cb;
    mod.frame = frame;
    mod.pointer = pointer_cb;
    mod.text = text_cb;
    mod.key = key_cb;
    mod.close_request = close_request_cb;
    (void)zcsr_runtime_window_run(&mod, 1, 1, nullptr);
}

#ifdef ZCSR_EDITOR_KEY_TEST
// Test-only hooks: drive the same apply_editor_input + handle_shortcuts path
// used by the real window loop, without an OpenGL renderer.
static uim_NodeId g_test_child = uim_NODE_INVALID;

extern "C" bool zcsr_editor_test_init(void) {
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.DisplaySize = ImVec2(960, 600);
    io.DeltaTime = 1.0f / 60.0f;
    // The real editor builds its font atlas through ImGui_ImplOpenGL3_Init.
    // The headless test must build the default atlas explicitly before NewFrame.
    unsigned char *pixels = nullptr;
    int atlas_w = 0, atlas_h = 0;
    io.Fonts->GetTexDataAsRGBA32(&pixels, &atlas_w, &atlas_h);
    return new_document();
}

extern "C" void zcsr_editor_test_shutdown(void) {
    destroy_document();
    destroy_project_browser();
    ImGui::DestroyContext();
}

extern "C" void zcsr_editor_test_set_save_path(const char *path) {
    g.project_path = path ? path : "";
    g.dirty = true;
}

extern "C" int zcsr_editor_test_make_child(void) {
    g_test_child = create_node("child", g.root, {10, 10, 100, 40}, uim_COMPONENT_PANEL);
    if (g_test_child != uim_NODE_INVALID) select_node(g_test_child, false);
    return (int)g_test_child;
}

extern "C" int zcsr_editor_test_child_alive(void) {
    uim_NodeInfo info{};
    return (g_test_child != uim_NODE_INVALID &&
            uim_node_get(g.manager, g_test_child, &info) == uim_OK) ? 1 : 0;
}

extern "C" int zcsr_editor_test_node_count(void) {
    size_t count = 0;
    if (!g.manager || g.page == uim_PAGE_INVALID) return -1;
    return uim_page_get_node_count(g.manager, g.page, &count) == uim_OK ? (int)count : -1;
}

extern "C" int zcsr_editor_test_playing(void) { return g.playing ? 1 : 0; }
extern "C" int zcsr_editor_test_dirty(void) { return g.dirty ? 1 : 0; }

extern "C" void zcsr_editor_test_open_rename(void) {
    if (g_test_child != uim_NODE_INVALID) begin_rename(g_test_child);
}

extern "C" void zcsr_editor_test_set_rename_name(const char *name) {
    ensure_field(&g.rename_text, 127u);
    field_set_clamped(&g.rename_text, name ? name : "");
}

extern "C" int zcsr_editor_test_rename_enter(void) {
    // Frame 1 opens the modal and requests focus on the input.
    g.keys.clear();
    apply_editor_input(&g, 960, 600);
    ImGui::NewFrame();
    draw_rename_popup();
    ImGui::EndFrame();
    // Frame 2 lets ImGui process the nav focus request.
    apply_editor_input(&g, 960, 600);
    ImGui::NewFrame();
    draw_rename_popup();
    ImGui::EndFrame();
    // Frames 3-5: press, release, press so the active InputText sees a real edge.
    for (int i = 0; i < 3; ++i) {
        g.keys.clear();
        if (i != 1) g.keys.push_back(ZCSR_KEY_ENTER);
        apply_editor_input(&g, 960, 600);
        ImGui::NewFrame();
        draw_rename_popup();
        ImGui::EndFrame();
        if (!g.rename_open) break;
    }
    return g.rename_open ? 0 : 1;
}

extern "C" void zcsr_editor_test_child_key(char *out, int cap) {
    uim_NodeInfo info{};
    if (!out || cap <= 0) return;
    out[0] = 0;
    if (g_test_child == uim_NODE_INVALID ||
        uim_node_get(g.manager, g_test_child, &info) != uim_OK ||
        !info.stable_key) return;
    std::snprintf(out, (size_t)cap, "%s", info.stable_key);
}

extern "C" int zcsr_editor_test_owns_key(int key) {
    return key_cb(key, &g) ? 1 : 0;
}

extern "C" void zcsr_editor_test_begin_key(int key, int ctrl, int shift) {
    g.keys.clear();
    // Drive the same module key callback used by zcsr_window_game_run(); do not
    // inject directly into EditorApp::keys or this test stops covering the
    // runtime-shell -> module key_cb boundary.
    (void)key_cb(key, &g);
    apply_editor_input(&g, 960, 600);
    ImGuiIO &io = ImGui::GetIO();
    io.AddKeyEvent(ImGuiMod_Ctrl, ctrl != 0);
    io.AddKeyEvent(ImGuiMod_Shift, shift != 0);
    io.AddKeyEvent(ImGuiMod_Super, false);
    io.AddKeyEvent(ImGuiKey_LeftSuper, false);
    ImGui::NewFrame();
}

extern "C" void zcsr_editor_test_begin_key_gui(int key, int ctrl, int shift, int gui) {
    g.keys.clear();
    (void)key_cb(key, &g);
    apply_editor_input(&g, 960, 600);
    ImGuiIO &io = ImGui::GetIO();
    io.AddKeyEvent(ImGuiMod_Ctrl, ctrl != 0);
    io.AddKeyEvent(ImGuiMod_Shift, shift != 0);
    io.AddKeyEvent(ImGuiMod_Super, gui != 0);
    io.AddKeyEvent(ImGuiKey_LeftSuper, gui != 0);
    ImGui::NewFrame();
}

extern "C" void zcsr_editor_test_set_primary_gui(int gui) {
    g_test_primary_gui = gui < 0 ? -1 : (gui ? 1 : 0);
}

extern "C" void zcsr_editor_test_dispatch(void) {
    handle_shortcuts();
    ImGui::EndFrame();
}

extern "C" void zcsr_editor_test_idle(void) {
    g.keys.clear();
    apply_editor_input(&g, 960, 600);
    ImGui::NewFrame();
    handle_shortcuts();
    ImGui::EndFrame();
}
#endif
