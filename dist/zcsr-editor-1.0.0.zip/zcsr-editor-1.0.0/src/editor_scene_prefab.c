#include "editor_scene_prefab.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "editor_scene_io.h"

uint64_t zcsr_editor_prefab_id_from_path(const char *utf8_path)
{
    const unsigned char *p = (const unsigned char *)utf8_path;
    uint64_t hash = 1469598103934665603ull; /* FNV-1a 64 offset basis */
    if (!p || !*p) return 0u;
    while (*p) {
        hash ^= (uint64_t)*p++;
        hash *= 1099511628211ull;
    }
    return hash ? hash : 1u;
}

bool zcsr_editor_prefab_save_entity(const zcsr_scene *scene,
                                    zcsr_entity_id source_id,
                                    const char *utf8_path,
                                    uint64_t *out_prefab_id)
{
    const zcsr_scene_entity *source;
    zcsr_scene *one;
    zcsr_scene_entity copy;
    zcsr_scene_point quad[4];
    zcsr_entity_id made;
    bool has_quad;
    uint64_t id;

    if (!scene || source_id == 0u || !utf8_path || !utf8_path[0]) return false;
    source = zcsr_scene_get_const(scene, source_id);
    if (!source) return false;
    id = zcsr_editor_prefab_id_from_path(utf8_path);
    if (id == 0u) return false;

    has_quad = zcsr_scene_has_quad(scene, source_id);
    if (has_quad && !zcsr_scene_entity_quad(scene, source_id, quad)) return false;
    if (has_quad) {
        for (int i = 0; i < 4; ++i) {
            if (!isfinite(quad[i].x) || !isfinite(quad[i].y) || !isfinite(quad[i].z))
                return false;
        }
    }

    copy = *source;
    copy.id = 0;
    copy.kind = ZCSR_SCENE_KIND_PREFAB;
    copy.prefab_id = id;
    copy.order = 0;
    if (!isfinite(copy.x) || !isfinite(copy.y) || !isfinite(copy.z) ||
        !isfinite(copy.w) || !isfinite(copy.h) ||
        !isfinite(copy.rotation_deg) || !isfinite(copy.pivot_x) ||
        !isfinite(copy.pivot_y) || !isfinite(copy.tint_r) ||
        !isfinite(copy.tint_g) || !isfinite(copy.tint_b) ||
        !isfinite(copy.tint_a))
        return false;

    one = (zcsr_scene *)malloc(sizeof(*one));
    if (!one) return false;
    zcsr_scene_init(one);
    made = zcsr_scene_add(one, &copy);
    if (made == 0u) { free(one); return false; }
    if (has_quad && !zcsr_scene_set_quad(one, made, quad)) { free(one); return false; }

    {
        zcsr_editor_scene_io_result rc = zcsr_editor_scene_save(one, utf8_path);
        free(one);
        if (rc != ZCSR_EDITOR_SCENE_IO_OK) return false;
    }
    if (out_prefab_id) *out_prefab_id = id;
    return true;
}

size_t zcsr_editor_prefab_instantiate(zcsr_scene *scene,
                                      const char *utf8_path,
                                      float x, float z,
                                      zcsr_entity_id *out_ids,
                                      size_t capacity,
                                      uint64_t *out_prefab_id)
{
    zcsr_scene *loaded;
    zcsr_entity_id *added;
    const zcsr_scene_entity *root;
    size_t added_count = 0u;
    uint64_t prefab_id;
    float dx, dz;

    if (!scene || !utf8_path || !utf8_path[0] ||
        !isfinite(x) || !isfinite(z))
        return 0u;
    prefab_id = zcsr_editor_prefab_id_from_path(utf8_path);
    if (prefab_id == 0u) return 0u;

    loaded = (zcsr_scene *)malloc(sizeof(*loaded));
    added = (zcsr_entity_id *)malloc(ZCSR_SCENE_MAX_ENTITIES * sizeof(*added));
    if (!loaded || !added) { free(loaded); free(added); return 0u; }
    zcsr_scene_init(loaded);
    if (zcsr_editor_scene_load(loaded, utf8_path) != ZCSR_EDITOR_SCENE_IO_OK ||
        loaded->count == 0u) {
        free(loaded);
        free(added);
        return 0u;
    }
    root = &loaded->entities[0];
    dx = x - root->x;
    dz = z - root->z;

    for (size_t i = 0u; i < loaded->count; ++i) {
        const zcsr_scene_entity *src = &loaded->entities[i];
        zcsr_scene_entity copy = *src;
        zcsr_scene_point quad[4];
        bool has_quad = zcsr_scene_has_quad(loaded, src->id);
        zcsr_entity_id made;

        if (has_quad && !zcsr_scene_entity_quad(loaded, src->id, quad)) {
            goto rollback;
        }
        copy.id = 0;
        copy.x = src->x + dx;
        copy.z = src->z + dz;
        copy.order = (int)scene->count;
        copy.kind = ZCSR_SCENE_KIND_PREFAB;
        copy.prefab_id = prefab_id;
        if (!isfinite(copy.x) || !isfinite(copy.z)) goto rollback;
        made = zcsr_scene_add(scene, &copy);
        if (made == 0u) goto rollback;
        added[added_count++] = made;
        if (has_quad) {
            for (int k = 0; k < 4; ++k) {
                quad[k].x += dx;
                quad[k].z += dz;
                if (!isfinite(quad[k].x) || !isfinite(quad[k].z)) goto rollback;
            }
            if (!zcsr_scene_set_quad(scene, made, quad)) goto rollback;
        }
    }

    if (out_ids) {
        size_t n = added_count < capacity ? added_count : capacity;
        memcpy(out_ids, added, n * sizeof(added[0]));
    }
    if (out_prefab_id) *out_prefab_id = prefab_id;
    free(loaded);
    free(added);
    return added_count;

rollback:
    for (size_t i = 0u; i < added_count; ++i)
        (void)zcsr_scene_remove(scene, added[i]);
    free(loaded);
    free(added);
    return 0u;
}
