/*
 * editor_domain.c — Facade over the pluggable editor document backend.
 *
 * The default implementation forwards every provider slot to the existing
 * C11 kernel (uim_Editor) over an injected UIM_ComponentManager. A host with
 * its own document model supplies its own zcsr_DomainProviderOps instead; the
 * facade only dispatches through the vtable and holds no model state of its
 * own beyond the wrapped kernel pointer.
 *
 * Renderer-neutral: no ImGui, GL, OS window or zcsr_scene dependency here.
 */
#include "editor_domain.h"

#include <stdlib.h>
#include <string.h>

struct zcsr_DomainEditor {
    const zcsr_DomainProviderOps *ops;
    void *user;
    uim_Editor *kernel;
    uim_EditorSelection selection_cache;
};

/* ------------------------------------------------------------------------- */
/* Default adapter: forwards to the bundled C11 kernel.                      */
/* ------------------------------------------------------------------------- */

static uim_Result default_create_node(void *user, const uim_NodeDesc *desc,
                                      uim_NodeId *out_id)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_create_node(e->kernel, desc, out_id);
}

static uim_Result default_inspect_node(void *user, uim_NodeId node_id,
                                       uim_NodeInfo *out_info)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_inspect_node(e->kernel, node_id, out_info);
}

static uim_Result default_set_rect(void *user, uim_NodeId node_id, uim_Rect rect)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_set_rect(e->kernel, node_id, rect);
}

static uim_Result default_delete_node(void *user, uim_NodeId node_id)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_delete_node(e->kernel, node_id);
}

static uim_Result default_get_selection(void *user, const uim_NodeId **out_ids,
                                        size_t *out_count)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    uim_Result rc = uir_editor_get_selection(e->kernel, &e->selection_cache);
    if (rc != uim_OK) return rc;
    *out_ids = e->selection_cache.ids;
    *out_count = e->selection_cache.count;
    return uim_OK;
}

static uim_Result default_set_selection(void *user, const uim_NodeId *ids,
                                        size_t count)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_select(e->kernel, ids, count);
}

static uim_Result default_undo(void *user)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_undo(e->kernel);
}

static uim_Result default_redo(void *user)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_redo(e->kernel);
}

static uim_Result default_history_state(void *user, uim_EditorHistoryState *out)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_get_history_state(e->kernel, out);
}

static uim_Result default_hit_test(void *user, uim_PageId page_id,
                                   float canvas_x, float canvas_y,
                                   uim_NodeId *out_node_id)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_canvas_hit_test(e->kernel, page_id, canvas_x, canvas_y,
                                      out_node_id);
}

static uim_Result default_box_select(void *user, uim_PageId page_id,
                                    uim_Rect canvas_rect, bool additive)
{
    zcsr_DomainEditor *e = (zcsr_DomainEditor *)user;
    return uir_editor_canvas_box_select(e->kernel, page_id, canvas_rect, additive);
}

static const zcsr_DomainProviderOps zcsr_domain_default_ops = {
    ZCSR_DOMAIN_ABI_VERSION,
    sizeof(zcsr_domain_default_ops),
    default_create_node,
    default_inspect_node,
    default_set_rect,
    default_delete_node,
    default_get_selection,
    default_set_selection,
    default_undo,
    default_redo,
    default_history_state,
    default_hit_test,
    default_box_select,
};

/* ------------------------------------------------------------------------- */
/* Lifecycle                                                                 */
/* ------------------------------------------------------------------------- */

uim_Result zcsr_domain_editor_create_default(UIM_ComponentManager *manager,
                                             size_t history_capacity,
                                             zcsr_DomainEditor **out_editor)
{
    zcsr_DomainEditor *e = NULL;
    uim_Result rc;

    if (!out_editor || !manager) return uim_ERR_ARGUMENT;
    *out_editor = NULL;

    e = (zcsr_DomainEditor *)calloc(1, sizeof(*e));
    if (!e) return uim_ERR_NOMEM;

    rc = uir_editor_create(manager, history_capacity, &e->kernel);
    if (rc != uim_OK) {
        free(e);
        return rc;
    }
    e->ops = &zcsr_domain_default_ops;
    e->user = e;
    *out_editor = e;
    return uim_OK;
}

uim_Result zcsr_domain_editor_create(const zcsr_DomainProviderOps *ops,
                                    void *user,
                                    zcsr_DomainEditor **out_editor)
{
    zcsr_DomainEditor *e = NULL;

    if (!out_editor || !ops) return uim_ERR_ARGUMENT;
    *out_editor = NULL;
    if (ops->abi_version != ZCSR_DOMAIN_ABI_VERSION) return uim_ERR_RANGE;
    if (ops->struct_size < sizeof(zcsr_DomainProviderOps)) return uim_ERR_RANGE;

    e = (zcsr_DomainEditor *)calloc(1, sizeof(*e));
    if (!e) return uim_ERR_NOMEM;

    e->ops = ops;
    e->user = user;
    e->kernel = NULL;
    *out_editor = e;
    return uim_OK;
}

void zcsr_domain_editor_destroy(zcsr_DomainEditor *editor)
{
    if (!editor) return;
    if (editor->kernel) uir_editor_destroy(editor->kernel);
    free(editor);
}

uim_Editor *zcsr_domain_editor_kernel(zcsr_DomainEditor *editor)
{
    return editor ? editor->kernel : NULL;
}

/* ------------------------------------------------------------------------- */
/* Facade dispatch                                                           */
/* ------------------------------------------------------------------------- */

#define DOMAIN_CHECK_SLOT(editor, slot)                                       \
    do {                                                                       \
        if (!(editor) || !(editor)->ops || !(editor)->ops->slot)               \
            return uim_ERR_UNSUPPORTED;                                        \
    } while (0)

uim_Result zcsr_domain_create_node(zcsr_DomainEditor *editor,
                                    const uim_NodeDesc *desc, uim_NodeId *out_id)
{
    DOMAIN_CHECK_SLOT(editor, create_node);
    return editor->ops->create_node(editor->user, desc, out_id);
}

uim_Result zcsr_domain_inspect_node(zcsr_DomainEditor *editor,
                                    uim_NodeId node_id, uim_NodeInfo *out_info)
{
    DOMAIN_CHECK_SLOT(editor, inspect_node);
    return editor->ops->inspect_node(editor->user, node_id, out_info);
}

uim_Result zcsr_domain_set_rect(zcsr_DomainEditor *editor,
                                 uim_NodeId node_id, uim_Rect rect)
{
    DOMAIN_CHECK_SLOT(editor, set_rect);
    return editor->ops->set_rect(editor->user, node_id, rect);
}

uim_Result zcsr_domain_delete_node(zcsr_DomainEditor *editor, uim_NodeId node_id)
{
    DOMAIN_CHECK_SLOT(editor, delete_node);
    return editor->ops->delete_node(editor->user, node_id);
}

uim_Result zcsr_domain_get_selection(zcsr_DomainEditor *editor,
                                     const uim_NodeId **out_ids, size_t *out_count)
{
    DOMAIN_CHECK_SLOT(editor, get_selection);
    return editor->ops->get_selection(editor->user, out_ids, out_count);
}

uim_Result zcsr_domain_set_selection(zcsr_DomainEditor *editor,
                                     const uim_NodeId *ids, size_t count)
{
    DOMAIN_CHECK_SLOT(editor, set_selection);
    return editor->ops->set_selection(editor->user, ids, count);
}

uim_Result zcsr_domain_undo(zcsr_DomainEditor *editor)
{
    DOMAIN_CHECK_SLOT(editor, undo);
    return editor->ops->undo(editor->user);
}

uim_Result zcsr_domain_redo(zcsr_DomainEditor *editor)
{
    DOMAIN_CHECK_SLOT(editor, redo);
    return editor->ops->redo(editor->user);
}

uim_Result zcsr_domain_history_state(zcsr_DomainEditor *editor,
                                     uim_EditorHistoryState *out_state)
{
    DOMAIN_CHECK_SLOT(editor, history_state);
    return editor->ops->history_state(editor->user, out_state);
}

uim_Result zcsr_domain_hit_test(zcsr_DomainEditor *editor, uim_PageId page_id,
                                float canvas_x, float canvas_y,
                                uim_NodeId *out_node_id)
{
    DOMAIN_CHECK_SLOT(editor, hit_test);
    return editor->ops->hit_test(editor->user, page_id, canvas_x, canvas_y,
                                 out_node_id);
}

uim_Result zcsr_domain_box_select(zcsr_DomainEditor *editor, uim_PageId page_id,
                                 uim_Rect canvas_rect, bool additive)
{
    DOMAIN_CHECK_SLOT(editor, box_select);
    return editor->ops->box_select(editor->user, page_id, canvas_rect, additive);
}
