#include "ui_editor_shell.h"
#include <string.h>

static void shell_event_push(uim_EditorShell *s, uim_ShellEventType type,
                             uim_ShellCommandId cmd, uim_WorkspacePanelId panel,
                             uim_WorkspaceViewportMode mode)
{
    uim_EditorShellEvent *e;
    if (s->event_count >= uim_EDITOR_SHELL_EVENT_CAPACITY) {
        s->dropped_events++;
        return;
    }
    e = &s->events[(s->event_head + s->event_count) % uim_EDITOR_SHELL_EVENT_CAPACITY];
    memset(e, 0, sizeof(*e));
    e->type = type;
    e->command_id = cmd;
    e->panel_id = panel;
    e->viewport_mode = mode;
    e->layout_revision = s->layout_revision;
    s->event_count++;
}

static uim_EditorShellPanelState *shell_panel(uim_EditorShell *s, uim_WorkspacePanelId id)
{
    for (size_t i = 0; i < s->panel_count; ++i)
        if (s->panels[i].desc.id == id) return &s->panels[i];
    return NULL;
}

static const uim_EditorShellPanelState *shell_panel_c(const uim_EditorShell *s, uim_WorkspacePanelId id)
{
    for (size_t i = 0; i < s->panel_count; ++i)
        if (s->panels[i].desc.id == id) return &s->panels[i];
    return NULL;
}

static bool shell_is_center(uim_WorkspacePanelId id)
{
    return id == uim_WORKSPACE_PANEL_SCENE || id == uim_WORKSPACE_PANEL_GAME;
}

static void shell_default_panels(uim_EditorShellPanelDesc out[8])
{
    uim_EditorShellPanelDesc p[8] = {
        {uim_WORKSPACE_PANEL_PALETTE, "Palette", 160.0f, 120.0f,
         uim_SHELL_PANEL_CLOSEABLE | uim_SHELL_PANEL_FLOATABLE,
         uim_WORKSPACE_PANEL_PALETTE, uim_WORKSPACE_DOCK_CENTER, 280.0f, 360.0f},
        {uim_WORKSPACE_PANEL_HIERARCHY, "Hierarchy", 180.0f, 120.0f,
         uim_SHELL_PANEL_CLOSEABLE | uim_SHELL_PANEL_FLOATABLE,
         uim_WORKSPACE_PANEL_PALETTE, uim_WORKSPACE_DOCK_CENTER, 320.0f, 420.0f},
        {uim_WORKSPACE_PANEL_SCENE, "Scene", 320.0f, 240.0f,
         uim_SHELL_PANEL_CENTER_HOST | uim_SHELL_PANEL_SINGLETON,
         uim_WORKSPACE_PANEL_SCENE, uim_WORKSPACE_DOCK_CENTER, 0.0f, 0.0f},
        {uim_WORKSPACE_PANEL_GAME, "Game", 320.0f, 240.0f,
         uim_SHELL_PANEL_CENTER_HOST | uim_SHELL_PANEL_SINGLETON,
         uim_WORKSPACE_PANEL_SCENE, uim_WORKSPACE_DOCK_CENTER, 0.0f, 0.0f},
        {uim_WORKSPACE_PANEL_INSPECTOR, "Inspector", 220.0f, 200.0f,
         uim_SHELL_PANEL_CLOSEABLE | uim_SHELL_PANEL_FLOATABLE,
         uim_WORKSPACE_PANEL_INSPECTOR, uim_WORKSPACE_DOCK_CENTER, 320.0f, 480.0f},
        {uim_WORKSPACE_PANEL_PROJECT, "Project", 200.0f, 100.0f,
         uim_SHELL_PANEL_CLOSEABLE | uim_SHELL_PANEL_FLOATABLE,
         uim_WORKSPACE_PANEL_PROJECT, uim_WORKSPACE_DOCK_CENTER, 360.0f, 260.0f},
        {uim_WORKSPACE_PANEL_ASSETS, "Assets", 200.0f, 100.0f,
         uim_SHELL_PANEL_CLOSEABLE | uim_SHELL_PANEL_FLOATABLE,
         uim_WORKSPACE_PANEL_PROJECT, uim_WORKSPACE_DOCK_CENTER, 360.0f, 260.0f},
        {uim_WORKSPACE_PANEL_CONSOLE, "Console", 200.0f, 100.0f,
         uim_SHELL_PANEL_CLOSEABLE | uim_SHELL_PANEL_FLOATABLE,
         uim_WORKSPACE_PANEL_PROJECT, uim_WORKSPACE_DOCK_CENTER, 480.0f, 220.0f},
    };
    memcpy(out, p, sizeof(p));
}

void uir_editor_shell_theme_dark(uim_EditorShellTheme *t)
{
    if (!t) return;
    memset(t, 0, sizeof(*t));
    t->theme_id = 1;
    t->root = (uim_ShellColor){0.105f, 0.110f, 0.125f, 1.0f};
    t->menu = (uim_ShellColor){0.135f, 0.140f, 0.160f, 1.0f};
    t->toolbar = (uim_ShellColor){0.125f, 0.130f, 0.150f, 1.0f};
    t->panel = (uim_ShellColor){0.155f, 0.160f, 0.180f, 1.0f};
    t->panel_header = (uim_ShellColor){0.180f, 0.185f, 0.210f, 1.0f};
    t->button = (uim_ShellColor){0.200f, 0.205f, 0.230f, 1.0f};
    t->button_active = (uim_ShellColor){0.250f, 0.330f, 0.420f, 1.0f};
    t->tab = (uim_ShellColor){0.160f, 0.165f, 0.190f, 1.0f};
    t->tab_active = (uim_ShellColor){0.230f, 0.270f, 0.330f, 1.0f};
    t->border = (uim_ShellColor){0.250f, 0.255f, 0.280f, 1.0f};
    t->splitter = (uim_ShellColor){0.130f, 0.135f, 0.150f, 1.0f};
    t->viewport = (uim_ShellColor){0.085f, 0.090f, 0.100f, 1.0f};
    t->status = (uim_ShellColor){0.120f, 0.125f, 0.140f, 1.0f};
    t->floating = (uim_ShellColor){0.175f, 0.180f, 0.205f, 1.0f};
    t->drop_target = (uim_ShellColor){0.300f, 0.420f, 0.520f, 0.65f};
    t->text = (uim_ShellColor){0.900f, 0.905f, 0.920f, 1.0f};
    t->text_dim = (uim_ShellColor){0.560f, 0.570f, 0.600f, 1.0f};
    t->accent = (uim_ShellColor){0.310f, 0.560f, 0.760f, 1.0f};
    t->menu_height = 24.0f;
    t->toolbar_height = 36.0f;
    t->status_height = 22.0f;
    t->panel_header_height = 26.0f;
    t->tab_height = 26.0f;
    t->splitter_size = 6.0f;
    t->spacing = 4.0f;
}

static void shell_build_workspace(uim_EditorShell *s, float w, float h)
{
    uim_WorkspaceConfig cfg;
    uim_WorkspacePanelDesc panels[8];
    memset(&cfg, 0, sizeof(cfg));
    cfg.width = w;
    cfg.height = h;
    cfg.menu_bar_height = s->theme.menu_height;
    cfg.toolbar_height = s->theme.toolbar_height;
    cfg.status_bar_height = s->theme.status_height;
    cfg.bottom_panel_height = 160.0f;
    cfg.left_panel_width = 240.0f;
    cfg.right_panel_width = 280.0f;
    cfg.splitter_size = s->theme.splitter_size;
    cfg.tab_height = s->theme.tab_height;
    for (size_t i = 0; i < s->panel_count && i < 8; ++i) {
        panels[i].id = s->panels[i].desc.id;
        panels[i].title = s->panels[i].desc.title;
        panels[i].min_width = s->panels[i].desc.min_width;
        panels[i].min_height = s->panels[i].desc.min_height;
        panels[i].flags = s->panels[i].desc.flags;
    }
    cfg.panels = panels;
    cfg.panel_count = s->panel_count > 8 ? 8 : s->panel_count;
    uim_workspace_init_default(&s->workspace, &cfg);
}

uim_Result uir_editor_shell_init_default(uim_EditorShell *shell,
                                         float client_width,
                                         float client_height)
{
    uim_EditorShellPanelDesc defaults[8];
    if (!shell || client_width <= 0.0f || client_height <= 0.0f) return uim_ERR_ARGUMENT;
    memset(shell, 0, sizeof(*shell));
    uir_editor_shell_theme_dark(&shell->theme);
    shell_default_panels(defaults);
    for (size_t i = 0; i < 8; ++i) {
        shell->panels[i].desc = defaults[i];
        shell->panels[i].registered = true;
    }
    shell->panel_count = 8;
    shell->active_tool = uim_SHELL_TOOL_SELECT;
    shell->grid_enabled = true;
    shell->open_menu = uim_SHELL_MENU_NONE;
    shell_build_workspace(shell, client_width, client_height);
    shell->layout_revision = 1;
    return uim_OK;
}

uim_Result uir_editor_shell_set_bounds(uim_EditorShell *shell,
                                       float client_width,
                                       float client_height)
{
    if (!shell || client_width <= 0.0f || client_height <= 0.0f) return uim_ERR_ARGUMENT;
    uim_Result rc = uim_workspace_set_bounds(&shell->workspace, client_width, client_height);
    if (rc != uim_OK) return rc;
    shell->layout_revision++;
    shell_event_push(shell, uim_SHELL_EVENT_LAYOUT_CHANGED, 0, 0, shell->workspace.viewport_mode);
    return uim_OK;
}

static void shell_add_element(uim_EditorShellFrame *f, uim_ShellElementKind kind,
                              uim_ShellStyleToken style, uim_Rect rect,
                              uim_WorkspacePanelId panel, uim_ShellCommandId command,
                              const char *label, uint32_t flags, uint16_t z)
{
    uim_EditorShellElement *e;
    if (f->element_count >= uim_EDITOR_SHELL_MAX_ELEMENTS) {
        f->dropped_elements++;
        return;
    }
    e = &f->elements[f->element_count++];
    memset(e, 0, sizeof(*e));
    e->kind = kind;
    e->style = style;
    e->rect = rect;
    e->panel_id = panel;
    e->command_id = command;
    e->label = label;
    e->flags = flags;
    e->z_order = z;
}

#define SHELL_MENU_X 8.0f
#define SHELL_MENU_W 72.0f
#define SHELL_MENU_POPUP_W 220.0f
#define SHELL_MENU_ITEM_H 24.0f
#define SHELL_MENU_PAD 4.0f

static size_t shell_menu_item_count(const uim_EditorShell *s, uim_ShellMenuId menu)
{
    size_t n = 0;
    if (!s || menu == uim_SHELL_MENU_NONE) return 0;
    for (size_t i = 0; i < s->command_count; ++i)
        if ((s->commands[i].flags & uim_SHELL_COMMAND_MENU) &&
            s->commands[i].menu_id == menu)
            n++;
    return n;
}

static uim_Rect shell_menu_popup_rect(const uim_EditorShell *s, uim_ShellMenuId menu)
{
    uim_Rect r = {0, 0, 0, 0};
    size_t n;
    if (!s || menu == uim_SHELL_MENU_NONE) return r;
    n = shell_menu_item_count(s, menu);
    r.x = SHELL_MENU_X + SHELL_MENU_W * (float)(menu - 1);
    r.y = s->workspace_frame.menu_bar.height;
    r.width = SHELL_MENU_POPUP_W;
    r.height = SHELL_MENU_PAD * 2.0f + SHELL_MENU_ITEM_H * (float)(n ? n : 1);
    return r;
}

/* Returns the command under (x,y) and the item rect used for press/release
 * pairing. Kept next to the frame builder so hit testing and rendering cannot
 * drift apart. */
static uim_ShellCommandId shell_menu_item_at(const uim_EditorShell *s,
                                             float x, float y,
                                             uim_Rect *out_rect)
{
    uim_Rect popup;
    size_t slot = 0;
    if (!s || s->open_menu == uim_SHELL_MENU_NONE) return 0;
    popup = shell_menu_popup_rect(s, s->open_menu);
    if (x < popup.x || y < popup.y ||
        x >= popup.x + popup.width || y >= popup.y + popup.height)
        return 0;
    for (size_t i = 0; i < s->command_count; ++i) {
        const uim_EditorShellCommandDesc *c = &s->commands[i];
        uim_Rect item;
        if (!(c->flags & uim_SHELL_COMMAND_MENU) || c->menu_id != s->open_menu)
            continue;
        item.x = popup.x + 1.0f;
        item.y = popup.y + SHELL_MENU_PAD + SHELL_MENU_ITEM_H * (float)slot;
        item.width = popup.width - 2.0f;
        item.height = SHELL_MENU_ITEM_H;
        if (x >= item.x && y >= item.y &&
            x < item.x + item.width && y < item.y + item.height) {
            if (out_rect) *out_rect = item;
            return c->id;
        }
        slot++;
    }
    return 0;
}

uim_Result uir_editor_shell_build_frame(uim_EditorShell *shell,
                                        uim_EditorShellFrame *out_frame)
{
    if (!shell || !out_frame) return uim_ERR_ARGUMENT;
    memset(out_frame, 0, sizeof(*out_frame));
    uim_Result rc = uim_workspace_build_frame(&shell->workspace, &out_frame->workspace);
    if (rc != uim_OK) return rc;
    shell->workspace_frame = out_frame->workspace;

    shell_add_element(out_frame, uim_SHELL_ELEMENT_MENU_BAR, uim_SHELL_STYLE_MENU,
                      out_frame->workspace.menu_bar, 0, 0, NULL, 0, 0);
    const char *menus[] = {"File", "Edit", "Assets", "Window", "Help"};
    float mx = SHELL_MENU_X;
    for (size_t i = 0; i < 5; ++i) {
        shell_add_element(out_frame, uim_SHELL_ELEMENT_MENU_HEADER, uim_SHELL_STYLE_MENU,
                          (uim_Rect){mx, 0.0f, SHELL_MENU_W, out_frame->workspace.menu_bar.height},
                          0, (uim_ShellCommandId)(i + 1), menus[i], 0,
                          i + 1 == (size_t)shell->open_menu ? 2 : 1);
        mx += SHELL_MENU_W;
    }
    if (shell->open_menu != uim_SHELL_MENU_NONE) {
        uim_Rect popup = shell_menu_popup_rect(shell, shell->open_menu);
        size_t slot = 0;
        shell_add_element(out_frame, uim_SHELL_ELEMENT_MENU_POPUP, uim_SHELL_STYLE_MENU,
                          popup, 0, 0, NULL, 0, 60);
        for (size_t i = 0; i < shell->command_count; ++i) {
            const uim_EditorShellCommandDesc *c = &shell->commands[i];
            uim_Rect item;
            if (!(c->flags & uim_SHELL_COMMAND_MENU) || c->menu_id != shell->open_menu)
                continue;
            item.x = popup.x + 1.0f;
            item.y = popup.y + SHELL_MENU_PAD + SHELL_MENU_ITEM_H * (float)slot;
            item.width = popup.width - 2.0f;
            item.height = SHELL_MENU_ITEM_H;
            shell_add_element(out_frame, uim_SHELL_ELEMENT_MENU_ITEM,
                              uim_SHELL_STYLE_MENU,
                              item, 0, c->id, c->label, c->flags, 61);
            slot++;
        }
    }
    shell_add_element(out_frame, uim_SHELL_ELEMENT_TOOLBAR, uim_SHELL_STYLE_TOOLBAR,
                      out_frame->workspace.toolbar, 0, 0, NULL, 0, 2);

    for (size_t i = 0; i < out_frame->workspace.panel_count; ++i) {
        const uim_WorkspacePanelView *v = &out_frame->workspace.panels[i];
        const uim_EditorShellPanelState *p = shell_panel_c(shell, v->panel_id);
        if (v->active) {
            shell_add_element(out_frame, uim_SHELL_ELEMENT_PANEL_HEADER, uim_SHELL_STYLE_PANEL_HEADER,
                              (uim_Rect){v->content_rect.x,
                                         v->content_rect.y - shell->theme.tab_height,
                                         v->content_rect.width, shell->theme.tab_height},
                              v->panel_id, 0, p ? p->desc.title : NULL, p ? p->desc.flags : 0, 10);
            shell_add_element(out_frame, shell_is_center(v->panel_id) ? uim_SHELL_ELEMENT_CENTER_HOST
                                                                       : uim_SHELL_ELEMENT_DOCK_PANEL,
                              shell_is_center(v->panel_id) ? uim_SHELL_STYLE_VIEWPORT : uim_SHELL_STYLE_PANEL,
                              v->content_rect, v->panel_id, 0, p ? p->desc.title : NULL,
                              p ? p->desc.flags : 0, 11);
        }
        shell_add_element(out_frame, uim_SHELL_ELEMENT_PANEL_TAB,
                          v->active ? uim_SHELL_STYLE_TAB_ACTIVE : uim_SHELL_STYLE_TAB,
                          v->tab_rect, v->panel_id, 0, p ? p->desc.title : NULL,
                          p ? p->desc.flags : 0, 20);
    }
    for (size_t i = 0; i < out_frame->workspace.splitter_count; ++i) {
        shell_add_element(out_frame, uim_SHELL_ELEMENT_SPLITTER, uim_SHELL_STYLE_SPLITTER,
                          out_frame->workspace.splitters[i].rect, 0, 0, NULL, 0, 30);
    }
    for (size_t i = 0; i < shell->floating_count; ++i) {
        if (!shell->floating[i].open) continue;
        shell_add_element(out_frame, uim_SHELL_ELEMENT_FLOAT_PANEL, uim_SHELL_STYLE_FLOATING,
                          shell->floating[i].rect, shell->floating[i].panel_id, 0, NULL, 0, 40);
        shell_add_element(out_frame, uim_SHELL_ELEMENT_FLOAT_TITLE, uim_SHELL_STYLE_PANEL_HEADER,
                          (uim_Rect){shell->floating[i].rect.x, shell->floating[i].rect.y,
                                     shell->floating[i].rect.width, uim_EDITOR_SHELL_FLOAT_TITLE_H},
                          shell->floating[i].panel_id, 0, NULL, 0, 41);
    }
    shell_add_element(out_frame, uim_SHELL_ELEMENT_STATUS_BAR, uim_SHELL_STYLE_STATUS,
                      out_frame->workspace.status_bar, 0, 0, NULL, 0, 50);

    if (uim_workspace_get_center_host_rect(&shell->workspace, &out_frame->workspace,
                                           &out_frame->center_host_rect,
                                           &out_frame->viewport_mode) == uim_OK) {
        out_frame->active_center_panel = out_frame->viewport_mode == uim_WORKSPACE_VIEW_GAME
                                             ? uim_WORKSPACE_PANEL_GAME
                                             : uim_WORKSPACE_PANEL_SCENE;
    }
    out_frame->layout_revision = shell->layout_revision;
    return uim_OK;
}

uim_Result uir_editor_shell_register_panel(uim_EditorShell *shell,
                                            const uim_EditorShellPanelDesc *desc)
{
    if (!shell || !desc || !desc->id) return uim_ERR_ARGUMENT;
    if (shell_panel(shell, desc->id)) return uim_ERR_EXISTS;
    if (shell->panel_count >= uim_EDITOR_SHELL_MAX_PANELS) return uim_ERR_RANGE;
    shell->panels[shell->panel_count].desc = *desc;
    shell->panels[shell->panel_count].registered = true;
    shell->panel_count++;
    return uim_OK;
}

uim_Result uir_editor_shell_register_command(uim_EditorShell *shell,
                                              const uim_EditorShellCommandDesc *desc)
{
    if (!shell || !desc || !desc->id) return uim_ERR_ARGUMENT;
    for (size_t i = 0; i < shell->command_count; ++i)
        if (shell->commands[i].id == desc->id) return uim_ERR_EXISTS;
    if (shell->command_count >= uim_EDITOR_SHELL_MAX_COMMANDS) return uim_ERR_RANGE;
    shell->commands[shell->command_count++] = *desc;
    return uim_OK;
}

uim_Result uir_editor_shell_panel_show(uim_EditorShell *shell,
                                       uim_WorkspacePanelId panel_id)
{
    if (!shell || !panel_id) return uim_ERR_ARGUMENT;
    uim_EditorShellPanelState *p = shell_panel(shell, panel_id);
    if (!p) return uim_ERR_NOT_FOUND;
    for (size_t i = 0; i < shell->floating_count; ++i)
        if (shell->floating[i].panel_id == panel_id) shell->floating[i].open = true;
    uim_WorkspacePanelId target = p->desc.default_target_panel ? p->desc.default_target_panel
                                                               : uim_WORKSPACE_PANEL_SCENE;
    uim_Result rc = uim_workspace_dock_panel(&shell->workspace, panel_id, target,
                                             p->desc.default_dock_zone);
    if (rc == uim_OK) {
        shell_event_push(shell, uim_SHELL_EVENT_PANEL_SHOWN, 0, panel_id, shell->workspace.viewport_mode);
        shell->layout_revision++;
    }
    return rc;
}

uim_Result uir_editor_shell_panel_hide(uim_EditorShell *shell,
                                       uim_WorkspacePanelId panel_id)
{
    if (!shell || !panel_id) return uim_ERR_ARGUMENT;
    const uim_EditorShellPanelState *p = shell_panel_c(shell, panel_id);
    if (!p) return uim_ERR_NOT_FOUND;
    if (p->desc.flags & uim_SHELL_PANEL_CENTER_HOST) return uim_ERR_STATE;
    for (size_t i = 0; i < shell->floating_count; ++i)
        if (shell->floating[i].panel_id == panel_id) shell->floating[i].open = false;
    uim_Result rc = uim_workspace_close_panel(&shell->workspace, panel_id);
    if (rc == uim_OK) {
        shell_event_push(shell, uim_SHELL_EVENT_PANEL_HIDDEN, 0, panel_id, shell->workspace.viewport_mode);
        shell->layout_revision++;
    }
    return rc;
}

uim_Result uir_editor_shell_panel_float(uim_EditorShell *shell,
                                        uim_WorkspacePanelId panel_id,
                                        uim_Rect rect)
{
    if (!shell || !panel_id) return uim_ERR_ARGUMENT;
    const uim_EditorShellPanelState *p = shell_panel_c(shell, panel_id);
    if (!p) return uim_ERR_NOT_FOUND;
    if (!(p->desc.flags & uim_SHELL_PANEL_FLOATABLE)) return uim_ERR_STATE;
    if (rect.width <= 0.0f || rect.height <= 0.0f) return uim_ERR_ARGUMENT;
    if (shell->floating_count >= uim_EDITOR_SHELL_MAX_FLOATING) return uim_ERR_RANGE;
    (void)uim_workspace_close_panel(&shell->workspace, panel_id);
    shell->floating[shell->floating_count].panel_id = panel_id;
    shell->floating[shell->floating_count].rect = rect;
    shell->floating[shell->floating_count].open = true;
    shell->floating[shell->floating_count].z_order = (uint16_t)(shell->floating_count + 1);
    shell->floating_count++;
    shell_event_push(shell, uim_SHELL_EVENT_PANEL_FLOATED, 0, panel_id, shell->workspace.viewport_mode);
    shell->layout_revision++;
    return uim_OK;
}

uim_Result uir_editor_shell_panel_dock(uim_EditorShell *shell,
                                       uim_WorkspacePanelId panel_id,
                                       uim_WorkspacePanelId target_panel_id,
                                       uim_WorkspaceDockZone zone)
{
    if (!shell || !panel_id || !target_panel_id) return uim_ERR_ARGUMENT;
    for (size_t i = 0; i < shell->floating_count; ++i)
        if (shell->floating[i].panel_id == panel_id) shell->floating[i].open = false;
    uim_Result rc = uim_workspace_dock_panel(&shell->workspace, panel_id, target_panel_id, zone);
    if (rc == uim_OK) {
        shell_event_push(shell, uim_SHELL_EVENT_PANEL_DOCKED, 0, panel_id, shell->workspace.viewport_mode);
        shell->layout_revision++;
    }
    return rc;
}

uim_Result uir_editor_shell_reset_layout(uim_EditorShell *shell)
{
    if (!shell) return uim_ERR_ARGUMENT;
    shell_build_workspace(shell, shell->workspace.config.width, shell->workspace.config.height);
    shell->floating_count = 0;
    shell->center_maximized = false;
    shell->layout_revision++;
    shell_event_push(shell, uim_SHELL_EVENT_LAYOUT_CHANGED, 0, 0, shell->workspace.viewport_mode);
    return uim_OK;
}

uim_Result uir_editor_shell_apply_layout_preset(uim_EditorShell *shell,
                                                 uim_EditorShellLayoutPreset preset)
{
    if (!shell) return uim_ERR_ARGUMENT;
    if (preset < uim_SHELL_LAYOUT_DEFAULT || preset > uim_SHELL_LAYOUT_DEBUG)
        return uim_ERR_ARGUMENT;
    uim_Result rc = uir_editor_shell_reset_layout(shell);
    if (rc != uim_OK) return rc;
    if (shell->workspace.root != uim_WORKSPACE_NODE_INVALID) {
        if (preset == uim_SHELL_LAYOUT_WIDE_VIEWPORT)
            shell->workspace.nodes[shell->workspace.root].ratio = 0.88f;
        else if (preset == uim_SHELL_LAYOUT_DEBUG)
            shell->workspace.nodes[shell->workspace.root].ratio = 0.62f;
    }
    return uim_OK;
}

uim_Result uir_editor_shell_set_center_maximized(uim_EditorShell *shell, bool maximized)
{
    if (!shell) return uim_ERR_ARGUMENT;
    if (shell->center_maximized == maximized) return uim_OK;
    shell->center_maximized = maximized;
    shell->layout_revision++;
    shell_event_push(shell, uim_SHELL_EVENT_LAYOUT_CHANGED, 0, 0, shell->workspace.viewport_mode);
    return uim_OK;
}

uim_Result uir_editor_shell_pointer_down(uim_EditorShell *shell,
                                         float x, float y, uint32_t modifiers)
{
    (void)modifiers;
    if (!shell) return uim_ERR_ARGUMENT;
    shell->pointer_x = shell->pointer_down_x = x;
    shell->pointer_y = shell->pointer_down_y = y;

    /* An open menu owns the pointer before any workspace hit testing. */
    if (shell->open_menu != uim_SHELL_MENU_NONE) {
        uim_Rect item;
        uim_ShellCommandId command = shell_menu_item_at(shell, x, y, &item);
        if (command) {
            shell->capture = uim_SHELL_CAPTURE_MENU_ITEM;
            shell->capture_command = command;
            shell->capture_rect = item;
            return uim_OK;
        }
    }

    /* Menu headers sit above the toolbar and are a click, not a workspace drag. */
    if (shell->workspace_frame.menu_bar.height > 0 &&
        y >= 0.0f && y <= shell->workspace_frame.menu_bar.height &&
        x >= SHELL_MENU_X && x < SHELL_MENU_X + SHELL_MENU_W * 5.0f) {
        int index = (int)((x - SHELL_MENU_X) / SHELL_MENU_W) + 1;
        if (index < 1) index = 1;
        if (index > 5) index = 5;
        shell->open_menu = shell->open_menu == (uim_ShellMenuId)index
                               ? uim_SHELL_MENU_NONE
                               : (uim_ShellMenuId)index;
        shell->capture = uim_SHELL_CAPTURE_MENU_HEADER;
        shell->capture_rect = (uim_Rect){SHELL_MENU_X + SHELL_MENU_W * (float)(index - 1),
                                         0.0f, SHELL_MENU_W,
                                         shell->workspace_frame.menu_bar.height};
        return uim_OK;
    }

    /* Clicking anywhere else dismisses the menu and continues normally. */
    shell->open_menu = uim_SHELL_MENU_NONE;

    uim_Result rc = uim_workspace_pointer_down(&shell->workspace, &shell->workspace_frame, x, y);
    if (rc == uim_OK && shell->workspace.active_splitter != uim_WORKSPACE_NODE_INVALID) {
        shell->capture = uim_SHELL_CAPTURE_SPLITTER;
    } else {
        for (size_t i = 0; i < shell->workspace_frame.panel_count; ++i) {
            const uim_WorkspacePanelView *p = &shell->workspace_frame.panels[i];
            uim_Rect r = p->tab_rect;
            if (x >= r.x && y >= r.y && x < r.x + r.width && y < r.y + r.height) {
                shell->capture = uim_SHELL_CAPTURE_TAB;
                shell->drag_panel = p->panel_id;
                shell->drag_started = false;
                return uim_OK;
            }
        }
        if (y >= shell->workspace_frame.toolbar.y &&
            y < shell->workspace_frame.toolbar.y + shell->workspace_frame.toolbar.height) {
            shell->capture = uim_SHELL_CAPTURE_TOOL_BUTTON;
        }
    }
    return rc;
}

uim_Result uir_editor_shell_pointer_move(uim_EditorShell *shell,
                                         float x, float y)
{
    if (!shell) return uim_ERR_ARGUMENT;
    shell->pointer_x = x;
    shell->pointer_y = y;
    if (shell->capture == uim_SHELL_CAPTURE_MENU_ITEM)
        return uim_OK;
    if (shell->open_menu != uim_SHELL_MENU_NONE &&
        y >= 0.0f && y <= shell->workspace_frame.menu_bar.height &&
        x >= SHELL_MENU_X && x < SHELL_MENU_X + SHELL_MENU_W * 5.0f) {
        int index = (int)((x - SHELL_MENU_X) / SHELL_MENU_W) + 1;
        if (index < 1) index = 1;
        if (index > 5) index = 5;
        shell->open_menu = (uim_ShellMenuId)index;
        return uim_OK;
    }
    if (shell->capture == uim_SHELL_CAPTURE_SPLITTER)
        return uim_workspace_pointer_move(&shell->workspace, x, y);
    if (shell->capture == uim_SHELL_CAPTURE_TAB && shell->drag_panel) {
        float dx = x - shell->pointer_down_x;
        float dy = y - shell->pointer_down_y;
        if (dx < 0.0f) dx = -dx;
        if (dy < 0.0f) dy = -dy;
        if (dx > 4.0f || dy > 4.0f) shell->drag_started = true;
        if (shell->drag_started) {
            shell->drop_target_panel = 0;
            shell->drop_zone = uim_WORKSPACE_DOCK_CENTER;
            (void)uim_workspace_get_drop_target(&shell->workspace_frame, x, y,
                                                &shell->drop_target_panel,
                                                &shell->drop_zone);
        }
        return uim_OK;
    }
    if (shell->capture == uim_SHELL_CAPTURE_FLOAT_MOVE &&
        shell->capture_float_index >= 0 &&
        shell->capture_float_index < (int16_t)shell->floating_count) {
        uim_EditorShellFloatingPanel *f = &shell->floating[shell->capture_float_index];
        f->rect.x = shell->float_origin_rect.x + (x - shell->float_origin_x);
        f->rect.y = shell->float_origin_rect.y + (y - shell->float_float_origin_y);
        return uim_OK;
    }
    return uim_OK;
}

uim_Result uir_editor_shell_pointer_up(uim_EditorShell *shell,
                                       float x, float y)
{
    if (!shell) return uim_ERR_ARGUMENT;
    if (shell->capture == uim_SHELL_CAPTURE_SPLITTER)
        uim_workspace_pointer_up(&shell->workspace);
    if (shell->capture == uim_SHELL_CAPTURE_TAB && shell->drag_panel && shell->drag_started) {
        uim_WorkspacePanelId target;
        uim_WorkspaceDockZone zone;
        if (uim_workspace_get_drop_target(&shell->workspace_frame, x, y, &target, &zone) == uim_OK)
            (void)uir_editor_shell_panel_dock(shell, shell->drag_panel, target, zone);
    }
    if (shell->capture == uim_SHELL_CAPTURE_MENU_ITEM && shell->capture_command) {
        uim_Rect r = shell->capture_rect;
        if (x >= r.x && y >= r.y && x < r.x + r.width && y < r.y + r.height) {
            for (size_t i = 0; i < shell->command_count; ++i) {
                const uim_EditorShellCommandDesc *c = &shell->commands[i];
                if (c->id != shell->capture_command) continue;
                if (c->flags & uim_SHELL_COMMAND_ENABLED)
                    shell_event_push(shell, uim_SHELL_EVENT_COMMAND, c->id, 0,
                                     shell->workspace.viewport_mode);
                break;
            }
        }
        shell->open_menu = uim_SHELL_MENU_NONE;
    }
    /* A header click keeps the popup open until the next click or Escape. */
    shell->capture = uim_SHELL_CAPTURE_NONE;
    shell->capture_command = 0;
    shell->drag_started = false;
    shell->drag_panel = 0;
    shell->drop_target_panel = 0;
    return uim_OK;
}

uim_Result uir_editor_shell_key_down(uim_EditorShell *shell,
                                     uint32_t key,
                                     uint32_t modifiers)
{
    if (!shell || !key) return uim_ERR_ARGUMENT;
    if (key == uim_SHELL_KEY_ESCAPE && shell->open_menu != uim_SHELL_MENU_NONE) {
        shell->open_menu = uim_SHELL_MENU_NONE;
        shell->capture = uim_SHELL_CAPTURE_NONE;
        return uim_OK;
    }
    for (size_t i = 0; i < shell->command_count; ++i) {
        const uim_EditorShellCommandDesc *c = &shell->commands[i];
        if (c->shortcut_key != key || c->shortcut_modifiers != modifiers) continue;
        if (!(c->flags & uim_SHELL_COMMAND_ENABLED)) continue;
        shell_event_push(shell, uim_SHELL_EVENT_COMMAND, c->id, 0, shell->workspace.viewport_mode);
        return uim_OK;
    }
    return uim_ERR_NOT_FOUND;
}

void uir_editor_shell_set_focus(uim_EditorShell *shell, bool focused)
{
    if (shell) shell->focused = focused;
}

uim_Result uir_editor_shell_poll_event(uim_EditorShell *shell,
                                       uim_EditorShellEvent *out_event)
{
    if (!shell || !out_event) return uim_ERR_ARGUMENT;
    if (!shell->event_count) {
        memset(out_event, 0, sizeof(*out_event));
        return uim_ERR_NOT_FOUND;
    }
    *out_event = shell->events[shell->event_head];
    shell->event_head = (shell->event_head + 1) % uim_EDITOR_SHELL_EVENT_CAPACITY;
    shell->event_count--;
    return uim_OK;
}

uim_Result uir_editor_shell_set_theme(uim_EditorShell *shell,
                                      const uim_EditorShellTheme *theme)
{
    if (!shell || !theme) return uim_ERR_ARGUMENT;
    shell->theme = *theme;
    return uim_OK;
}

uim_Result uir_editor_shell_get_center_host(const uim_EditorShell *shell,
                                            uim_Rect *out_rect,
                                            uim_WorkspaceViewportMode *out_mode)
{
    if (!shell || !out_rect || !out_mode) return uim_ERR_ARGUMENT;
    return uim_workspace_get_center_host_rect(&shell->workspace, &shell->workspace_frame,
                                              out_rect, out_mode);
}

const uim_EditorShellTheme *uir_editor_shell_get_theme(const uim_EditorShell *shell)
{
    return shell ? &shell->theme : NULL;
}

const uim_Workspace *uir_editor_shell_get_workspace(const uim_EditorShell *shell)
{
    return shell ? &shell->workspace : NULL;
}

uim_Workspace *uir_editor_shell_get_workspace_mut(uim_EditorShell *shell)
{
    return shell ? &shell->workspace : NULL;
}
