#include "editor_scene_history.h"

#include <stdlib.h>
#include <string.h>
#include <stdint.h>

enum { ZCSR_EDITOR_SCENE_HISTORY_DEPTH = 16u };

typedef struct zcsr_editor_scene_snapshot {
    size_t count;
    size_t quad_count;
    zcsr_scene_entity entities[ZCSR_SCENE_MAX_ENTITIES];
    zcsr_scene_quad_override quads[ZCSR_SCENE_MAX_ENTITIES];
} zcsr_editor_scene_snapshot;

struct zcsr_editor_scene_history {
    zcsr_editor_scene_snapshot* undo;
    zcsr_editor_scene_snapshot* redo;
    zcsr_editor_scene_snapshot* pending;
    size_t undo_count;
    size_t redo_count;
    bool has_pending;
};

static void hash_u64(uint64_t* h, uint64_t v) {
    *h ^= v;
    *h *= 1099511628211ull;
}

static void hash_u32(uint64_t* h, uint32_t v) {
    hash_u64(h, (uint64_t)v);
}

static void hash_float(uint64_t* h, float v) {
    uint32_t bits = 0;
    memcpy(&bits, &v, sizeof(bits));
    hash_u32(h, bits);
}

static void hash_point(uint64_t* h, zcsr_scene_point p) {
    hash_float(h, p.x);
    hash_float(h, p.y);
    hash_float(h, p.z);
}

static void hash_entity(uint64_t* h, const zcsr_scene_entity* e) {
    hash_u64(h, e->id);
    hash_float(h, e->x);
    hash_float(h, e->y);
    hash_float(h, e->z);
    hash_float(h, e->w);
    hash_float(h, e->h);
    hash_float(h, e->rotation_deg);
    hash_float(h, e->pivot_x);
    hash_float(h, e->pivot_y);
    hash_u32(h, (uint32_t)e->layer);
    hash_u32(h, (uint32_t)e->order);
    hash_float(h, e->tint_r);
    hash_float(h, e->tint_g);
    hash_float(h, e->tint_b);
    hash_float(h, e->tint_a);
    hash_u32(h, e->texture);
    hash_u32(h, e->visible ? 1u : 0u);
}

static void hash_quad(uint64_t* h, const zcsr_scene_quad_override* q) {
    size_t c;
    hash_u64(h, q->id);
    for (c = 0; c < 4; ++c) hash_point(h, q->corners[c]);
}

static uint64_t hash_scene_content(const zcsr_scene* scene, bool include_camera) {
    uint64_t h = 1469598103934665603ull;
    size_t i;
    if (!scene) return 0;
    hash_u64(&h, (uint64_t)scene->count);
    hash_u64(&h, (uint64_t)scene->quad_count);
    if (include_camera) {
        hash_float(&h, scene->camera.target_x);
        hash_float(&h, scene->camera.target_y);
        hash_float(&h, scene->camera.target_z);
        hash_float(&h, scene->camera.yaw_deg);
        hash_float(&h, scene->camera.pitch_deg);
        hash_float(&h, scene->camera.roll_deg);
        hash_float(&h, scene->camera.distance);
        hash_float(&h, scene->camera.ortho_size);
    }
    for (i = 0; i < scene->count; ++i) hash_entity(&h, &scene->entities[i]);
    for (i = 0; i < scene->quad_count; ++i) hash_quad(&h, &scene->quads[i]);
    return h;
}

static void snapshot_capture(zcsr_editor_scene_snapshot* out, const zcsr_scene* scene) {
    if (!out || !scene) return;
    out->count = scene->count > ZCSR_SCENE_MAX_ENTITIES
        ? ZCSR_SCENE_MAX_ENTITIES : scene->count;
    out->quad_count = scene->quad_count > ZCSR_SCENE_MAX_ENTITIES
        ? ZCSR_SCENE_MAX_ENTITIES : scene->quad_count;
    if (out->count > 0) {
        memcpy(out->entities, scene->entities,
               out->count * sizeof(out->entities[0]));
    }
    if (out->quad_count > 0) {
        memcpy(out->quads, scene->quads,
               out->quad_count * sizeof(out->quads[0]));
    }
}

static uint64_t snapshot_hash(const zcsr_editor_scene_snapshot* snap) {
    uint64_t h = 1469598103934665603ull;
    size_t i;
    if (!snap) return 0;
    hash_u64(&h, (uint64_t)snap->count);
    hash_u64(&h, (uint64_t)snap->quad_count);
    for (i = 0; i < snap->count; ++i) hash_entity(&h, &snap->entities[i]);
    for (i = 0; i < snap->quad_count; ++i) hash_quad(&h, &snap->quads[i]);
    return h;
}

static void snapshot_apply(const zcsr_editor_scene_snapshot* snap, zcsr_scene* scene) {
    if (!snap || !scene) return;
    scene->count = snap->count;
    scene->quad_count = snap->quad_count;
    if (scene->count > 0) {
        memcpy(scene->entities, snap->entities,
               scene->count * sizeof(scene->entities[0]));
    }
    if (scene->quad_count > 0) {
        memcpy(scene->quads, snap->quads,
               scene->quad_count * sizeof(scene->quads[0]));
    }
    /* camera and next_id are intentionally preserved. */
}

static void push_undo(zcsr_editor_scene_history* history,
                      const zcsr_editor_scene_snapshot* snap) {
    if (!history || !snap) return;
    if (history->undo_count >= ZCSR_EDITOR_SCENE_HISTORY_DEPTH) {
        memmove(&history->undo[0], &history->undo[1],
                (ZCSR_EDITOR_SCENE_HISTORY_DEPTH - 1u) * sizeof(history->undo[0]));
        history->undo_count = ZCSR_EDITOR_SCENE_HISTORY_DEPTH - 1u;
    }
    history->undo[history->undo_count++] = *snap;
}

static void push_redo(zcsr_editor_scene_history* history,
                      const zcsr_editor_scene_snapshot* snap) {
    if (!history || !snap) return;
    if (history->redo_count >= ZCSR_EDITOR_SCENE_HISTORY_DEPTH) {
        memmove(&history->redo[0], &history->redo[1],
                (ZCSR_EDITOR_SCENE_HISTORY_DEPTH - 1u) * sizeof(history->redo[0]));
        history->redo_count = ZCSR_EDITOR_SCENE_HISTORY_DEPTH - 1u;
    }
    history->redo[history->redo_count++] = *snap;
}

zcsr_editor_scene_history* zcsr_editor_scene_history_create(void) {
    zcsr_editor_scene_history* history =
        (zcsr_editor_scene_history*)calloc(1, sizeof(*history));
    if (!history) return NULL;
    history->undo = (zcsr_editor_scene_snapshot*)calloc(
        ZCSR_EDITOR_SCENE_HISTORY_DEPTH, sizeof(*history->undo));
    history->redo = (zcsr_editor_scene_snapshot*)calloc(
        ZCSR_EDITOR_SCENE_HISTORY_DEPTH, sizeof(*history->redo));
    history->pending = (zcsr_editor_scene_snapshot*)calloc(1, sizeof(*history->pending));
    if (!history->undo || !history->redo || !history->pending) {
        zcsr_editor_scene_history_destroy(history);
        return NULL;
    }
    return history;
}

void zcsr_editor_scene_history_destroy(zcsr_editor_scene_history* history) {
    if (!history) return;
    free(history->undo);
    free(history->redo);
    free(history->pending);
    free(history);
}

bool zcsr_editor_scene_history_begin(zcsr_editor_scene_history* history,
                                     const zcsr_scene* scene) {
    if (!history || !scene) return false;
    if (history->has_pending) {
        (void)zcsr_editor_scene_history_commit(history, scene);
    }
    snapshot_capture(history->pending, scene);
    history->has_pending = true;
    return true;
}

bool zcsr_editor_scene_history_commit(zcsr_editor_scene_history* history,
                                      const zcsr_scene* scene) {
    uint64_t before_hash;
    uint64_t now_hash;
    if (!history || !scene || !history->has_pending) return false;
    before_hash = snapshot_hash(history->pending);
    now_hash = hash_scene_content(scene, false);
    history->has_pending = false;
    if (before_hash == now_hash) return false;
    push_undo(history, history->pending);
    history->redo_count = 0;
    return true;
}

bool zcsr_editor_scene_history_cancel(zcsr_editor_scene_history* history,
                                      zcsr_scene* scene) {
    if (!history || !scene || !history->has_pending) return false;
    snapshot_apply(history->pending, scene);
    history->has_pending = false;
    return true;
}

bool zcsr_editor_scene_history_undo(zcsr_editor_scene_history* history,
                                    zcsr_scene* scene) {
    zcsr_editor_scene_snapshot current;
    if (!history || !scene) return false;
    if (history->has_pending) {
        (void)zcsr_editor_scene_history_commit(history, scene);
    }
    if (history->undo_count == 0) return false;
    snapshot_capture(&current, scene);
    push_redo(history, &current);
    snapshot_apply(&history->undo[--history->undo_count], scene);
    return true;
}

bool zcsr_editor_scene_history_redo(zcsr_editor_scene_history* history,
                                    zcsr_scene* scene) {
    zcsr_editor_scene_snapshot current;
    if (!history || !scene) return false;
    if (history->has_pending) {
        (void)zcsr_editor_scene_history_commit(history, scene);
    }
    if (history->redo_count == 0) return false;
    snapshot_capture(&current, scene);
    push_undo(history, &current);
    snapshot_apply(&history->redo[--history->redo_count], scene);
    return true;
}

void zcsr_editor_scene_history_reset(zcsr_editor_scene_history* history,
                                     const zcsr_scene* scene) {
    (void)scene;
    if (!history) return;
    history->undo_count = 0;
    history->redo_count = 0;
    history->has_pending = false;
}

size_t zcsr_editor_scene_history_undo_count(const zcsr_editor_scene_history* history) {
    return history ? history->undo_count : 0;
}

size_t zcsr_editor_scene_history_redo_count(const zcsr_editor_scene_history* history) {
    return history ? history->redo_count : 0;
}

bool zcsr_editor_scene_history_has_pending(const zcsr_editor_scene_history* history) {
    return history ? history->has_pending : false;
}

uint64_t zcsr_editor_scene_content_hash(const zcsr_scene* scene) {
    return hash_scene_content(scene, true);
}
