/* editor_host_cocoa.m — native macOS dialogs for the editor host boundary.
 *
 * Only the three user-facing dialogs live here. Process launch, executable
 * lookup and the host lifetime stay in editor_host_posix.c, so the Cocoa
 * backend cannot create a second window or own a second main loop.
 *
 * NSOpenPanel/NSSavePanel/NSAlert are AppKit's real modal panels. osascript is
 * deliberately not used: it is an external process, has different focus and
 * sandbox behaviour, and cannot reliably preserve UTF-8 paths or extensions.
 */
#import <Cocoa/Cocoa.h>

#include "editor_host.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void cocoa_copy(char* out, size_t capacity, const char* text) {
    if (!out || capacity == 0) return;
    if (!text) {
        out[0] = '\0';
        return;
    }
    size_t n = strlen(text);
    if (n >= capacity) n = capacity - 1;
    memcpy(out, text, n);
    out[n] = '\0';
}

static void cocoa_ensure_extension(char* path, size_t capacity, const char* extension) {
    if (!path || !path[0] || !extension || !extension[0]) return;
    const char* base = strrchr(path, '/');
    base = base ? base + 1 : path;
    if (strrchr(base, '.')) return;
    size_t n = strlen(path);
    size_t e = strlen(extension);
    if (n + e + 2 > capacity) return;
    path[n++] = '.';
    memcpy(path + n, extension, e + 1);
}

static NSString* cocoa_string(const char* text) {
    if (!text) return nil;
    return [NSString stringWithUTF8String:text];
}

static void cocoa_activate_app(void) {
    NSApplication* app = [NSApplication sharedApplication];
    if (!app) return;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    [app activateIgnoringOtherApps:YES];
#pragma clang diagnostic pop
}

static void cocoa_apply_file_type(NSSavePanel* panel, const char* extension) {
    if (!panel || !extension || !extension[0]) return;
    NSString* type = cocoa_string(extension);
    if (!type) return;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    [panel setAllowedFileTypes:[NSArray arrayWithObject:type]];
#pragma clang diagnostic pop
}

bool editor_host_open_file(editor_host* host, const char* title, const char* extension,
                           char* out_path, size_t out_capacity) {
    (void)host;
    if (!out_path || out_capacity == 0) return false;
    out_path[0] = '\0';

    @autoreleasepool {
        NSOpenPanel* panel = [NSOpenPanel openPanel];
        if (!panel) return false;
        [panel setCanChooseFiles:YES];
        [panel setCanChooseDirectories:NO];
        [panel setAllowsMultipleSelection:NO];
        [panel setResolvesAliases:YES];
        [panel setTitle:cocoa_string(title && title[0] ? title : "Open File")];
        cocoa_apply_file_type(panel, extension);
        cocoa_activate_app();

        if ([panel runModal] != NSModalResponseOK) return false;
        NSURL* url = [panel URL];
        const char* path = url ? [[url path] UTF8String] : NULL;
        if (!path || !path[0]) return false;
        cocoa_copy(out_path, out_capacity, path);
        return out_path[0] != '\0';
    }
}

bool editor_host_save_file(editor_host* host, const char* title, const char* extension,
                           const char* suggested_name, char* out_path, size_t out_capacity) {
    (void)host;
    if (!out_path || out_capacity == 0) return false;
    out_path[0] = '\0';

    @autoreleasepool {
        NSSavePanel* panel = [NSSavePanel savePanel];
        if (!panel) return false;
        [panel setCanCreateDirectories:YES];
        [panel setExtensionHidden:NO];
        [panel setTitle:cocoa_string(title && title[0] ? title : "Save File")];
        cocoa_apply_file_type(panel, extension);
        NSString* suggested = cocoa_string(suggested_name && suggested_name[0]
                                          ? suggested_name : "untitled");
        if (suggested) [panel setNameFieldStringValue:suggested];
        cocoa_activate_app();

        if ([panel runModal] != NSModalResponseOK) return false;
        NSURL* url = [panel URL];
        const char* path = url ? [[url path] UTF8String] : NULL;
        if (!path || !path[0]) return false;
        cocoa_copy(out_path, out_capacity, path);
        cocoa_ensure_extension(out_path, out_capacity, extension);
        return out_path[0] != '\0';
    }
}

editor_host_unsaved_choice editor_host_confirm_unsaved(editor_host* host,
                                                       const char* title,
                                                       const char* message) {
    (void)host;
    @autoreleasepool {
        NSString* alert_title = cocoa_string(title && title[0] ? title : "ZCSR Editor");
        NSString* alert_message = cocoa_string(message && message[0]
                                              ? message : "Unsaved changes.");
        if (!alert_title) alert_title = @"ZCSR Editor";
        if (!alert_message) alert_message = @"Unsaved changes.";

        NSAlert* alert = [[NSAlert alloc] init];
        if (!alert) return EDITOR_HOST_UNSAVED_CANCEL;
        [alert setMessageText:alert_title];
        [alert setInformativeText:alert_message];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert addButtonWithTitle:@"Save"];
        [alert addButtonWithTitle:@"Discard"];
        [alert addButtonWithTitle:@"Cancel"];
        cocoa_activate_app();

        NSInteger response = [alert runModal];
#if !__has_feature(objc_arc)
        [alert release];
#endif
        if (response == NSAlertFirstButtonReturn) return EDITOR_HOST_UNSAVED_SAVE;
        if (response == NSAlertSecondButtonReturn) return EDITOR_HOST_UNSAVED_DISCARD;
        return EDITOR_HOST_UNSAVED_CANCEL;
    }
}
