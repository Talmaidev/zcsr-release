#include "ui_editor_viewport_host.h"
#include "ui_editor_workspace.h"
#include <string.h>

static bool vh_ops_valid(const uim_EditorViewportHostOps *ops)
{
    return ops && ops->abi_version == uim_EDITOR_VIEWPORT_HOST_ABI_VERSION &&
           ops->struct_size >= sizeof(*ops) &&
           ops->create_viewport && ops->set_rect && ops->set_mode &&
           ops->set_visible && ops->set_focus && ops->set_input_route &&
           ops->process_input && ops->render && ops->destroy_viewport;
}

uim_Result uir_editor_viewport_host_init(uim_EditorViewportHost *host,
                                         const uim_EditorViewportHostOps *ops,
                                         void *user)
{
    if (!host || !vh_ops_valid(ops)) return uim_ERR_ARGUMENT;
    memset(host, 0, sizeof(*host));
    host->ops = *ops;
    host->user = user;
    host->state = uim_EDITOR_VIEWPORT_EMPTY;
    host->mode = uim_WORKSPACE_VIEW_SCENE;
    host->input_route = uim_EDITOR_VIEWPORT_INPUT_NONE;
    return uim_OK;
}

static uim_Result vh_ensure(uim_EditorViewportHost *host)
{
    uim_Result rc;
    if (!host->token) {
        rc = host->ops.create_viewport(host->user, &host->token, &host->generation);
        if (rc != uim_OK) { host->token = 0; return rc; }
        if (!host->token) return uim_ERR_STATE;
        host->state = uim_EDITOR_VIEWPORT_CREATED;
    }
    return uim_OK;
}

uim_Result uir_editor_viewport_host_sync(uim_EditorViewportHost *host,
                                         const uim_Workspace *workspace,
                                         const uim_WorkspaceFrame *frame,
                                         bool center_visible)
{
    uim_Rect rect;
    uim_WorkspaceViewportMode mode;
    uim_Result rc;
    if (!host || !workspace || !frame) return uim_ERR_ARGUMENT;
    rc = vh_ensure(host);
    if (rc != uim_OK) return rc;
    if (!center_visible || uim_workspace_get_center_host_rect(workspace, frame, &rect, &mode) != uim_OK) {
        if (host->visible) {
            rc = host->ops.set_visible(host->user, host->token, host->generation, false);
            if (rc != uim_OK) return rc;
            host->visible = false;
        }
        host->state = uim_EDITOR_VIEWPORT_CREATED;
        return uim_OK;
    }
    if (!host->rect_valid || memcmp(&host->applied_rect, &rect, sizeof(rect)) != 0) {
        rc = host->ops.set_rect(host->user, host->token, host->generation, rect);
        if (rc != uim_OK) return rc;
        host->applied_rect = rect;
        host->rect_valid = true;
    }
    if (!host->mode_valid || host->mode != mode) {
        rc = host->ops.set_mode(host->user, host->token, host->generation, mode);
        if (rc != uim_OK) return rc;
        host->mode = mode;
        host->mode_valid = true;
    }
    if (!host->visible) {
        rc = host->ops.set_visible(host->user, host->token, host->generation, true);
        if (rc != uim_OK) return rc;
        host->visible = true;
    }
    if (host->input_route != uim_EDITOR_VIEWPORT_INPUT_EDITOR) {
        rc = host->ops.set_input_route(host->user, host->token, host->generation,
                                       uim_EDITOR_VIEWPORT_INPUT_EDITOR);
        if (rc != uim_OK) return rc;
        host->input_route = uim_EDITOR_VIEWPORT_INPUT_EDITOR;
    }
    host->state = uim_EDITOR_VIEWPORT_VISIBLE;
    return uim_OK;
}

uim_Result uir_editor_viewport_host_set_focus(uim_EditorViewportHost *host,
                                               bool focused)
{
    uim_Result rc;
    if (!host) return uim_ERR_ARGUMENT;
    if (host->focused == focused) return uim_OK;
    rc = vh_ensure(host);
    if (rc != uim_OK) return rc;
    rc = host->ops.set_focus(host->user, host->token, host->generation, focused);
    if (rc != uim_OK) return rc;
    host->focused = focused;
    return uim_OK;
}

uim_Result uir_editor_viewport_host_process_input(uim_EditorViewportHost *host,
                                                   const uim_EditorViewportInput *input)
{
    uim_Result rc;
    if (!host || !input) return uim_ERR_ARGUMENT;
    if (host->state != uim_EDITOR_VIEWPORT_VISIBLE) return uim_ERR_STATE;
    if (host->input_route != uim_EDITOR_VIEWPORT_INPUT_EDITOR) return uim_ERR_STATE;
    if (input->text && input->text_size > 0 && !input->text) return uim_ERR_ARGUMENT;
    rc = host->ops.process_input(host->user, host->token, host->generation, input);
    return rc;
}

uim_Result uir_editor_viewport_host_render(uim_EditorViewportHost *host,
                                            void *renderer_context)
{
    if (!host) return uim_ERR_ARGUMENT;
    if (host->state != uim_EDITOR_VIEWPORT_VISIBLE) return uim_ERR_STATE;
    return host->ops.render(host->user, host->token, host->generation, renderer_context,
                            host->applied_rect, host->mode);
}

void uir_editor_viewport_host_destroy(uim_EditorViewportHost *host)
{
    if (!host || !host->token) return;
    host->ops.destroy_viewport(host->user, host->token, host->generation);
    host->token = 0;
    host->generation = 0;
    host->state = uim_EDITOR_VIEWPORT_EMPTY;
    host->visible = false;
    host->focused = false;
    host->rect_valid = false;
    host->mode_valid = false;
}
