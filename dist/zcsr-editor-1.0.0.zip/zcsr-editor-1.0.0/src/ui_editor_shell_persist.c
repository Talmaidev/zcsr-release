#include "ui_editor_shell_persist.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define PERSIST_MAGIC 0x5A435352u /* "ZCSR" */
#define PERSIST_HEADER 36u
#define PERSIST_NODE_BYTES 74u
#define PERSIST_FLOAT_BYTES 28u

typedef struct PersistHeader {
    uint32_t magic;
    uint16_t major;
    uint16_t minor;
    uint32_t node_count;
    uint32_t root;
    uint32_t viewport_mode;
    uint32_t revision;
    float width;
    float height;
    uint32_t crc;
} PersistHeader;

static uint32_t crc32_bytes(const void *data, size_t size)
{
    const uint8_t *p = (const uint8_t *)data;
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < size; ++i) {
        crc ^= p[i];
        for (int b = 0; b < 8; ++b)
            crc = (crc >> 1) ^ (0xEDB88320u & (uint32_t)(-(int32_t)(crc & 1u)));
    }
    return ~crc;
}

size_t uir_editor_shell_layout_serialized_size(void)
{
    return PERSIST_HEADER +
           PERSIST_NODE_BYTES * (size_t)uim_WORKSPACE_MAX_NODES +
           PERSIST_FLOAT_BYTES * (size_t)uim_EDITOR_SHELL_MAX_FLOATING;
}

static void put_u32(uint8_t **p, uint32_t v)
{
    memcpy(*p, &v, 4);
    *p += 4;
}

static void put_u16(uint8_t **p, uint16_t v)
{
    memcpy(*p, &v, 2);
    *p += 2;
}

static void put_f32(uint8_t **p, float v)
{
    uint32_t u;
    memcpy(&u, &v, 4);
    put_u32(p, u);
}

static void put_node(uint8_t **p, const uim_WorkspaceNode *n)
{
    put_u32(p, (uint32_t)n->type);
    put_u16(p, n->parent);
    put_u16(p, n->child_a);
    put_u16(p, n->child_b);
    put_u32(p, (uint32_t)n->axis);
    put_f32(p, n->ratio);
    put_f32(p, n->rect.x);
    put_f32(p, n->rect.y);
    put_f32(p, n->rect.width);
    put_f32(p, n->rect.height);
    put_u32(p, n->panel_count);
    put_u32(p, n->active_index);
    for (size_t i = 0; i < uim_WORKSPACE_MAX_TABS_PER_GROUP; ++i) put_u32(p, n->panel_ids[i]);
}

uim_Result uir_editor_shell_layout_save(const uim_EditorShell *shell,
                                        void *buffer, size_t capacity,
                                        size_t *out_written)
{
    if (!shell || !buffer || !out_written) return uim_ERR_ARGUMENT;
    size_t need = uir_editor_shell_layout_serialized_size();
    if (capacity < need) return uim_ERR_BUFFER;
    memset(buffer, 0, need);
    uint8_t *base = (uint8_t *)buffer;
    uint8_t *p = base + PERSIST_HEADER;
    uint32_t node_count = 0;
    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i)
        if (shell->workspace.nodes[i].type != uim_WORKSPACE_NODE_UNUSED) node_count++;
    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i)
        put_node(&p, &shell->workspace.nodes[i]);
    for (size_t i = 0; i < uim_EDITOR_SHELL_MAX_FLOATING; ++i) {
        const uim_EditorShellFloatingPanel *f = &shell->floating[i];
        put_u32(&p, f->panel_id);
        put_f32(&p, f->rect.x);
        put_f32(&p, f->rect.y);
        put_f32(&p, f->rect.width);
        put_f32(&p, f->rect.height);
        put_u32(&p, f->z_order);
        put_u32(&p, f->open ? 1u : 0u);
    }
    uint32_t crc = crc32_bytes(base + PERSIST_HEADER, need - PERSIST_HEADER);
    PersistHeader h = {PERSIST_MAGIC, uim_EDITOR_SHELL_LAYOUT_FORMAT_MAJOR,
                       uim_EDITOR_SHELL_LAYOUT_FORMAT_MINOR, node_count,
                       shell->workspace.root, (uint32_t)shell->workspace.viewport_mode,
                       shell->layout_revision, shell->workspace.config.width,
                       shell->workspace.config.height, crc};
    memcpy(base, &h, PERSIST_HEADER);
    *out_written = need;
    return uim_OK;
}

static uint32_t get_u32(const uint8_t **p)
{
    uint32_t v;
    memcpy(&v, *p, 4);
    *p += 4;
    return v;
}

static uint16_t get_u16(const uint8_t **p)
{
    uint16_t v;
    memcpy(&v, *p, 2);
    *p += 2;
    return v;
}

static float get_f32(const uint8_t **p)
{
    uint32_t u = get_u32(p);
    float f;
    memcpy(&f, &u, 4);
    return f;
}

uim_Result uir_editor_shell_layout_load(uim_EditorShell *shell,
                                        const void *buffer, size_t size)
{
    if (!shell || !buffer) return uim_ERR_ARGUMENT;
    if (size != uir_editor_shell_layout_serialized_size()) return uim_ERR_ARGUMENT;
    PersistHeader h;
    memcpy(&h, buffer, PERSIST_HEADER);
    if (h.magic != PERSIST_MAGIC || h.major != uim_EDITOR_SHELL_LAYOUT_FORMAT_MAJOR ||
        h.minor > uim_EDITOR_SHELL_LAYOUT_FORMAT_MINOR || h.node_count > uim_WORKSPACE_MAX_NODES ||
        (h.root != uim_WORKSPACE_NODE_INVALID && h.root >= uim_WORKSPACE_MAX_NODES) ||
        h.viewport_mode > uim_WORKSPACE_VIEW_GAME ||
        !isfinite(h.width) || !isfinite(h.height) || h.width <= 0.0f || h.height <= 0.0f)
        return uim_ERR_STATE;
    uint32_t crc = crc32_bytes((const uint8_t *)buffer + PERSIST_HEADER, size - PERSIST_HEADER);
    if (crc != h.crc) return uim_ERR_STATE;
    const uint8_t *p = (const uint8_t *)buffer + PERSIST_HEADER;
    for (size_t i = 0; i < uim_WORKSPACE_MAX_NODES; ++i) {
        uim_WorkspaceNode *n = &shell->workspace.nodes[i];
        n->type = (uim_WorkspaceNodeType)get_u32(&p);
        n->parent = get_u16(&p);
        n->child_a = get_u16(&p);
        n->child_b = get_u16(&p);
        n->axis = (uim_WorkspaceAxis)get_u32(&p);
        n->ratio = get_f32(&p);
        n->rect.x = get_f32(&p);
        n->rect.y = get_f32(&p);
        n->rect.width = get_f32(&p);
        n->rect.height = get_f32(&p);
        n->panel_count = (uint8_t)get_u32(&p);
        n->active_index = (uint8_t)get_u32(&p);
        for (size_t j = 0; j < uim_WORKSPACE_MAX_TABS_PER_GROUP; ++j) n->panel_ids[j] = get_u32(&p);
        if (n->type > uim_WORKSPACE_NODE_TABS || n->panel_count > uim_WORKSPACE_MAX_TABS_PER_GROUP ||
            (n->panel_count && n->active_index >= n->panel_count)) return uim_ERR_STATE;
    }
    for (size_t i = 0; i < uim_EDITOR_SHELL_MAX_FLOATING; ++i) {
        uim_EditorShellFloatingPanel *f = &shell->floating[i];
        f->panel_id = get_u32(&p);
        f->rect.x = get_f32(&p);
        f->rect.y = get_f32(&p);
        f->rect.width = get_f32(&p);
        f->rect.height = get_f32(&p);
        f->z_order = (uint16_t)get_u32(&p);
        f->open = get_u32(&p) != 0;
    }
    shell->workspace.root = (uim_WorkspaceNodeId)h.root;
    shell->workspace.viewport_mode = (uim_WorkspaceViewportMode)h.viewport_mode;
    shell->workspace.config.width = h.width;
    shell->workspace.config.height = h.height;
    shell->floating_count = 0;
    for (size_t i = 0; i < uim_EDITOR_SHELL_MAX_FLOATING; ++i)
        if (shell->floating[i].open || shell->floating[i].panel_id) shell->floating_count = i + 1;
    shell->layout_revision = h.revision;
    return uim_OK;
}
