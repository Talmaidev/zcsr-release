#include "ui_editor_file_service_host.h"
#include <stdlib.h>
#include <string.h>

#define FS_MAX_BASE 512u
#define FS_MAX_PATH 1024u
#define FS_MAX_HANDLES 32u

typedef struct FsEntry {
    bool used;
    bool directory;
    bool writing;
    uim_FileHandle handle;
    zcsr_file_t *file;
    zcsr_dir_t *dir;
    char target[FS_MAX_PATH];
    char temp[FS_MAX_PATH];
} FsEntry;

typedef struct ZcsrAdapter {
    zcsr_file_service_t *zfs;
    char base[FS_MAX_BASE];
    FsEntry entries[FS_MAX_HANDLES];
    uint32_t serial;
} ZcsrAdapter;

static ZcsrAdapter *adapter_of(uim_FileService *service)
{
    return service && service->user ? (ZcsrAdapter *)service->user : NULL;
}

static bool is_absolute_or_uri(const char *path)
{
    if (!path) return false;
    if (strstr(path, "://")) return true;
    if (path[0] == '/' || path[0] == '\\') return true;
    if (path[0] && path[1] == ':') return true;
    return false;
}

static bool resolve_path(ZcsrAdapter *a, const char *path, char *out, size_t cap)
{
    if (!path || !out || !cap) return false;
    if (is_absolute_or_uri(path) || !a->base[0]) {
        size_t n = strlen(path);
        if (n >= cap) return false;
        memcpy(out, path, n + 1);
        return true;
    }
    size_t blen = strlen(a->base);
    size_t plen = strlen(path);
    bool slash = blen > 0 && a->base[blen - 1] != '/' && a->base[blen - 1] != '\\';
    if (blen + (slash ? 1u : 0u) + plen >= cap) return false;
    memcpy(out, a->base, blen);
    if (slash) out[blen++] = '/';
    memcpy(out + blen, path, plen + 1);
    return true;
}

static FsEntry *entry_alloc(ZcsrAdapter *a, uim_FileHandle *out)
{
    for (size_t i = 0; i < FS_MAX_HANDLES; ++i) {
        if (!a->entries[i].used) {
            memset(&a->entries[i], 0, sizeof(a->entries[i]));
            a->entries[i].used = true;
            a->entries[i].handle = (uim_FileHandle)(i + 1);
            *out = a->entries[i].handle;
            return &a->entries[i];
        }
    }
    return NULL;
}

static FsEntry *entry_of(ZcsrAdapter *a, uim_FileHandle handle)
{
    if (!a || !handle || handle > FS_MAX_HANDLES) return NULL;
    FsEntry *e = &a->entries[handle - 1];
    return e->used ? e : NULL;
}

static uim_FileResult map_result(zcsr_file_result_t rc)
{
    switch (rc) {
    case ZCSR_FILE_OK: return uim_FILE_OK;
    case ZCSR_FILE_END: return uim_FILE_END;
    case ZCSR_FILE_ERR_ARGUMENT: return uim_FILE_ERR_ARGUMENT;
    case ZCSR_FILE_ERR_NOT_FOUND: return uim_FILE_ERR_NOT_FOUND;
    case ZCSR_FILE_ERR_ALREADY_EXISTS: return uim_FILE_ERR_ALREADY_EXISTS;
    case ZCSR_FILE_ERR_ACCESS: return uim_FILE_ERR_ACCESS;
    case ZCSR_FILE_ERR_IO: return uim_FILE_ERR_IO;
    case ZCSR_FILE_ERR_NO_SPACE: return uim_FILE_ERR_NO_SPACE;
    case ZCSR_FILE_ERR_NOT_DIRECTORY: return uim_FILE_ERR_NOT_DIRECTORY;
    case ZCSR_FILE_ERR_IS_DIRECTORY: return uim_FILE_ERR_IS_DIRECTORY;
    case ZCSR_FILE_ERR_UNSUPPORTED: return uim_FILE_ERR_UNSUPPORTED;
    default: return uim_FILE_ERR_INTERNAL;
    }
}

static uim_FileResult fs_stat(void *user, const char *utf8_path, uim_FileStat *out_stat)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char path[FS_MAX_PATH];
    zcsr_file_stat_t st;
    if (!a || !utf8_path || !out_stat || !resolve_path(a, utf8_path, path, sizeof(path)))
        return uim_FILE_ERR_ARGUMENT;
    zcsr_file_result_t rc = zcsr_file_stat(a->zfs, path, &st);
    if (rc != ZCSR_FILE_OK) return map_result(rc);
    memset(out_stat, 0, sizeof(*out_stat));
    out_stat->struct_size = sizeof(*out_stat);
    out_stat->kind = st.kind == ZCSR_FILE_KIND_DIRECTORY ? uim_FILE_KIND_DIRECTORY
                  : st.kind == ZCSR_FILE_KIND_REGULAR ? uim_FILE_KIND_REGULAR
                                                     : uim_FILE_KIND_UNKNOWN;
    out_stat->size_bytes = st.size_bytes;
    out_stat->modified_time_unix_ns = st.modified_time_unix_ns;
    return uim_FILE_OK;
}

static uim_FileResult fs_directory_open(void *user, const char *utf8_path,
                                        uim_DirectoryHandle *out_handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char path[FS_MAX_PATH];
    zcsr_dir_t *dir = NULL;
    if (!a || !utf8_path || !out_handle || !resolve_path(a, utf8_path, path, sizeof(path)))
        return uim_FILE_ERR_ARGUMENT;
    zcsr_file_result_t rc = zcsr_dir_open(a->zfs, path, &dir);
    if (rc != ZCSR_FILE_OK || !dir) return map_result(rc == ZCSR_FILE_OK ? ZCSR_FILE_ERR_IO : rc);
    uim_FileHandle handle;
    FsEntry *e = entry_alloc(a, &handle);
    if (!e) { zcsr_dir_close(a->zfs, dir); return uim_FILE_ERR_TOO_MANY_OPEN; }
    e->directory = true;
    e->dir = dir;
    *out_handle = handle;
    return uim_FILE_OK;
}

static uim_FileResult fs_directory_next(void *user, uim_DirectoryHandle handle,
                                        uim_DirectoryEntry *out_entry,
                                        char *name_buffer, size_t name_capacity)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    zcsr_dir_entry_t entry;
    if (!e || !e->directory || !out_entry || !name_buffer || !name_capacity)
        return uim_FILE_ERR_ARGUMENT;
    zcsr_file_result_t rc = zcsr_dir_next(a->zfs, e->dir, &entry);
    if (rc != ZCSR_FILE_OK) return map_result(rc);
    size_t n = entry.name ? strlen(entry.name) : 0;
    if (n >= name_capacity) {
        out_entry->name_bytes = (uint32_t)n;
        return uim_FILE_ERR_BUFFER_TOO_SMALL;
    }
    memcpy(name_buffer, entry.name ? entry.name : "", n + 1);
    memset(out_entry, 0, sizeof(*out_entry));
    out_entry->struct_size = sizeof(*out_entry);
    out_entry->kind = entry.kind == ZCSR_FILE_KIND_DIRECTORY ? uim_FILE_KIND_DIRECTORY
                    : entry.kind == ZCSR_FILE_KIND_REGULAR ? uim_FILE_KIND_REGULAR
                                                           : uim_FILE_KIND_UNKNOWN;
    out_entry->size_bytes = entry.size_bytes;
    out_entry->modified_time_unix_ns = entry.modified_time_unix_ns;
    out_entry->name_bytes = (uint32_t)n;
    return uim_FILE_OK;
}

static uim_FileResult fs_directory_close(void *user, uim_DirectoryHandle handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    if (!e || !e->directory) return uim_FILE_ERR_STALE_HANDLE;
    zcsr_file_result_t rc = zcsr_dir_close(a->zfs, e->dir);
    memset(e, 0, sizeof(*e));
    return map_result(rc);
}

static uim_FileResult fs_create_directory(void *user, const char *utf8_path)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char path[FS_MAX_PATH];
    if (!a || !utf8_path || !resolve_path(a, utf8_path, path, sizeof(path)))
        return uim_FILE_ERR_ARGUMENT;
    return map_result(zcsr_dir_create(a->zfs, path));
}

static uim_FileResult fs_remove_file(void *user, const char *utf8_path)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char path[FS_MAX_PATH];
    if (!a || !utf8_path || !resolve_path(a, utf8_path, path, sizeof(path)))
        return uim_FILE_ERR_ARGUMENT;
    return map_result(zcsr_file_delete(a->zfs, path));
}

static uim_FileResult fs_remove_directory(void *user, const char *utf8_path)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char path[FS_MAX_PATH];
    if (!a || !utf8_path || !resolve_path(a, utf8_path, path, sizeof(path)))
        return uim_FILE_ERR_ARGUMENT;
    return map_result(zcsr_dir_delete(a->zfs, path));
}

static uim_FileResult fs_rename(void *user, const char *from, const char *to)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char from_path[FS_MAX_PATH], to_path[FS_MAX_PATH];
    if (!a || !from || !to ||
        !resolve_path(a, from, from_path, sizeof(from_path)) ||
        !resolve_path(a, to, to_path, sizeof(to_path)))
        return uim_FILE_ERR_ARGUMENT;
    return map_result(zcsr_file_rename(a->zfs, from_path, to_path));
}

static uim_FileResult fs_open_read(void *user, const char *utf8_path,
                                   uim_FileHandle *out_handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char path[FS_MAX_PATH];
    zcsr_file_t *file = NULL;
    if (!a || !utf8_path || !out_handle || !resolve_path(a, utf8_path, path, sizeof(path)))
        return uim_FILE_ERR_ARGUMENT;
    zcsr_file_result_t rc = zcsr_file_open_read(a->zfs, path, &file);
    if (rc != ZCSR_FILE_OK || !file) return map_result(rc == ZCSR_FILE_OK ? ZCSR_FILE_ERR_IO : rc);
    FsEntry *e = entry_alloc(a, out_handle);
    if (!e) { zcsr_file_close(a->zfs, file); return uim_FILE_ERR_TOO_MANY_OPEN; }
    e->file = file;
    return uim_FILE_OK;
}

static uim_FileResult fs_open_write_atomic(void *user, const char *utf8_target,
                                           uim_FileHandle *out_handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    char target[FS_MAX_PATH], temp[FS_MAX_PATH];
    if (!a || !utf8_target || !out_handle ||
        !resolve_path(a, utf8_target, target, sizeof(target)))
        return uim_FILE_ERR_ARGUMENT;
    a->serial++;
    size_t tn = strlen(target);
    if (tn + 24 >= sizeof(temp)) return uim_FILE_ERR_ARGUMENT;
    memcpy(temp, target, tn);
    temp[tn] = '.';
    temp[tn + 1] = 'z';
    temp[tn + 2] = 'c';
    temp[tn + 3] = 's';
    temp[tn + 4] = 'r';
    temp[tn + 5] = 't';
    temp[tn + 6] = 'm';
    temp[tn + 7] = 'p';
    temp[tn + 8] = 0;
    char suffix[16];
    size_t sn = 0;
    uint32_t v = a->serial;
    do { suffix[sn++] = (char)('0' + (v % 10)); v /= 10; } while (v && sn < 15);
    suffix[sn] = 0;
    memcpy(temp + tn + 8, suffix, sn + 1);
    zcsr_file_t *file = NULL;
    zcsr_file_result_t rc = zcsr_file_open_write(a->zfs, temp, &file);
    if (rc != ZCSR_FILE_OK || !file) return map_result(rc == ZCSR_FILE_OK ? ZCSR_FILE_ERR_IO : rc);
    FsEntry *e = entry_alloc(a, out_handle);
    if (!e) { zcsr_file_close(a->zfs, file); zcsr_file_delete(a->zfs, temp); return uim_FILE_ERR_TOO_MANY_OPEN; }
    e->file = file;
    e->writing = true;
    memcpy(e->target, target, strlen(target) + 1);
    memcpy(e->temp, temp, strlen(temp) + 1);
    return uim_FILE_OK;
}

static uim_FileResult fs_read(void *user, uim_FileHandle handle, void *buffer,
                              size_t capacity, size_t *out_bytes_read)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    if (!e || e->directory || !e->file || !out_bytes_read) return uim_FILE_ERR_ARGUMENT;
    return map_result(zcsr_file_read(a->zfs, e->file, buffer, capacity, out_bytes_read));
}

static uim_FileResult fs_write(void *user, uim_FileHandle handle,
                               const void *data, size_t size, size_t *out_bytes_written)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    if (!e || !e->writing || !e->file || !out_bytes_written) return uim_FILE_ERR_ARGUMENT;
    return map_result(zcsr_file_write(a->zfs, e->file, data, size, out_bytes_written));
}

static uim_FileResult fs_seek(void *user, uim_FileHandle handle, int64_t offset,
                              uim_FileSeekOrigin origin, uint64_t *out_position)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    zcsr_file_seek_origin_t zorigin;
    if (!e || e->directory || !e->file || !out_position) return uim_FILE_ERR_ARGUMENT;
    switch (origin) {
    case uim_FILE_SEEK_BEGIN: zorigin = ZCSR_FILE_SEEK_BEGIN; break;
    case uim_FILE_SEEK_CURRENT: zorigin = ZCSR_FILE_SEEK_CURRENT; break;
    case uim_FILE_SEEK_END: zorigin = ZCSR_FILE_SEEK_END; break;
    default: return uim_FILE_ERR_ARGUMENT;
    }
    return map_result(zcsr_file_seek(a->zfs, e->file, offset, zorigin, out_position));
}

static uim_FileResult fs_flush(void *user, uim_FileHandle handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    if (!e || e->directory || !e->file) return uim_FILE_ERR_ARGUMENT;
    /* The ZCSR v1 file ABI has no explicit flush; close/commit flushes. */
    return uim_FILE_OK;
}

static uim_FileResult fs_commit_atomic(void *user, uim_FileHandle handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    if (!e || !e->writing || !e->file) return uim_FILE_ERR_STALE_HANDLE;
    zcsr_file_result_t rc = zcsr_file_close(a->zfs, e->file);
    e->file = NULL;
    if (rc != ZCSR_FILE_OK) {
        (void)zcsr_file_delete(a->zfs, e->temp);
        memset(e, 0, sizeof(*e));
        return map_result(rc);
    }
    rc = zcsr_file_rename(a->zfs, e->temp, e->target);
    memset(e, 0, sizeof(*e));
    return map_result(rc);
}

static uim_FileResult fs_abort_atomic(void *user, uim_FileHandle handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    if (!e || !e->writing) return uim_FILE_ERR_STALE_HANDLE;
    if (e->file) (void)zcsr_file_close(a->zfs, e->file);
    zcsr_file_result_t rc = zcsr_file_delete(a->zfs, e->temp);
    memset(e, 0, sizeof(*e));
    return rc == ZCSR_FILE_ERR_NOT_FOUND ? uim_FILE_OK : map_result(rc);
}

static uim_FileResult fs_close(void *user, uim_FileHandle handle)
{
    ZcsrAdapter *a = (ZcsrAdapter *)user;
    FsEntry *e = entry_of(a, handle);
    if (!e) return uim_FILE_ERR_STALE_HANDLE;
    if (e->directory) return fs_directory_close(user, handle);
    if (e->writing) return fs_abort_atomic(user, handle);
    zcsr_file_result_t rc = e->file ? zcsr_file_close(a->zfs, e->file) : ZCSR_FILE_OK;
    memset(e, 0, sizeof(*e));
    return map_result(rc);
}

uim_FileResult uim_file_service_create_from_zcsr(zcsr_file_service_t *zfs,
                                                   uim_FileService *out_service)
{
    if (!zfs || !out_service) return uim_FILE_ERR_ARGUMENT;
    ZcsrAdapter *a = (ZcsrAdapter *)calloc(1, sizeof(*a));
    if (!a) return uim_FILE_ERR_INTERNAL;
    a->zfs = zfs;
    memset(out_service, 0, sizeof(*out_service));
    out_service->abi_version = uim_FILE_SERVICE_ABI_VERSION;
    out_service->struct_size = sizeof(*out_service);
    out_service->user = a;
    out_service->ops.stat_path = fs_stat;
    out_service->ops.directory_open = fs_directory_open;
    out_service->ops.directory_next = fs_directory_next;
    out_service->ops.directory_close = fs_directory_close;
    out_service->ops.create_directory = fs_create_directory;
    out_service->ops.remove_file = fs_remove_file;
    out_service->ops.remove_directory = fs_remove_directory;
    out_service->ops.rename_path = fs_rename;
    out_service->ops.open_read = fs_open_read;
    out_service->ops.open_write_atomic = fs_open_write_atomic;
    out_service->ops.read = fs_read;
    out_service->ops.write = fs_write;
    out_service->ops.seek = fs_seek;
    out_service->ops.flush = fs_flush;
    out_service->ops.commit_atomic = fs_commit_atomic;
    out_service->ops.abort_atomic = fs_abort_atomic;
    out_service->ops.close = fs_close;
    return uim_FILE_OK;
}

uim_FileResult uim_file_service_set_base_path(uim_FileService *service,
                                               const char *utf8_base_path)
{
    ZcsrAdapter *a = adapter_of(service);
    if (!a || !utf8_base_path) return uim_FILE_ERR_ARGUMENT;
    if (strlen(utf8_base_path) >= sizeof(a->base)) return uim_FILE_ERR_ARGUMENT;
    size_t n = strlen(utf8_base_path);
    memcpy(a->base, utf8_base_path, n + 1);
    while (n > 1 && (a->base[n - 1] == '/' || a->base[n - 1] == '\\')) a->base[--n] = 0;
    return uim_FILE_OK;
}

void uim_file_service_destroy(uim_FileService *service)
{
    ZcsrAdapter *a = adapter_of(service);
    if (!a) return;
    for (size_t i = 0; i < FS_MAX_HANDLES; ++i) {
        FsEntry *e = &a->entries[i];
        if (!e->used) continue;
        if (e->directory) (void)zcsr_dir_close(a->zfs, e->dir);
        else if (e->file) (void)zcsr_file_close(a->zfs, e->file);
        if (e->writing) (void)zcsr_file_delete(a->zfs, e->temp);
    }
    free(a);
    memset(service, 0, sizeof(*service));
}
