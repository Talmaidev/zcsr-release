/* editor_host_posix.c — POSIX process/executable backend shared by Linux and
 * macOS. Linux file dialogs are implemented here; macOS overrides only the
 * three dialog/confirm entries in editor_host_cocoa.m with native Cocoa
 * panels. No OS window is created here; the runtime shell still owns the
 * only window and main loop. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>

#if defined(__APPLE__)
#include <mach-o/dyld.h>
#endif

#include "editor_host.h"
#include "zcsr/platform.h"

struct editor_host {
    int unused;
};

static void host_copy(char* out, size_t capacity, const char* text) {
    if (!out || capacity == 0) return;
    if (!text) {
        out[0] = '\0';
        return;
    }
    size_t n = strlen(text);
    if (n >= capacity) n = capacity - 1;
    memcpy(out, text, n);
    out[n] = '\0';
}

#if !defined(__APPLE__)
static void host_trim_newline(char* text) {
    if (!text) return;
    size_t n = strlen(text);
    while (n > 0 && (text[n - 1] == '\n' || text[n - 1] == '\r' || text[n - 1] == ' ')) {
        text[--n] = '\0';
    }
}

static void host_ensure_extension(char* path, size_t capacity, const char* extension) {
    if (!path || !path[0] || !extension || !extension[0]) return;
    const char* base = strrchr(path, '/');
    base = base ? base + 1 : path;
    if (strrchr(base, '.')) return;
    size_t n = strlen(path);
    size_t e = strlen(extension);
    if (n + e + 2 > capacity) return;
    path[n++] = '.';
    memcpy(path + n, extension, e + 1);
}
#endif /* !__APPLE__: Linux dialog helpers. */

static char* host_shell_quote(const char* text) {
    if (!text) text = "";
    size_t n = strlen(text);
    size_t out_cap = n * 4 + 3;
    char* out = (char*)malloc(out_cap);
    if (!out) return NULL;
    size_t at = 0;
    out[at++] = '\'';
    for (size_t i = 0; i < n; ++i) {
        if (text[i] == '\'') {
            out[at++] = '\'';
            out[at++] = '\\';
            out[at++] = '\'';
            out[at++] = '\'';
        } else {
            out[at++] = text[i];
        }
    }
    out[at++] = '\'';
    out[at] = '\0';
    return out;
}

static bool host_capture(const char* command, char* output, size_t output_capacity, int* out_status) {
    if (output && output_capacity) output[0] = '\0';
    if (out_status) *out_status = 1;
    FILE* pipe = popen(command, "r");
    if (!pipe) return false;
    size_t used = 0;
    char buffer[4096];
    size_t n = 0;
    while ((n = fread(buffer, 1, sizeof(buffer), pipe)) > 0) {
        if (output && used + 1 < output_capacity) {
            size_t room = output_capacity - used - 1;
            size_t copy = n < room ? n : room;
            memcpy(output + used, buffer, copy);
            used += copy;
            output[used] = '\0';
        }
    }
    int status = pclose(pipe);
    int exit_code = 1;
    if (status >= 0) {
        if (WIFEXITED(status)) exit_code = WEXITSTATUS(status);
        else if (WIFSIGNALED(status)) exit_code = 128 + WTERMSIG(status);
    }
    if (out_status) *out_status = exit_code;
    return true;
}

static bool host_existing_path(char* out, size_t capacity) {
    if (!out || capacity == 0) return false;
#if defined(__APPLE__)
    char raw[4096];
    uint32_t size = (uint32_t)sizeof(raw);
    if (_NSGetExecutablePath(raw, &size) != 0) return false;
    host_copy(out, capacity, raw);
    return true;
#else
    char raw[4096];
    ssize_t n = readlink("/proc/self/exe", raw, sizeof(raw) - 1);
    if (n <= 0) return false;
    raw[n] = '\0';
    host_copy(out, capacity, raw);
    return true;
#endif
}

#if !defined(__APPLE__)
static bool host_linux_open(const char* title, const char* extension,
                            char* out_path, size_t out_capacity) {
    char filter[160];
    if (extension && extension[0]) {
        snprintf(filter, sizeof(filter), "ZCSR Files (*.%s) | *.%s", extension, extension);
    } else {
        snprintf(filter, sizeof(filter), "All Files | *");
    }
    char* q_title = host_shell_quote(title ? title : "Open File");
    char* q_filter = host_shell_quote(filter);
    if (!q_title || !q_filter) {
        free(q_title);
        free(q_filter);
        return false;
    }
    char command[4096];
    snprintf(command, sizeof(command),
             "zenity --file-selection --title=%s --file-filter=%s 2>/dev/null",
             q_title, q_filter);
    int status = 1;
    host_capture(command, out_path, out_capacity, &status);
    if (status == 0) {
        host_trim_newline(out_path);
        free(q_title);
        free(q_filter);
        return out_path[0] != '\0';
    }
    if (status == 1 || status == 5) {
        free(q_title);
        free(q_filter);
        return false;
    }
    snprintf(command, sizeof(command),
             "kdialog --getopenfilename \"$HOME\" %s 2>/dev/null",
             q_filter);
    host_capture(command, out_path, out_capacity, &status);
    free(q_title);
    free(q_filter);
    if (status != 0) return false;
    host_trim_newline(out_path);
    return out_path[0] != '\0';
}

static bool host_linux_save(const char* title, const char* extension, const char* suggested,
                            char* out_path, size_t out_capacity) {
    char filter[160];
    if (extension && extension[0]) {
        snprintf(filter, sizeof(filter), "ZCSR Files (*.%s) | *.%s", extension, extension);
    } else {
        snprintf(filter, sizeof(filter), "All Files | *");
    }
    char* q_title = host_shell_quote(title ? title : "Save File");
    char* q_name = host_shell_quote(suggested ? suggested : "");
    char* q_filter = host_shell_quote(filter);
    if (!q_title || !q_name || !q_filter) {
        free(q_title);
        free(q_name);
        free(q_filter);
        return false;
    }
    char command[4096];
    snprintf(command, sizeof(command),
             "zenity --file-selection --save --confirm-overwrite --title=%s --filename=%s --file-filter=%s 2>/dev/null",
             q_title, q_name, q_filter);
    int status = 1;
    host_capture(command, out_path, out_capacity, &status);
    if (status == 0) {
        host_trim_newline(out_path);
        host_ensure_extension(out_path, out_capacity, extension);
        free(q_title);
        free(q_name);
        free(q_filter);
        return out_path[0] != '\0';
    }
    if (status == 1 || status == 5) {
        free(q_title);
        free(q_name);
        free(q_filter);
        return false;
    }
    snprintf(command, sizeof(command),
             "kdialog --getsavefilename \"$HOME\" %s 2>/dev/null",
             q_filter);
    host_capture(command, out_path, out_capacity, &status);
    free(q_title);
    free(q_name);
    free(q_filter);
    if (status != 0) return false;
    host_trim_newline(out_path);
    host_ensure_extension(out_path, out_capacity, extension);
    return out_path[0] != '\0';
}
#endif /* !__APPLE__ */

editor_host* editor_host_create(zcsr_surface* surface) {
    (void)surface;
    editor_host* host = (editor_host*)calloc(1, sizeof(*host));
    if (!host) return NULL;
    return host;
}

void editor_host_destroy(editor_host* host) {
    free(host);
}

#if !defined(__APPLE__)
bool editor_host_open_file(editor_host* host, const char* title, const char* extension,
                           char* out_path, size_t out_capacity) {
    (void)host;
    if (!out_path || out_capacity == 0) return false;
    return host_linux_open(title, extension, out_path, out_capacity);
}

bool editor_host_save_file(editor_host* host, const char* title, const char* extension,
                           const char* suggested_name, char* out_path, size_t out_capacity) {
    (void)host;
    if (!out_path || out_capacity == 0) return false;
    return host_linux_save(title, extension, suggested_name, out_path, out_capacity);
}

editor_host_unsaved_choice editor_host_confirm_unsaved(editor_host* host,
                                                       const char* title,
                                                       const char* message) {
    (void)host;
    char* q_title = host_shell_quote(title ? title : "ZCSR Editor");
    char* q_message = host_shell_quote(message ? message : "Unsaved changes.");
    if (!q_title || !q_message) {
        free(q_title);
        free(q_message);
        return EDITOR_HOST_UNSAVED_CANCEL;
    }
    char command[4096];
    snprintf(command, sizeof(command),
             "zenity --list --title=%s --text=%s --column=Action --column=Meaning "
             "\"Save\" \"Save and exit\" \"Discard\" \"Discard changes\" \"Cancel\" \"Stay\" 2>/dev/null",
             q_title, q_message);
    char answer[256] = {0};
    int status = 1;
    host_capture(command, answer, sizeof(answer), &status);
    if (status == 0) {
        free(q_title);
        free(q_message);
        if (strstr(answer, "Save")) return EDITOR_HOST_UNSAVED_SAVE;
        if (strstr(answer, "Discard")) return EDITOR_HOST_UNSAVED_DISCARD;
        return EDITOR_HOST_UNSAVED_CANCEL;
    }
    if (status == 1 || status == 5) {
        free(q_title);
        free(q_message);
        return EDITOR_HOST_UNSAVED_CANCEL;
    }
    snprintf(command, sizeof(command), "kdialog --yesnocancel %s 2>/dev/null", q_message);
    host_capture(command, answer, sizeof(answer), &status);
    free(q_title);
    free(q_message);
    if (status == 0) return EDITOR_HOST_UNSAVED_SAVE;
    if (status == 1) return EDITOR_HOST_UNSAVED_DISCARD;
    return EDITOR_HOST_UNSAVED_CANCEL;
}
#endif /* !__APPLE__: Cocoa owns these three entries on macOS. */

bool editor_host_executable_path(editor_host* host, char* out_path, size_t out_capacity) {
    (void)host;
    return host_existing_path(out_path, out_capacity);
}

bool editor_host_run_process(editor_host* host, const char* command, const char* working_dir,
                             char* output, size_t output_capacity, int* out_exit_code) {
    (void)host;
    if (!command) return false;
    char* q_dir = working_dir && working_dir[0] ? host_shell_quote(working_dir) : NULL;
    if (working_dir && working_dir[0] && !q_dir) return false;
    size_t cap = strlen(command) + (q_dir ? strlen(q_dir) : 0) + 32;
    char* full = (char*)malloc(cap);
    if (!full) {
        free(q_dir);
        return false;
    }
    if (q_dir) snprintf(full, cap, "cd %s && %s 2>&1", q_dir, command);
    else snprintf(full, cap, "%s 2>&1", command);
    free(q_dir);
    int status = 1;
    bool ok = host_capture(full, output, output_capacity, &status);
    free(full);
    if (out_exit_code) *out_exit_code = status;
    return ok;
}

bool editor_host_launch_process(editor_host* host, const char* command, const char* working_dir) {
    (void)host;
    if (!command) return false;
    pid_t pid = fork();
    if (pid < 0) return false;
    if (pid == 0) {
        /* Intermediate child exits immediately; the grandchild is reparented,
         * so the editor never has to wait for the launched player. */
        pid_t grandchild = fork();
        if (grandchild == 0) {
            setsid();
            if (working_dir && working_dir[0]) {
                if (chdir(working_dir) != 0) _exit(127);
            }
            execl("/bin/sh", "sh", "-c", command, (char*)NULL);
            _exit(127);
        }
        _exit(grandchild < 0 ? 127 : 0);
    }
    (void)waitpid(pid, NULL, 0);
    return true;
}