#include "editor_scene_io.h"

#include "zcsr/scene_io.h"

/* Editor-facing names over the shared engine scene IO. Keeping the wrapper in
 * the editor preserves the existing editor API/tests while the runtime player
 * uses zcsr_scene_io directly, so both sides read exactly one schema. */

static zcsr_editor_scene_io_result map_result(zcsr_scene_io_result result) {
    switch (result) {
    case ZCSR_SCENE_IO_OK: return ZCSR_EDITOR_SCENE_IO_OK;
    case ZCSR_SCENE_IO_INVALID_ARGUMENT: return ZCSR_EDITOR_SCENE_IO_INVALID_ARGUMENT;
    case ZCSR_SCENE_IO_OPEN_FAILED: return ZCSR_EDITOR_SCENE_IO_OPEN_FAILED;
    case ZCSR_SCENE_IO_BAD_HEADER: return ZCSR_EDITOR_SCENE_IO_BAD_HEADER;
    case ZCSR_SCENE_IO_BAD_RECORD: return ZCSR_EDITOR_SCENE_IO_BAD_RECORD;
    case ZCSR_SCENE_IO_CAPACITY: return ZCSR_EDITOR_SCENE_IO_CAPACITY;
    case ZCSR_SCENE_IO_IO_ERROR: return ZCSR_EDITOR_SCENE_IO_IO_ERROR;
    default: return ZCSR_EDITOR_SCENE_IO_IO_ERROR;
    }
}

zcsr_editor_scene_io_result zcsr_editor_scene_serialize(const zcsr_scene *scene,
                                                        char **out_text,
                                                        size_t *out_size) {
    return map_result(zcsr_scene_io_serialize(scene, out_text, out_size));
}

zcsr_editor_scene_io_result zcsr_editor_scene_deserialize(const char *text,
                                                          size_t size,
                                                          zcsr_scene *scene) {
    return map_result(zcsr_scene_io_deserialize(text, size, scene));
}

zcsr_editor_scene_io_result zcsr_editor_scene_save(const zcsr_scene *scene,
                                                   const char *utf8_path) {
    return map_result(zcsr_scene_io_save(scene, utf8_path));
}

zcsr_editor_scene_io_result zcsr_editor_scene_load(zcsr_scene *scene,
                                                   const char *utf8_path) {
    return map_result(zcsr_scene_io_load(scene, utf8_path));
}

const char *zcsr_editor_scene_io_result_name(
    zcsr_editor_scene_io_result result) {
    switch (result) {
    case ZCSR_EDITOR_SCENE_IO_OK: return "ok";
    case ZCSR_EDITOR_SCENE_IO_INVALID_ARGUMENT: return "invalid argument";
    case ZCSR_EDITOR_SCENE_IO_OPEN_FAILED: return "open failed";
    case ZCSR_EDITOR_SCENE_IO_BAD_HEADER: return "bad header";
    case ZCSR_EDITOR_SCENE_IO_BAD_RECORD: return "bad record";
    case ZCSR_EDITOR_SCENE_IO_CAPACITY: return "capacity";
    case ZCSR_EDITOR_SCENE_IO_IO_ERROR: return "io error";
    default: return "unknown";
    }
}
