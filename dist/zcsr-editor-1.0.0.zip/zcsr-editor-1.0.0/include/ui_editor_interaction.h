#ifndef UI_EDITOR_INTERACTION_H
#define UI_EDITOR_INTERACTION_H
/*
 * ui_editor_interaction.h — Editor 的鼠标交互状态机
 *
 * 为什么需要它：
 *   编辑器在 runtime.c 里手写「坐标落在矩形里就点击」，没有 hover、没有按下/释放
 *   的边界语义，也没有"拖动中"的概念。window_shell 那边走的是 UIM 的鼠标状态机，
 *   两条路径行为不一致，这就是 editor 鼠标"能动不能拖、看得见点不中"的结构性原因。
 *
 * 本模块只做纯 CPU 的命中与状态机，不碰 GL、不碰平台：
 *   - 每帧注册若干命中矩形（按注册顺序决定 z 序，后注册的优先）
 *   - 每帧喂一次鼠标位置 + 左键状态，得到 hover / press / click / release / drag
 *
 * 事件语义（一帧内最多各一次）：
 *   clicked_id   左键在某个 target 上按下（按下沿）
 *   released_id  按下后在同一個 target 上松开（完成一次 click）
 *   drag_id      正在按住并且已经超过拖动阈值（离开按下点超过 threshold）
 *   hover_id     当前指针下的 target
 */
#include <stdbool.h>
#include <stddef.h>
#include "uim_component_manager.h"

#ifdef __cplusplus
extern "C" {
#endif

#define uim_UI_MAX_TARGETS 256u   /* Project/Hierarchy/Inspector/菜单同时注册；128 会溢出并静默丢弃后注册的 Inspector 命中区 */

/* 区域枚举：只用于调用方分派，模块本身不解释 */
typedef enum uim_UiRegion {
    uim_UI_REGION_NONE = 0,
    uim_UI_REGION_MENU,
    uim_UI_REGION_HIERARCHY,
    uim_UI_REGION_RUNTIME,
    uim_UI_REGION_INSPECTOR,
    uim_UI_REGION_STATUS,
    uim_UI_REGION_CORNER,
    uim_UI_REGION_CUSTOM
} uim_UiRegion;

typedef struct uim_UiHitTarget {
    uim_Rect rect;
    int      id;        /* 调用方自定义，-1 表示未用 */
    int      region;
    bool     enabled;
} uim_UiHitTarget;

typedef struct uim_UiInteraction {
    uim_UiHitTarget targets[uim_UI_MAX_TARGETS];
    size_t target_count;

    int  hover_id;
    int  press_id;
    int  clicked_id;
    int  released_id;
    int  drag_id;

    float press_x, press_y;
    bool  left_down;
    bool  dragging;
    bool  released_edge;   /* 本帧是否发生了“松开”沿（不论松在哪） */
    float drag_threshold;   /* 默认 4.0 像素 */
} uim_UiInteraction;

/* 清空所有 state。调用前不需要先 reset targets（一起清）。 */
void uim_ui_interaction_reset(uim_UiInteraction *ui);

/* 注册一个命中矩形。返回 target 下标（>=0），满或参数非法返回 -1。
 * 同一帧重复调用会追加；调用方应在 begin_frame 时重建。 */
int uim_ui_hit_add(uim_UiInteraction *ui, int region, int id, uim_Rect rect, bool enabled);

/* 每帧开始：清 targets 与事件，但保留 press/drag 的跨帧状态。 */
void uim_ui_begin_frame(uim_UiInteraction *ui);

/* 每帧一次：喂鼠标。返回本帧最高优先级事件 id（clicked > released > drag > hover），
 * 没有事件返回 -1。事件也可从结构体字段读。 */
int uim_ui_update(uim_UiInteraction *ui, float x, float y, bool left_down);

/* 带显式边沿的版本：合成输入/远程输入可能在同一帧内完成 down+up，
 * 只靠 left_down 的布尔状态会漏掉整次点击。pressed/released 来自
 * zcsr_mouse_state 的 pressed/released mask。 */
int uim_ui_update_edges(uim_UiInteraction *ui, float x, float y, bool left_down,
                        bool left_pressed, bool left_released);

int  uim_ui_hover_id(const uim_UiInteraction *ui);
int  uim_ui_press_id(const uim_UiInteraction *ui);
int  uim_ui_clicked_id(const uim_UiInteraction *ui);
int  uim_ui_released_id(const uim_UiInteraction *ui);
/* 本帧是否是“松开”沿：菜单这类“点在别处就关”的逻辑应当用它，
 * 而不是用按下沿（快速点击时按下沿可能还带着上一帧的指针位置）。 */
bool uim_ui_released_edge(const uim_UiInteraction *ui);
int  uim_ui_drag_id(const uim_UiInteraction *ui);
bool uim_ui_is_hovered(const uim_UiInteraction *ui, int id);
bool uim_ui_is_dragging(const uim_UiInteraction *ui, int id);

#ifdef __cplusplus
}
#endif
#endif /* UI_EDITOR_INTERACTION_H */
