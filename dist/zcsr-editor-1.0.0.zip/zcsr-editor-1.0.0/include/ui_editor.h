#ifndef UI_EDITOR_H
#define UI_EDITOR_H
#include "uim_component_manager.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct uim_Editor uim_Editor;
struct uim_ComponentRegistry;
typedef struct uim_EditorSelection { const uim_NodeId *ids; size_t count; } uim_EditorSelection;
typedef enum uim_EditorAlign {
    uim_EDITOR_ALIGN_LEFT=1, uim_EDITOR_ALIGN_HCENTER, uim_EDITOR_ALIGN_RIGHT,
    uim_EDITOR_ALIGN_TOP, uim_EDITOR_ALIGN_VCENTER, uim_EDITOR_ALIGN_BOTTOM
} uim_EditorAlign;
typedef enum uim_EditorAxis { uim_EDITOR_AXIS_HORIZONTAL=1, uim_EDITOR_AXIS_VERTICAL=2 } uim_EditorAxis;
typedef struct uim_EditorGuide { bool vertical; float position; } uim_EditorGuide;

typedef enum uim_EditorOverlayType {
    uim_EDITOR_OVERLAY_GRID_LINE=1,
    uim_EDITOR_OVERLAY_GUIDE_LINE,
    uim_EDITOR_OVERLAY_SAFE_AREA,
    uim_EDITOR_OVERLAY_NODE_BOUNDS,
    uim_EDITOR_OVERLAY_SELECTED_BOUNDS,
    uim_EDITOR_OVERLAY_FOCUS_BOUNDS,
    uim_EDITOR_OVERLAY_RESIZE_HANDLE,
    uim_EDITOR_OVERLAY_SELECTION_MARQUEE
} uim_EditorOverlayType;
typedef struct uim_EditorOverlayCommand {
    uim_EditorOverlayType type;
    uim_NodeId node_id;
    uim_Rect rect;
    float x1, y1, x2, y2;
    uint32_t handle_index;
} uim_EditorOverlayCommand;

typedef enum uim_EditorModifiers {
    uim_EDITOR_MOD_SHIFT = 1u << 0,
    uim_EDITOR_MOD_CTRL  = 1u << 1,
    uim_EDITOR_MOD_ALT   = 1u << 2
} uim_EditorModifiers;
typedef enum uim_EditorKey {
    uim_EDITOR_KEY_ESCAPE=1,
    uim_EDITOR_KEY_DELETE,
    uim_EDITOR_KEY_LEFT,
    uim_EDITOR_KEY_RIGHT,
    uim_EDITOR_KEY_UP,
    uim_EDITOR_KEY_DOWN,
    uim_EDITOR_KEY_Z,
    uim_EDITOR_KEY_Y,
    uim_EDITOR_KEY_D
} uim_EditorKey;

typedef struct uim_EditorHistoryState {
    size_t undo_count;
    size_t redo_count;
    size_t capacity;
} uim_EditorHistoryState;
typedef struct uim_EditorHierarchyItem {
    uim_NodeInfo node;
    const char *display_name; /* Editor-owned; borrowed until metadata mutation */
    uint32_t depth;
    bool has_children;
    bool expanded;
} uim_EditorHierarchyItem;
typedef struct uim_EditorCanvasState {
    uim_Rect viewport;          /* screen-space viewport */
    float zoom;                 /* allowed range 0.05..16 */
    float pan_x, pan_y;          /* screen-space pan offset */
    float grid_size;             /* page-space; 0 disables grid */
    bool show_grid;
    bool snap_to_grid;
    uim_Rect safe_area;          /* page-space rectangle */
    bool safe_area_enabled;
} uim_EditorCanvasState;

uim_Result uir_editor_create(UIM_ComponentManager *receiver, size_t history_capacity, uim_Editor **out_editor);
void uir_editor_destroy(uim_Editor *editor);
uim_Result uir_editor_select(uim_Editor *editor, const uim_NodeId *ids, size_t count);
uim_Result uir_editor_get_selection(const uim_Editor *editor, uim_EditorSelection *out_selection);
uim_Result uir_editor_set_focus_node(uim_Editor *editor, uim_NodeId node_id);
uim_Result uir_editor_get_focus_node(const uim_Editor *editor, uim_NodeId *out_node_id);
uim_Result uir_editor_set_canvas_state(uim_Editor *editor, const uim_EditorCanvasState *state);
uim_Result uir_editor_get_canvas_state(const uim_Editor *editor, uim_EditorCanvasState *out_state);
uim_Result uir_editor_zoom_at(uim_Editor *editor, float new_zoom, float canvas_x, float canvas_y);
uim_Result uir_editor_pan(uim_Editor *editor, float dx, float dy);
uim_Result uir_editor_set_guides(uim_Editor *editor, const uim_EditorGuide *guides, size_t count);
uim_Result uir_editor_get_guide(const uim_Editor *editor, size_t index, uim_EditorGuide *out_guide);
uim_Result uir_editor_canvas_to_page(const uim_Editor *editor, float canvas_x, float canvas_y, float *out_page_x, float *out_page_y);
uim_Result uir_editor_page_to_canvas(const uim_Editor *editor, float page_x, float page_y, float *out_canvas_x, float *out_canvas_y);
uim_Result uir_editor_inspect_node(const uim_Editor *editor, uim_NodeId node_id, uim_NodeInfo *out_info);
uim_Result uir_editor_get_child_count(const uim_Editor *editor, uim_NodeId parent_id, size_t *out_count);
uim_Result uir_editor_get_child_at(const uim_Editor *editor, uim_NodeId parent_id, size_t index, uim_NodeInfo *out_info);
uim_Result uir_editor_create_node(uim_Editor *editor, const uim_NodeDesc *desc, uim_NodeId *out_node_id);
uim_Result uir_editor_duplicate_node(uim_Editor *editor, uim_NodeId source_id, float offset_x, float offset_y, uim_NodeId *out_node_id);
uim_Result uir_editor_delete_node(uim_Editor *editor, uim_NodeId node_id);
uim_Result uir_editor_reorder_node(uim_Editor *editor, uim_NodeId node_id, size_t new_sibling_index);
uim_Result uir_editor_move_node(uim_Editor *editor, uim_NodeId node_id, float dx, float dy);
uim_Result uir_editor_move_selection(uim_Editor *editor, float dx, float dy);
uim_Result uir_editor_resize_node(uim_Editor *editor, uim_NodeId node_id, float width, float height);
uim_Result uir_editor_set_rect(uim_Editor *editor, uim_NodeId node_id, uim_Rect rect);
uim_Result uir_editor_set_transform3(uim_Editor *editor, uim_NodeId node_id,
                                     const uim_Transform3 *transform);
uim_Result uir_editor_set_space(uim_Editor *editor, uim_NodeId node_id, uim_Space space);
uim_Result uir_editor_set_layout_constraints(uim_Editor *editor, uim_NodeId node_id, uim_LayoutConstraints constraints);
uim_Result uir_editor_resolve_page_layout(uim_Editor *editor, uim_PageId page_id, float viewport_width, float viewport_height);
uim_Result uir_editor_set_component_config(uim_Editor *editor, uim_NodeId node_id, const void *data, size_t size);
uim_Result uir_editor_component_attach_registered(uim_Editor *editor,
                                                  const struct uim_ComponentRegistry *registry,
                                                  uim_NodeId node_id, uim_ComponentTypeId type_id,
                                                  uim_ComponentInstanceId *out_instance_id);
uim_Result uir_editor_component_detach(uim_Editor *editor, uim_ComponentInstanceId instance);
uim_Result uir_editor_component_set_property(uim_Editor *editor,
                                             const struct uim_ComponentRegistry *registry,
                                             uim_ComponentInstanceId instance,
                                             uim_PropertyId property, uim_Value value);
uim_Result uir_editor_set_setting_pending(uim_Editor *editor, uim_PropertyId property_id, uim_Value value);
uim_Result uir_editor_get_setting_state(const uim_Editor *editor, uim_PropertyId property_id, uim_SettingState *out_state);
uim_Result uir_editor_set_parent(uim_Editor *editor, uim_NodeId node_id, uim_NodeId parent_id);
uim_Result uir_editor_set_visible(uim_Editor *editor, uim_NodeId node_id, bool visible);
uim_Result uir_editor_set_enabled(uim_Editor *editor, uim_NodeId node_id, bool enabled);
uim_Result uir_editor_set_z_order(uim_Editor *editor, uim_NodeId node_id, int32_t z_order);
uim_Result uir_editor_set_child_order(uim_Editor *editor, uim_NodeId node_id, uint32_t child_order);
uim_Result uir_editor_bring_to_front(uim_Editor *editor, uim_NodeId node_id);
uim_Result uir_editor_send_to_back(uim_Editor *editor, uim_NodeId node_id);
uim_Result uir_editor_align_selection(uim_Editor *editor, uim_EditorAlign alignment);
uim_Result uir_editor_distribute_selection(uim_Editor *editor, uim_EditorAxis axis);
uim_Result uir_editor_undo(uim_Editor *editor);
uim_Result uir_editor_redo(uim_Editor *editor);
void uir_editor_clear_history(uim_Editor *editor);

/* Active Page and non-destructive hierarchy presentation state. */
uim_Result uir_editor_set_active_page(uim_Editor *editor, uim_PageId page_id);
uim_Result uir_editor_get_active_page(const uim_Editor *editor, uim_PageId *out_page_id);
uim_Result uir_editor_hierarchy_set_name(uim_Editor *editor, uim_NodeId node_id, const char *display_name);
uim_Result uir_editor_hierarchy_set_expanded(uim_Editor *editor, uim_NodeId node_id, bool expanded);
uim_Result uir_editor_hierarchy_get_item(const uim_Editor *editor, uim_NodeId node_id, uim_EditorHierarchyItem *out_item);
uim_Result uir_editor_hierarchy_get_visible_count(const uim_Editor *editor, size_t *out_count);
uim_Result uir_editor_hierarchy_get_visible_at(const uim_Editor *editor, size_t index, uim_EditorHierarchyItem *out_item);

/* Page-space picking and selection. World rectangles include parent offsets. */
uim_Result uir_editor_canvas_hit_test(const uim_Editor *editor, uim_PageId page_id, float canvas_x, float canvas_y, uim_NodeId *out_node_id);
uim_Result uir_editor_canvas_box_select(uim_Editor *editor, uim_PageId page_id, uim_Rect canvas_rect, bool additive);
/* Pointer gestures are model operations; the frontend forwards logical canvas coordinates.
 * A drag is one atomic undo entry. Escape/cancel restores the pre-gesture state. */
uim_Result uir_editor_canvas_pointer_down(uim_Editor *editor, uim_PageId page_id,
                                          float canvas_x, float canvas_y, uint32_t modifiers);
uim_Result uir_editor_canvas_pointer_move(uim_Editor *editor, float canvas_x, float canvas_y);
uim_Result uir_editor_canvas_pointer_up(uim_Editor *editor, float canvas_x, float canvas_y);
uim_Result uir_editor_canvas_pointer_cancel(uim_Editor *editor);
uim_Result uir_editor_key_down(uim_Editor *editor, uim_EditorKey key, uint32_t modifiers);

/* History inspection and renderer-neutral Editor overlay list. Query required command
 * count with out_commands=NULL/capacity=0; insufficient capacity returns uim_ERR_BUFFER.
 * All overlay coordinates are in canvas/screen space. */
uim_Result uir_editor_get_history_state(const uim_Editor *editor, uim_EditorHistoryState *out_state);
uim_Result uir_editor_build_overlay(const uim_Editor *editor, uim_PageId page_id,
                                    uim_EditorOverlayCommand *out_commands, size_t capacity,
                                    size_t *out_count);

#ifdef __cplusplus
}
#endif
#endif
