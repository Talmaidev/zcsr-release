#ifndef UI_HIERARCHY_H
#define UI_HIERARCHY_H

/*
 * UIR Hierarchy Domain.
 * 只保存编辑器视图状态：选中的 Node ID、展开的 Node ID 集合。
 * 不复制 Node 数据，Receiver 是唯一事实来源。
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "uim_component_manager.h"

#ifdef __cplusplus
extern "C" {
#endif

#define uim_HIER_MAX_EXPANDED 32u
#define uim_HIER_MAX_VISIBLE 128u

typedef struct uim_Hierarchy uim_Hierarchy;

typedef struct uim_HierRow {
    uim_NodeId node_id;
    int depth;
    bool is_expanded;
    bool has_children;
    bool selected;
    char node_name[64];
    uint32_t type_id;  /* uim_ComponentTypeId */
} uim_HierRow;

uim_Hierarchy* uim_hierarchy_create(void);
void uim_hierarchy_destroy(uim_Hierarchy *h);

/* 设置数据源：Host 传入 Receiver 和 root node id */
void uim_hierarchy_set_source(uim_Hierarchy *h, const UIM_ComponentManager *rec, uim_NodeId root_id);

/* 点击行：选中 + 如果该行有子节点则切换展开/折叠。
 * 仅用于点击行首三角/展开区域；点击行正文请用 uim_hierarchy_select_row。 */
void uim_hierarchy_handle_row_click(uim_Hierarchy *h, int row_index);

/* 只选中，不改变展开状态（Unity 里点击行正文的语义）。 */
void uim_hierarchy_select_row(uim_Hierarchy *h, int row_index);

/* 清空层级树的选中标记（多选减到空时用）。 */
void uim_hierarchy_clear_selection(uim_Hierarchy *h);

/* 只切换展开状态，不改变选中。 */
void uim_hierarchy_toggle_row(uim_Hierarchy *h, int row_index);

/* 查询可见行数 */
int uim_hierarchy_visible_count(const uim_Hierarchy *h);

/* 获取指定行数据（内部从 Receiver 实时查询） */
bool uim_hierarchy_get_row(const uim_Hierarchy *h, int index, uim_HierRow *out_row);

/* 当前选中的 Node ID */
uim_NodeId uim_hierarchy_selected(const uim_Hierarchy *h);

#ifdef __cplusplus
}
#endif
#endif
