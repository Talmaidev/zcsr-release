#ifndef UI_EDITOR_PROVIDER_H
#define UI_EDITOR_PROVIDER_H
/* Opaque external view manager. The editor host owns native-child and
 * render-callback views; the renderer only needs the selected center host
 * element from the Shell frame. Keeping this opaque avoids leaking platform
 * or graphics types into the renderer-neutral shell. */
typedef struct uim_ExternalViewManager uim_ExternalViewManager;
#endif
