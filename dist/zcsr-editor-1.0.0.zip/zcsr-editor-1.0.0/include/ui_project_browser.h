﻿#ifndef UI_PROJECT_BROWSER_H
#define UI_PROJECT_BROWSER_H

/*
 * UIR Project Browser Domain.
 *
 * Owns project root path, directory tree state, expand/collapse, selection,
 * refresh and error status. Does NOT render and does NOT depend on any
 * platform or graphics API. Host calls this Domain on each frame and uses
 * the visible node list to draw.
 *
 * The Domain reads disk content exclusively through uim_FileService ABI v1.
 * Host creates the File Service and injects it here.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "uim_file_service.h"

#ifdef __cplusplus
extern "C" {
#endif

#define uim_PB_MAX_NAME_UTF8 128u
#define uim_PB_MAX_PATH_UTF8 256u
#define uim_PB_MAX_VISIBLE_NODES 256u
#define uim_PB_MAX_EXPANDED 32u

typedef struct uim_ProjectBrowser uim_ProjectBrowser;

typedef enum uim_PBError {
    uim_PB_OK = 0,
    uim_PB_ERR_NOT_INITIALIZED,
    uim_PB_ERR_ROOT_NOT_FOUND,
    uim_PB_ERR_ACCESS_DENIED,
    uim_PB_ERR_READ_FAILED,
    uim_PB_ERR_OUT_OF_MEMORY,
    uim_PB_ERR_CAPACITY_EXCEEDED,
    uim_PB_ERR_INVALID_PATH,
    uim_PB_ERR_NO_SELECTION,
    uim_PB_ERR_OPERATION_FAILED,
    uim_PB_ERR_INVALID_INDEX   /* get_node: visible index < 0 or >= visible_count */
} uim_PBError;

typedef struct uim_PBVisibleNode {
    uint32_t index;
    int      depth;
    bool     is_dir;
    bool     expanded;
    bool     selected;
    char     name[uim_PB_MAX_NAME_UTF8];
    char     rel_path[uim_PB_MAX_PATH_UTF8];
} uim_PBVisibleNode;

/* Lifecycle */
uim_ProjectBrowser* uim_project_browser_create(void);
void uim_project_browser_destroy(uim_ProjectBrowser *pb);

/* Inject File Service. Domain does NOT take ownership of the service;
 * host must keep it alive until destroy returns. */
uim_PBError uim_project_browser_set_file_service(uim_ProjectBrowser *pb,
                                                 const uim_FileService *fs);

/* Set project root (UTF-8, relative paths inside root are resolved by FS).
 * Passing empty string or NULL clears the root. */
uim_PBError uim_project_browser_set_root(uim_ProjectBrowser *pb, const char *utf8_root);

/* Re-read root directory and rebuild visible tree. */
uim_PBError uim_project_browser_refresh(uim_ProjectBrowser *pb);

/* Toggle expand/collapse on the directory at visible index.
 * Returns true if the event was consumed by this panel. */
bool uim_project_browser_toggle_node(uim_ProjectBrowser *pb, int visible_index);

/* Select a visible node. */
void uim_project_browser_select(uim_ProjectBrowser *pb, int visible_index);

/* Real file operations. Names are single path components inside the project root:
 * empty, absolute, drive-qualified, separator-containing and "."/".." are rejected. */
uim_PBError uim_project_browser_create_dir(uim_ProjectBrowser *pb, const char *name);
uim_PBError uim_project_browser_rename_selected(uim_ProjectBrowser *pb, const char *new_name);
uim_PBError uim_project_browser_remove_selected(uim_ProjectBrowser *pb);

/* Accessors for Host rendering. */
int uim_project_browser_visible_count(const uim_ProjectBrowser *pb);
uim_PBError uim_project_browser_get_node(const uim_ProjectBrowser *pb,
                                          int visible_index,
                                          uim_PBVisibleNode *out_node);
uim_PBError uim_project_browser_get_error(const uim_ProjectBrowser *pb);
bool uim_project_browser_capacity_exceeded(const uim_ProjectBrowser *pb);
const char* uim_project_browser_root_path(const uim_ProjectBrowser *pb);
int uim_project_browser_selected_index(const uim_ProjectBrowser *pb);

#ifdef __cplusplus
}
#endif
#endif
