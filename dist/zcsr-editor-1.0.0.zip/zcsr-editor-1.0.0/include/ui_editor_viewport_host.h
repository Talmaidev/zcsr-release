#ifndef UI_EDITOR_VIEWPORT_HOST_H
#define UI_EDITOR_VIEWPORT_HOST_H

#include "ui_editor_workspace.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * UIR Editor Engine Viewport Host.
 *
 * The viewport is a logical engine view rendered inside the Editor Main
 * Window's existing renderer/context. It is NOT an OS Window, zcsr_surface,
 * HWND, native child window, or a second editor process.
 *
 * The application owns the Editor Main Window, renderer frame, and final
 * present. The engine backend owns the logical viewport/runtime state only.
 * render() is called between the application's begin-frame and present; it
 * must not create a surface/context, clear the whole editor, or present.
 */
#define uim_EDITOR_VIEWPORT_HOST_ABI_VERSION 1u

typedef enum uim_EditorViewportInputRoute {
    uim_EDITOR_VIEWPORT_INPUT_NONE = 0,
    uim_EDITOR_VIEWPORT_INPUT_EDITOR = 1,
    uim_EDITOR_VIEWPORT_INPUT_GAME = 2
} uim_EditorViewportInputRoute;

typedef enum uim_EditorViewportInputType {
    uim_EDITOR_VIEWPORT_POINTER_MOVE = 1,
    uim_EDITOR_VIEWPORT_POINTER_DOWN,
    uim_EDITOR_VIEWPORT_POINTER_UP,
    uim_EDITOR_VIEWPORT_POINTER_WHEEL,
    uim_EDITOR_VIEWPORT_KEY_DOWN,
    uim_EDITOR_VIEWPORT_KEY_UP,
    uim_EDITOR_VIEWPORT_TEXT
} uim_EditorViewportInputType;

typedef struct uim_EditorViewportInput {
    uim_EditorViewportInputType type;
    /* x/y are viewport-local logical coordinates (Editor host converts from
     * client coordinates after hit-testing the center host rect). */
    float x;
    float y;
    float wheel_delta;
    uint32_t pointer_id;
    uint32_t buttons;
    uint32_t key;
    uint32_t modifiers;
    const char *text; /* borrowed for the duration of process_input() */
    size_t text_size;
} uim_EditorViewportInput;

typedef enum uim_EditorViewportHostState {
    uim_EDITOR_VIEWPORT_EMPTY = 0,
    uim_EDITOR_VIEWPORT_CREATED = 1,
    uim_EDITOR_VIEWPORT_VISIBLE = 2
} uim_EditorViewportHostState;

typedef struct uim_EditorViewportHostOps {
    uint32_t abi_version;
    uint32_t struct_size;

    /* Create a logical Engine Viewport/runtime view. Must not create an OS
     * window, Surface, GL context, or call any platform Window API. */
    uim_Result (*create_viewport)(void *user, uintptr_t *out_token,
                                  uint64_t *out_generation);
    uim_Result (*set_rect)(void *user, uintptr_t token, uint64_t generation,
                           uim_Rect editor_client_rect);
    uim_Result (*set_mode)(void *user, uintptr_t token, uint64_t generation,
                           uim_WorkspaceViewportMode mode);
    uim_Result (*set_visible)(void *user, uintptr_t token, uint64_t generation,
                              bool visible);
    uim_Result (*set_focus)(void *user, uintptr_t token, uint64_t generation,
                            bool focused);
    uim_Result (*set_input_route)(void *user, uintptr_t token, uint64_t generation,
                                   uim_EditorViewportInputRoute route);
    uim_Result (*process_input)(void *user, uintptr_t token, uint64_t generation,
                                 const uim_EditorViewportInput *input);

    /* Draw only the viewport content into the supplied rect using the already
     * active Editor renderer/context. Do not begin/end/present the outer frame. */
    uim_Result (*render)(void *user, uintptr_t token, uint64_t generation,
                         void *renderer_context, uim_Rect rect,
                         uim_WorkspaceViewportMode mode);

    /* Destroy only logical viewport/runtime view state. Must not destroy the
     * Editor Main Window or its renderer/context. */
    void (*destroy_viewport)(void *user, uintptr_t token, uint64_t generation);
} uim_EditorViewportHostOps;

typedef struct uim_EditorViewportHost {
    uim_EditorViewportHostOps ops;
    void *user;
    uintptr_t token;
    uint64_t generation;
    uim_Rect applied_rect;
    uim_WorkspaceViewportMode mode;
    uim_EditorViewportInputRoute input_route;
    uim_EditorViewportHostState state;
    bool rect_valid;
    bool mode_valid;
    bool focused;
    bool visible;
} uim_EditorViewportHost;

uim_Result uir_editor_viewport_host_init(uim_EditorViewportHost *host,
                                         const uim_EditorViewportHostOps *ops,
                                         void *user);
/* Sync after Workspace frame construction. Creates the logical view once,
 * then applies rect/mode/route/visibility changes without creating OS windows. */
uim_Result uir_editor_viewport_host_sync(uim_EditorViewportHost *host,
                                         const uim_Workspace *workspace,
                                         const uim_WorkspaceFrame *frame,
                                         bool center_visible);
uim_Result uir_editor_viewport_host_set_focus(uim_EditorViewportHost *host,
                                               bool focused);
uim_Result uir_editor_viewport_host_process_input(uim_EditorViewportHost *host,
                                                   const uim_EditorViewportInput *input);
/* Call during the Editor's active render frame, after begin and before present. */
uim_Result uir_editor_viewport_host_render(uim_EditorViewportHost *host,
                                            void *renderer_context);
void uir_editor_viewport_host_destroy(uim_EditorViewportHost *host);

#ifdef __cplusplus
}
#endif
#endif
