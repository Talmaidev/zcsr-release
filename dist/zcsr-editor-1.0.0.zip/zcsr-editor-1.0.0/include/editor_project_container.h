#ifndef ZCSR_EDITOR_PROJECT_CONTAINER_H
#define ZCSR_EDITOR_PROJECT_CONTAINER_H

/* Single-file `.uiproj` container.
 *
 * The UI document and the 2.5D scene are authored together, so they are
 * stored together. The container is deliberately a thin framing layer:
 *
 *   ZCSRPROJ 1
 *   project <byte-size>
 *   scene <byte-size>
 *   <project bytes><scene bytes>
 *
 * UIM still owns the project bytes (`UIRJ ...`) and the editor still owns the
 * scene text (`ZCSRSCENE ...`). No module learns the other's schema; the
 * runtime only needs to read the project section when it does not render a
 * scene. */

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum zcsr_editor_container_result {
    ZCSR_EDITOR_CONTAINER_OK = 0,
    ZCSR_EDITOR_CONTAINER_INVALID_ARGUMENT,
    ZCSR_EDITOR_CONTAINER_OPEN_FAILED,
    ZCSR_EDITOR_CONTAINER_BAD_HEADER,
    ZCSR_EDITOR_CONTAINER_IO_ERROR
} zcsr_editor_container_result;

/* Writes atomically (`.tmp` + rename). Both buffers are owned by the caller. */
zcsr_editor_container_result zcsr_editor_project_container_save(
    const char *utf8_path,
    const unsigned char *project, size_t project_size,
    const char *scene, size_t scene_size);

/* Reads both sections. On success the caller owns *out_project (free) and
 * *out_scene (free). Scene may be empty (size 0, pointer NULL). */
zcsr_editor_container_result zcsr_editor_project_container_load(
    const char *utf8_path,
    unsigned char **out_project, size_t *out_project_size,
    char **out_scene, size_t *out_scene_size);

/* Returns true when the file starts with the container header. */
bool zcsr_editor_project_container_probe(const char *utf8_path);

const char *zcsr_editor_container_result_name(zcsr_editor_container_result result);

#ifdef __cplusplus
}
#endif

#endif /* ZCSR_EDITOR_PROJECT_CONTAINER_H */
