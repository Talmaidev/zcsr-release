#ifndef UI_EDITOR_WORKSPACE_H
#define UI_EDITOR_WORKSPACE_H

#include "ui_editor.h"


#ifdef __cplusplus
extern "C" {
#endif

/*
 * Renderer-neutral Editor Workspace / Docking Shell.
 *
 * This module owns editor-level panel layout, docking, tabs, and splitter
 * interaction. It does not create OS windows, ZCSR Primitives, render targets,
 * or GPU resources. The host draws the returned rectangles using its existing
 * ZCSR UI/rendering APIs.
 *
 * Storage is caller-owned and fixed-capacity: no heap allocation is performed.
 */
#define uim_WORKSPACE_MAX_PANELS       16u
#define uim_WORKSPACE_MAX_NODES        31u
#define uim_WORKSPACE_MAX_TABS_PER_GROUP 8u
#define uim_WORKSPACE_MAX_SPLITTERS    16u
#define uim_WORKSPACE_TAB_HEIGHT       26.0f
#define uim_WORKSPACE_SPLITTER_SIZE     6.0f

typedef uint32_t uim_WorkspacePanelId;
typedef uint16_t uim_WorkspaceNodeId;

#define uim_WORKSPACE_NODE_INVALID ((uim_WorkspaceNodeId)0xFFFFu)

typedef enum uim_WorkspacePanel {
    uim_WORKSPACE_PANEL_PALETTE   = 1,
    uim_WORKSPACE_PANEL_HIERARCHY = 2,
    uim_WORKSPACE_PANEL_SCENE     = 3,
    uim_WORKSPACE_PANEL_GAME      = 4,
    uim_WORKSPACE_PANEL_INSPECTOR = 5,
    uim_WORKSPACE_PANEL_PROJECT   = 6,
    uim_WORKSPACE_PANEL_ASSETS    = 7,
    uim_WORKSPACE_PANEL_CONSOLE   = 8
} uim_WorkspacePanel;

typedef enum uim_WorkspaceAxis {
    uim_WORKSPACE_AXIS_HORIZONTAL = 1, /* children are left and right */
    uim_WORKSPACE_AXIS_VERTICAL   = 2  /* children are top and bottom */
} uim_WorkspaceAxis;

typedef enum uim_WorkspaceDockZone {
    uim_WORKSPACE_DOCK_CENTER = 0, /* add as a tab in the target group */
    uim_WORKSPACE_DOCK_LEFT,
    uim_WORKSPACE_DOCK_RIGHT,
    uim_WORKSPACE_DOCK_TOP,
    uim_WORKSPACE_DOCK_BOTTOM
} uim_WorkspaceDockZone;

typedef enum uim_WorkspaceViewportMode {
    uim_WORKSPACE_VIEW_SCENE = 1,
    uim_WORKSPACE_VIEW_GAME  = 2
} uim_WorkspaceViewportMode;

typedef struct uim_WorkspacePanelDesc {
    uim_WorkspacePanelId id;
    const char *title;       /* borrowed; must outlive the workspace */
    float min_width;
    float min_height;
    uint32_t flags;
} uim_WorkspacePanelDesc;

typedef struct uim_WorkspaceConfig {
    float width;
    float height;
    float menu_bar_height;
    float toolbar_height;
    float status_bar_height;
    float bottom_panel_height;
    float left_panel_width;
    float right_panel_width;
    float splitter_size;
    float tab_height;
    const uim_WorkspacePanelDesc *panels;
    size_t panel_count;
} uim_WorkspaceConfig;

typedef enum uim_WorkspaceNodeType {
    uim_WORKSPACE_NODE_UNUSED = 0,
    uim_WORKSPACE_NODE_SPLIT = 1,
    uim_WORKSPACE_NODE_TABS = 2
} uim_WorkspaceNodeType;

typedef struct uim_WorkspaceNode {
    uim_WorkspaceNodeType type;
    uim_WorkspaceNodeId parent;
    uim_WorkspaceNodeId child_a;
    uim_WorkspaceNodeId child_b;
    uim_WorkspaceAxis axis;
    float ratio;
    uim_Rect rect;
    uim_WorkspacePanelId panel_ids[uim_WORKSPACE_MAX_TABS_PER_GROUP];
    uint8_t panel_count;
    uint8_t active_index;
} uim_WorkspaceNode;

typedef struct uim_WorkspacePanelView {
    uim_WorkspacePanelId panel_id;
    uim_WorkspaceNodeId group_node;
    uim_Rect tab_rect;
    uim_Rect content_rect;
    bool active;
} uim_WorkspacePanelView;

typedef struct uim_WorkspaceSplitterView {
    uim_WorkspaceNodeId node_id;
    uim_WorkspaceAxis axis;
    uim_Rect rect;
    float ratio;
} uim_WorkspaceSplitterView;

typedef struct uim_WorkspaceFrame {
    uim_Rect menu_bar;
    uim_Rect toolbar;
    uim_Rect status_bar;
    uim_Rect dock_area;
    uim_WorkspacePanelView panels[uim_WORKSPACE_MAX_PANELS];
    size_t panel_count;
    uim_WorkspaceSplitterView splitters[uim_WORKSPACE_MAX_SPLITTERS];
    size_t splitter_count;
} uim_WorkspaceFrame;

typedef struct uim_Workspace {
    uim_WorkspaceConfig config;
    uim_WorkspacePanelDesc panels[uim_WORKSPACE_MAX_PANELS];
    size_t panel_count;
    uim_WorkspaceNode nodes[uim_WORKSPACE_MAX_NODES];
    uim_WorkspaceNodeId root;
    uim_WorkspaceNodeId active_splitter;
    uim_Rect last_dock_area;
    uim_WorkspaceViewportMode viewport_mode;
    uint32_t layout_revision;
} uim_Workspace;

/* Initialize the default professional editor layout:
 * Palette / Hierarchy | Scene+Game viewport | Inspector
 * with Project/Assets/Console tabbed in the bottom dock.
 * `workspace` storage belongs to the caller. */
uim_Result uim_workspace_init_default(uim_Workspace *workspace,
                                      const uim_WorkspaceConfig *config);
uim_Result uim_workspace_set_bounds(uim_Workspace *workspace,
                                    float width, float height);
uim_Result uim_workspace_build_frame(uim_Workspace *workspace,
                                     uim_WorkspaceFrame *out_frame);
uim_Result uim_workspace_get_panel_view(const uim_WorkspaceFrame *frame,
                                        uim_WorkspacePanelId panel_id,
                                        uim_WorkspacePanelView *out_view);

/* Select a tab. Scene/Game selection also changes viewport mode. */
uim_Result uim_workspace_activate_panel(uim_Workspace *workspace,
                                        uim_WorkspacePanelId panel_id);
uim_Result uim_workspace_get_panel_title(const uim_Workspace *workspace,
                                         uim_WorkspacePanelId panel_id,
                                         const char **out_title);
uim_Result uim_workspace_get_active_panel(const uim_Workspace *workspace,
                                          uim_WorkspaceNodeId group_node,
                                          uim_WorkspacePanelId *out_panel_id);

/* Move an existing panel, or restore a previously docked/closed panel, beside
 * or into the target panel's tab group. Edge docking creates a split; center
 * docking creates a tab. This is the operation called after a panel drag/drop. */
uim_Result uim_workspace_dock_panel(uim_Workspace *workspace,
                                    uim_WorkspacePanelId panel_id,
                                    uim_WorkspacePanelId target_panel_id,
                                    uim_WorkspaceDockZone zone);
uim_Result uim_workspace_close_panel(uim_Workspace *workspace,
                                     uim_WorkspacePanelId panel_id);
uim_Result uim_workspace_get_drop_target(const uim_WorkspaceFrame *frame,
                                         float x, float y,
                                         uim_WorkspacePanelId *out_target_panel,
                                         uim_WorkspaceDockZone *out_zone);

/* Pointer routing for tabs and splitters. Panel-header drag/drop is completed
 * by calling get_drop_target() and then dock_panel() on pointer release. */
uim_Result uim_workspace_pointer_down(uim_Workspace *workspace,
                                      const uim_WorkspaceFrame *frame,
                                      float x, float y);
uim_Result uim_workspace_pointer_move(uim_Workspace *workspace,
                                      float x, float y);
uim_Result uim_workspace_pointer_up(uim_Workspace *workspace);

/* Center Scene/Game viewport helpers. The actual Game runtime and renderer
 * remain host responsibilities. Existing Editor Core owns pan/zoom state. */
uim_Result uim_workspace_viewport_set_mode(uim_Workspace *workspace,
                                            uim_WorkspaceViewportMode mode);
uim_Result uim_workspace_viewport_get_mode(const uim_Workspace *workspace,
                                            uim_WorkspaceViewportMode *out_mode);
uim_Result uim_workspace_viewport_get_rect(const uim_WorkspaceFrame *frame,
                                            uim_WorkspaceViewportMode mode,
                                            uim_Rect *out_rect);
/* Explicit Center Host Slot API. Returns the content rectangle of the active
 * Scene/Game tab inside the one Editor Main Window. It does not create a
 * native window, surface, or render target. */
uim_Result uim_workspace_get_center_host_rect(
    const uim_Workspace *workspace, const uim_WorkspaceFrame *frame,
    uim_Rect *out_rect, uim_WorkspaceViewportMode *out_mode);
uim_Result uim_workspace_viewport_apply_rect(uim_Editor *editor,
                                              uim_Rect viewport_rect);
uim_Result uim_workspace_viewport_zoom_at(uim_Editor *editor,
                                           float zoom, float screen_x,
                                           float screen_y);
uim_Result uim_workspace_viewport_pan(uim_Editor *editor,
                                      float dx, float dy);
uim_Result uim_workspace_viewport_fit_page(uim_Editor *editor,
                                            float page_width,
                                            float page_height,
                                            float margin);

#ifdef __cplusplus
}
#endif
#endif
