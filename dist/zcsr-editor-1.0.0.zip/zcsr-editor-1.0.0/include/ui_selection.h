#ifndef UI_SELECTION_H
#define UI_SELECTION_H

/*
 * UIR Selection Domain.
 * 统一管理 Editor 选中状态，不复制节点数据，只保存 Node ID。
 */
#include <stdbool.h>
#include "uim_component_manager.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct uim_Selection uim_Selection;

#define uim_SELECTION_MAX_NODES 64

/* 创建/销毁 */
uim_Selection* uim_selection_create(void);
void uim_selection_destroy(uim_Selection *sel);

/* 主选中节点（最后加入的那个），uim_NODE_INVALID 表示无选中 */
uim_NodeId uim_selection_get(const uim_Selection *sel);

/* 设置为唯一选中（清空其他） */
void uim_selection_set(uim_Selection *sel, uim_NodeId node_id);

/* 加选（去重；新节点成为主选中） */
void uim_selection_add(uim_Selection *sel, uim_NodeId node_id);

/* 减选；若减掉的是主选中，主选中回落到剩余集合的最后一个 */
void uim_selection_remove(uim_Selection *sel, uim_NodeId node_id);

/* 有则减、无则加 */
void uim_selection_toggle(uim_Selection *sel, uim_NodeId node_id);

bool uim_selection_contains(const uim_Selection *sel, uim_NodeId node_id);
int  uim_selection_count(const uim_Selection *sel);
uim_NodeId uim_selection_get_at(const uim_Selection *sel, int index);

/* 清除选中状态 */
void uim_selection_clear(uim_Selection *sel);

/* 是否有选中 */
bool uim_selection_has_selection(const uim_Selection *sel);

/* 监听者数量限制（预留多选扩展） */
#define uim_SELECTION_MAX_LISTENERS 4

/* 选择变化回调（预留，当前暂不使用） */
typedef void (*uim_SelectionChangedCallback)(uim_NodeId old_id, uim_NodeId new_id, void *userdata);

#ifdef __cplusplus
}
#endif
#endif
