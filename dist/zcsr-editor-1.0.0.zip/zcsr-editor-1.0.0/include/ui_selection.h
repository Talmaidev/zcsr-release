#ifndef UI_SELECTION_H
#define UI_SELECTION_H

/*
 * Compatibility forwarder.
 *
 * Selection state is owned by UIM (uim_selection.h) since 2026-11-24: the type
 * already used the uim_ prefix and both editor and runtime need it, so it must
 * not be implemented inside the editor. This header keeps the old include path
 * working for editor sources and tests; do not add code here.
 */
#include "uim_selection.h"

#endif
