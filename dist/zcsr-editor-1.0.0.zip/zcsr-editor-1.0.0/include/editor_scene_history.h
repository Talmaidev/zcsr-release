#ifndef ZCSR_EDITOR_SCENE_HISTORY_H
#define ZCSR_EDITOR_SCENE_HISTORY_H

/* C11 scene undo/redo history.
 *
 * The history stores only document content (entities + quad overrides), never
 * the camera or viewport size.  Undo/redo therefore restores layout without
 * resetting the user's current camera.  next_id is also preserved separately
 * by the scene and is intentionally not rewound.
 *
 * A gesture is expressed as begin(scene) -> mutate -> commit(scene).  commit
 * discards the entry when the content did not actually change, so a click that
 * merely focuses an Inspector field does not create an undo step.  cancel()
 * restores the pre-gesture content for Esc.
 */

#include "zcsr/scene.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct zcsr_editor_scene_history zcsr_editor_scene_history;

zcsr_editor_scene_history* zcsr_editor_scene_history_create(void);
void zcsr_editor_scene_history_destroy(zcsr_editor_scene_history* history);

/* Start one gesture.  If another gesture is still pending, it is committed
 * against the current scene first. */
bool zcsr_editor_scene_history_begin(zcsr_editor_scene_history* history,
                                     const zcsr_scene* scene);
/* Push the pre-gesture state only if the content changed. */
bool zcsr_editor_scene_history_commit(zcsr_editor_scene_history* history,
                                      const zcsr_scene* scene);
/* Restore the pre-gesture state and discard the pending entry. */
bool zcsr_editor_scene_history_cancel(zcsr_editor_scene_history* history,
                                      zcsr_scene* scene);

bool zcsr_editor_scene_history_undo(zcsr_editor_scene_history* history,
                                    zcsr_scene* scene);
bool zcsr_editor_scene_history_redo(zcsr_editor_scene_history* history,
                                    zcsr_scene* scene);

void zcsr_editor_scene_history_reset(zcsr_editor_scene_history* history,
                                     const zcsr_scene* scene);
size_t zcsr_editor_scene_history_undo_count(const zcsr_editor_scene_history* history);
size_t zcsr_editor_scene_history_redo_count(const zcsr_editor_scene_history* history);
bool zcsr_editor_scene_history_has_pending(const zcsr_editor_scene_history* history);

/* Stable content hash for dirty tracking.  Includes scene content and camera
 * pose, but excludes camera viewport dimensions, which change on window resize.
 * The editor compares this hash with the hash captured at save/load time. */
uint64_t zcsr_editor_scene_content_hash(const zcsr_scene* scene);

#ifdef __cplusplus
}
#endif

#endif /* ZCSR_EDITOR_SCENE_HISTORY_H */
