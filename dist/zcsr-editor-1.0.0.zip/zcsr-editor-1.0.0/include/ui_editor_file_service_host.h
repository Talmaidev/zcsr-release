﻿#ifndef UI_EDITOR_FILE_SERVICE_HOST_H
#define UI_EDITOR_FILE_SERVICE_HOST_H

/*
 * Host-facing construction API for the UIR File Service adapter.
 *
 * Kept separate from ui_editor_file_service.h so the platform-neutral ABI
 * header stays free of engine types. Only Editor Host wiring includes this.
 */
#include "uim_file_service.h"
#include "zcsr/file_service.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Wrap a ZCSR file service. The returned service is owned by the caller and
 * released with uim_file_service_destroy(). */
uim_FileResult uim_file_service_create_from_zcsr(zcsr_file_service_t *zfs,
                                                   uim_FileService *out_service);

/* Bind project-relative paths to this base directory. Absolute paths and URIs
 * are passed through unchanged. */
uim_FileResult uim_file_service_set_base_path(uim_FileService *service,
                                               const char *utf8_base_path);

void uim_file_service_destroy(uim_FileService *service);

#ifdef __cplusplus
}
#endif
#endif
