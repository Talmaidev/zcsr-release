#ifndef ZCSR_EDITOR_DOMAIN_H
#define ZCSR_EDITOR_DOMAIN_H

/*
 * editor_domain.h — Public umbrella for the renderer-neutral C11 editor domain.
 *
 * This is the stable include a C11 host (e.g. the PVZ editor) consumes. It
 * aggregates the neutral editor domains: document model, selection, hierarchy
 * rows, canvas viewport state, shell layout, project/asset browser, marquee /
 * picking, interaction state machine and the two render-backend operation
 * tables.
 *
 * Boundary rules (see docs/INTEGRATION_API.md):
 *  - No Dear ImGui, no OpenGL/GL context, no OS window, no zcsr_scene model.
 *  - Value types are the plain C vocabulary from the UIM headers
 *    (uim_Rect / uim_NodeId / uim_NodeInfo / uim_Value / ...).
 *  - The document-model backend is pluggable through zcsr_DomainProviderOps.
 *    The bundled default adapter forwards to the existing C11 kernel over an
 *    injected UIM_ComponentManager; a host may supply its own provider over its
 *    own document model instead.
 */

#include "uim_component_manager.h"

#include "ui_editor.h"
#include "ui_selection.h"
#include "ui_hierarchy.h"
#include "ui_editor_interaction.h"
#include "ui_editor_workspace.h"
#include "ui_editor_shell.h"
#include "ui_editor_shell_renderer.h"
#include "ui_editor_shell_persist.h"
#include "ui_editor_viewport_host.h"
#include "ui_project_browser.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ZCSR_DOMAIN_ABI_VERSION 1u

/* ------------------------------------------------------------------------- */
/* Pluggable document-model backend                                          */
/* ------------------------------------------------------------------------- */

/*
 * Provider vtable for the document model, selection, command stack and
 * picking. Every callback receives the `user` pointer supplied at creation.
 *
 * ABI contract:
 *  - All callbacks are synchronous, called on the host editor/UI thread.
 *  - Return uim_OK on success; an uim_ERR_* code on failure.
 *  - Borrowed pointers (desc, ids, out_info) are valid only during the call.
 *  - The provider owns no renderer, window or context; it only reads/writes
 *    its own document model.
 *
 * NULL function pointers are allowed only where noted; the default adapter
 * implements every slot. A custom backend should fill abi_version,
 * struct_size and every slot it supports; unimplemented slots must return
 * uim_ERR_UNSUPPORTED.
 */
typedef struct zcsr_DomainProviderOps {
    uint32_t abi_version;
    uint32_t struct_size;

    /* Document model ----------------------------------------------------- */

    /* Create a node from desc; out_id receives the new provider-local id. */
    uim_Result (*create_node)(void *user, const uim_NodeDesc *desc,
                              uim_NodeId *out_id);
    /* Read the current node snapshot into out_info. */
    uim_Result (*inspect_node)(void *user, uim_NodeId node_id,
                               uim_NodeInfo *out_info);
    /* Replace the node local rectangle (provider records an undo entry). */
    uim_Result (*set_rect)(void *user, uim_NodeId node_id, uim_Rect rect);
    /* Remove the node (provider records an undo entry). */
    uim_Result (*delete_node)(void *user, uim_NodeId node_id);

    /* Selection ----------------------------------------------------------- */

    /* Borrowed view over the current selection; ids valid until the next
     * provider mutation. count 0 means empty selection. */
    uim_Result (*get_selection)(void *user, const uim_NodeId **out_ids,
                                 size_t *out_count);
    /* Replace the current selection; ids may be NULL when count is 0. */
    uim_Result (*set_selection)(void *user, const uim_NodeId *ids, size_t count);

    /* Command stack / history -------------------------------------------- */

    uim_Result (*undo)(void *user);
    uim_Result (*redo)(void *user);
    uim_Result (*history_state)(void *user, uim_EditorHistoryState *out_state);

    /* Picking / marquee --------------------------------------------------- */

    /* Hit-test one canvas point; out_node_id receives the topmost hit. */
    uim_Result (*hit_test)(void *user, uim_PageId page_id,
                           float canvas_x, float canvas_y, uim_NodeId *out_node_id);
    /* Select every entity intersecting canvas_rect; additive keeps the current
     * selection. */
    uim_Result (*box_select)(void *user, uim_PageId page_id,
                             uim_Rect canvas_rect, bool additive);
} zcsr_DomainProviderOps;

/* Opaque facade editor. Holds either the default kernel adapter or a custom
 * provider. Storage is heap-owned; destroy releases it. */
typedef struct zcsr_DomainEditor zcsr_DomainEditor;

/* Create the default backend: wraps a uim_Editor over the supplied manager.
 * The manager is not owned; the host keeps it alive until destroy returns. */
uim_Result zcsr_domain_editor_create_default(UIM_ComponentManager *manager,
                                              size_t history_capacity,
                                              zcsr_DomainEditor **out_editor);

/* Create a facade over a custom provider. `ops` must outlive the editor.
 * `user` is forwarded to every provider callback. */
uim_Result zcsr_domain_editor_create(const zcsr_DomainProviderOps *ops,
                                      void *user,
                                      zcsr_DomainEditor **out_editor);

void zcsr_domain_editor_destroy(zcsr_DomainEditor *editor);

/* Facade dispatch ----------------------------------------------------------- */

uim_Result zcsr_domain_create_node(zcsr_DomainEditor *editor,
                                    const uim_NodeDesc *desc,
                                    uim_NodeId *out_id);
uim_Result zcsr_domain_inspect_node(zcsr_DomainEditor *editor,
                                    uim_NodeId node_id, uim_NodeInfo *out_info);
uim_Result zcsr_domain_set_rect(zcsr_DomainEditor *editor,
                                 uim_NodeId node_id, uim_Rect rect);
uim_Result zcsr_domain_delete_node(zcsr_DomainEditor *editor, uim_NodeId node_id);

uim_Result zcsr_domain_get_selection(zcsr_DomainEditor *editor,
                                      const uim_NodeId **out_ids,
                                      size_t *out_count);
uim_Result zcsr_domain_set_selection(zcsr_DomainEditor *editor,
                                     const uim_NodeId *ids, size_t count);

uim_Result zcsr_domain_undo(zcsr_DomainEditor *editor);
uim_Result zcsr_domain_redo(zcsr_DomainEditor *editor);
uim_Result zcsr_domain_history_state(zcsr_DomainEditor *editor,
                                     uim_EditorHistoryState *out_state);

uim_Result zcsr_domain_hit_test(zcsr_DomainEditor *editor, uim_PageId page_id,
                                 float canvas_x, float canvas_y,
                                 uim_NodeId *out_node_id);
uim_Result zcsr_domain_box_select(zcsr_DomainEditor *editor, uim_PageId page_id,
                                  uim_Rect canvas_rect, bool additive);

/* Access the wrapped kernel editor. Returns NULL for a custom-provider
 * facade. Hosts on the default backend may call the uir_editor_* canvas /
 * gesture / overlay APIs through this pointer; custom backends own their own
 * viewport and picking implementation. */
uim_Editor *zcsr_domain_editor_kernel(zcsr_DomainEditor *editor);

#ifdef __cplusplus
}
#endif
#endif /* ZCSR_EDITOR_DOMAIN_H */
