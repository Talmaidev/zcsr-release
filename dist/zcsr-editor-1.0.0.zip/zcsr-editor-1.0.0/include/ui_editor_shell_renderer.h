#ifndef UI_EDITOR_SHELL_RENDERER_H
#define UI_EDITOR_SHELL_RENDERER_H

/* Generic Shell frame renderer dispatch. No graphics/platform headers. */
#include "ui_editor_shell.h"
#include "ui_editor_provider.h"

#ifdef __cplusplus
extern "C" {
#endif

#define uim_EDITOR_SHELL_RENDER_ABI_VERSION 1u

typedef struct uim_EditorShellRenderOps {
    uint32_t abi_version;
    uint32_t struct_size;
    uim_Result (*begin_frame)(void *user, void *renderer_context,
                              const uim_EditorShellFrame *frame,
                              const uim_EditorShellTheme *theme);
    /* Draw one Shell element. The backend owns clipping and actual pixels.
     * CENTER_HOST should draw only its background/border; the external view
     * renderer is invoked immediately afterward by this dispatcher. */
    uim_Result (*draw_element)(void *user, void *renderer_context,
                               const uim_EditorShellElement *element,
                               const uim_EditorShellTheme *theme);
    /* Draw selection/gizmos immediately after the center view, before later
     * z_order elements (floating panels and popups) are painted above it. */
    uim_Result (*draw_center_overlay)(void *user, void *renderer_context,
                                      const uim_EditorShellFrame *frame,
                                      const uim_EditorShellElement *center_element);
    uim_Result (*end_frame)(void *user, void *renderer_context);
} uim_EditorShellRenderOps;

/* Dispatch a complete Shell frame in stable ascending z_order. For the center
 * host, the backend paints the slot, then the selected external provider is
 * asked to render there. Native-child providers are already visible as child
 * surfaces and therefore perform no renderer callback. Does NOT begin/present
 * any platform frame unless the supplied backend chooses to do so. */
uim_Result uir_editor_shell_render_frame(
    const uim_EditorShellFrame *frame,
    const uim_EditorShellTheme *theme,
    uim_ExternalViewManager *external_views,
    void *renderer_context,
    const uim_EditorShellRenderOps *ops,
    void *user);

#ifdef __cplusplus
}
#endif
#endif
