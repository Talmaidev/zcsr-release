#ifndef ZCSR_EDITOR_SCENE_AUTHORING_H
#define ZCSR_EDITOR_SCENE_AUTHORING_H

/* C11 scene authoring commands.
 *
 * The editor shell owns presentation and input mapping. This module owns the
 * mutations that change a `zcsr_scene`: add, duplicate, delete, move and quad
 * editing. Read-only queries stay in `zcsr/scene.h`.
 *
 * The module is UI-toolkit neutral. It does not know about Dear ImGui, windows,
 * selection widgets or undo presentation. A command result reports whether the
 * scene changed and which entity should become the caller's selection. */

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "zcsr/scene.h"

typedef struct zcsr_editor_scene_change {
    bool changed;
    zcsr_entity_id id; /* new/remaining selection; 0 means clear selection */
} zcsr_editor_scene_change;

/* Adds a centered box at x/z with width/height and tint. */
zcsr_editor_scene_change zcsr_editor_scene_add_box(zcsr_scene *scene,
                                                   float x, float z,
                                                   float w, float h,
                                                   float r, float g, float b);

/* Adds a sprite entity that points at a registered asset. The asset registry
 * owns the path and kind; the scene only stores stable ids. */
zcsr_editor_scene_change zcsr_editor_scene_add_asset(zcsr_scene *scene,
                                                     float x, float z,
                                                     float w, float h,
                                                     uint32_t kind,
                                                     uint64_t prefab_id,
                                                     uint64_t asset_id);

/* Sets yaw rotation in degrees and width/height. */
bool zcsr_editor_scene_set_rotation(zcsr_scene *scene, zcsr_entity_id id,
                                    float rotation_deg);
bool zcsr_editor_scene_set_size(zcsr_scene *scene, zcsr_entity_id id,
                                float w, float h);
bool zcsr_editor_scene_set_asset_ref(zcsr_scene *scene, zcsr_entity_id id,
                                     uint32_t kind, uint64_t prefab_id,
                                     uint64_t asset_id);

/* Adds a box and replaces its shape with the editor's default quad. */
zcsr_editor_scene_change zcsr_editor_scene_add_quad(zcsr_scene *scene,
                                                    float x, float z,
                                                    float size,
                                                    float r, float g, float b);

/* Copies the entity, offsets x/z, gives it a new id and copies any quad. */
zcsr_editor_scene_change zcsr_editor_scene_duplicate(zcsr_scene *scene,
                                                     zcsr_entity_id id,
                                                     float dx, float dz);

/* Removes the entity. Always clears selection on success. */
zcsr_editor_scene_change zcsr_editor_scene_delete(zcsr_scene *scene,
                                                  zcsr_entity_id id);

/* Moves the entity by a world-space delta. */
bool zcsr_editor_scene_move(zcsr_scene *scene, zcsr_entity_id id,
                            float dx, float dz);
bool zcsr_editor_scene_set_y(zcsr_scene *scene, zcsr_entity_id id, float y);

/* Replaces all four corners. Rejects missing entities and non-finite points. */
bool zcsr_editor_scene_set_quad(zcsr_scene *scene, zcsr_entity_id id,
                                const zcsr_scene_point quad[4]);

/* Moves one explicit-quad corner. `corner` is 0..3. */
bool zcsr_editor_scene_set_corner(zcsr_scene *scene, zcsr_entity_id id,
                                  int corner, float x, float y, float z);

/* Drops the explicit quad and returns to the rectangle shape. */
bool zcsr_editor_scene_clear_quad(zcsr_scene *scene, zcsr_entity_id id);

#ifdef __cplusplus
}
#endif

#endif /* ZCSR_EDITOR_SCENE_AUTHORING_H */
