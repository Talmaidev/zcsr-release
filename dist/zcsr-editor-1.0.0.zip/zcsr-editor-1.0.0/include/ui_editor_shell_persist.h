#ifndef UI_EDITOR_SHELL_PERSIST_H
#define UI_EDITOR_SHELL_PERSIST_H

#include "ui_editor_shell.h"

#ifdef __cplusplus
extern "C" {
#endif

#define uim_EDITOR_SHELL_LAYOUT_FORMAT_MAJOR 1u
#define uim_EDITOR_SHELL_LAYOUT_FORMAT_MINOR 0u

/* Portable little-endian, versioned, CRC-protected layout blob. The host owns
 * the file I/O; this module only encodes/decodes bytes. No raw C struct dumps. */
size_t uir_editor_shell_layout_serialized_size(void);
uim_Result uir_editor_shell_layout_save(const uim_EditorShell *shell,
                                        void *buffer, size_t capacity,
                                        size_t *out_written);
uim_Result uir_editor_shell_layout_load(uim_EditorShell *shell,
                                        const void *buffer, size_t size);

#ifdef __cplusplus
}
#endif
#endif
