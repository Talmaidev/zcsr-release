#ifndef EDITOR_HOST_H
#define EDITOR_HOST_H

/*
 * editor_host.h — the editor's platform host boundary.
 *
 * The editor document/authoring layer never includes OS headers. It asks this
 * C ABI for the few desktop operations that cannot come from zcsr core:
 * native file pickers, unsaved-confirm UI, process launch, and the executable
 * path. Each platform implements this file once (Win32 / Cocoa / X11-GTK).
 *
 * This is deliberately not a second window, main loop, or renderer. The
 * runtime shell still owns the only OS window and keeps pumping input.
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct zcsr_surface zcsr_surface;

typedef enum editor_host_unsaved_choice {
    EDITOR_HOST_UNSAVED_CANCEL = 0,
    EDITOR_HOST_UNSAVED_SAVE = 1,
    EDITOR_HOST_UNSAVED_DISCARD = 2
} editor_host_unsaved_choice;

typedef struct editor_host editor_host;

/* Attach to the runtime shell's existing surface. Does not create a window. */
editor_host* editor_host_create(zcsr_surface* surface);
void editor_host_destroy(editor_host* host);

/* Native open/save dialogs. extension is without the dot, e.g. "uireproj".
 * out_path receives a UTF-8 NUL-terminated path. Returns false on cancel or
 * host failure. */
bool editor_host_open_file(editor_host* host,
                           const char* title,
                           const char* extension,
                           char* out_path,
                           size_t out_capacity);
bool editor_host_save_file(editor_host* host,
                           const char* title,
                           const char* extension,
                           const char* suggested_name,
                           char* out_path,
                           size_t out_capacity);

/* One unsaved-changes decision. The caller owns the actual save. */
editor_host_unsaved_choice editor_host_confirm_unsaved(editor_host* host,
                                                       const char* title,
                                                       const char* message);

/* UTF-8 path of the running editor executable. */
bool editor_host_executable_path(editor_host* host, char* out_path, size_t out_capacity);

/* Run a command and capture combined stdout/stderr. output is always
 * NUL-terminated when output_capacity > 0. Returns false only when the process
 * could not be started. */
bool editor_host_run_process(editor_host* host,
                             const char* command,
                             const char* working_dir,
                             char* output,
                             size_t output_capacity,
                             int* out_exit_code);

/* Start a process without waiting for it. */
bool editor_host_launch_process(editor_host* host,
                                const char* command,
                                const char* working_dir);

#ifdef __cplusplus
}
#endif

#endif /* EDITOR_HOST_H */