#ifndef UI_EDITOR_SHELL_H
#define UI_EDITOR_SHELL_H

#include "ui_editor_workspace.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * UIR Editor Shell v0.9
 * Renderer-neutral, fixed-capacity C editor shell.
 *
 * Ownership rules:
 * - The application owns the one native Editor Main Window and its renderer.
 * - This module owns only logical workspace/layout/command/panel state.
 * - Floating panels are internal overlay panels, never native OS windows.
 * - Scene/Game are protected center-host tabs, never floatable or closable.
 * - Engine rendering is hosted separately through an Engine Viewport adapter.
 *
 * All strings in descriptors are borrowed and must outlive the shell.
 * No heap allocation is performed by this module.
 */

#define uim_EDITOR_SHELL_ABI_VERSION       1u
#define uim_EDITOR_SHELL_MAX_PANELS        uim_WORKSPACE_MAX_PANELS
#define uim_EDITOR_SHELL_MAX_COMMANDS      64u
#define uim_EDITOR_SHELL_MAX_FLOATING      8u
#define uim_EDITOR_SHELL_MAX_ELEMENTS      384u
#define uim_EDITOR_SHELL_EVENT_CAPACITY    64u
#define uim_EDITOR_SHELL_MAX_MENU_ITEMS    24u
#define uim_EDITOR_SHELL_TAB_CLOSE_SIZE    18.0f
#define uim_EDITOR_SHELL_FLOAT_TITLE_H     28.0f
#define uim_EDITOR_SHELL_FLOAT_GRIP        14.0f

/* Stable panel IDs. Custom IDs must be >= uim_WORKSPACE_PANEL_CUSTOM_BASE. */
#define uim_WORKSPACE_PANEL_DEVICE_SIMULATOR 9u
#define uim_WORKSPACE_PANEL_PROFILER        10u
#define uim_WORKSPACE_PANEL_CUSTOM_BASE     1024u

typedef uint32_t uim_ShellCommandId;
typedef uint32_t uim_ShellMenuId;

typedef enum uim_ShellPanelFlags {
    uim_SHELL_PANEL_CLOSEABLE = 1u << 0,
    uim_SHELL_PANEL_FLOATABLE = 1u << 1,
    uim_SHELL_PANEL_HIDDEN_BY_DEFAULT = 1u << 2,
    uim_SHELL_PANEL_CENTER_HOST = 1u << 3,
    uim_SHELL_PANEL_SINGLETON = 1u << 4
} uim_ShellPanelFlags;

typedef struct uim_EditorShellPanelDesc {
    uim_WorkspacePanelId id;
    const char *title;
    float min_width;
    float min_height;
    uint32_t flags;
    uim_WorkspacePanelId default_target_panel;
    uim_WorkspaceDockZone default_dock_zone;
    float default_float_width;
    float default_float_height;
} uim_EditorShellPanelDesc;

typedef enum uim_ShellMenu {
    uim_SHELL_MENU_NONE = 0,
    uim_SHELL_MENU_FILE = 1,
    uim_SHELL_MENU_EDIT = 2,
    uim_SHELL_MENU_ASSETS = 3,
    uim_SHELL_MENU_WINDOW = 4,
    uim_SHELL_MENU_HELP = 5
} uim_ShellMenu;

typedef enum uim_ShellCommandFlags {
    uim_SHELL_COMMAND_MENU = 1u << 0,
    uim_SHELL_COMMAND_TOOLBAR = 1u << 1,
    uim_SHELL_COMMAND_SEPARATOR_BEFORE = 1u << 2,
    uim_SHELL_COMMAND_CHECKABLE = 1u << 3,
    uim_SHELL_COMMAND_ENABLED = 1u << 4
} uim_ShellCommandFlags;

typedef enum uim_ShellModifier {
    uim_SHELL_MOD_NONE  = 0,
    uim_SHELL_MOD_CTRL  = 1u << 0,
    uim_SHELL_MOD_SHIFT = 1u << 1,
    uim_SHELL_MOD_ALT   = 1u << 2
} uim_ShellModifier;

#define uim_SHELL_KEY_DELETE 0x10001u
#define uim_SHELL_KEY_ESCAPE 0x10002u
#define uim_SHELL_KEY_ENTER  0x10003u
#define uim_SHELL_KEY_F1     0x10011u
#define uim_SHELL_KEY_F5     0x10015u

typedef struct uim_EditorShellCommandDesc {
    uim_ShellCommandId id;
    const char *label;
    uim_ShellMenuId menu_id;
    uint32_t flags;
    uint32_t shortcut_key; /* ASCII uppercase or uim_SHELL_KEY_* */
    uint32_t shortcut_modifiers;
    uint16_t toolbar_group;
} uim_EditorShellCommandDesc;

typedef enum uim_ShellTool {
    uim_SHELL_TOOL_SELECT = 1,
    uim_SHELL_TOOL_MOVE = 2,
    uim_SHELL_TOOL_RESIZE = 3
} uim_ShellTool;

typedef enum uim_ShellElementKind {
    uim_SHELL_ELEMENT_MENU_BAR = 1,
    uim_SHELL_ELEMENT_MENU_HEADER,
    uim_SHELL_ELEMENT_MENU_POPUP,
    uim_SHELL_ELEMENT_MENU_ITEM,
    uim_SHELL_ELEMENT_TOOLBAR,
    uim_SHELL_ELEMENT_TOOL_BUTTON,
    uim_SHELL_ELEMENT_DOCK_PANEL,
    uim_SHELL_ELEMENT_PANEL_HEADER,
    uim_SHELL_ELEMENT_PANEL_TAB,
    uim_SHELL_ELEMENT_TAB_CLOSE,
    uim_SHELL_ELEMENT_SPLITTER,
    uim_SHELL_ELEMENT_CENTER_HOST,
    uim_SHELL_ELEMENT_STATUS_BAR,
    uim_SHELL_ELEMENT_FLOAT_PANEL,
    uim_SHELL_ELEMENT_FLOAT_TITLE,
    uim_SHELL_ELEMENT_FLOAT_CLOSE,
    uim_SHELL_ELEMENT_FLOAT_RESIZE,
    uim_SHELL_ELEMENT_DOCK_DROP_PREVIEW
} uim_ShellElementKind;

typedef enum uim_ShellStyleToken {
    uim_SHELL_STYLE_NONE = 0,
    uim_SHELL_STYLE_ROOT,
    uim_SHELL_STYLE_MENU,
    uim_SHELL_STYLE_MENU_HOVER,
    uim_SHELL_STYLE_TOOLBAR,
    uim_SHELL_STYLE_BUTTON,
    uim_SHELL_STYLE_BUTTON_ACTIVE,
    uim_SHELL_STYLE_PANEL,
    uim_SHELL_STYLE_PANEL_HEADER,
    uim_SHELL_STYLE_TAB,
    uim_SHELL_STYLE_TAB_ACTIVE,
    uim_SHELL_STYLE_BORDER,
    uim_SHELL_STYLE_SPLITTER,
    uim_SHELL_STYLE_VIEWPORT,
    uim_SHELL_STYLE_STATUS,
    uim_SHELL_STYLE_FLOATING,
    uim_SHELL_STYLE_DROP_TARGET,
    uim_SHELL_STYLE_TEXT,
    uim_SHELL_STYLE_TEXT_DIM,
    uim_SHELL_STYLE_ACCENT
} uim_ShellStyleToken;

typedef struct uim_ShellColor {
    float r, g, b, a;
} uim_ShellColor;

typedef struct uim_EditorShellTheme {
    uint32_t theme_id;
    uim_ShellColor root;
    uim_ShellColor menu;
    uim_ShellColor toolbar;
    uim_ShellColor panel;
    uim_ShellColor panel_header;
    uim_ShellColor button;
    uim_ShellColor button_active;
    uim_ShellColor tab;
    uim_ShellColor tab_active;
    uim_ShellColor border;
    uim_ShellColor splitter;
    uim_ShellColor viewport;
    uim_ShellColor status;
    uim_ShellColor floating;
    uim_ShellColor drop_target;
    uim_ShellColor text;
    uim_ShellColor text_dim;
    uim_ShellColor accent;
    float menu_height;
    float toolbar_height;
    float status_height;
    float panel_header_height;
    float tab_height;
    float splitter_size;
    float spacing;
} uim_EditorShellTheme;

typedef struct uim_EditorShellElement {
    uim_ShellElementKind kind;
    uim_ShellStyleToken style;
    uim_Rect rect;
    uim_WorkspacePanelId panel_id;
    uim_ShellCommandId command_id;
    uim_ShellMenuId menu_id;
    const char *label; /* borrowed from panel/command descriptors */
    uint32_t flags;
    uint16_t z_order;
} uim_EditorShellElement;

typedef struct uim_EditorShellFrame {
    uim_WorkspaceFrame workspace;
    uim_EditorShellElement elements[uim_EDITOR_SHELL_MAX_ELEMENTS];
    size_t element_count;
    uim_Rect center_host_rect;
    uim_WorkspaceViewportMode viewport_mode;
    uim_WorkspacePanelId active_center_panel;
    uint32_t layout_revision;
    uint32_t dropped_elements;
} uim_EditorShellFrame;

typedef enum uim_ShellEventType {
    uim_SHELL_EVENT_NONE = 0,
    uim_SHELL_EVENT_COMMAND,
    uim_SHELL_EVENT_PANEL_SHOWN,
    uim_SHELL_EVENT_PANEL_HIDDEN,
    uim_SHELL_EVENT_PANEL_FLOATED,
    uim_SHELL_EVENT_PANEL_DOCKED,
    uim_SHELL_EVENT_VIEW_CHANGED,
    uim_SHELL_EVENT_LAYOUT_CHANGED
} uim_ShellEventType;

typedef struct uim_EditorShellEvent {
    uim_ShellEventType type;
    uim_ShellCommandId command_id;
    uim_WorkspacePanelId panel_id;
    uim_WorkspaceViewportMode viewport_mode;
    uint32_t layout_revision;
} uim_EditorShellEvent;

typedef struct uim_EditorShellFloatingPanel {
    uim_WorkspacePanelId panel_id;
    uim_Rect rect;
    uint16_t z_order;
    bool open;
} uim_EditorShellFloatingPanel;

typedef struct uim_EditorShellPanelState {
    uim_EditorShellPanelDesc desc;
    bool registered;
} uim_EditorShellPanelState;

typedef enum uim_EditorShellLayoutPreset {
    uim_SHELL_LAYOUT_DEFAULT = 1,
    uim_SHELL_LAYOUT_WIDE_VIEWPORT = 2,
    uim_SHELL_LAYOUT_UI_AUTHORING = 3,
    uim_SHELL_LAYOUT_DEBUG = 4
} uim_EditorShellLayoutPreset;

typedef enum uim_ShellCapture {
    uim_SHELL_CAPTURE_NONE = 0,
    uim_SHELL_CAPTURE_SPLITTER,
    uim_SHELL_CAPTURE_TAB,
    uim_SHELL_CAPTURE_FLOAT_MOVE,
    uim_SHELL_CAPTURE_FLOAT_RESIZE,
    uim_SHELL_CAPTURE_MENU_HEADER,
    uim_SHELL_CAPTURE_MENU_ITEM,
    uim_SHELL_CAPTURE_TOOL_BUTTON,
    uim_SHELL_CAPTURE_TAB_CLOSE,
    uim_SHELL_CAPTURE_FLOAT_CLOSE
} uim_ShellCapture;

typedef struct uim_EditorShell {
    uim_Workspace workspace;
    uim_WorkspaceFrame workspace_frame;
    uim_EditorShellPanelState panels[uim_EDITOR_SHELL_MAX_PANELS];
    size_t panel_count;
    uim_EditorShellCommandDesc commands[uim_EDITOR_SHELL_MAX_COMMANDS];
    size_t command_count;
    uim_EditorShellFloatingPanel floating[uim_EDITOR_SHELL_MAX_FLOATING];
    size_t floating_count;
    uim_EditorShellTheme theme;
    uim_EditorShellEvent events[uim_EDITOR_SHELL_EVENT_CAPACITY];
    size_t event_head;
    size_t event_count;
    uint32_t dropped_events;
    uim_ShellMenuId open_menu;
    uim_ShellCapture capture;
    uim_WorkspacePanelId capture_panel;
    uim_ShellCommandId capture_command;
    uim_Rect capture_rect;
    int16_t capture_float_index;
    float pointer_down_x, pointer_down_y;
    float pointer_x, pointer_y;
    float float_origin_x, float_float_origin_y;
    uim_Rect float_origin_rect;
    bool drag_started;
    uim_WorkspacePanelId drag_panel;
    uim_WorkspacePanelId drop_target_panel;
    uim_WorkspaceDockZone drop_zone;
    uim_ShellTool active_tool;
    bool grid_enabled;
    bool snap_enabled;
    bool focused;
    bool center_maximized;
    uim_WorkspaceNode saved_nodes[uim_WORKSPACE_MAX_NODES];
    uim_WorkspaceNodeId saved_root;
    uim_WorkspaceViewportMode saved_viewport_mode;
    uim_EditorShellFloatingPanel saved_floating[uim_EDITOR_SHELL_MAX_FLOATING];
    uint32_t layout_revision;
} uim_EditorShell;

/* Stable built-in command IDs. Hosts execute external commands from the event queue. */
enum {
    uim_SHELL_CMD_NEW_DOCUMENT = 1,
    uim_SHELL_CMD_OPEN_DOCUMENT,
    uim_SHELL_CMD_SAVE_DOCUMENT,
    uim_SHELL_CMD_SAVE_AS,
    uim_SHELL_CMD_EXIT,
    uim_SHELL_CMD_UNDO = 16,
    uim_SHELL_CMD_REDO,
    uim_SHELL_CMD_DUPLICATE,
    uim_SHELL_CMD_DELETE,
    uim_SHELL_CMD_GRID,
    uim_SHELL_CMD_SNAP,
    uim_SHELL_CMD_SELECT_TOOL = 24,
    uim_SHELL_CMD_MOVE_TOOL,
    uim_SHELL_CMD_RESIZE_TOOL,
    uim_SHELL_CMD_ZOOM_IN,
    uim_SHELL_CMD_ZOOM_OUT,
    uim_SHELL_CMD_VIEW_FIT,
    uim_SHELL_CMD_SWITCH_SCENE_GAME,
    uim_SHELL_CMD_IMPORT_ASSETS = 40,
    uim_SHELL_CMD_BUILD,
    uim_SHELL_CMD_PLAY,
    uim_SHELL_CMD_STOP,
    uim_SHELL_CMD_SHOW_PALETTE = 64,
    uim_SHELL_CMD_SHOW_HIERARCHY,
    uim_SHELL_CMD_SHOW_INSPECTOR,
    uim_SHELL_CMD_SHOW_PROJECT,
    uim_SHELL_CMD_SHOW_ASSETS,
    uim_SHELL_CMD_SHOW_CONSOLE,
    uim_SHELL_CMD_SHOW_DEVICE_SIMULATOR,
    uim_SHELL_CMD_SHOW_PROFILER,
    uim_SHELL_CMD_RESET_LAYOUT,
    uim_SHELL_CMD_ABOUT = 96,
    uim_SHELL_CMD_LAYOUT_WIDE = 97,
    uim_SHELL_CMD_LAYOUT_UI_AUTHORING = 98,
    uim_SHELL_CMD_LAYOUT_DEBUG = 99,
    uim_SHELL_CMD_MAXIMIZE_CENTER = 100
};

/* Initialize the complete default ZCSR dark editor layout and built-in menus. */
uim_Result uir_editor_shell_init_default(uim_EditorShell *shell,
                                         float client_width,
                                         float client_height);
uim_Result uir_editor_shell_set_bounds(uim_EditorShell *shell,
                                       float client_width,
                                       float client_height);
uim_Result uir_editor_shell_build_frame(uim_EditorShell *shell,
                                        uim_EditorShellFrame *out_frame);

/* Extend the shell without changing the renderer or the Engine ABI. */
uim_Result uir_editor_shell_register_panel(uim_EditorShell *shell,
                                            const uim_EditorShellPanelDesc *desc);
uim_Result uir_editor_shell_register_command(uim_EditorShell *shell,
                                              const uim_EditorShellCommandDesc *desc);
uim_Result uir_editor_shell_panel_show(uim_EditorShell *shell,
                                       uim_WorkspacePanelId panel_id);
uim_Result uir_editor_shell_panel_hide(uim_EditorShell *shell,
                                       uim_WorkspacePanelId panel_id);
uim_Result uir_editor_shell_panel_float(uim_EditorShell *shell,
                                        uim_WorkspacePanelId panel_id,
                                        uim_Rect rect);
uim_Result uir_editor_shell_panel_dock(uim_EditorShell *shell,
                                       uim_WorkspacePanelId panel_id,
                                       uim_WorkspacePanelId target_panel_id,
                                       uim_WorkspaceDockZone zone);
uim_Result uir_editor_shell_reset_layout(uim_EditorShell *shell);
uim_Result uir_editor_shell_apply_layout_preset(uim_EditorShell *shell,
                                                 uim_EditorShellLayoutPreset preset);
uim_Result uir_editor_shell_set_center_maximized(uim_EditorShell *shell,
                                                  bool maximized);

/* Pointer coordinates are Editor Main Window client-space coordinates. */
uim_Result uir_editor_shell_pointer_down(uim_EditorShell *shell,
                                         float x, float y,
                                         uint32_t modifiers);
uim_Result uir_editor_shell_pointer_move(uim_EditorShell *shell,
                                         float x, float y);
uim_Result uir_editor_shell_pointer_up(uim_EditorShell *shell,
                                       float x, float y);
uim_Result uir_editor_shell_key_down(uim_EditorShell *shell,
                                     uint32_t key,
                                     uint32_t modifiers);
void uir_editor_shell_set_focus(uim_EditorShell *shell, bool focused);
uim_Result uir_editor_shell_poll_event(uim_EditorShell *shell,
                                       uim_EditorShellEvent *out_event);

uim_Result uir_editor_shell_set_theme(uim_EditorShell *shell,
                                      const uim_EditorShellTheme *theme);
void uir_editor_shell_theme_dark(uim_EditorShellTheme *out_theme);
uim_Result uir_editor_shell_get_center_host(const uim_EditorShell *shell,
                                            uim_Rect *out_rect,
                                            uim_WorkspaceViewportMode *out_mode);
const uim_EditorShellTheme *uir_editor_shell_get_theme(const uim_EditorShell *shell);
const uim_Workspace *uir_editor_shell_get_workspace(const uim_EditorShell *shell);
uim_Workspace *uir_editor_shell_get_workspace_mut(uim_EditorShell *shell);

#ifdef __cplusplus
}
#endif
#endif
