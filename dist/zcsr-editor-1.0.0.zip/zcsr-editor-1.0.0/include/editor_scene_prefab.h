#ifndef ZCSR_EDITOR_SCENE_PREFAB_H
#define ZCSR_EDITOR_SCENE_PREFAB_H

/* C11 prefab file workflow for the editor's 2.5D scene.
 *
 * A prefab is a normal `.uiscene` file containing one or more entities. No
 * second schema is introduced: save uses `editor_scene_io`, instantiate uses
 * the same loader. The editor only adds the stable `prefab_id` and
 * `ZCSR_SCENE_KIND_PREFAB` marker so a scene record can point back to its
 * source. The scene list does not interpret prefab contents.
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "zcsr/scene.h"

/* Stable FNV-1a path identity, never 0. */
uint64_t zcsr_editor_prefab_id_from_path(const char *utf8_path);

/* Saves `source_id` (and its quad, if any) as a prefab file. The file is a
 * normal `.uiscene` with the entity marked as `ZCSR_SCENE_KIND_PREFAB`.
 * Returns false for a missing entity, non-finite data or IO failure. */
bool zcsr_editor_prefab_save_entity(const zcsr_scene *scene,
                                    zcsr_entity_id source_id,
                                    const char *utf8_path,
                                    uint64_t *out_prefab_id);

/* Loads the prefab file and appends every entity, offset so the prefab root
 * lands at (x, z). The original prefab entity positions are preserved as
 * relative offsets. Writes up to `capacity` ids to `out_ids`; returns the
 * number of entities added. On partial failure all added entities are removed. */
size_t zcsr_editor_prefab_instantiate(zcsr_scene *scene,
                                      const char *utf8_path,
                                      float x, float z,
                                      zcsr_entity_id *out_ids,
                                      size_t capacity,
                                      uint64_t *out_prefab_id);

#ifdef __cplusplus
}
#endif

#endif /* ZCSR_EDITOR_SCENE_PREFAB_H */
