#ifndef UI_EDITOR_COMPONENT_REGISTRY_H
#define UI_EDITOR_COMPONENT_REGISTRY_H

/* Compatibility include only. The component descriptor ABI is owned by UIM.
 * New code must include <uim_component_registry.h> directly. */
#include "uim_component_registry.h"

#endif /* UI_EDITOR_COMPONENT_REGISTRY_H */
