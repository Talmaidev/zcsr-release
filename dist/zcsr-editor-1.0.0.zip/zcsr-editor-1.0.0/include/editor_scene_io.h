#ifndef ZCSR_EDITOR_SCENE_IO_H
#define ZCSR_EDITOR_SCENE_IO_H

 /* C11 owner of the editor scene text format (`.uiscene` and the scene
 * section embedded in `.uiproj`).
 *
 * This module owns serialization and parsing only. It does not own the
 * editor window, the scene UI, selection, undo or the runtime.
 *
 * File shape v2:
 *   ZCSRSCENE 2
 *   camera <8 floats> <view_w int> <view_h int>
 *   entity <id> <8 floats> <layer int> <order int> <4 tint floats>
 *          <texture uint> <visible int> <kind uint> <prefab u64> <asset u64>
 *   quad   <id> <12 floats>
 *
 * V1 files remain loadable (camera has only view_w; entity has no kind/prefab/
 * asset fields). `quad` lines follow the `entity` line they override. Unknown,
 * duplicate or incomplete records are rejected; load is transactional and
 * leaves the caller's scene untouched on failure. Save is atomic (`.tmp` +
 * rename) so a crash cannot truncate the previous scene. */

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "zcsr/scene.h"

typedef enum zcsr_editor_scene_io_result {
    ZCSR_EDITOR_SCENE_IO_OK = 0,
    ZCSR_EDITOR_SCENE_IO_INVALID_ARGUMENT,
    ZCSR_EDITOR_SCENE_IO_OPEN_FAILED,
    ZCSR_EDITOR_SCENE_IO_BAD_HEADER,
    ZCSR_EDITOR_SCENE_IO_BAD_RECORD,
    ZCSR_EDITOR_SCENE_IO_CAPACITY,
    ZCSR_EDITOR_SCENE_IO_IO_ERROR
} zcsr_editor_scene_io_result;

/* Saves the full scene, including camera and explicit quad overrides. */
zcsr_editor_scene_io_result zcsr_editor_scene_save(const zcsr_scene *scene,
                                                   const char *utf8_path);

/* In-memory form used by the single `.uiproj` container and by tests. The
 * caller owns *out_text and must free() it. */
zcsr_editor_scene_io_result zcsr_editor_scene_serialize(const zcsr_scene *scene,
                                                        char **out_text,
                                                        size_t *out_size);

/* Loads from bytes, transactionally. */
zcsr_editor_scene_io_result zcsr_editor_scene_deserialize(const char *text,
                                                          size_t size,
                                                          zcsr_scene *scene);

/* Loads into a temporary scene and copies into `scene` only on success. */
zcsr_editor_scene_io_result zcsr_editor_scene_load(zcsr_scene *scene,
                                                   const char *utf8_path);

/* Stable diagnostic spelling for logs and tests. Never returns NULL. */
const char *zcsr_editor_scene_io_result_name(zcsr_editor_scene_io_result result);

#ifdef __cplusplus
}
#endif

#endif /* ZCSR_EDITOR_SCENE_IO_H */
