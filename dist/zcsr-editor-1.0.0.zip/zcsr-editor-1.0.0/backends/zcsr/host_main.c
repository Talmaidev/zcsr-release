/* host_main.c — ZCSR Editor host entry.
 *
 * The editor is authoring-only. Packaged player.exe is built by
 * zcsr_runtime/player and is not this executable. */

#include <stdio.h>
#include <string.h>

#if defined(_WIN32)
#  include <windows.h>
#endif

extern void runtime(void);

#if defined(_WIN32)
/* 双击 exe 时 Windows 会给控制台子系统程序新建一个控制台窗口：它会盖在编辑器
 * 上面并抢走键盘焦点，让“点开就打字”变成点开没反应。仅当这个控制台是本进程
 * 独占（不是从 cmd/PowerShell 继承）时才隐藏它，日志仍然写进 stdout。 */
static void host_hide_own_console(void) {
    DWORD owners[8];
    DWORD count;
    HWND console;
    if (GetConsoleWindow() == NULL) return;
    count = GetConsoleProcessList(owners, (DWORD)(sizeof(owners) / sizeof(owners[0])));
    if (count != 1u) return;   /* 继承来的终端：不动用户的窗口 */
    console = GetConsoleWindow();
    if (console != NULL) ShowWindow(console, SW_HIDE);
}
#endif

int main(int argc, char **argv) {
#if defined(_WIN32)
    host_hide_own_console();
#endif
    (void)argc;
    (void)argv;
    runtime();
    return 0;
}
