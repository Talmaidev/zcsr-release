cmake_minimum_required(VERSION 3.16)
project(zcsr_editor LANGUAGES C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(MSVC)
  add_compile_options(/utf-8)
endif()

# Editor is an independent authoring product. It consumes engine/runtime/UIM
# targets; it does not compile engine or UIM sources into its own target.
# Project IO and player runtime live in UIM/runtime, never in this repo.
set(ZCSR_ENGINE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../zero-coupling-signal-router" CACHE PATH "zcsr engine repo")
set(ZCSR_UIM_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../UIM" CACHE PATH "UIM repo")
set(ZCSR_RUNTIME_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../zcsr_runtime" CACHE PATH "zcsr_runtime repo")

set(ZCSR_ENGINE_INCLUDE "${ZCSR_ENGINE_DIR}/include" CACHE PATH "" FORCE)
set(ZCSR_RUNTIME_INCLUDE "${ZCSR_RUNTIME_DIR}/zcsr_runtime_shell/include" CACHE PATH "" FORCE)

enable_testing()
# Editor itself never links page manager; the UIM page-manager target is kept
# in this combined build only for its contract test target.
set(ZCSR_UIM_WITH_PAGE_MANAGER ON CACHE BOOL "Build the optional UIM page manager target" FORCE)
add_subdirectory(${ZCSR_RUNTIME_DIR} "${CMAKE_CURRENT_BINARY_DIR}/zcsr_runtime")


# Editor-only chrome. Dear ImGui (docking branch) is vendored under third_party
# and deliberately not linked by any player/runtime target.
add_library(zcsr_imgui STATIC
    third_party/imgui/imgui.cpp
    third_party/imgui/imgui_draw.cpp
    third_party/imgui/imgui_tables.cpp
    third_party/imgui/imgui_widgets.cpp
    third_party/imgui/backends/imgui_impl_opengl3.cpp)
target_include_directories(zcsr_imgui PUBLIC
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/backends)
if(WIN32)
  target_link_libraries(zcsr_imgui PUBLIC opengl32)
endif()

add_library(zcsr_editor_kernel STATIC
    src/ui_editor.c)
target_include_directories(zcsr_editor_kernel PUBLIC
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(zcsr_editor_kernel PUBLIC zcsr_uim)
if(MSVC)
  target_compile_options(zcsr_editor_kernel PRIVATE /experimental:c11atomics)
endif()

add_executable(zcsr_editor
    backends/zcsr/host_main.c
    src/editor_app.cpp)

target_include_directories(zcsr_editor PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/backends/zcsr
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/backends
    ${ZCSR_ENGINE_DIR}/include
    ${ZCSR_ENGINE_DIR}/third_party/glad/include
    ${ZCSR_UIM_DIR}/include
    ${ZCSR_UIM_DIR}/integrations/zcsr
    ${ZCSR_RUNTIME_DIR}/zcsr_runtime_shell/include)

if(MSVC)
  target_compile_options(zcsr_editor PRIVATE /experimental:c11atomics)
endif()

target_link_libraries(zcsr_editor PRIVATE
    zcsr_imgui
    zcsr_editor_kernel
    zcsr_runtime_shell
    zcsr_uim_project
    zcsr_uim_page_view
    zcsr_uim
    zcsr_uim_zcsr_bridge
    zcsr_ui
    zcsr_glrender
    zcsr_platform
    zcsr_core
    zcsr_font
    zcsr_atlas
    zcsr_image
    zcsr_input
    zcsr_inputext
    zcsr_camera
    zcsr_camera3d
    zcsr_sprite
    zcsr_signal
    zcsr_assets
    zcsr_collision
    zcsr_save
    zcsr_viewport
    zcsr_file_service)

if(WIN32)
  target_link_libraries(zcsr_editor PRIVATE user32 gdi32 opengl32 comdlg32 imm32)
endif()

# Real keyboard contract: drives editor_app.cpp's input + shortcut path with
# ZCSR_KEY_* values, not a headless mapping table.
add_executable(editor_key_contract_test
    tests/test_editor_key_contract.cpp
    src/editor_app.cpp)
target_compile_definitions(editor_key_contract_test PRIVATE ZCSR_EDITOR_KEY_TEST=1)
target_include_directories(editor_key_contract_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/backends/zcsr
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/backends
    ${ZCSR_ENGINE_DIR}/include
    ${ZCSR_ENGINE_DIR}/third_party/glad/include
    ${ZCSR_UIM_DIR}/include
    ${ZCSR_UIM_DIR}/integrations/zcsr
    ${ZCSR_RUNTIME_DIR}/zcsr_runtime_shell/include)
target_link_libraries(editor_key_contract_test PRIVATE
    zcsr_imgui
    zcsr_editor_kernel
    zcsr_runtime_shell
    zcsr_uim_project
    zcsr_uim_page_view
    zcsr_uim
    zcsr_uim_zcsr_bridge
    zcsr_ui
    zcsr_glrender
    zcsr_platform
    zcsr_core
    zcsr_font
    zcsr_atlas
    zcsr_image
    zcsr_input
    zcsr_inputext
    zcsr_camera
    zcsr_camera3d
    zcsr_sprite
    zcsr_signal
    zcsr_assets
    zcsr_collision
    zcsr_save
    zcsr_viewport
    zcsr_file_service)
if(WIN32)
  target_link_libraries(editor_key_contract_test PRIVATE user32 gdi32 opengl32 comdlg32 imm32)
endif()
if(MSVC)
  target_compile_options(editor_key_contract_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_key_contract COMMAND editor_key_contract_test)
set_tests_properties(editor_key_contract PROPERTIES TIMEOUT 30
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

# Standalone package player lives in zcsr_runtime/player and is built by the
# runtime repository. The editor only copies that executable during packaging.
# It deliberately does not compile editor_app.cpp/ImGui/EditorKernel/page_manager.

# Editor-native tests. These cover the project format and package builder,
# not just the UIM libraries pulled in through add_subdirectory().
add_executable(editor_project_test
    tests/test_ui_editor_project.c)
target_include_directories(editor_project_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(editor_project_test PRIVATE zcsr_uim_project)
if(MSVC)
  target_compile_options(editor_project_test PRIVATE /experimental:c11atomics)
endif()
# Page runtime (document-level play loop) tests: Motion tick, pause/step,
# snapshot restore, and the registry-driven Motion descriptor.
add_executable(page_runtime_test
    tests/test_page_runtime.c)
target_include_directories(page_runtime_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${ZCSR_ENGINE_INCLUDE}
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(page_runtime_test PRIVATE zcsr_uim)
if(MSVC)
  target_compile_options(page_runtime_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_page_runtime COMMAND page_runtime_test)

# Runtime snapshot v2: full node/component restore + 3D projected pick.
add_executable(runtime_state_test
    tests/test_runtime_state.c)
target_include_directories(runtime_state_test PRIVATE
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(runtime_state_test PRIVATE zcsr_uim)
if(MSVC)
  target_compile_options(runtime_state_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_runtime_state COMMAND runtime_state_test)

add_test(NAME editor_project_roundtrip COMMAND editor_project_test roundtrip)
add_test(NAME editor_project_package COMMAND editor_project_test package)
add_test(NAME editor_project_v2 COMMAND editor_project_test v2)
add_test(NAME editor_project_legacy COMMAND editor_project_test legacy)

# Debt guards: source ownership and direct-GL growth. Both report the current
# baseline; they fail only when the debt grows or a source is orphaned.
add_test(NAME editor_sources_built
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_sources_built.cmake)
add_test(NAME editor_gl_debt_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_gl_debt.cmake)

# Duplicate-owner freeze: prevents a second window loop, shell instance, or undo
# history from being added while the product is being migrated module-by-module.
add_test(NAME editor_single_owner_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_single_owner.cmake)

# P3 behavior gate: the model is not merely compilable; selection, move,
# atomic gesture undo, delete/duplicate and history must actually work.
add_executable(editor_model_test
    tests/test_editor_model.c)
target_link_libraries(editor_model_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_model COMMAND editor_model_test)
