cmake_minimum_required(VERSION 3.16)

# --- Hard guard: the build tree must live OUTSIDE the source tree ------------
# ZCSR repositories (and their Linux checkouts)
# must stay free of build output: no in-source builds, no in-repo build/ or
# build-*/ directories, no scratch CMakeCache.txt. This is enforced here at
# configure time so a stale command line cannot silently re-pollute the tree.
#
# Guard interval: CMAKE_BINARY_DIR == CMAKE_SOURCE_DIR, or CMAKE_BINARY_DIR is
# located underneath CMAKE_SOURCE_DIR. Comparison is case-insensitive on
# Windows (paths there are case-insensitive) and separator-aware, so a sibling
# directory whose name merely starts with the source path is still allowed.
if(CMAKE_BINARY_DIR)
  # Normalise to forward slashes first (file(TO_CMAKE_PATH) exists since 3.16,
  # unlike cmake_path, which would raise the minimum CMake version).
  file(TO_CMAKE_PATH "${CMAKE_SOURCE_DIR}" _zcsr_guard_src)
  file(TO_CMAKE_PATH "${CMAKE_BINARY_DIR}" _zcsr_guard_bin)
  if(WIN32)
    string(TOLOWER "${_zcsr_guard_src}" _zcsr_guard_src_cmp)
    string(TOLOWER "${_zcsr_guard_bin}" _zcsr_guard_bin_cmp)
  else()
    set(_zcsr_guard_src_cmp "${_zcsr_guard_src}")
    set(_zcsr_guard_bin_cmp "${_zcsr_guard_bin}")
  endif()
  string(LENGTH "${_zcsr_guard_src_cmp}" _zcsr_guard_src_len)
  string(SUBSTRING "${_zcsr_guard_bin_cmp}" 0 ${_zcsr_guard_src_len}
         _zcsr_guard_bin_head)
  set(_zcsr_guard_in_repo FALSE)
  if(_zcsr_guard_bin_cmp STREQUAL _zcsr_guard_src_cmp)
    set(_zcsr_guard_in_repo TRUE)
  elseif(_zcsr_guard_bin_head STREQUAL _zcsr_guard_src_cmp)
    string(SUBSTRING "${_zcsr_guard_bin_cmp}" ${_zcsr_guard_src_len} 1
           _zcsr_guard_sep)
    if(_zcsr_guard_sep STREQUAL "/" OR _zcsr_guard_sep STREQUAL "\\")
      set(_zcsr_guard_in_repo TRUE)
    endif()
  endif()
  if(_zcsr_guard_in_repo)
    get_filename_component(_zcsr_repo_name "${CMAKE_CURRENT_SOURCE_DIR}" NAME)
    get_filename_component(_zcsr_default_build_root
      "${CMAKE_CURRENT_SOURCE_DIR}/../../build" ABSOLUTE)
    message(FATAL_ERROR
      "In-repo build directory refused by ZCSR build-layout guard.\n"
      "  CMAKE_SOURCE_DIR = ${CMAKE_SOURCE_DIR}\n"
      "  CMAKE_BINARY_DIR = ${CMAKE_BINARY_DIR}\n"
      "\n"
      "Build trees must live outside the source tree; the checkout must stay clean.\n"
      "Use any absolute out-of-tree build directory. The portable default is:\n"
      "  ${_zcsr_default_build_root}/zcsr/${_zcsr_repo_name}/<preset>\n"
      "\n"
      "Example:\n"
      "  cmake -S . -B \"${_zcsr_default_build_root}/zcsr/${_zcsr_repo_name}/win-msvc\"\n"
      "  cmake -S . -B \"${_zcsr_default_build_root}/zcsr/${_zcsr_repo_name}/linux-gcc\"\n"
      "\n"
      "Pass -B explicitly (or set ZCSR_BUILD_ROOT in your own wrapper) to use\n"
      "another out-of-tree root.\n")
  endif()
  unset(_zcsr_repo_name)
  unset(_zcsr_default_build_root)
  unset(_zcsr_guard_src)
  unset(_zcsr_guard_bin)
  unset(_zcsr_guard_src_cmp)
  unset(_zcsr_guard_bin_cmp)
  unset(_zcsr_guard_src_len)
  unset(_zcsr_guard_bin_head)
  unset(_zcsr_guard_sep)
  unset(_zcsr_guard_in_repo)
endif()

project(zcsr_editor VERSION 1.0.0 LANGUAGES C CXX)
include(GNUInstallDirs)
include(CMakePackageConfigHelpers)
if(APPLE)
  enable_language(OBJC)
endif()

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(MSVC)
  add_compile_options(/utf-8)
endif()

# Editor is an independent authoring product. It consumes engine/runtime/UIM
# targets; it does not compile engine or UIM sources into its own target.
# Project IO and player runtime live in UIM/runtime, never in this repo.
set(ZCSR_ENGINE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../zero-coupling-signal-router" CACHE PATH "zcsr engine repo")
set(ZCSR_UIM_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../UIM" CACHE PATH "UIM repo")
set(ZCSR_RUNTIME_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../zcsr_runtime" CACHE PATH "zcsr_runtime repo")

set(ZCSR_ENGINE_INCLUDE "${ZCSR_ENGINE_DIR}/include" CACHE PATH "" FORCE)
set(ZCSR_RUNTIME_INCLUDE "${ZCSR_RUNTIME_DIR}/zcsr_runtime_shell/include" CACHE PATH "" FORCE)

enable_testing()
# Editor itself never links the setting page manager; the legacy page-manager
# target is kept in this combined build only for its contract test target.
set(ZCSR_UIM_WITH_PAGE_MANAGER ON CACHE BOOL "Build the legacy setting page manager target" FORCE)
add_subdirectory(${ZCSR_RUNTIME_DIR} "${CMAKE_CURRENT_BINARY_DIR}/zcsr_runtime")


# Editor-only chrome. Dear ImGui (docking branch) is vendored under third_party
# and deliberately not linked by any player/runtime target.
add_library(zcsr_imgui STATIC
    third_party/imgui/imgui.cpp
    third_party/imgui/imgui_draw.cpp
    third_party/imgui/imgui_tables.cpp
    third_party/imgui/imgui_widgets.cpp
    third_party/imgui/backends/imgui_impl_opengl3.cpp)
target_include_directories(zcsr_imgui PUBLIC
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/backends)
if(WIN32)
  target_link_libraries(zcsr_imgui PUBLIC opengl32)
elseif(APPLE)
  find_library(ZCSR_OPENGL_FRAMEWORK OpenGL)
  if(NOT ZCSR_OPENGL_FRAMEWORK)
    message(FATAL_ERROR "OpenGL framework not found — required for the macOS editor.")
  endif()
  target_link_libraries(zcsr_imgui PUBLIC ${ZCSR_OPENGL_FRAMEWORK})
elseif(UNIX)
  find_package(OpenGL REQUIRED)
  target_link_libraries(zcsr_imgui PUBLIC OpenGL::GL ${CMAKE_DL_LIBS})
endif()

if(WIN32)
  add_library(zcsr_editor_host STATIC src/editor_host_win32.c)
elseif(APPLE)
  add_library(zcsr_editor_host STATIC
      src/editor_host_posix.c
      src/editor_host_cocoa.m)
else()
  add_library(zcsr_editor_host STATIC src/editor_host_posix.c)
endif()
target_include_directories(zcsr_editor_host PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
    $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>)
target_link_libraries(zcsr_editor_host PUBLIC zcsr_platform)
if(APPLE)
  find_library(ZCSR_COCOA_FRAMEWORK Cocoa)
  if(NOT ZCSR_COCOA_FRAMEWORK)
    message(FATAL_ERROR "Cocoa framework not found — required for native macOS file dialogs.")
  endif()
  target_link_libraries(zcsr_editor_host PUBLIC ${ZCSR_COCOA_FRAMEWORK})
endif()

# Renderer-neutral C11 editor domain. No Dear ImGui, no zcsr_scene model, no
# GL context, no OS window. This is the target a C11 host (e.g. the PVZ
# editor) links directly; see docs/INTEGRATION_API.md.
add_library(zcsr_editor_domain STATIC
    src/editor_domain.c
    src/ui_editor.c
    src/ui_hierarchy.c
    src/ui_editor_interaction.c
    src/ui_editor_workspace.c
    src/ui_editor_shell.c
    src/ui_editor_shell_renderer.c
    src/ui_editor_shell_persist.c
    src/ui_editor_viewport_host.c
    src/ui_project_browser.c)
target_include_directories(zcsr_editor_domain PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
    $<BUILD_INTERFACE:${ZCSR_UIM_DIR}/include>
    $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>)
target_link_libraries(zcsr_editor_domain PUBLIC zcsr_uim zcsr_uim_project)
if(UNIX AND NOT APPLE)
  # ui_editor.c uses fminf/fmaxf/roundf; libm is not implicit for C consumers.
  target_link_libraries(zcsr_editor_domain PUBLIC m)
endif()
if(MSVC)
  target_compile_options(zcsr_editor_domain PRIVATE /experimental:c11atomics)
endif()

# Full editor kernel: neutral domain + scene-bound authoring/IO/prefab/history,
# the project container codec and the engine file-service bridge. The existing
# app and headless tests keep linking this target; its public surface is
# unchanged.
add_library(zcsr_editor_kernel STATIC
    src/editor_scene_io.c
    src/editor_scene_authoring.c
    src/editor_scene_prefab.c
    src/editor_scene_history.c
    src/editor_project_container.c
    src/ui_editor_file_service_host.c)
target_include_directories(zcsr_editor_kernel PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
    $<BUILD_INTERFACE:${ZCSR_ENGINE_INCLUDE}>
    $<BUILD_INTERFACE:${ZCSR_UIM_DIR}/include>
    $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>)
target_link_libraries(zcsr_editor_kernel PUBLIC
    zcsr_editor_domain
    zcsr_uim
    zcsr_scene
    zcsr_scene_io
    zcsr_file_service)
target_link_libraries(zcsr_editor_kernel PRIVATE zcsr_uim_project)
if(MSVC)
  target_compile_options(zcsr_editor_kernel PRIVATE /experimental:c11atomics)
endif()

add_executable(zcsr_editor
    backends/zcsr/host_main.c
    src/editor_app.cpp)

target_include_directories(zcsr_editor PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/backends/zcsr
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/backends
    ${ZCSR_ENGINE_DIR}/include
    ${ZCSR_UIM_DIR}/include
    ${ZCSR_UIM_DIR}/integrations/zcsr
    ${ZCSR_RUNTIME_DIR}/zcsr_runtime_shell/include)

# Run uses the same CMake build that produced the editor. No packaging step
# and no "open project file" step is on the Run path.
set(ZCSR_RUN_TARGET "zcsr_player" CACHE STRING "CMake target built by editor Run")
if(WIN32)
  set(ZCSR_RUN_EXE "zcsr_player.exe" CACHE STRING "Executable launched by editor Run")
  set(ZCSR_RUN_CONFIG_DIR "Debug" CACHE STRING "CMake configuration directory used by editor Run")
else()
  set(ZCSR_RUN_EXE "zcsr_player" CACHE STRING "Executable launched by editor Run")
  set(ZCSR_RUN_CONFIG_DIR "" CACHE STRING "CMake configuration directory used by editor Run")
endif()
target_compile_definitions(zcsr_editor PRIVATE
    ZCSR_EDITOR_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}"
    ZCSR_EDITOR_BINARY_DIR="${CMAKE_CURRENT_BINARY_DIR}"
    ZCSR_CMAKE_COMMAND="${CMAKE_COMMAND}"
    ZCSR_RUN_TARGET="${ZCSR_RUN_TARGET}"
    ZCSR_RUN_EXE="${ZCSR_RUN_EXE}"
    ZCSR_RUN_CONFIG_DIR="${ZCSR_RUN_CONFIG_DIR}")

if(MSVC)
  target_compile_options(zcsr_editor PRIVATE /experimental:c11atomics)
endif()

target_link_libraries(zcsr_editor PRIVATE
    zcsr_imgui
    zcsr_editor_host
    zcsr_editor_kernel
    zcsr_runtime_shell
    zcsr_uim_project
    zcsr_uim_page_view
    zcsr_uim
    zcsr_uim_zcsr_bridge
    zcsr_ui
    zcsr_glrender
    zcsr_platform
    zcsr_core
    zcsr_font
    zcsr_atlas
    zcsr_image
    zcsr_input
    zcsr_inputext
    zcsr_camera
    zcsr_camera3d
    zcsr_scene_camera
    zcsr_scene
    zcsr_scene_render
    zcsr_sprite
    zcsr_signal
    zcsr_assets
    zcsr_collision
    zcsr_save
    zcsr_viewport
    zcsr_file_service)

if(WIN32)
  target_link_libraries(zcsr_editor PRIVATE user32 gdi32 opengl32 comdlg32 imm32)
endif()

# Real keyboard contract: drives editor_app.cpp's input + shortcut path with
# ZCSR_KEY_* values, not a headless mapping table.
add_executable(editor_key_contract_test
    tests/test_editor_key_contract.cpp
    src/editor_app.cpp)
target_compile_definitions(editor_key_contract_test PRIVATE ZCSR_EDITOR_KEY_TEST=1)
target_include_directories(editor_key_contract_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/backends/zcsr
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/backends
    ${ZCSR_ENGINE_DIR}/include
    ${ZCSR_UIM_DIR}/include
    ${ZCSR_UIM_DIR}/integrations/zcsr
    ${ZCSR_RUNTIME_DIR}/zcsr_runtime_shell/include)
target_link_libraries(editor_key_contract_test PRIVATE
    zcsr_imgui
    zcsr_editor_host
    zcsr_editor_kernel
    zcsr_runtime_shell
    zcsr_uim_project
    zcsr_uim_page_view
    zcsr_uim
    zcsr_uim_zcsr_bridge
    zcsr_ui
    zcsr_glrender
    zcsr_platform
    zcsr_core
    zcsr_font
    zcsr_atlas
    zcsr_image
    zcsr_input
    zcsr_inputext
    zcsr_camera
    zcsr_camera3d
    zcsr_scene_camera
    zcsr_scene
    zcsr_scene_render
    zcsr_sprite
    zcsr_signal
    zcsr_assets
    zcsr_collision
    zcsr_save
    zcsr_viewport
    zcsr_file_service)
if(WIN32)
  target_link_libraries(editor_key_contract_test PRIVATE user32 gdi32 opengl32 comdlg32 imm32)
endif()
if(MSVC)
  target_compile_options(editor_key_contract_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_key_contract COMMAND editor_key_contract_test)
set_tests_properties(editor_key_contract PROPERTIES TIMEOUT 30
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

# CLI contract: --autoquit must not override an explicit --smoke-frames.
# The GUI smoke needs a real display, so it is opt-in on Linux. Windows always
# registers it; macOS and Linux Xvfb runs pass -DZCSR_EDITOR_REGISTER_SMOKE_TEST=ON.
option(ZCSR_EDITOR_REGISTER_SMOKE_TEST
       "Register the editor GUI smoke test (requires a display)" OFF)
if(WIN32)
  set(ZCSR_EDITOR_REGISTER_SMOKE_TEST ON)
endif()
if(ZCSR_EDITOR_REGISTER_SMOKE_TEST)
  add_test(NAME editor_smoke_30
      COMMAND zcsr_editor --smoke-frames 30 --autoquit)
  set_tests_properties(editor_smoke_30 PROPERTIES
      TIMEOUT 20
      PASS_REGULAR_EXPRESSION "requested exit after 30 frames"
      WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})
endif()

# Standalone package player lives in zcsr_runtime/player and is built by the
# runtime repository. The editor only copies that executable during packaging.
# It deliberately does not compile editor_app.cpp/ImGui/EditorKernel/page_manager.

# Headless platform-boundary contract: executable path + process capture.
add_executable(editor_host_test tests/test_editor_host.c)
target_link_libraries(editor_host_test PRIVATE zcsr_editor_host)
if(WIN32)
  target_link_libraries(editor_host_test PRIVATE user32 comdlg32)
endif()
add_test(NAME editor_host COMMAND editor_host_test)

# Editor-native tests. These cover the project format and package builder,
# not just the UIM libraries pulled in through add_subdirectory().
add_executable(editor_project_test
    tests/test_ui_editor_project.c)
target_include_directories(editor_project_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(editor_project_test PRIVATE zcsr_uim_project)
if(MSVC)
  target_compile_options(editor_project_test PRIVATE /experimental:c11atomics)
endif()
# Page runtime (document-level play loop) tests: Motion tick, pause/step,
# snapshot restore, and the registry-driven Motion descriptor.
add_executable(page_runtime_test
    tests/test_page_runtime.c)
target_include_directories(page_runtime_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${ZCSR_ENGINE_INCLUDE}
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(page_runtime_test PRIVATE zcsr_uim)
if(MSVC)
  target_compile_options(page_runtime_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_page_runtime COMMAND page_runtime_test)

# Runtime snapshot v2: full node/component restore + 3D projected pick.
add_executable(runtime_state_test
    tests/test_runtime_state.c)
target_include_directories(runtime_state_test PRIVATE
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(runtime_state_test PRIVATE zcsr_uim)
if(MSVC)
  target_compile_options(runtime_state_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_runtime_state COMMAND runtime_state_test)

add_test(NAME editor_project_roundtrip COMMAND editor_project_test roundtrip)
add_test(NAME editor_project_package COMMAND editor_project_test package)
add_test(NAME editor_project_v2 COMMAND editor_project_test v2)
add_test(NAME editor_project_legacy COMMAND editor_project_test legacy)

# Debt guards: source ownership and direct-GL growth. Both report the current
# baseline; they fail only when the debt grows or a source is orphaned.
add_test(NAME editor_sources_built
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_sources_built.cmake)
add_test(NAME editor_gl_debt_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_gl_debt.cmake)
# Platform boundary guard: product code must not include Win32/GL headers,
# cast native handles, or index its own Win32 dialog/process/timer implementations.
add_test(NAME editor_platform_owner_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_platform_owner.cmake)

# Duplicate-owner freeze: prevents a second window loop, shell instance, or undo
# history from being added while the product is being migrated module-by-module.
add_test(NAME editor_single_owner_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_single_owner.cmake)

# P3 behavior gate: the model is not merely compilable; selection, move,
# atomic gesture undo, delete/duplicate and history must actually work.
add_executable(editor_model_test
    tests/test_editor_model.c)
target_link_libraries(editor_model_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_model COMMAND editor_model_test)

# Scene text format is owned by C11 editor_scene_io.c, not editor_app.cpp.
# This test is headless and covers save/load roundtrip, transactionality and
# malformed-record rejection without opening a window or running the suite.
add_executable(editor_scene_io_test
    tests/test_editor_scene_io.c)
target_link_libraries(editor_scene_io_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_scene_io COMMAND editor_scene_io_test)
set_tests_properties(editor_scene_io PROPERTIES TIMEOUT 15
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(editor_shell_domains_test
    tests/test_editor_shell_domains.c)
target_include_directories(editor_shell_domains_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${ZCSR_ENGINE_INCLUDE}
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(editor_shell_domains_test PRIVATE zcsr_editor_kernel)
if(MSVC)
  target_compile_options(editor_shell_domains_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_shell_domains COMMAND editor_shell_domains_test)
set_tests_properties(editor_shell_domains PROPERTIES TIMEOUT 20)

add_test(NAME editor_scene_io_owner_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_scene_io_owner.cmake)

# Scene mutations are C11 authoring commands, not inline ImGui callbacks.
# This test is headless: add, duplicate, delete, move and quad corner edits.
add_executable(editor_scene_authoring_test
    tests/test_editor_scene_authoring.c)
target_link_libraries(editor_scene_authoring_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_scene_authoring COMMAND editor_scene_authoring_test)
set_tests_properties(editor_scene_authoring PROPERTIES TIMEOUT 15
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_test(NAME editor_scene_authoring_owner_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_scene_authoring_owner.cmake)

add_executable(editor_scene_prefab_test
    tests/test_editor_scene_prefab.c)
target_link_libraries(editor_scene_prefab_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_scene_prefab COMMAND editor_scene_prefab_test)
set_tests_properties(editor_scene_prefab PROPERTIES TIMEOUT 15
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(editor_scene_history_test
    tests/test_editor_scene_history.c)
target_link_libraries(editor_scene_history_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_scene_history COMMAND editor_scene_history_test)
set_tests_properties(editor_scene_history PROPERTIES TIMEOUT 15
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(editor_domains_test
    tests/test_editor_domains.c)
target_link_libraries(editor_domains_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_domains COMMAND editor_domains_test)
set_tests_properties(editor_domains PROPERTIES TIMEOUT 15
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

# Headless reference host for the renderer-neutral domain. Links only
# zcsr_editor_domain: no kernel scene sources, no host layer, no ImGui/GL.
add_executable(editor_domain_provider_test
    tests/test_editor_domain_provider.c)
target_include_directories(editor_domain_provider_test PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${ZCSR_UIM_DIR}/include)
target_link_libraries(editor_domain_provider_test PRIVATE zcsr_editor_domain)
if(MSVC)
  target_compile_options(editor_domain_provider_test PRIVATE /experimental:c11atomics)
endif()
add_test(NAME editor_domain_provider COMMAND editor_domain_provider_test)
set_tests_properties(editor_domain_provider PROPERTIES TIMEOUT 15
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(editor_project_container_test
    tests/test_editor_project_container.c)
target_link_libraries(editor_project_container_test PRIVATE zcsr_editor_kernel)
add_test(NAME editor_project_container COMMAND editor_project_container_test)
set_tests_properties(editor_project_container PROPERTIES TIMEOUT 15
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

# C++ is still present in editor_app.cpp (Dear ImGui chrome). This guard only
# freezes that surface; it must not be read as "C11 conversion complete".
add_test(NAME editor_cxx_surface_guard
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/check_editor_cxx_surface.cmake)

# Editor tests live in this directory, so their module label is local.
set(ZCSR_EDITOR_TESTS
    editor_key_contract editor_host editor_page_runtime editor_runtime_state
    editor_project_roundtrip editor_project_package editor_project_v2
    editor_project_legacy editor_sources_built editor_gl_debt_guard
    editor_platform_owner_guard editor_single_owner_guard editor_model
    editor_scene_io editor_shell_domains editor_scene_io_owner_guard
    editor_scene_authoring editor_scene_authoring_owner_guard
    editor_scene_history editor_domains editor_project_container
    editor_domain_provider
    editor_cxx_surface_guard)
set_tests_properties(${ZCSR_EDITOR_TESTS} PROPERTIES
    LABELS "module;editor;fast")

# --- Install / export package -------------------------------------------------
# Consumers get the C11 editor domains (kernel/host) and the editor executable.
# The ImGui static library remains an editor-internal implementation detail.
install(TARGETS zcsr_editor_domain zcsr_editor_kernel zcsr_editor_host
  EXPORT zcsr_editorTargets
  ARCHIVE DESTINATION ${CMAKE_INSTALL_LIBDIR}
  LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
  RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
  INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR})
install(TARGETS zcsr_editor RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR})
install(DIRECTORY include/ DESTINATION ${CMAKE_INSTALL_INCLUDEDIR})
install(EXPORT zcsr_editorTargets
  FILE zcsr_editorTargets.cmake
  NAMESPACE zcsr::
  DESTINATION ${CMAKE_INSTALL_LIBDIR}/cmake/zcsr_editor)
configure_package_config_file(
  ${CMAKE_CURRENT_SOURCE_DIR}/cmake/zcsr_editorConfig.cmake.in
  ${CMAKE_CURRENT_BINARY_DIR}/zcsr_editorConfig.cmake
  INSTALL_DESTINATION ${CMAKE_INSTALL_LIBDIR}/cmake/zcsr_editor)
write_basic_package_version_file(
  ${CMAKE_CURRENT_BINARY_DIR}/zcsr_editorConfigVersion.cmake
  VERSION ${PROJECT_VERSION}
  COMPATIBILITY SameMajorVersion)
install(FILES
  ${CMAKE_CURRENT_BINARY_DIR}/zcsr_editorConfig.cmake
  ${CMAKE_CURRENT_BINARY_DIR}/zcsr_editorConfigVersion.cmake
  DESTINATION ${CMAKE_INSTALL_LIBDIR}/cmake/zcsr_editor)
