# Editor parity / 必备功能口径

日期：2026-11-25
口径：数据、格式、命令和校验在 C11；`editor_app.cpp` 只做一层可被第三方以 C++ 消费的 ImGui chrome。运行路径固定为 CMake 构建 + 启动，不做自研打包。

## 已接通

- Project / Assets：C11 目录树、刷新、新建/重命名/删除；资产导入到 `assets/`、`.uirassets` 注册表、移除注册；资产列表拖拽 `zcsr_asset`。
- Scene 资产：Kind / prefab id / asset id Inspector；拖入场景生成 sprite 或实例化 `.uiscene` prefab；选中实体保存为 prefab 并注册。
- Prefab：普通 `.uiscene` + 路径 FNV-1a `prefab_id`；C11 保存单实体、加载并按根位置实例化、失败回滚。
- Game：独立窗口，Fit/1280x720/1920x1080/960x540，FPS/帧时间/模式统计；Play 自动打开；Window 菜单与工具栏可切换。
- Gizmo：UI/Scene 的 Move/Rotate/Scale；World/Local；Snap；场景 Y 轴改高度、X/Z 走地面。
- 节点：Copy/Paste 子树；sibling 上移/下移；Duplicate。
- 多选 Inspector：节点列表、group move、Apply to all、Delete selected。
- Console：过滤、清空、匹配计数；Hierarchy/Project 搜索过滤。
- Preferences：网格尺寸/显示/吸附/缩放步长、gizmo 吸附与步长、自动保存秒数；自动保存只对已有路径生效。
- Property Drawer：长字符串/list 用换行分隔的多行编辑；Trigger/Selector/Effect 枚举标签；现有数值/布尔/向量/资产选择。
- 文本字段：单击定位、拖拽选区、Shift+方向、Home/End、双击选词、字段内 undo/redo、多行上下导航、平台 IME 锚点。
- Play：Pause / Resume / Step / Stop；Step 先暂停再 `uim_runtime_step`。

## 验证

- editor Release CTest：44/44。
- UIM：13/13（含 C++20 / C++14 consumer）；engine：67 注册 / 66 通过 + 1 跳过（`audio_switch` 硬件依赖）；runtime：16/16；tools：13/13。
- 五个主仓合计：152 通过 + 1 跳过 / 0 失败；RTS 已归档，不纳入本轮。
- `zcsr_editor --smoke-frames 30 --autoquit` 输出 30 帧，退出码 0；已固化为 `editor_smoke_30` CTest。
- C++ 守卫通过；精确行数以守卫输出为准。

## 边界（不是缺陷清单）

- Game 是 ImGui 相机投影/贴图窗口，不是独立 FBO / runtime render texture。
- Prefab 不做覆盖、变体、独立编辑模式；资产不做缩略图/音频试听。
- Inspector 的 list 仍是 UIM string，不是第二套数组存储类型。
- Preferences 目前是会话内存设置，不跨进程持久化；自动保存未命名文档会跳过。
- 场景 gizmo 的屏幕空间手柄仍是最小实现，不做 Unity 式多手柄布局。

## 明确不做（架构规则）

- Build Settings / 自研打包 / 平台导出流水线。Run 只走 CMake Debug build + `zcsr_player`；`editor_project_package` 仅保留为 UIM 包格式回归测试。
- 新增第二个 C++ 产品核心。C++ 只作为 chrome / 第三方消费层；新增数据、格式、命令、校验必须进 C11。
